# 常熟站智考通 v2.3 — 验收记录（静默崩溃根因修复版）

> 程序名：常熟站智考通，版本 v2.3。v2.2 是启动双路径版（新增 `启动智考通.bat` 与
> 启动器直启）；v2.3 是静默崩溃根因修复版，相对 v2.2 其余功能不变。
> mvp-v07 与 mvp-zhikaotong-v1 原样保留，未动；v2.0、v2.1、v2.2 的 zip 与文件也在同一
> 目录下并存，未动。验收日期：2026-11-06。

## 一、根因与修复原理（v2.3 改了什么）

### 根因

`pythonw.exe` 没有控制台，启动时 `sys.stdout` / `sys.stderr` 都是 `None`。
任何 `print()` / `sys.stdout.write()` / `sys.stderr.write()` 都会抛
`AttributeError`（`'NoneType' object has no attribute 'write'`）。

崩溃链（v2.2 代码上复现，见第三节阴性对照）：

1. 服务器线程跑 `server.main()` 时第 1243–1244 行的 `print("listening...")` 立即崩掉，
   端口起不来；
2. `ensure_embedded_server` 返回 `False`；
3. `_main()` 第 422 行的 `sys.stderr.write` 警告再崩一次；
4. v2.0 没有启动兜底，traceback 打不出来，所以静默退出、任务管理器里没有进程；
   v2.2 的兜底（写 `error.log` + 弹框）把它抓出来弹框，根因这才现形。
   同类隐患还有 `server.py` 第 83 行附近每次 HTTP 请求的日志写 `stderr`，
   以及 `main.py` 第 105/112 行。

### 修复（代码部分，v2.3 发布前已完成并验证，本次只做版本、打包、上架）

在 `exe/app/main.py`、`exe/app/server/server.py`、`web/server.py` 三个文件里加了
`_ensure_stdio()`（模块加载时立即调用）+ 纵深防御 `try/except`：

- `_ensure_stdio` 逻辑：只有 `sys.stdout` 或 `sys.stderr` 是 `None` 时才处理；
  先接到 exe 根目录的 `zhikaotong.log`（`main.py` 用 `__file__` 上两级推算，
  `server.py` 用 `__file__` 上三级推算；`open(..., "a", encoding="utf-8", buffering=1)`
  行缓冲，日志立即落盘）；打不开则接 `open(os.devnull, "w")`；再打不开静默跳过；
  全程 `try/except`，绝不抛异常；stdio 本来正常时原样不动。
- `main.py`：`_ensure_stdio` 在 `import os/sys/traceback` 之后、`HERE` 定义之前；
  三处 `sys.stderr.write`（embedded server import failed / embedded server stopped /
  embedded server did not start 警告）各包了 `try/except`。
  `_report_startup_error` 里第 65 行已有 `try/except`，未动。
- `server.py`（web/ 与 exe/app/server/ 两份完全一致）：`_ensure_stdio` 在标准库
  import 之后、`import db` 之前；`log_message`（第 83 行附近）包了 `try/except`。
  `server.main()` 里第 1243–1244 行的 `print` 未动（靠 `_ensure_stdio` 接管 stdio
  后不再崩）。
- `web/server.py` 与 `exe/app/server/server.py` 保持逐文件一致
  （除 web 独有的 README.md/data/start.bat/start.sh）。

效果：pythonw 下启动过程的日志写进 exe 根目录的 `zhikaotong.log`
（启动失败时先看它，再看 `error.log`）；控制台 `python.exe` 下（debug.bat）
stdio 正常，原样不动，输出不受影响，不产生 `zhikaotong.log`。

## 二、v2.3 改了什么（相对 v2.2）

| # | 改动 | 位置 |
| --- | --- | --- |
| 1 | 上述 `_ensure_stdio` 根因修复 + 各处未保护写操作的 `try/except` 纵深防御（代码部分发布前已完成，本次未改动修复逻辑；本次只改了 `main.py` / `server.py` 两份的文档头与 `server.py` 的 VERSION） | `exe/app/main.py`、`exe/app/server/server.py`、`web/server.py` |
| 2 | 版本号统一升到 v2.3：branding.json（exe/ 与 rebrand-tool/ 各一份）、server.py 两份的 VERSION、theme.py 的 VERSION/TITLE、app.js/lite.js 的 VERSION 与界面显示、db.py 的 app_version 默认值、federation.py 的 VERSION、seed.py 的初始题库版本（v2.3.0）、import_jobs 的新版本号（v2.3.x）、各产品 .py 文件首行文档字符串、product-intro.md、showcase.html（三份同步）、README（web/README.md 与 exe/README.txt）、web/start.bat、web/start.sh、exe/debug.bat 标题 | 全树 |
| 3 | product-intro.md 与 showcase.html（三份）加 v2.3 改动说明；exe/README.txt 末尾加“启动日志（v2.3 新增）”一节，说明 zhikaotong.log 在 exe 根目录、启动失败时先看它；showcase 的“exe 双击没反应？”FAQ 与已知限制加 zhikaotong.log 与“v2.3 修复未在真实 Windows 机上双击验证过”的说明 | 文档 |
| 4 | 打包注意：与 v2.2 相同，exe zip 与完整包里 `启动智考通.bat` 是中文文件名、按 GBK 编码写入 zip（不带 UTF-8 标志），Win7/Win10 中文系统自带解压能正常显示中文名；其余文件全部英文文件名。包里不含 error.log、zhikaotong.log 与 `__pycache__`（打包前已清掉） | 打包 |

其余功能（12 模块、刷题宝 15 项并入功能、改名工具、端口 8766、账号）与 v2.2 完全一致，未动。
启动器（`changshu-zhikaotong.exe`）与 `启动智考通.bat` 未改，仍是 v2.2 的。

### 版本号 v2.3（全树核对）

- `branding.json` 两份均为 v2.3；`server.py` 两份 VERSION 均为 v2.3；
  `theme.py` VERSION/TITLE 为 v2.3；`app.js` VERSION 为 v2.3；
  `lite.js` 版本比对为 v2.3；`db.py` app_version 默认值为 v2.3；
  `federation.py` VERSION 为 v2.3；`seed.py` 初始题库版本 v2.3.0；
  `import_jobs` 新版本号 v2.3.x；各产品 `.py` 首行文档字符串均为 v2.3；
  `rebrand.py` 两份的文档头与版本默认值均为 v2.3。
- 全树剩下的 v2.2 字样共 15 处，全部是有意的历史表述或排除位置，用户能看到的
  版本号已全部是 v2.3：
  - showcase.html（三份）第 317 行历史句“v2.1 新增启动诊断……；v2.2 新增 bat 启动
    与启动器直启”（后已追加 v2.3 分句）与第 505 行 FAQ“v2.2 起主用启动方式是……”；
  - `main.py` 第 30 行与 `server.py` 两份第 27 行 `_ensure_stdio` 文档字符串里
    “这正是 v2.0/v2.1 静默崩溃、v2.2 弹启动失败框的根因”（准确的历史陈述，未动）；
  - `exe/README.txt` 第 4 行“启动方法（v2.2 起主用 bat）”；
  - product-intro.md：“v2.2 改动”整段、“v2.3 改动……相对 v2.2 其余功能不变”、
    “v2.2 新增主用启动方式”、“v2.2 起启动器不再预检文件”、
    文件表里“主用启动脚本（GBK + CRLF，v2.2 新增）”。
  - 排除位置：`exe/python34/`（Python 标准库，未动）、`_build/`（构建脚本与
    v2.2 阴性对照，见第三节）、旧版 acceptance-*.md 与旧 zip（未动）。

## 三、验证结果（全部在最终 v2.3 代码上重跑）

验证脚本：`_build/verify_pyw.py`（本次的模拟 pythonw.exe 环境验证脚本：
import main/server 之前先把 `sys.stdout`/`sys.stderr` 置 `None`，再调
`ensure_embedded_server` 并请求 `/api/version` 与 `/`）。

### 1. 模拟 pythonw.exe 环境（`python3 _build/verify_pyw.py fixed`）：PASS

在最终 v2.3 代码上重跑，结果 PASS：

- `exceptions: NONE`；`ensure_embedded_server` 返回 `True`；
- `/api/version` 200，返回 `{"ok": true, "data": {"current_version": "v2.3",
  "app_name": "常熟站智考通", "latest": null}}`；
- `/` 200；
- `sys.stdout`/`sys.stderr` 在 import 后被接到临时目录的 `zhikaotong.log`
  （`TextIOWrapper`，`mode='a'`，`encoding='utf-8'`）；
- 日志头：`常熟站智考通 v2.3 listening on http://127.0.0.1:端口/`、
  `data: .../zhikaotong.db` 与三条请求日志（两次 `/api/version`、一次 `/`，
  均为 200）。

### 2. 阴性对照（`python3 _build/verify_pyw.py v22`，从 v2.2 完整包解出未修复代码）：FAIL

- `ensure_embedded_server` 返回 `False`，`/api/version` 连不上
  （`RemoteDisconnected`），stdio 仍为 `None`，无 `zhikaotong.log`。
- 证明该脚本确实能检出此 bug，修复是有效的。

### 3. 控制台 stdio 检查（正常 console 下 import web/server）：通过

- `sys.stdout`/`sys.stderr` 原样不动，不产生 `zhikaotong.log`
  （debug.bat 输出不受影响）；`VERSION` 为 v2.3。

### 4. 语法与兼容性

- 全部 70 个 .py（web/ + exe/app/ + rebrand.py 两份，排除 `__pycache__` 与
  python34/Lib）做 `ast.parse` 全过；AST 查 `JoinedStr`（f-string）与
  `NamedExpr`（walrus）节点，无真命中。
- `app.js` 与 `lite.js`（web/ 与 exe/app/server/ 各两份）做 `node --check` 全过。
- `web/` 与 `exe/app/server/` 除 web 独有的 README.md/data/start.bat/start.sh 外
  逐文件一致（`diff -r` 无差异）。
- 注意：本机已无 Python 3.8，语法检查用系统 Python 3.12 的 ast.parse；
  本次改动只涉及版本号字符串、文档与 `_ensure_stdio` 修复（发布前已验证），
  未改应用逻辑。

### 5. 网页版干净副本冒烟（从 v2.3 完整包解出，空闲端口，未占 8766）

- 根页 `/` 200、`/lite` 200、`showcase.html` 200；
- `/api/version` 返回 `current_version: v2.3`；
- 民警登录成功（POST `/api/auth/login`，`minjing` / `123456`）。

### 6. 打包

- `changshu-zhikaotong-v2.3-exe.zip`：exe/ 内容平铺打包，`unzip -t` 全过；
  内含 `启动智考通.bat`（中文名 GBK 编码，无 UTF-8 标志）、debug.bat、
  python34/python.exe 与 pythonw.exe。
- `changshu-zhikaotong-v2.3-web.zip`：web/ 内容平铺打包，`unzip -t` 全过。
- `changshu-zhikaotong-v2.3-full.zip`：顶层文件夹 `changshu-zhikaotong-v2.3/` +
  GBK README.txt + exe/ + web/ + product-intro.md + showcase.html +
  acceptance-v2.3.md，`unzip -t` 全过。
- 包里不含 error.log、zhikaotong.log 与 `__pycache__`（打包前已清掉）。
- 三个 zip 的字节数与 md5：

| zip | 字节数 | md5 |
| --- | --- | --- |
| `changshu-zhikaotong-v2.3-exe.zip` | 10,700,288 | 3e756eb92e21f397e2b02934d78c7523 |
| `changshu-zhikaotong-v2.3-web.zip` | 205,378 | 2ad5b3d31a59bf7683f1e3b6bab937a6 |
| `changshu-zhikaotong-v2.3-full.zip` | （见交付汇报；验收文档内不嵌完整包自身的 md5，避免自指） | — |

## 四、让用户做的事（启动步骤）

1. 从 GitHub 公开库下载 `changshu-zhikaotong-v2.3-full.zip`，完整解压（不要直接在压缩包里双击）。
2. 进解出来的 `changshu-zhikaotong-v2.3/exe/` 文件夹，双击 **`启动智考通.bat`**（推荐）。
   也可以双击 `changshu-zhikaotong.exe`，效果一样。
3. 如果 bat 也起不来：先看 exe 文件夹根目录的 **`zhikaotong.log`**（v2.3 新增，
   pythonw 下的启动过程日志），再看 `error.log`（启动失败兜底写的报错全文）；
   再双击 debug.bat，把黑色控制台窗口截图发回来；把 `zhikaotong.log` 与
   `error.log` 的全文发回来。

## 五、已知限制（没有验证过，不要当作已验证）

- **v2.3 的 stdio 修复未在真实 Windows 机上双击验证过**（只在 Linux 下模拟
  pythonw.exe 环境验证通过：stdio 置 None 后服务器能起来、/api/version 200、
  日志写进 zhikaotong.log）。最终仍需用户在真实 Win7/Win10 机上双击
  `启动智考通.bat` 确认。
- 32 位 exe 未在真实 Windows 机上双击验证过（只在 Linux 下验逻辑与编译），
  GUI 未在真实 Windows 上点按过；真实局域网多机与 150 并发未测；
  浏览器实测动效手感与减弱动效切换未做；真实导入样张（Excel/Word 各一份）未测。
- v2.0 的三个旧问题修复（部门对比精确汇总、计划进度去重计数、模板开考含简答题）
  沿用 v2.0/v2.1/v2.2 的验收结论，v2.3 未重测（v2.3 没改这些逻辑，只修 stdio
  与升版本标识）。

## 六、上架

- GitHub 公开库 GGBondIII/download-hub，`zhikaotong-v2.3/` 目录（完整包 zip +
  showcase.html + product-intro.md），总站 index.html 最上方加 v2.3 section，
  push 到 master 分支。提交号与三条直链实测结果见交付汇报。
