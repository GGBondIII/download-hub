# -*- coding: utf-8 -*-
"""常熟站智考通 v2.3 -- 自绘 logo。

按原版风格重绘(不要复制原版 logo.png):
藏青圆角方底 + 白色盾牌轮廓,内含金色飞机(上)、金色翻开的书(中)、
金色锚(右下)、金色虚线弧。纯 tkinter Canvas 绘制,无外部图片。
Python 3.4 兼容语法。
"""
from theme import NAVY, NAVY_DARK, GOLD


def draw_logo(canvas, x, y, size, navy=None, gold=None):
    """在 (x, y) 处画边长为 size 的 logo。返回占用的边框坐标。"""
    navy = navy or NAVY
    gold = gold or GOLD
    s = float(size)
    # 藏青圆角方底:矩形 + 四角圆片近似圆角
    r = s * 0.16
    canvas.create_rectangle(x + r, y, x + s - r, y + s, fill=navy,
                            outline=navy)
    canvas.create_rectangle(x, y + r, x + s, y + s - r, fill=navy,
                            outline=navy)
    for cx, cy in ((x + r, y + r), (x + s - r, y + r),
                   (x + r, y + s - r), (x + s - r, y + s - r)):
        canvas.create_oval(cx - r, cy - r, cx + r, cy + r, fill=navy,
                           outline=navy)
    # 白色盾牌轮廓
    cx = x + s * 0.50
    top = y + s * 0.12
    mid = y + s * 0.62
    bot = y + s * 0.88
    lw = s * 0.30
    pts = [cx - lw, top, cx + lw, top, cx + lw, mid,
           cx, bot, cx - lw, mid]
    canvas.create_polygon(pts, outline="#FFFFFF", fill="", width=max(2, s * 0.03))
    # 金色飞机(上):机身三角 + 机翼
    px, py = cx, y + s * 0.24
    canvas.create_polygon(px, py - s * 0.05, px + s * 0.045, py + s * 0.05,
                          px - s * 0.045, py + s * 0.05, fill=gold,
                          outline=gold)
    canvas.create_line(px - s * 0.10, py + s * 0.02, px + s * 0.10,
                       py + s * 0.02, fill=gold, width=max(2, s * 0.025))
    # 金色翻开的书(中):两页弧形
    bx, by = cx, y + s * 0.50
    canvas.create_arc(bx - s * 0.17, by - s * 0.07, bx, by + s * 0.07,
                      start=90, extent=180, outline=gold,
                      width=max(2, s * 0.03), style="arc")
    canvas.create_arc(bx, by - s * 0.07, bx + s * 0.17, by + s * 0.07,
                      start=270, extent=180, outline=gold,
                      width=max(2, s * 0.03), style="arc")
    canvas.create_line(bx, by - s * 0.06, bx, by + s * 0.06, fill=gold,
                       width=max(2, s * 0.025))
    # 金色锚(右下)
    ax, ay = cx + s * 0.13, y + s * 0.70
    canvas.create_oval(ax - s * 0.025, ay - s * 0.06, ax + s * 0.025,
                       ay - s * 0.01, outline=gold,
                       width=max(2, s * 0.025))
    canvas.create_line(ax, ay - s * 0.01, ax, ay + s * 0.07, fill=gold,
                       width=max(2, s * 0.025))
    canvas.create_arc(ax - s * 0.05, ay + s * 0.01, ax + s * 0.05,
                      ay + s * 0.09, start=180, extent=180, outline=gold,
                      width=max(2, s * 0.025), style="arc")
    # 金色虚线弧(盾牌外圈)
    canvas.create_arc(x + s * 0.08, y + s * 0.06, x + s * 0.92,
                      y + s * 0.94, start=200, extent=140, outline=gold,
                      width=max(1, s * 0.015), style="arc",
                      dash=(max(2, int(s * 0.03)), max(2, int(s * 0.02))))
    return (x, y, x + s, y + s)


def logo_canvas(parent, size, bg=None):
    """返回一个已画好 logo 的 Canvas。"""
    from tkinter import Canvas
    cv = Canvas(parent, width=size, height=size, highlightthickness=0,
                bg=bg or NAVY)
    draw_logo(cv, 2, 2, size - 4)
    return cv
