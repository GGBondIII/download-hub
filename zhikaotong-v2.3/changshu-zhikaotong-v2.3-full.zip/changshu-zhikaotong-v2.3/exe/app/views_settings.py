# -*- coding: utf-8 -*-
"""常熟站智考通 v2.3 -- 系统设置。

显示模式(全屏/窗口切换并记住)、字号标准/特大、选项乱序开关、
智能分析开关、修改密码、账号与服务器、客户端更新卡片。
Python 3.4 兼容语法,仅标准库。
"""
import threading

from tkinter import Frame, Label, StringVar
from tkinter.ttk import Button, Combobox, Entry

from theme import (NAVY, BG, CARD, TEXT, TEXT_MUTED, BORDER, VERSION, font)
from widgets import clear, banner
from api_client import ApiError


def build_settings(app, parent):
    clear(parent)
    app.page = "settings"
    app.set_space_handler(None)
    Label(parent, text="系统设置", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    _card(app, parent, "显示模式")
    row = Frame(parent, bg=CARD)
    row.pack(fill="x", padx=16)
    mode = "全屏" if app.config.get("fullscreen") else "窗口"
    Label(row, text="当前模式:{0}(默认全屏启动,F11 可随时切换)".format(mode),
          bg=CARD, fg=TEXT, font=font(row, 12)).pack(side="left", padx=14,
                                                     pady=8)
    Button(row, text="切换为窗口" if app.config.get("fullscreen") else "切换为全屏",
           style="Navy.TButton", command=lambda: _toggle_full(app, parent)
           ).pack(side="right", padx=14)
    _card(app, parent, "答题偏好")
    row = Frame(parent, bg=CARD)
    row.pack(fill="x", padx=16)
    Label(row, text="题干与选项字号", bg=CARD, fg=TEXT,
          font=font(row, 12)).pack(side="left", padx=14, pady=8)
    size_var = StringVar(value="特大" if app.config.get("font_size") == "large"
                         else "标准")
    Combobox(row, textvariable=size_var, values=["标准", "特大"], width=10,
             state="readonly").pack(side="left", padx=6)
    Button(row, text="保存字号", style="Ghost.TButton",
           command=lambda: _save_size(app, size_var)).pack(side="left", padx=6)
    row2 = Frame(parent, bg=CARD)
    row2.pack(fill="x", padx=16)
    Label(row2, text="练习与模拟考试中打乱选项顺序",
          bg=CARD, fg=TEXT, font=font(row2, 12)).pack(side="left", padx=14,
                                                      pady=8)
    sh_var = StringVar(value="开" if app.config.get("shuffle_options") else "关")
    Combobox(row2, textvariable=sh_var, values=["开", "关"], width=6,
             state="readonly").pack(side="left", padx=6)
    Button(row2, text="保存", style="Ghost.TButton",
           command=lambda: _save_toggle(app, "shuffle_options", sh_var)
           ).pack(side="left", padx=6)
    row3 = Frame(parent, bg=CARD)
    row3.pack(fill="x", padx=16)
    Label(row3, text="答错时显示本地智能分析", bg=CARD, fg=TEXT,
          font=font(row3, 12)).pack(side="left", padx=14, pady=8)
    sa_var = StringVar(value="开" if app.config.get("smart_analysis", True)
                       else "关")
    Combobox(row3, textvariable=sa_var, values=["开", "关"], width=6,
             state="readonly").pack(side="left", padx=6)
    Button(row3, text="保存", style="Ghost.TButton",
           command=lambda: _save_toggle(app, "smart_analysis", sa_var)
           ).pack(side="left", padx=6)
    Label(row3, text="保存后下次生效", bg=CARD, fg=TEXT_MUTED,
          font=font(row3, 11)).pack(side="left", padx=8)
    _card(app, parent, "修改密码")
    form = Frame(parent, bg=CARD)
    form.pack(fill="x", padx=16)
    old_var, new_var, cfm_var = StringVar(), StringVar(), StringVar()
    for label, var in (("当前密码", old_var), ("新密码(至少 6 位)", new_var),
                       ("确认新密码", cfm_var)):
        Label(form, text=label, bg=CARD, fg=TEXT,
              font=font(form, 12)).pack(anchor="w", padx=14, pady=(4, 0))
        Entry(form, textvariable=var, show="*", width=30,
              font=font(form, 12)).pack(anchor="w", padx=14, pady=2)
    msg = Label(form, text="", bg=CARD, fg="#16A34A", font=font(form, 12))
    msg.pack(anchor="w", padx=14, pady=4)

    def change_pw():
        if len(new_var.get()) < 6:
            msg.configure(text="新密码至少 6 位", fg="#DC2626")
            return
        if new_var.get() != cfm_var.get():
            msg.configure(text="两次输入不一致", fg="#DC2626")
            return
        try:
            app.api.post("/api/auth/change-password",
                         {"old_password": old_var.get(),
                          "new_password": new_var.get(),
                          "confirm_password": cfm_var.get()})
        except ApiError as e:
            msg.configure(text=e.message, fg="#DC2626")
            return
        msg.configure(text="密码修改成功,下次登录请使用新密码", fg="#16A34A")

    Button(form, text="修改密码", style="Navy.TButton",
           command=change_pw).pack(anchor="w", padx=14, pady=10)
    _card(app, parent, "账号与服务器")
    user = app.user or {}
    try:
        invite = ""
        if user.get("role") == "admin":
            invite = (app.api.get("/api/settings/invite-code") or {}
                      ).get("invite_code", "")
    except ApiError:
        invite = ""
    info = Frame(parent, bg=CARD)
    info.pack(fill="x", padx=16)
    for k, v in (("当前用户", "{0}({1})".format(user.get("name", ""),
                               user.get("username", ""))),
                 ("部门", user.get("department", "")),
                 ("角色", user.get("role_name", "")),
                 ("服务器", app.config.get("server_url", "")),
                 ("软件版本", VERSION),
                 ("学员注册邀请码", invite or "仅管理员可见")):
        Label(info, text="{0}:{1}".format(k, v), bg=CARD, fg=TEXT,
              font=font(info, 12), anchor="w").pack(fill="x", padx=14, pady=2)
    if user.get("role") == "admin":
        Label(info, text="更换邀请码请到管理员端 - 客户端更新发布页下方的邀请码设置",
              bg=CARD, fg=TEXT_MUTED, font=font(info, 11), anchor="w"
              ).pack(fill="x", padx=14, pady=(2, 8))
    _card(app, parent, "客户端更新")
    upd = Frame(parent, bg=CARD)
    upd.pack(fill="x", padx=16, pady=(0, 20))
    Label(upd, text="软件升级由服务器统一发布,无需重新安装;本机启动时自动检查并升级。",
          bg=CARD, fg=TEXT, font=font(upd, 12), anchor="w", wraplength=800,
          justify="left").pack(fill="x", padx=14, pady=8)
    status = Label(upd, text="正在检查...", bg=CARD, fg=TEXT_MUTED,
                   font=font(upd, 12))
    status.pack(anchor="w", padx=14, pady=(0, 8))
    Button(upd, text="立即检查更新", style="Navy.TButton",
           command=lambda: _check(app, status)).pack(anchor="w", padx=14,
                                                     pady=(0, 12))
    _check(app, status)
    return parent


def _card(app, parent, title):
    Label(parent, text=title, bg=BG, fg=NAVY,
          font=font(parent, 14, bold=True)).pack(anchor="w", padx=16,
                                                  pady=(12, 2))


def _toggle_full(app, parent):
    app.config["fullscreen"] = not app.config.get("fullscreen")
    app.save_config()
    app.apply_display_mode()
    build_settings(app, parent)


def _save_size(app, var):
    app.config["font_size"] = "large" if var.get() == "特大" else "standard"
    app.save_config()
    app.refresh_style()


def _save_toggle(app, key, var):
    app.config[key] = (var.get() == "开")
    app.save_config()


def _check(app, status_label):
    def work():
        try:
            data = app.api.get("/api/version",
                               params={"platform": "win7-32"})
            latest = (data or {}).get("latest")
        except Exception:
            latest = None
            data = None
        def done():
            if latest and latest.get("version") != VERSION:
                status_label.configure(
                    text="服务器最新版本:{0}  {1}".format(
                        latest.get("version"), latest.get("note", "")))
            elif latest:
                status_label.configure(text="已是最新版本")
            else:
                status_label.configure(text="服务器暂无已发布版本")
        try:
            status_label.after(0, done)
        except Exception:
            pass
    threading.Thread(target=work, daemon=True).start()
