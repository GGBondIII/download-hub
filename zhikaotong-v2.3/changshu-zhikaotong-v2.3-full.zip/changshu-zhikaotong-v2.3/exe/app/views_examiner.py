# -*- coding: utf-8 -*-
"""常熟站智考通 v2.3 -- 考官端:考试管理、题库管理。

Python 3.4 兼容语法,仅标准库。
"""
import base64
import os

from tkinter import Frame, Label, StringVar, Toplevel
from tkinter.ttk import Button, Combobox, Entry, Treeview

try:
    from tkinter import filedialog
except ImportError:
    filedialog = None

from theme import (NAVY, BG, CARD, TEXT, TEXT_MUTED, BORDER, font)
from widgets import (clear, banner, confirm_dialog)
from api_client import ApiError

TYPES = ["单选", "多选", "判断", "填空", "简答"]
SUBJECTS = ["自定义", "基础法规", "业务技能"]


def build_examiner_home(app, parent):
    """考官首页:考试管理 + 题库管理入口。"""
    clear(parent)
    app.page = "examiner_home"
    app.set_space_handler(None)
    Label(parent, text="考官端", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    row = Frame(parent, bg=BG)
    row.pack(fill="x", padx=16, pady=8)
    Button(row, text="考试管理", style="Navy.TButton",
           command=lambda: app.goto("exam_manage")).pack(side="left", padx=6)
    Button(row, text="题库管理", style="Navy.TButton",
           command=lambda: app.goto("question_manage")).pack(side="left", padx=6)
    Button(row, text="系统设置", style="Ghost.TButton",
           command=lambda: app.goto("settings")).pack(side="left", padx=6)
    row2 = Frame(parent, bg=BG)
    row2.pack(fill="x", padx=16, pady=8)
    for text, page in (("组卷模板", "templates"), ("导入任务", "import_jobs"),
                       ("题库质量", "quality"), ("简答批阅", "essay_queue"),
                       ("AI 变式", "ai_variants")):
        Button(row2, text=text, style="Gold.TButton",
               command=lambda p=page: app.goto(p)).pack(side="left", padx=6)
    return parent


def build_exam_manage(app, parent, status_filter=""):
    clear(parent)
    app.page = "exam_manage"
    Label(parent, text="考试管理", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    bar = Frame(parent, bg=BG)
    bar.pack(fill="x", padx=16, pady=4)
    fvar = StringVar(value=status_filter or "全部")
    Combobox(bar, textvariable=fvar, values=["全部", "草稿", "已发布", "已结束"],
             width=10, state="readonly").pack(side="left", padx=4)
    Button(bar, text="筛选", style="Ghost.TButton",
           command=lambda: build_exam_manage(app, parent, fvar.get())
           ).pack(side="left", padx=4)
    Button(bar, text="创建考试", style="Navy.TButton",
           command=lambda: _exam_dialog(app, parent, None)
           ).pack(side="right", padx=4)
    params = {}
    if status_filter and status_filter != "全部":
        params["status"] = status_filter
    try:
        exams = app.api.get("/api/admin/exams", params=params or None)
    except ApiError as e:
        banner(parent, e.message, "error")
        return parent
    app.ui["admin_exams"] = exams
    if not exams:
        Label(parent, text="还没有考试,点击右上角创建", bg=BG, fg=TEXT_MUTED,
              font=font(parent, 14)).pack(pady=30)
        return parent
    for ex in exams:
        card = Frame(parent, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1)
        card.pack(fill="x", padx=16, pady=6)
        head = Frame(card, bg=CARD)
        head.pack(fill="x", padx=12, pady=(8, 2))
        Label(head, text=ex.get("name", ""), bg=CARD, fg=NAVY,
              font=font(head, 14, bold=True)).pack(side="left")
        Label(head, text=ex.get("status", ""), bg=CARD, fg=NAVY,
              font=font(head, 12, bold=True)).pack(side="left", padx=10)
        Label(card, text="科目:{0}  时长:{1} 分钟  模式:{2}  名单:{3} 人".format(
            ex.get("subject", ""), ex.get("duration_min", ""),
            "全员同一份卷" if ex.get("mode") == "fixed" else "每人随机抽题",
            len(ex.get("members") or [])), bg=CARD, fg=TEXT_MUTED,
            font=font(card, 12), anchor="w").pack(fill="x", padx=12, pady=2)
        row = Frame(card, bg=CARD)
        row.pack(fill="x", padx=12, pady=(2, 10))
        eid = ex.get("id")
        Button(row, text="编辑", style="Ghost.TButton",
               command=lambda e=ex: _exam_dialog(app, parent, e)
               ).pack(side="left", padx=3)
        Button(row, text="成绩", style="Ghost.TButton",
               command=lambda eid=eid: _show_results(app, parent, eid)
               ).pack(side="left", padx=3)
        if ex.get("mode") == "fixed":
            Button(row, text="生成固定试卷", style="Ghost.TButton",
                   command=lambda eid=eid: _gen_fixed(app, parent, eid)
                   ).pack(side="left", padx=3)
            Button(row, text="查看固定试卷", style="Ghost.TButton",
                   command=lambda eid=eid: _view_fixed(app, parent, eid)
                   ).pack(side="left", padx=3)
        if ex.get("status") == "草稿":
            Button(row, text="发布", style="Navy.TButton",
                   command=lambda eid=eid: _exam_action(app, parent, eid,
                                                         "publish")
                   ).pack(side="left", padx=3)
        if ex.get("status") == "已发布":
            Button(row, text="结束", style="Gold.TButton",
                   command=lambda eid=eid: _exam_action(app, parent, eid,
                                                         "end")
                   ).pack(side="left", padx=3)
        Button(row, text="删除", style="Ghost.TButton",
               command=lambda eid=eid: _delete_exam(app, parent, eid)
               ).pack(side="left", padx=3)
    return parent


def _exam_action(app, parent, eid, action):
    try:
        app.api.post("/api/admin/exams/{0}/{1}".format(eid, action), {})
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    build_exam_manage(app, parent)


def _delete_exam(app, parent, eid):
    try:
        res = app.api.get("/api/admin/exams/{0}/results".format(eid))
        sub = res.get("submitted", 0)
        total = res.get("total_members", 0)
        ongoing = total - sub
    except ApiError:
        sub, ongoing = 0, 0
    text = ("删除后名单、试卷、成绩将一起清掉,不可恢复。"
            "已有 {0} 人交卷,还有 {1} 人正在考试,其作答将作废。".format(sub, ongoing))
    confirm_dialog(parent, "删除考试", text,
                   lambda: _do_delete_exam(app, parent, eid),
                   yes_text="确认删除")


def _do_delete_exam(app, parent, eid):
    try:
        app.api.delete("/api/admin/exams/{0}".format(eid))
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    build_exam_manage(app, parent)


def _gen_fixed(app, parent, eid):
    try:
        data = app.api.post("/api/admin/exams/{0}/fixed-paper".format(eid), {})
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    banner(parent, data.get("message", "已生成固定试卷,所有考生将使用这份相同的试卷"),
           "ok")
    app.ui["fixed_paper"] = data


def _view_fixed(app, parent, eid):
    try:
        data = app.api.get("/api/admin/exams/{0}/fixed-paper".format(eid))
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    top = Toplevel(parent)
    top.title("固定试卷")
    top.geometry("640x420+200+120")
    top.configure(bg=CARD)
    paper = data.get("paper") or []
    qs = data.get("questions") or []
    if not paper:
        Label(top, text="尚未生成固定试卷", bg=CARD, fg=TEXT_MUTED,
              font=font(top, 13)).pack(pady=20)
        return
    Label(top, text="共 {0} 题(题目与顺序全员相同)".format(len(paper)),
          bg=CARD, fg=NAVY, font=font(top, 13, bold=True)).pack(pady=8)
    for i, q in enumerate(qs):
        Label(top, text="{0}. [{1}] {2}".format(i + 1, q.get("type", ""),
              q.get("stem", "")), bg=CARD, fg=TEXT, font=font(top, 12),
              wraplength=580, justify="left", anchor="w"
              ).pack(fill="x", padx=14, pady=2)
    Button(top, text="关闭", style="Navy.TButton",
           command=top.destroy).pack(pady=12)


def _show_results(app, parent, eid):
    clear(parent)
    app.page = "exam_results"
    Label(parent, text="考试成绩", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    try:
        data = app.api.get("/api/admin/exams/{0}/results".format(eid))
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    exam = data.get("exam") or {}
    Label(parent, text="{0}  应考 {1} 人 / 已交卷 {2} 人 / 平均分 {3}".format(
        exam.get("name", ""), data.get("total_members", 0),
        data.get("submitted", 0), data.get("average", "")), bg=BG, fg=TEXT,
        font=font(parent, 13)).pack(anchor="w", padx=16, pady=4)
    Button(parent, text="导出 CSV", style="Navy.TButton",
           command=lambda: _export_csv(app, parent, eid)
           ).pack(anchor="w", padx=16, pady=6)
    Button(parent, text="打印成绩单(HTML)", style="Gold.TButton",
           command=lambda: _exam_print(app, parent, eid)
           ).pack(anchor="w", padx=16, pady=4)
    Button(parent, text="返回考试管理", style="Ghost.TButton",
           command=lambda: app.goto("exam_manage")).pack(anchor="w", padx=16,
                                                         pady=4)
    cols = ("姓名", "用户名", "部门", "状态", "交卷时间", "得分")
    tree = Treeview(parent, columns=cols, show="headings", height=14)
    for c in cols:
        tree.heading(c, text=c)
        tree.column(c, width=110)
    tree.pack(fill="both", expand=True, padx=16, pady=8)
    for row in data.get("list") or []:
        tree.insert("", "end", values=(row.get("name", ""),
                    row.get("username", ""), row.get("department", ""),
                    row.get("status", ""), row.get("submitted_at", ""),
                    row.get("score", "")))

    def review(event):
        sel = tree.selection()
        if not sel:
            return
        vals = tree.item(sel[0], "values")
        # 按用户名找 user_id:再查成绩列表
        for row in data.get("list") or []:
            if row.get("username") == vals[1]:
                _review_one(app, parent, eid, row.get("user_id"))
                break

    tree.bind("<Double-1>", review)
    Label(parent, text="双击一行可阅卷回看(逐题:学员所选 / 正确答案 / 解析)",
          bg=BG, fg=TEXT_MUTED, font=font(parent, 11)).pack(anchor="w",
                                                             padx=16, pady=4)


def _review_one(app, parent, eid, uid):
    try:
        data = app.api.get("/api/admin/exams/{0}/review/{1}".format(eid, uid))
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    clear(parent)
    Label(parent, text="阅卷回看", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    Label(parent, text="得分 {0}/{1}".format(data.get("score", ""),
          data.get("full_score", "")), bg=BG, fg=TEXT,
          font=font(parent, 13)).pack(anchor="w", padx=16)
    from widgets import render_results
    render_results(parent, app, data.get("results") or [])
    Button(parent, text="返回", style="Ghost.TButton",
           command=lambda: _show_results(app, parent, eid)).pack(anchor="w",
                                                                 padx=16, pady=8)


def _export_csv(app, parent, eid):
    try:
        raw = app.api.download("/api/admin/exams/{0}/results.csv".format(eid))
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    if filedialog is None:
        banner(parent, "当前环境不支持文件对话框", "error")
        return
    path = filedialog.asksaveasfilename(defaultextension=".csv",
                                        filetypes=[("CSV", "*.csv")])
    if not path:
        return
    try:
        with open(path, "wb") as f:
            f.write(raw)
    except Exception as e:
        banner(parent, "保存失败:{0}".format(e), "error")
        return
    banner(parent, "已导出到 {0}".format(path), "ok")


def _exam_dialog(app, parent, exam):
    top = Toplevel(parent)
    top.title("编辑考试" if exam else "创建考试")
    top.geometry("560x620+220+80")
    top.configure(bg=CARD)
    top.transient(parent)
    top.grab_set()
    vars_ = {}
    fields = [("考试名称", "name", exam.get("name", "") if exam else ""),
              ("考试科目", "subject", exam.get("subject", "") if exam else "基础法规"),
              ("时长(分钟)", "duration_min", str(exam.get("duration_min", 60)) if exam else "60"),
              ("可考开始时间(选填)", "start_at", exam.get("start_at", "") if exam else ""),
              ("结束时间(选填)", "end_at", exam.get("end_at", "") if exam else "")]
    for label, key, val in fields:
        Label(top, text=label, bg=CARD, fg=TEXT,
              font=font(top, 12)).pack(anchor="w", padx=16, pady=(6, 0))
        var = StringVar(value=val)
        Entry(top, textvariable=var, width=40,
              font=font(top, 12)).pack(anchor="w", padx=16)
        vars_[key] = var
    mode_var = StringVar(value=(exam or {}).get("mode", "fixed"))
    Label(top, text="试卷模式", bg=CARD, fg=TEXT,
          font=font(top, 12)).pack(anchor="w", padx=16, pady=(6, 0))
    Combobox(top, textvariable=mode_var,
             values=["fixed", "random"], width=20, state="readonly"
             ).pack(anchor="w", padx=16)
    Label(top, text="fixed=全员同一份卷,random=每人开考时随机抽题",
          bg=CARD, fg=TEXT_MUTED, font=font(top, 11)).pack(anchor="w", padx=16)
    sh_var = StringVar(value="开" if (exam or {}).get("shuffle") else "关")
    Label(top, text="题目乱序", bg=CARD, fg=TEXT,
          font=font(top, 12)).pack(anchor="w", padx=16, pady=(6, 0))
    Combobox(top, textvariable=sh_var, values=["开", "关"], width=8,
             state="readonly").pack(anchor="w", padx=16)
    qc = (exam or {}).get("qcounts") or {}
    qs = (exam or {}).get("qscores") or {}
    count_vars, score_vars = {}, {}
    for t in ("单选", "多选", "判断"):
        row = Frame(top, bg=CARD)
        row.pack(fill="x", padx=16, pady=2)
        Label(row, text="{0}数量".format(t), bg=CARD, fg=TEXT,
              font=font(row, 12)).pack(side="left")
        cv = StringVar(value=str(qc.get(t, 0)))
        Entry(row, textvariable=cv, width=5,
              font=font(row, 12)).pack(side="left", padx=4)
        Label(row, text="每题分", bg=CARD, fg=TEXT,
              font=font(row, 12)).pack(side="left", padx=(10, 2))
        sv = StringVar(value=str(qs.get(t, 5)))
        Entry(row, textvariable=sv, width=5,
              font=font(row, 12)).pack(side="left", padx=4)
        count_vars[t] = cv
        score_vars[t] = sv
    msg = Label(top, text="", bg=CARD, fg="#DC2626", font=font(top, 12))
    msg.pack(anchor="w", padx=16, pady=4)
    app.ui["exam_dialog_vars"] = vars_
    app.ui["exam_dialog_counts"] = count_vars
    app.ui["exam_dialog_scores"] = score_vars
    app.ui["exam_dialog_mode"] = mode_var

    def save():
        try:
            dur = int(vars_["duration_min"].get())
        except Exception:
            msg.configure(text="时长须为数字")
            return
        payload = {"name": vars_["name"].get().strip(),
                   "subject": vars_["subject"].get().strip() or "基础法规",
                   "duration_min": dur,
                   "shuffle": sh_var.get() == "开",
                   "mode": mode_var.get(),
                   "qcounts": dict((t, int(count_vars[t].get() or 0))
                                   for t in count_vars),
                   "qscores": dict((t, int(score_vars[t].get() or 0))
                                   for t in score_vars),
                   "start_at": vars_["start_at"].get().strip(),
                   "end_at": vars_["end_at"].get().strip()}
        if not payload["name"]:
            msg.configure(text="考试名称不能为空")
            return
        try:
            if exam:
                app.api.put("/api/admin/exams/{0}".format(exam.get("id")),
                            payload)
            else:
                # 名单默认全选所有学员;取 /api/users/students(考官与
                # 管理员均可调)。失败时退回空名单,考试仍可创建,名单
                # 可由管理员后续补。
                members = []
                try:
                    students = app.api.get("/api/users/students")
                    members = [u.get("id") for u in (students or [])]
                except Exception:
                    members = []
                payload["members"] = members
                app.api.post("/api/admin/exams", payload)
        except ApiError as e:
            msg.configure(text=e.message)
            return
        except Exception as e:
            msg.configure(text="保存失败:{0}".format(e))
            return
        top.destroy()
        build_exam_manage(app, parent)

    Button(top, text="保存", style="Navy.TButton",
           command=save).pack(pady=12)
    app.ui["exam_dialog_save"] = save
    return top


# ---------------- 题库管理 ----------------

def build_question_manage(app, parent, page=1):
    clear(parent)
    app.page = "question_manage"
    Label(parent, text="题库管理", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    bar = Frame(parent, bg=BG)
    bar.pack(fill="x", padx=16, pady=4)
    q_var = StringVar()
    Entry(bar, textvariable=q_var, width=20,
          font=font(bar, 12)).pack(side="left", padx=4)
    type_var = StringVar(value="全部")
    Combobox(bar, textvariable=type_var,
             values=["全部"] + TYPES, width=10, state="readonly"
             ).pack(side="left", padx=4)
    Button(bar, text="搜索", style="Ghost.TButton",
           command=lambda: _search(app, parent, q_var.get(), type_var.get())
           ).pack(side="left", padx=4)
    Button(bar, text="下载导入模板", style="Ghost.TButton",
           command=lambda: _download_template(app, parent)).pack(side="left", padx=4)
    Button(bar, text="导入", style="Ghost.TButton",
           command=lambda: _import_questions(app, parent)).pack(side="left", padx=4)
    Button(bar, text="新增题目", style="Navy.TButton",
           command=lambda: _question_dialog(app, parent, None)
           ).pack(side="right", padx=4)
    app.ui["q_search_var"] = q_var
    app.ui["q_type_var"] = type_var
    _question_list(app, parent, page, q="", qtype="")


def _search(app, parent, q, qtype):
    _question_list(app, parent, 1, q=q,
                   qtype="" if qtype == "全部" else qtype)


def _question_list(app, parent, page, q, qtype):
    for w in parent.winfo_children():
        if getattr(w, "_qlist", False):
            w.destroy()
    frame = Frame(parent, bg=BG)
    frame._qlist = True
    frame.pack(fill="both", expand=True)
    params = {"page": page, "page_size": 20}
    if q:
        params["q"] = q
    if qtype:
        params["type"] = qtype
    try:
        data = app.api.get("/api/questions", params=params)
    except ApiError as e:
        banner(frame, e.message, "error")
        return
    items = (data or {}).get("items") or []
    total = (data or {}).get("total", 0)
    app.ui["question_items"] = items
    Label(frame, text="题库共 {0} 题".format(total), bg=BG, fg=TEXT,
          font=font(frame, 12)).pack(anchor="w", padx=16, pady=4)
    cols = ("题号", "题干", "题型", "分类", "答案", "状态")
    tree = Treeview(frame, columns=cols, show="headings", height=14)
    widths = {"题号": 80, "题干": 380, "题型": 70, "分类": 100, "答案": 80,
              "状态": 70}
    for c in cols:
        tree.heading(c, text=c)
        tree.column(c, width=widths[c])
    tree.pack(fill="both", expand=True, padx=16)
    idmap = {}
    for it in items:
        iid = tree.insert("", "end", values=(it.get("no", ""),
                           (it.get("stem", "") or "")[:40], it.get("type", ""),
                           it.get("category", ""), it.get("answer", ""),
                           it.get("status", "")))
        idmap[iid] = it
    app.ui["question_tree"] = tree
    app.ui["question_idmap"] = idmap
    row = Frame(frame, bg=BG)
    row.pack(fill="x", padx=16, pady=6)
    Button(row, text="上一页", style="Ghost.TButton",
           command=lambda: build_question_manage(app, parent, max(1, page - 1))
           if page > 1 else None).pack(side="left", padx=4)
    Button(row, text="下一页", style="Ghost.TButton",
           command=lambda: build_question_manage(app, parent, page + 1)
           ).pack(side="left", padx=4)
    Label(row, text="第 {0} 页".format(page), bg=BG, fg=TEXT_MUTED,
          font=font(row, 12)).pack(side="left", padx=8)

    def sel():
        s = tree.selection()
        if not s:
            return None
        return idmap.get(s[0])

    def edit_sel():
        it = sel()
        if it:
            _question_dialog(app, parent, it)

    def del_sel():
        it = sel()
        if not it:
            banner(frame, "请先选择题目", "warn")
            return
        confirm_dialog(parent, "删除题目", "确定删除 {0} 吗?".format(it.get("no", "")),
                       lambda: _del_questions(app, parent, [it.get("id")]))

    def toggle_sel():
        it = sel()
        if not it:
            return
        new = "停用" if it.get("status") == "启用" else "启用"
        try:
            app.api.post("/api/questions/{0}/status".format(it.get("id")),
                         {"status": new})
        except ApiError as e:
            banner(frame, e.message, "error")
            return
        build_question_manage(app, parent, page)

    Button(row, text="编辑所选", style="Ghost.TButton",
           command=edit_sel).pack(side="left", padx=4)
    Button(row, text="删除所选", style="Ghost.TButton",
           command=del_sel).pack(side="left", padx=4)
    Button(row, text="启用 / 停用", style="Ghost.TButton",
           command=toggle_sel).pack(side="left", padx=4)


def _del_questions(app, parent, ids):
    try:
        app.api.delete("/api/questions", body={"ids": ids})
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    build_question_manage(app, parent)


def _download_template(app, parent):
    try:
        raw = app.api.download("/api/questions/template")
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    if filedialog is None:
        return
    path = filedialog.asksaveasfilename(
        defaultextension=".xlsx",
        initialfile="question-import-template.xlsx")
    if not path:
        return
    with open(path, "wb") as f:
        f.write(raw)
    banner(parent, "模板已保存到 {0}".format(path), "ok")


def _import_questions(app, parent):
    if filedialog is None:
        banner(parent, "当前环境不支持文件对话框", "error")
        return
    path = filedialog.askopenfilename(
        filetypes=[("Excel/Word", "*.xlsx *.docx")])
    if not path:
        return
    try:
        with open(path, "rb") as f:
            raw = f.read()
    except Exception as e:
        banner(parent, "读取失败:{0}".format(e), "error")
        return
    try:
        data = app.api.post("/api/questions/import",
                            {"filename": os.path.basename(path),
                             "content_b64": base64.b64encode(raw).decode("ascii")})
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    banner(parent, data.get("message", "导入完成"), "ok")
    app.ui["import_result"] = data
    build_question_manage(app, parent)


def _question_dialog(app, parent, q):
    top = Toplevel(parent)
    top.title("编辑题目" if q else "新增题目")
    top.geometry("600x640+200+60")
    top.configure(bg=CARD)
    top.transient(parent)
    top.grab_set()
    vars_ = {}
    for label, key, val in (("题号(可空,自动生成)", "no", (q or {}).get("no", "")),
                            ("题干 *", "stem", (q or {}).get("stem", "")),
                            ("分类", "category", (q or {}).get("category", "")),
                            ("正确答案 *", "answer", (q or {}).get("answer", "")),
                            ("解析", "analysis", (q or {}).get("analysis", "")),
                            ("图片文件名(需已在服务器目录)", "image",
                             (q or {}).get("image", ""))):
        Label(top, text=label, bg=CARD, fg=TEXT,
              font=font(top, 12)).pack(anchor="w", padx=16, pady=(6, 0))
        var = StringVar(value=val)
        Entry(top, textvariable=var, width=55,
              font=font(top, 12)).pack(anchor="w", padx=16)
        vars_[key] = var
    type_var = StringVar(value=(q or {}).get("type", "单选"))
    Label(top, text="题型", bg=CARD, fg=TEXT,
          font=font(top, 12)).pack(anchor="w", padx=16, pady=(6, 0))
    Combobox(top, textvariable=type_var, values=TYPES, width=12,
             state="readonly").pack(anchor="w", padx=16)
    opt_vars = {}
    opts = (q or {}).get("options") or {}
    Label(top, text="选项(A-D)", bg=CARD, fg=TEXT,
          font=font(top, 12)).pack(anchor="w", padx=16, pady=(6, 0))
    for letter in "ABCD":
        row = Frame(top, bg=CARD)
        row.pack(fill="x", padx=16, pady=2)
        Label(row, text=letter, bg=CARD, fg=NAVY,
              font=font(row, 12, bold=True)).pack(side="left")
        var = StringVar(value=opts.get(letter, ""))
        Entry(row, textvariable=var, width=48,
              font=font(row, 12)).pack(side="left", padx=6)
        opt_vars[letter] = var
    msg = Label(top, text="", bg=CARD, fg="#DC2626", font=font(top, 12))
    msg.pack(anchor="w", padx=16, pady=4)
    app.ui["question_dialog_vars"] = vars_
    app.ui["question_dialog_type"] = type_var
    app.ui["question_dialog_opts"] = opt_vars

    def save():
        payload = dict((k, v.get().strip()) for k, v in vars_.items())
        payload["type"] = type_var.get()
        payload["options"] = dict((k, v.get().strip()) for k, v in
                                  opt_vars.items() if v.get().strip())
        if not payload["stem"]:
            msg.configure(text="题干不能为空")
            return
        if not payload["answer"]:
            msg.configure(text="答案不能为空")
            return
        try:
            if q:
                app.api.put("/api/questions/{0}".format(q.get("id")), payload)
            else:
                app.api.post("/api/questions", payload)
        except ApiError as e:
            msg.configure(text=e.message)
            return
        top.destroy()
        build_question_manage(app, parent)

    Button(top, text="保存", style="Navy.TButton",
           command=save).pack(pady=12)
    app.ui["question_dialog_save"] = save
    return top


# ---------------- v2:组卷模板 / 导入任务 / 质量闭环 / 简答批阅 / AI 变式 ----------------
# 字段形状(按服务端实际契约):
# 模板 rules 为 {"type_counts": {"单选": n, "多选": n, "判断": n, "填空": n, "简答": n}}——
# 中文题型键;英文键(single/multi/judge/fill/short)或错键名(counts)会被服务端静默忽略,
# 抽题回退为随机补题。列表渲染兼容旧形状(扁平中文键 / 扁平英文键)以便读旧模板。
# 质量行含 question_id/stem/total/correct/accuracy/flag;
# 简答队列行含 id/question_id/stem/user_answer/reference_answer/
# rubric/max_score/display_name/team;变式行含 id/stem/source/status/
# parent_stem。模板开考返回 {"exam_id": ...} 或 {"exam": {...}}。
# 题目停用/恢复只收中文值 {"status": "停用"|"启用"},英文值报 400。

TEMPLATE_TYPES = [("单选", "single"), ("多选", "multi"), ("判断", "judge"),
                  ("填空", "fill"), ("简答", "short")]
EN2CN_TYPE = {"single": "单选", "multi": "多选", "judge": "判断",
              "fill": "填空", "short": "简答"}


def template_type_counts(rules):
    """从模板 rules 里读出 {中文题型: 数量}，兼容三种旧形状。"""
    if not isinstance(rules, dict):
        return {}
    tc = rules.get("type_counts")
    if isinstance(tc, dict) and tc:
        return dict((k, v) for k, v in tc.items()
                    if k in ("单选", "多选", "判断", "填空", "简答"))
    out = {}
    for k, v in rules.items():
        if k in ("单选", "多选", "判断", "填空", "简答"):
            out[k] = v
        elif k in EN2CN_TYPE:
            out[EN2CN_TYPE[k]] = v
    return out


def build_templates(app, parent):
    clear(parent)
    app.page = "templates"
    app.set_space_handler(None)
    Label(parent, text="组卷模板", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    bar = Frame(parent, bg=BG)
    bar.pack(fill="x", padx=16, pady=4)
    Button(bar, text="新建模板", style="Navy.TButton",
           command=lambda: _template_dialog(app, parent, None)
           ).pack(side="left", padx=4)
    Button(bar, text="返回考试管理", style="Ghost.TButton",
           command=lambda: app.goto("exam_manage")).pack(side="left", padx=4)
    try:
        templates = app.api.v2_templates()
    except ApiError as e:
        banner(parent, e.message, "error")
        app.ui["v2_templates"] = []
        return parent
    if isinstance(templates, dict):
        templates = templates.get("templates") or []
    app.ui["v2_templates"] = templates or []
    if not templates:
        Label(parent, text="暂无组卷模板,点击新建", bg=BG, fg=TEXT_MUTED,
              font=font(parent, 14)).pack(pady=30)
        return parent
    for t in templates:
        card = Frame(parent, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1)
        card.pack(fill="x", padx=16, pady=6)
        rules = t.get("rules_json") or t.get("rules") or {}
        if isinstance(rules, str):
            try:
                import json as _json
                rules = _json.loads(rules)
            except Exception:
                rules = {}
        tc = template_type_counts(rules)
        rule_text = "、".join("{0}{1}题".format(cn, tc.get(cn, 0))
                              for cn, _en in TEMPLATE_TYPES
                              if tc.get(cn))
        Label(card, text="{0}  共 {1} 题".format(t.get("title", ""),
              t.get("total_count", "")), bg=CARD, fg=NAVY,
              font=font(card, 14, bold=True), anchor="w").pack(
                  fill="x", padx=12, pady=(8, 2))
        Label(card, text="科目:{0}  配比:{1}".format(t.get("subject", ""),
              rule_text or "未设配比"), bg=CARD, fg=TEXT_MUTED,
              font=font(card, 12), anchor="w").pack(fill="x", padx=12)
        row = Frame(card, bg=CARD)
        row.pack(fill="x", padx=12, pady=(4, 10))
        tid = t.get("id")
        Button(row, text="按模板开考", style="Navy.TButton",
               command=lambda tid=tid: _template_start(app, parent, tid)
               ).pack(side="left", padx=3)
        Button(row, text="删除", style="Ghost.TButton",
               command=lambda tid=tid: _template_delete(app, parent, tid)
               ).pack(side="left", padx=3)
    return parent


def _template_dialog(app, parent, template):
    top = Toplevel(parent)
    top.title("新建组卷模板")
    top.geometry("520x560+240+80")
    top.configure(bg=CARD)
    top.transient(parent)
    top.grab_set()
    title_var = StringVar(value="")
    subj_var = StringVar(value="基础法规")
    total_var = StringVar(value="20")
    for label, var in (("模板名称 *", title_var), ("科目", subj_var),
                       ("总题数", total_var)):
        Label(top, text=label, bg=CARD, fg=TEXT,
              font=font(top, 12)).pack(anchor="w", padx=16, pady=(6, 0))
        Entry(top, textvariable=var, width=40,
              font=font(top, 12)).pack(anchor="w", padx=16)
    Label(top, text="各题型题数(含简答,留空为 0)", bg=CARD, fg=TEXT,
          font=font(top, 12)).pack(anchor="w", padx=16, pady=(8, 2))
    count_vars = {}
    for cn, en in TEMPLATE_TYPES:
        row = Frame(top, bg=CARD)
        row.pack(fill="x", padx=16, pady=2)
        Label(row, text=cn, bg=CARD, fg=NAVY,
              font=font(row, 12, bold=True)).pack(side="left")
        var = StringVar(value="0")
        Entry(row, textvariable=var, width=6,
              font=font(row, 12)).pack(side="left", padx=8)
        count_vars[cn] = var
    msg = Label(top, text="", bg=CARD, fg="#DC2626", font=font(top, 12))
    msg.pack(anchor="w", padx=16, pady=4)
    app.ui["template_dialog_vars"] = {"title": title_var,
                                      "subject": subj_var,
                                      "total": total_var}
    app.ui["template_dialog_counts"] = count_vars

    def save():
        title = title_var.get().strip()
        if not title:
            msg.configure(text="模板名称不能为空")
            return
        try:
            total = int(total_var.get() or 0)
        except Exception:
            msg.configure(text="总题数须为数字")
            return
        # 服务端只读 rules.type_counts（中文题型键）；英文键会被静默忽略。
        type_counts = {}
        for cn, var in count_vars.items():
            try:
                type_counts[cn] = int(var.get() or 0)
            except Exception:
                type_counts[cn] = 0
        try:
            app.api.v2_template_create(title, subj_var.get().strip(),
                                       total, {"type_counts": type_counts})
        except ApiError as e:
            msg.configure(text=e.message)
            return
        top.destroy()
        build_templates(app, parent)

    Button(top, text="保存", style="Navy.TButton",
           command=save).pack(pady=12)
    app.ui["template_dialog_save"] = save
    return top


def _template_start(app, parent, tid):
    try:
        data = app.api.v2_template_start(tid)
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    app.ui["template_start_result"] = data
    exam_id = None
    if isinstance(data, dict):
        exam_id = data.get("exam_id") or data.get("id")
        if isinstance(data.get("exam"), dict):
            exam_id = data["exam"].get("id")
    if exam_id:
        banner(parent, "已按模板开考,考试 ID {0}".format(exam_id), "ok")
        app.goto("exam_manage")
    else:
        banner(parent, (data or {}).get("message", "已按模板开考") if
               isinstance(data, dict) else "已按模板开考", "ok")
        app.goto("exam_manage")


def _template_delete(app, parent, tid):
    def do_it():
        try:
            app.api.v2_template_delete(tid)
        except ApiError as e:
            banner(parent, e.message, "error")
            return
        build_templates(app, parent)
    confirm_dialog(parent, "删除模板", "确定删除该组卷模板吗?",
                   do_it, yes_text="删除")


def build_quality(app, parent):
    """题库质量闭环:疑似错题标红、停用/恢复、重算质量分。"""
    clear(parent)
    app.page = "quality"
    app.set_space_handler(None)
    Label(parent, text="题库质量闭环", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    bar = Frame(parent, bg=BG)
    bar.pack(fill="x", padx=16, pady=4)
    Button(bar, text="重算质量分", style="Navy.TButton",
           command=lambda: _quality_refresh(app, parent)).pack(side="left",
                                                               padx=4)
    Button(bar, text="返回题库管理", style="Ghost.TButton",
           command=lambda: app.goto("question_manage")).pack(side="left",
                                                             padx=4)
    try:
        rows = app.api.v2_quality()
    except ApiError as e:
        banner(parent, e.message, "error")
        app.ui["v2_quality"] = []
        return parent
    if isinstance(rows, dict):
        rows = rows.get("quality") or []
    app.ui["v2_quality"] = rows or []
    if not rows:
        Label(parent, text="暂无质量数据(需先有作答记录,再点重算质量分)",
              bg=BG, fg=TEXT_MUTED, font=font(parent, 14)).pack(pady=30)
        return parent
    for r in rows:
        flag = r.get("flag", "normal")
        suspect = flag != "normal"
        acc = r.get("accuracy", 0)
        if acc and acc <= 1:
            acc = int(round(acc * 100))
        card = Frame(parent, bg=CARD,
                     highlightbackground="#DC2626" if suspect else BORDER,
                     highlightthickness=2 if suspect else 1)
        card.pack(fill="x", padx=16, pady=6)
        Label(card, text="{0}  {1}".format(
            "【疑似错题】" if suspect else "", (r.get("stem", "") or "")[:60]),
            bg=CARD, fg="#DC2626" if suspect else TEXT,
            font=font(card, 13, bold=True), anchor="w", wraplength=860,
            justify="left").pack(fill="x", padx=12, pady=(8, 2))
        Label(card, text="题号:{0}  作答 {1} 次,答对 {2} 次,正确率 {3}%".format(
            r.get("question_id", ""), r.get("total", 0), r.get("correct", 0),
            acc), bg=CARD, fg=TEXT_MUTED, font=font(card, 12),
            anchor="w").pack(fill="x", padx=12)
        row = Frame(card, bg=CARD)
        row.pack(fill="x", padx=12, pady=(4, 10))
        qid = r.get("question_id")
        Button(row, text="停用该题", style="Gold.TButton",
               command=lambda qid=qid: _quality_set_status(app, parent, qid,
                                                           "停用")
               ).pack(side="left", padx=3)
        Button(row, text="恢复启用", style="Navy.TButton",
               command=lambda qid=qid: _quality_set_status(app, parent, qid,
                                                           "启用")
               ).pack(side="left", padx=3)
    return parent


def _quality_refresh(app, parent):
    try:
        app.api.v2_quality_refresh()
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    banner(parent, "质量分已重算", "ok")
    build_quality(app, parent)


def _quality_set_status(app, parent, qid, status):
    try:
        app.api.v2_question_status(qid, status)
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    banner(parent, "题目 {0} 已改为 {1}".format(
        qid, "停用" if status == "停用" else "启用"), "ok")
    build_quality(app, parent)


def build_import_jobs(app, parent):
    """导入任务:列表 + 审核发布 + 图文配对复核 + PDF 导入 + 题库版本。"""
    clear(parent)
    app.page = "import_jobs"
    app.set_space_handler(None)
    Label(parent, text="导入任务", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    bar = Frame(parent, bg=BG)
    bar.pack(fill="x", padx=16, pady=4)
    Button(bar, text="导入 PDF", style="Navy.TButton",
           command=lambda: _import_pdf(app, parent)).pack(side="left", padx=4)
    Button(bar, text="题库版本", style="Ghost.TButton",
           command=lambda: _show_bank_versions(app, parent)).pack(side="left",
                                                                  padx=4)
    Button(bar, text="返回题库管理", style="Ghost.TButton",
           command=lambda: app.goto("question_manage")).pack(side="left",
                                                             padx=4)
    try:
        jobs = app.api.v2_import_jobs()
    except ApiError as e:
        banner(parent, e.message, "error")
        app.ui["v2_import_jobs"] = []
        return parent
    if isinstance(jobs, dict):
        app.ui["v2_import_queue"] = jobs.get("review_queue") or []
        jobs = jobs.get("jobs") or []
    app.ui["v2_import_jobs"] = jobs or []
    if not jobs:
        Label(parent, text="暂无导入任务", bg=BG, fg=TEXT_MUTED,
              font=font(parent, 14)).pack(pady=30)
        return parent
    for j in jobs:
        card = Frame(parent, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1)
        card.pack(fill="x", padx=16, pady=6)
        Label(card, text="{0}  状态:{1}".format(j.get("filename", ""),
              j.get("status", "")), bg=CARD, fg=NAVY,
              font=font(card, 13, bold=True), anchor="w").pack(
                  fill="x", padx=12, pady=(8, 2))
        Label(card, text="共 {0} 行,成功 {1} 行,失败 {2} 行,导入人:{3}".format(
            j.get("total_rows", ""), j.get("ok_rows", ""),
            j.get("bad_rows", ""), j.get("created_by", "")), bg=CARD,
            fg=TEXT_MUTED, font=font(card, 12), anchor="w").pack(
                fill="x", padx=12)
        row = Frame(card, bg=CARD)
        row.pack(fill="x", padx=12, pady=(4, 10))
        jid = j.get("id")
        Button(row, text="图文配对复核", style="Navy.TButton",
               command=lambda jid=jid: _show_pairings(app, parent, jid)
               ).pack(side="left", padx=3)
        Button(row, text="审核通过并发布", style="Gold.TButton",
               command=lambda jid=jid: _import_approve(app, parent, jid)
               ).pack(side="left", padx=3)
    return parent


def _import_approve(app, parent, jid):
    try:
        app.api.v2_import_job_approve(jid)
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    banner(parent, "导入任务 {0} 已审核通过并发布".format(jid), "ok")
    build_import_jobs(app, parent)


def _show_pairings(app, parent, jid):
    try:
        data = app.api.v2_import_pairings(jid)
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    pairing = {}
    rows = data
    if isinstance(data, dict):
        pairing = data.get("pairing") or {}
        rows = data.get("pairings") or []
    app.ui["v2_pairings"] = rows or []
    top = Toplevel(parent)
    top.title("图文配对复核")
    top.geometry("720x480+180+80")
    top.configure(bg=CARD)
    Label(top, text="自动 {0} / 复核 {1} / 人工 {2}".format(
        pairing.get("auto", ""), pairing.get("review", ""),
        pairing.get("manual", "")), bg=CARD, fg=NAVY,
        font=font(top, 13, bold=True)).pack(anchor="w", padx=14, pady=8)
    if not rows:
        Label(top, text="该任务无图文配对记录", bg=CARD, fg=TEXT_MUTED,
              font=font(top, 12)).pack(pady=20)
    for p in rows or []:
        card = Frame(top, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1)
        card.pack(fill="x", padx=14, pady=4)
        conf = p.get("confidence", 0)
        if conf and conf <= 1:
            conf = int(round(conf * 100))
        Label(card, text="图:{0}  题:{1}  置信度 {2}%  状态:{3}".format(
            p.get("filename", "") or p.get("asset_path", ""),
            (p.get("stem", "") or "")[:30], conf, p.get("status", "")),
            bg=CARD, fg=TEXT, font=font(card, 12), anchor="w",
            wraplength=640, justify="left").pack(fill="x", padx=10, pady=4)
        row = Frame(card, bg=CARD)
        row.pack(fill="x", padx=10, pady=(0, 8))
        pid = p.get("id")
        Button(row, text="确认配对", style="Navy.TButton",
               command=lambda pid=pid: _pairing_do(app, parent, pid,
                                                   "confirm")
               ).pack(side="left", padx=3)
        Button(row, text="拒绝(改人工)", style="Ghost.TButton",
               command=lambda pid=pid: _pairing_do(app, parent, pid,
                                                   "reject")
               ).pack(side="left", padx=3)
    Button(top, text="关闭", style="Navy.TButton",
           command=top.destroy).pack(pady=10)


def _pairing_do(app, parent, pid, action):
    try:
        if action == "confirm":
            app.api.v2_pairing_confirm(pid)
        else:
            app.api.v2_pairing_reject(pid)
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    banner(parent, "配对已{0}".format("确认" if action == "confirm" else "拒绝"),
           "ok")


def _import_pdf(app, parent):
    if filedialog is None:
        banner(parent, "当前环境不支持文件对话框", "error")
        return
    path = filedialog.askopenfilename(filetypes=[("PDF", "*.pdf")])
    if not path:
        return
    try:
        with open(path, "rb") as f:
            raw = f.read()
    except Exception as e:
        banner(parent, "读取失败:{0}".format(e), "error")
        return
    try:
        data = app.api.v2_import_pdf(os.path.basename(path),
                                     base64.b64encode(raw).decode("ascii"))
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    banner(parent, (data or {}).get("message", "PDF 导入完成") if
           isinstance(data, dict) else "PDF 导入完成", "ok")
    app.ui["v2_pdf_import_result"] = data
    build_import_jobs(app, parent)


def _show_bank_versions(app, parent):
    try:
        versions = app.api.v2_bank_versions()
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    if isinstance(versions, dict):
        versions = versions.get("versions") or []
    app.ui["v2_bank_versions"] = versions or []
    top = Toplevel(parent)
    top.title("题库版本")
    top.geometry("640x420+200+120")
    top.configure(bg=CARD)
    if not versions:
        Label(top, text="暂无题库版本", bg=CARD, fg=TEXT_MUTED,
              font=font(top, 12)).pack(pady=20)
    for v in versions or []:
        card = Frame(top, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1)
        card.pack(fill="x", padx=14, pady=4)
        Label(card, text="{0}  {1} 题  {2}".format(v.get("version_no", ""),
              v.get("question_count", ""),
              "当前版本" if v.get("is_current") else ""), bg=CARD, fg=NAVY,
              font=font(card, 12, bold=True), anchor="w").pack(
                  fill="x", padx=10, pady=(6, 2))
        row = Frame(card, bg=CARD)
        row.pack(fill="x", padx=10, pady=(0, 8))
        vid = v.get("id")
        Button(row, text="回滚到该版本", style="Gold.TButton",
               command=lambda vid=vid: _bank_rollback(app, parent, vid)
               ).pack(side="left", padx=3)
    row2 = Frame(top, bg=CARD)
    row2.pack(fill="x", padx=14, pady=8)
    Button(row2, text="发布新版本", style="Navy.TButton",
           command=lambda: _bank_publish(app, parent)).pack(side="left")
    Button(row2, text="关闭", style="Ghost.TButton",
           command=top.destroy).pack(side="left", padx=6)


def _bank_publish(app, parent):
    try:
        data = app.api.v2_bank_publish("客户端发布")
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    banner(parent, "已发布 {0}({1} 题)".format(
        (data or {}).get("version", "") if isinstance(data, dict) else "",
        (data or {}).get("count", "") if isinstance(data, dict) else ""),
        "ok")


def _bank_rollback(app, parent, vid):
    def do_it():
        try:
            app.api.v2_bank_rollback(vid)
        except ApiError as e:
            banner(parent, e.message, "error")
            return
        banner(parent, "已回滚到版本 {0}".format(vid), "ok")
    confirm_dialog(parent, "回滚题库", "回滚后当前版本将被替换,确定吗?",
                   do_it, yes_text="回滚")


def build_essay_queue(app, parent):
    """简答批阅:待批队列 + 人工打分(≥60%满分算对)。"""
    clear(parent)
    app.page = "essay_queue"
    app.set_space_handler(None)
    Label(parent, text="简答批阅", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    try:
        queue = app.api.v2_essay_queue()
    except ApiError as e:
        banner(parent, e.message, "error")
        app.ui["v2_essay_queue"] = []
        return parent
    if isinstance(queue, dict):
        queue = queue.get("queue") or []
    app.ui["v2_essay_queue"] = queue or []
    if not queue:
        Label(parent, text="暂无待批阅的简答题", bg=BG, fg=TEXT_MUTED,
              font=font(parent, 14)).pack(pady=30)
        return parent
    for item in queue:
        card = Frame(parent, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1)
        card.pack(fill="x", padx=16, pady=6)
        Label(card, text="{0}({1})".format(
            item.get("display_name", "") or item.get("username", ""),
            item.get("team", "")), bg=CARD, fg=NAVY,
            font=font(card, 13, bold=True), anchor="w").pack(
                fill="x", padx=12, pady=(8, 2))
        Label(card, text="题干:{0}".format(item.get("stem", "")), bg=CARD,
              fg=TEXT, font=font(card, 12), wraplength=860, justify="left",
              anchor="w").pack(fill="x", padx=12)
        Label(card, text="学员答案:{0}".format(item.get("user_answer", "")),
              bg=CARD, fg=TEXT, font=font(card, 12), wraplength=860,
              justify="left", anchor="w").pack(fill="x", padx=12)
        Label(card, text="参考答案:{0}".format(
            item.get("reference_answer", "") or item.get("answer", "")),
            bg=CARD, fg=GREEN, font=font(card, 12), wraplength=860,
            justify="left", anchor="w").pack(fill="x", padx=12)
        if item.get("rubric"):
            Label(card, text="评分标准:{0}".format(item.get("rubric")),
                  bg=CARD, fg=TEXT_MUTED, font=font(card, 12),
                  wraplength=860, justify="left", anchor="w").pack(
                      fill="x", padx=12)
        max_score = item.get("max_score", 10)
        row = Frame(card, bg=CARD)
        row.pack(fill="x", padx=12, pady=(4, 10))
        Label(row, text="得分(满分 {0}):".format(max_score), bg=CARD,
              fg=TEXT, font=font(row, 12)).pack(side="left")
        score_var = StringVar()
        Entry(row, textvariable=score_var, width=6,
              font=font(row, 12)).pack(side="left", padx=4)
        comment_var = StringVar()
        Label(row, text="评语:", bg=CARD, fg=TEXT,
              font=font(row, 12)).pack(side="left", padx=(10, 2))
        Entry(row, textvariable=comment_var, width=30,
              font=font(row, 12)).pack(side="left", padx=4)
        rid = item.get("id")

        def review(rid=rid, sv=score_var, cv=comment_var):
            try:
                score = float(sv.get())
            except Exception:
                banner(parent, "分数须为数字", "error")
                return
            try:
                res = app.api.v2_essay_review(rid, score, cv.get())
            except ApiError as e:
                banner(parent, e.message, "error")
                return
            passed = None
            if isinstance(res, dict):
                passed = res.get("passed")
            banner(parent, "已批阅:{0}".format(
                "通过(≥60%)" if passed else
                ("未通过" if passed is False else "已记录")), "ok")
            build_essay_queue(app, parent)

        Button(row, text="提交批阅", style="Navy.TButton",
               command=review).pack(side="left", padx=6)
    return parent


def build_ai_variants(app, parent):
    """AI 变式审核:本地规则变式(非 LLM),人工审核通过/拒绝。"""
    clear(parent)
    app.page = "ai_variants"
    app.set_space_handler(None)
    Label(parent, text="AI 变式审核", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    form = Frame(parent, bg=CARD, highlightbackground=BORDER,
                 highlightthickness=1)
    form.pack(fill="x", padx=16, pady=6)
    Label(form, text="按母题生成变式(本地规则,仅改选项顺序/表述/数字,"
          "不改考点)", bg=CARD, fg=NAVY, font=font(form, 12, bold=True)
          ).pack(anchor="w", padx=14, pady=(8, 2))
    qid_var = StringVar()
    Label(form, text="母题 ID(题目数字 ID)", bg=CARD, fg=TEXT,
          font=font(form, 12)).pack(anchor="w", padx=14)
    Entry(form, textvariable=qid_var, width=12,
          font=font(form, 12)).pack(anchor="w", padx=14)
    count_var = StringVar(value="2")
    Label(form, text="生成数量(1-3)", bg=CARD, fg=TEXT,
          font=font(form, 12)).pack(anchor="w", padx=14, pady=(6, 0))
    Combobox(form, textvariable=count_var, values=["1", "2", "3"], width=6,
             state="readonly").pack(anchor="w", padx=14)
    msg = Label(form, text="", bg=CARD, fg="#16A34A", font=font(form, 12))
    msg.pack(anchor="w", padx=14, pady=4)

    def gen():
        try:
            qid = int(qid_var.get())
        except Exception:
            msg.configure(text="请填写正确的母题 ID", fg="#DC2626")
            return
        try:
            data = app.api.v2_ai_variant_create(qid, int(count_var.get()))
        except ApiError as e:
            msg.configure(text=e.message, fg="#DC2626")
            return
        ids = (data or {}).get("variant_ids", []) if isinstance(data, dict) \
            else []
        msg.configure(text="已生成 {0} 道变式(草稿):{1},须人工审核后发布".format(
            len(ids), ids), fg="#16A34A")
        app.root.after(800, lambda: build_ai_variants(app, parent))

    Button(form, text="生成变式", style="Navy.TButton",
           command=gen).pack(anchor="w", padx=14, pady=10)
    app.ui["ai_variant_gen"] = gen
    app.ui["ai_variant_qid"] = qid_var
    try:
        variants = app.api.v2_ai_variants()
    except ApiError as e:
        banner(parent, e.message, "error")
        app.ui["v2_ai_variants"] = []
        return parent
    if isinstance(variants, dict):
        variants = variants.get("variants") or []
    app.ui["v2_ai_variants"] = variants or []
    if not variants:
        Label(parent, text="暂无待审核变式", bg=BG, fg=TEXT_MUTED,
              font=font(parent, 14)).pack(pady=20)
        return parent
    for v in variants:
        card = Frame(parent, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1)
        card.pack(fill="x", padx=16, pady=6)
        Label(card, text="{0}".format((v.get("stem", "") or "")[:80]),
              bg=CARD, fg=TEXT, font=font(card, 12), wraplength=860,
              justify="left", anchor="w").pack(fill="x", padx=12, pady=(8, 2))
        Label(card, text="来源:{0}  状态:{1}  母题:{2}".format(
            v.get("source", ""), v.get("status", ""),
            (v.get("parent_stem", "") or "")[:40]), bg=CARD, fg=TEXT_MUTED,
            font=font(card, 12), anchor="w", wraplength=860,
            justify="left").pack(fill="x", padx=12)
        row = Frame(card, bg=CARD)
        row.pack(fill="x", padx=12, pady=(4, 10))
        vid = v.get("id")

        def approve(vid=vid):
            try:
                app.api.v2_ai_variant_approve(vid)
            except ApiError as e:
                banner(parent, e.message, "error")
                return
            banner(parent, "变式 {0} 已审核通过并发布".format(vid), "ok")
            build_ai_variants(app, parent)

        def reject(vid=vid):
            try:
                app.api.v2_ai_variant_reject(vid)
            except ApiError as e:
                banner(parent, e.message, "error")
                return
            banner(parent, "变式 {0} 已驳回".format(vid), "ok")
            build_ai_variants(app, parent)

        Button(row, text="审核通过", style="Navy.TButton",
               command=approve).pack(side="left", padx=3)
        Button(row, text="驳回", style="Ghost.TButton",
               command=reject).pack(side="left", padx=3)
    return parent


def _exam_print(app, parent, eid):
    """打印成绩单:取 v2 HTML,另存为 .html 文件后用浏览器打印。"""
    try:
        raw = app.api.v2_exam_print(eid)
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    if filedialog is None:
        banner(parent, "当前环境不支持文件对话框", "error")
        return
    path = filedialog.asksaveasfilename(defaultextension=".html",
                                        initialfile="exam-{0}-print.html".format(eid),
                                        filetypes=[("HTML", "*.html")])
    if not path:
        return
    try:
        with open(path, "wb") as f:
            f.write(raw)
    except Exception as e:
        banner(parent, "保存失败:{0}".format(e), "error")
        return
    banner(parent, "成绩单已保存到 {0},可用浏览器打开打印".format(path), "ok")
