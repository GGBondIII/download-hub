# -*- coding: utf-8 -*-
"""常熟站智考通 v2.3 — 后台可视化:管理员总览/部门/个人统计、报告仪表盘数据、预警。

照抄刷题宝 v0.7 server.py 1401–1430、1666–1700 行与 admin_overview/
report_for/team_report 的逻辑,改成 v1 的数据模型(部门=users.department)。
修复(合并方案§五-1):exact_team_stats 精确汇总部门答对数与总作答数——
practice_records(correct=1)按部门汇总 + exam_attempts 与 mock_attempts 把
answers 与 paper 逐题用 grade_answer 重判后计数;禁止用“总作答×平均正确率”
推算;仪表盘与后台横向对比柱状图只用精确值。
Python 3.4 兼容语法。
"""
import json
from datetime import datetime

import db
import auth
import exams as exam_mod
import plans as plans_mod


def _grade_attempt_questions(conn, question_ids, answers, qscores):
    """把一次考试/模拟考的作答逐题重判,返回 (total, correct)。
    answers: {qid_str: {'a': 作答, 's': 自评}}。简答未批阅的不计入。"""
    total, _full, results, _pending = exam_mod.grade_paper(
        question_ids, answers, qscores)
    correct = len([r for r in results if r['correct'] is True])
    graded = len([r for r in results if r['correct'] is not None])
    return graded, correct


def exact_team_stats(conn, team):
    """部门精确统计(合并方案§五-1):答对数与总作答数全部精确汇总,禁止推算。
    来源三处:
    (1) practice_records:correct=1 按部门汇总;
    (2) exam_attempts(已交卷/迟交):paper 与 answers 逐题 grade_answer 重判;
    (3) mock_attempts(已完成):同理重判。"""
    mids = [r[0] for r in conn.execute(
        "SELECT id FROM users WHERE department=?", (team,)).fetchall()]
    if not mids:
        return {'team': team, 'member_count': 0, 'total_attempts': 0,
                'correct': 0, 'avg_accuracy': 0, 'participation': 0,
                'below_target': 0}
    ph = ','.join('?' * len(mids))
    total = 0
    correct = 0
    # (1) 日常练习
    row = conn.execute(
        "SELECT COUNT(*), COALESCE(SUM(correct), 0) FROM practice_records"
        " WHERE user_id IN ({0})".format(ph), mids).fetchone()
    total += row[0]
    correct += row[1]
    # (2) 正式考试:逐题重判
    for att in conn.execute(
            "SELECT * FROM exam_attempts WHERE user_id IN ({0})"
            " AND status IN ('已交卷', '迟交')".format(ph), mids).fetchall():
        paper = json.loads(att['paper'] or '[]')
        answers = json.loads(att['answers'] or '{}')
        exam = conn.execute("SELECT qscores FROM exams WHERE id=?",
                            (att['exam_id'],)).fetchone()
        qscores = json.loads(exam[0] or '{}') if exam else {}
        t, c = _grade_attempt_questions(conn, paper, answers, qscores)
        total += t
        correct += c
    # (3) 模拟考试:逐题重判
    for att in conn.execute(
            "SELECT * FROM mock_attempts WHERE user_id IN ({0})"
            " AND status='已完成'".format(ph), mids).fetchall():
        qids = json.loads(att['questions'] or '[]')
        answers = json.loads(att['answers'] or '{}')
        cfg = json.loads(att['config'] or '{}')
        qscores = cfg.get('scores') or {}
        t, c = _grade_attempt_questions(conn, qids, answers, qscores)
        total += t
        correct += c
    part = conn.execute(
        "SELECT COUNT(DISTINCT user_id) FROM attempts WHERE user_id IN ({0})"
        " AND date(answered_at)>=date('now', '-14 days')".format(ph),
        mids).fetchone()[0]
    below = 0
    for m in mids:
        r = conn.execute(
            "SELECT COUNT(*), COALESCE(SUM(is_correct), 0) FROM attempts"
            " WHERE user_id=? AND mode IN ('practice', 'exam')", (m,)).fetchone()
        if r[0] >= 10 and r[0] and r[1] / r[0] < 0.60:
            below += 1
    return {'team': team, 'member_count': len(mids), 'total_attempts': total,
            'correct': correct,
            'avg_accuracy': round(correct / total, 3) if total else 0,
            'participation': round(part / len(mids), 3) if mids else 0,
            'below_target': below}


def admin_overview():
    conn = db.get_conn()
    with db.DB_LOCK:
        total_users = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        today = datetime.now().strftime("%Y-%m-%d")
        active_today = conn.execute(
            "SELECT COUNT(DISTINCT user_id) FROM attempts"
            " WHERE substr(answered_at, 1, 10)=?", (today,)).fetchone()[0]
        today_attempts = conn.execute(
            "SELECT COUNT(*) FROM attempts WHERE substr(answered_at, 1, 10)=?"
            " AND mode IN ('practice', 'exam')", (today,)).fetchone()[0]
        tot = conn.execute(
            "SELECT COUNT(*) FROM attempts WHERE mode IN ('practice', 'exam')").fetchone()[0]
        cor = conn.execute(
            "SELECT COUNT(*) FROM attempts WHERE mode IN ('practice', 'exam')"
            " AND is_correct=1").fetchone()[0]
        trend = [{'date': r[0], 'total': r[1], 'correct': r[2] or 0}
                 for r in conn.execute(
                     "SELECT substr(answered_at, 1, 10), COUNT(*), SUM(is_correct)"
                     " FROM attempts WHERE mode IN ('practice', 'exam')"
                     " GROUP BY 1 ORDER BY 1 DESC LIMIT 14").fetchall()]
        trend = list(reversed(trend))
        pending = conn.execute(
            "SELECT COUNT(*) FROM review_queue WHERE status='pending'").fetchone()[0]
        weak_top = [{'knowledge': r[0], 'total': r[1], 'correct': r[2],
                     'accuracy': round(r[2] / r[1], 3) if r[1] else 0}
                    for r in conn.execute(
                        "SELECT knowledge, SUM(total), SUM(correct) FROM mastery_states"
                        " GROUP BY knowledge ORDER BY correct * 1.0 / NULLIF(total, 0)"
                        " ASC LIMIT 5").fetchall()]
        suspects = conn.execute(
            "SELECT COUNT(*) FROM quality_scores WHERE flag!='normal'").fetchone()[0]
        teams = []
        for trow in conn.execute(
                "SELECT DISTINCT department FROM users"
                " WHERE department IS NOT NULL AND department<>''").fetchall():
            teams.append(exact_team_stats(conn, trow[0]))
        warnings = []
        for u in conn.execute("SELECT id, name, department FROM users").fetchall():
            last = conn.execute(
                "SELECT MAX(answered_at) FROM attempts WHERE user_id=?",
                (u[0],)).fetchone()[0]
            if not last or (datetime.now()
                           - datetime.strptime(last, "%Y-%m-%d %H:%M:%S")).days >= 7:
                warnings.append({'type': 'inactive_7d', 'user_id': u[0],
                                 'display_name': u[1], 'team': u[2],
                                 'detail': '7 天无作答' if last else '从未作答'})
            r7 = conn.execute(
                "SELECT COUNT(*), COALESCE(SUM(is_correct), 0) FROM attempts"
                " WHERE user_id=? AND mode IN ('practice', 'exam')"
                " AND date(answered_at)>=date('now', '-7 days')",
                (u[0],)).fetchone()
            r14 = conn.execute(
                "SELECT COUNT(*), COALESCE(SUM(is_correct), 0) FROM attempts"
                " WHERE user_id=? AND mode IN ('practice', 'exam')"
                " AND date(answered_at)>=date('now', '-14 days')"
                " AND date(answered_at)<date('now', '-7 days')",
                (u[0],)).fetchone()
            if r7[0] >= 5 and r14[0] >= 5 and r7[1] / r7[0] < r14[1] / r14[0] - 0.15:
                warnings.append({'type': 'accuracy_drop', 'user_id': u[0],
                                 'display_name': u[1], 'team': u[2],
                                 'detail': '近 7 天正确率 {0},低于前 7 天 {1}'.format(
                                     round(r7[1] / r7[0], 2),
                                     round(r14[1] / r14[0], 2))})
        for r in conn.execute(
                "SELECT knowledge, SUM(total), SUM(correct) FROM mastery_states"
                " GROUP BY knowledge").fetchall():
            if r[1] >= 10 and r[2] / r[1] < 0.60:
                warnings.append({'type': 'knowledge_low', 'user_id': None,
                                 'display_name': '全站', 'team': '',
                                 'detail': '知识点「{0}」全站正确率 {1}({2} 题),低于 60%'.format(
                                     r[0], round(r[2] / r[1], 2), r[1])})
        heat = {}
        for r in conn.execute(
                "SELECT u.department, m.knowledge, SUM(m.total), SUM(m.correct)"
                " FROM mastery_states m JOIN users u ON u.id=m.user_id"
                " GROUP BY u.department, m.knowledge").fetchall():
            heat.setdefault(r[1], {})[r[0]] = round(r[3] / r[2], 2) if r[2] else 0
        plans_active = conn.execute("SELECT COUNT(*) FROM study_plans").fetchone()[0]
        plans_overdue = 0
        for pl in conn.execute("SELECT * FROM study_plans").fetchall():
            if not pl['due_date'] or pl['due_date'] >= today:
                continue
            uids = [r[0] for r in conn.execute(
                "SELECT user_id FROM tasks WHERE plan_id=?", (pl['id'],)).fetchall()]
            if uids and any(plans_mod.plan_progress(conn, pl, uid)['pct'] < 100
                            for uid in uids):
                plans_overdue += 1
    return {'total_users': total_users, 'active_today': active_today,
            'today_attempts': today_attempts,
            'avg_accuracy': round(cor / tot, 3) if tot else 0,
            'total_attempts': tot, 'trend14': trend,
            'pending_review': pending, 'weak_top': weak_top,
            'suspects': suspects, 'teams': teams, 'warnings': warnings,
            'heatmap': heat, 'plans_active': plans_active,
            'plans_overdue': plans_overdue}


def report_for(user_id):
    import adaptive
    conn = db.get_conn()
    with db.DB_LOCK:
        user = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
        total = conn.execute(
            "SELECT COUNT(*) FROM attempts WHERE user_id=?"
            " AND mode IN ('practice', 'exam') AND is_correct IS NOT NULL",
            (user_id,)).fetchone()[0]
        correct = conn.execute(
            "SELECT COUNT(*) FROM attempts WHERE user_id=?"
            " AND mode IN ('practice', 'exam') AND is_correct=1",
            (user_id,)).fetchone()[0]
        ess_total = conn.execute(
            "SELECT COUNT(*) FROM attempts a JOIN questions q ON q.id=a.question_id"
            " WHERE a.user_id=? AND q.type='简答' AND a.mode IN ('practice', 'exam')",
            (user_id,)).fetchone()[0]
        ess_pending = conn.execute(
            "SELECT COUNT(*) FROM attempts a JOIN questions q ON q.id=a.question_id"
            " WHERE a.user_id=? AND q.type='简答' AND a.mode IN ('practice', 'exam')"
            " AND a.is_correct IS NULL", (user_id,)).fetchone()[0]
        ess_sc = conn.execute(
            "SELECT COALESCE(SUM(score), 0), COALESCE(SUM(max_score), 0)"
            " FROM review_scores WHERE user_id=? AND status='graded'",
            (user_id,)).fetchone()
        essay_stat = {'total': ess_total, 'graded': ess_total - ess_pending,
                      'pending': ess_pending, 'score': ess_sc[0],
                      'max_score': ess_sc[1]}
        plans_stat = []
        for pl in conn.execute(
                "SELECT sp.* FROM study_plans sp JOIN tasks t ON t.plan_id=sp.id"
                " WHERE t.user_id=? ORDER BY sp.due_date LIMIT 5",
                (user_id,)).fetchall():
            p = plans_mod.plan_progress(conn, pl, user_id)
            plans_stat.append({'id': pl['id'], 'title': pl['title'],
                               'knowledge': pl['knowledge'],
                               'due_date': pl['due_date'], 'done': p['done'],
                               'target': p['target'], 'pct': p['pct'],
                               'overdue': p['overdue'],
                               'days_left': p['days_left'],
                               'daily_count': p['daily_count']})
        by_kn = []
        for r in conn.execute(
                "SELECT knowledge, total, correct, elo FROM mastery_states"
                " WHERE user_id=? ORDER BY elo ASC", (user_id,)).fetchall():
            acc = round(r[2] / r[1], 3) if r[1] else 0
            by_kn.append({'knowledge': r[0], 'total': r[1], 'correct': r[2],
                          'accuracy': acc, 'elo': r[3]})
        trend = [{'date': r[0], 'total': r[1], 'correct': r[2] or 0}
                 for r in conn.execute(
                     "SELECT substr(answered_at, 1, 10), COUNT(*), SUM(is_correct)"
                     " FROM attempts WHERE user_id=? GROUP BY 1 ORDER BY 1 DESC LIMIT 14",
                     (user_id,)).fetchall()]
        wrong_n = conn.execute(
            "SELECT COUNT(*) FROM wrong_book WHERE user_id=? AND mastered=0",
            (user_id,)).fetchone()[0]
        due_n = conn.execute(
            "SELECT COUNT(*) FROM review_schedule WHERE user_id=?"
            " AND date(next_review)<=date('now')", (user_id,)).fetchone()[0]
        streak = adaptive.streak_days(conn, user_id)
        prof = adaptive.adaptive_profile(conn, user_id)
    weak = sorted([k for k in by_kn if k['total'] >= 5 and k['accuracy'] < 0.60],
                  key=lambda x: (x['accuracy'], x['elo']))[:5]
    advice = ''
    if weak:
        advice = '薄弱项:' + '、'.join(k['knowledge'] for k in weak) + ',建议用薄弱项训练每天练 10 道。'
    elif total < 20:
        advice = '样本不足:已答 {0} 题,满 20 题后开始个性化判断;先做 10 道练习再看报告。'.format(total)
    else:
        advice = '暂无明显薄弱项,继续保持随机测验。'
    return {'username': user['username'] if user else '',
            'display_name': user['name'] if user else '',
            'team': user['department'] if user else '',
            'total': total, 'correct': correct,
            'accuracy': round(correct / total, 3) if total else 0,
            'by_knowledge': by_kn, 'weak_top': weak, 'trend': trend,
            'wrong_count': wrong_n, 'due_count': due_n,
            'streak_days': streak, 'essay': essay_stat, 'plans': plans_stat,
            'adaptive': {'weak_knowledge': prof['weak_knowledge'],
                         'mastered_knowledge': prof['mastered_knowledge'],
                         'ratio': prof['ratio'],
                         'sample_note': prof['sample_note'],
                         'cold_start': prof['cold_start'],
                         'per_knowledge': prof['per_knowledge']},
            'advice': advice}


def team_report(team, requester_role='admin'):
    conn = db.get_conn()
    with db.DB_LOCK:
        if requester_role == 'examiner':
            members = conn.execute(
                "SELECT id FROM users WHERE department=?", (team,)).fetchall()
        else:
            members = conn.execute("SELECT id FROM users").fetchall()
        mids = [r[0] for r in members]
        if not mids:
            return {'team': team, 'member_count': 0, 'total_attempts': 0,
                    'avg_accuracy': 0, 'knowledge': [], 'wrong_top': []}
        ph = ','.join('?' * len(mids))
        total = conn.execute(
            "SELECT COUNT(*) FROM attempts WHERE user_id IN ({0})".format(ph),
            mids).fetchone()[0]
        correct = conn.execute(
            "SELECT COUNT(*) FROM attempts WHERE user_id IN ({0})"
            " AND is_correct=1".format(ph), mids).fetchone()[0]
        kn = []
        for r in conn.execute(
                "SELECT knowledge, SUM(total), SUM(correct) FROM mastery_states"
                " WHERE user_id IN ({0}) GROUP BY knowledge ORDER BY 2 DESC".format(ph),
                mids).fetchall():
            kn.append({'knowledge': r[0], 'total': r[1], 'correct': r[2],
                       'accuracy': round(r[2] / r[1], 3) if r[1] else 0})
        wrong = [{'question_id': r[0], 'wrong_count': r[1]}
                 for r in conn.execute(
                     "SELECT question_id, COUNT(*) FROM wrong_book"
                     " WHERE user_id IN ({0}) AND mastered=0"
                     " GROUP BY question_id ORDER BY 2 DESC LIMIT 10".format(ph),
                     mids).fetchall()]
    return {'team': team, 'member_count': len(mids), 'total_attempts': total,
            'avg_accuracy': round(correct / total, 3) if total else 0,
            'knowledge': kn, 'wrong_top': wrong}


def charts_data(user_id=None, scope='me'):
    """仪表盘数据:雷达+趋势+柱状+热力+环形(纯数据,前端用 SVG 画)。
    scope='me' 只算该用户;scope='all' 算全站。"""
    conn = db.get_conn()
    with db.DB_LOCK:
        if scope == 'all' or user_id is None:
            cond = ''
            params = []
        else:
            cond = ' WHERE a.user_id=?'
            params = [user_id]
        radar = []
        for r in conn.execute(
                "SELECT q.category, COUNT(*), COALESCE(SUM(a.is_correct), 0)"
                " FROM attempts a JOIN questions q ON q.id=a.question_id"
                + cond + " AND q.category<>'' GROUP BY q.category",
                params).fetchall():
            radar.append({'knowledge': r[0], 'total': r[1], 'correct': r[2],
                          'accuracy': round(r[2] / r[1], 3) if r[1] else 0})
        trend = [{'date': r[0], 'total': r[1], 'correct': r[2] or 0}
                 for r in conn.execute(
                     "SELECT substr(a.answered_at, 1, 10), COUNT(*), SUM(a.is_correct)"
                     " FROM attempts a" + cond +
                     " GROUP BY 1 ORDER BY 1 DESC LIMIT 14",
                     params).fetchall()]
        trend = list(reversed(trend))
        bar = []
        for r in conn.execute(
                "SELECT q.type, COUNT(*), COALESCE(SUM(a.is_correct), 0)"
                " FROM attempts a JOIN questions q ON q.id=a.question_id"
                + cond + " GROUP BY q.type", params).fetchall():
            bar.append({'type': r[0], 'total': r[1], 'correct': r[2],
                        'accuracy': round(r[2] / r[1], 3) if r[1] else 0})
        heat = {}
        for r in conn.execute(
                "SELECT u.department, m.knowledge, SUM(m.total), SUM(m.correct)"
                " FROM mastery_states m JOIN users u ON u.id=m.user_id"
                " GROUP BY u.department, m.knowledge").fetchall():
            heat.setdefault(r[1], {})[r[0]] = round(r[3] / r[2], 2) if r[2] else 0
        if scope == 'all' or user_id is None:
            tot = conn.execute(
                "SELECT COUNT(*) FROM attempts WHERE is_correct IS NOT NULL").fetchone()[0]
            cor = conn.execute(
                "SELECT COUNT(*) FROM attempts WHERE is_correct=1").fetchone()[0]
            pend = conn.execute(
                "SELECT COUNT(*) FROM attempts WHERE is_correct IS NULL").fetchone()[0]
        else:
            tot = conn.execute(
                "SELECT COUNT(*) FROM attempts WHERE user_id=?"
                " AND is_correct IS NOT NULL", (user_id,)).fetchone()[0]
            cor = conn.execute(
                "SELECT COUNT(*) FROM attempts WHERE user_id=? AND is_correct=1",
                (user_id,)).fetchone()[0]
            pend = conn.execute(
                "SELECT COUNT(*) FROM attempts WHERE user_id=?"
                " AND is_correct IS NULL", (user_id,)).fetchone()[0]
    ring = {'correct': cor, 'wrong': tot - cor, 'pending': pend, 'total': tot + pend}
    return {'radar': radar, 'trend': trend, 'bar': bar, 'heatmap': heat,
            'ring': ring}
