# -*- coding: utf-8 -*-
"""常熟站智考通 v2.3 — Excel(.xlsx)导入:纯标准库(zipfile + xml)。

模板列(与 question-import-template.xlsx 一致):
题型 | 题干 | 选项A | 选项B | 选项C | 另项D | 选项E | 答案 | 解析 | 科目 | 知识点 | 难度 | 来源 | 题干图片说明
题型也接受 single/multi/judge/fill/short。判断答案填 对/错。
图片:直接插在 Excel 里的浮动图按锚定行挂到对应题上,图片存入 data/assets/,
题里只存文件名引用。
另含用户批量导入解析(parse_user_rows):列 用户名/姓名/部门/角色/密码。
Python 3.4 兼容语法。
"""
import os
import re
import zipfile
import xml.etree.ElementTree as ET

import questions as qmod

NS = {'m': 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
NS_D = {'m': 'http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing'}


def _col_letters(cell_ref):
    m = re.match(r'([A-Z]+)(\d+)', cell_ref or '')
    if not m:
        return '', 0
    return m.group(1), int(m.group(2))


def _col_index(letters):
    n = 0
    for ch in letters:
        n = n * 26 + (ord(ch) - ord('A') + 1)
    return n


def _cell_text(cell, shared):
    t = cell.get('t')
    if t == 's':
        v = cell.find('m:v', NS)
        if v is not None and v.text is not None:
            try:
                return shared[int(v.text)]
            except (ValueError, IndexError):
                return ''
        return ''
    if t == 'inlineStr':
        parts = []
        for node in cell.iter('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t'):
            parts.append(node.text or '')
        return ''.join(parts)
    v = cell.find('m:v', NS)
    if v is not None and v.text is not None:
        return v.text
    parts = []
    for node in cell.iter('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t'):
        parts.append(node.text or '')
    return ''.join(parts)


def _read_shared_strings(zf):
    shared = []
    try:
        data = zf.read('xl/sharedStrings.xml')
    except KeyError:
        return shared
    root = ET.fromstring(data)
    for si in root.findall('m:si', NS):
        parts = []
        for node in si.iter('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t'):
            parts.append(node.text or '')
        shared.append(''.join(parts))
    return shared


def _sheet_names(zf):
    try:
        root = ET.fromstring(zf.read('xl/workbook.xml'))
    except KeyError:
        return []
    names = []
    for sh in root.iter('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}sheet'):
        names.append(sh.get('name'))
    return names


def _sheet_path(zf, index):
    # xl/worksheets/sheetN.xml 按 workbook 顺序对应
    return 'xl/worksheets/sheet{0}.xml'.format(index + 1)


def parse_xlsx_bytes(data):
    """返回 (rows, errors):rows 为每行 dict(列名->文本),errors 为解析级错误。"""
    import io
    zf = zipfile.ZipFile(io.BytesIO(data))
    shared = _read_shared_strings(zf)
    names = _sheet_names(zf)
    # 优先找名为"题库"/"用户"的页,否则第 1 页
    idx = 0
    for i, name in enumerate(names):
        if name in ('题库', '题目'):
            idx = i
            break
    try:
        root = ET.fromstring(zf.read(_sheet_path(zf, idx)))
    except KeyError:
        return [], ["找不到工作表"]
    rows = []
    for row_el in root.iter('{http://schemas.openxmlformats.org/spreadsheetml/2006/main}row'):
        vals = {}
        for cell in row_el.findall('m:c', NS):
            ref = cell.get('r') or ''
            letters, _num = _col_letters(ref)
            vals[_col_index(letters)] = _cell_text(cell, shared)
        rows.append(vals)
    return rows, []


def _header_map(header_row):
    mapping = {}
    for col_idx, text in header_row.items():
        t = (text or '').strip()
        mapping[t] = col_idx
    return mapping


def parse_question_xlsx(data, assets_dir=''):
    """解析题库 xlsx,返回 (ok_list, bad_list)。
    ok_list:可直接 create_question 的 dict;bad_list:{row, error}。
    带图:浮动图按行挂题,图片写入 assets_dir,返回的文件名进 image 字段。"""
    rows, errors = parse_xlsx_bytes(data)
    ok_list = []
    bad_list = []
    for e in errors:
        bad_list.append({'row': 0, 'error': e})
    if not rows:
        bad_list.append({'row': 0, 'error': '文件为空或无工作表'})
        return ok_list, bad_list
    header = _header_map(rows[0])
    # 图片:读 drawing,按锚定行映射
    images_by_row = {}
    if assets_dir:
        images_by_row = _extract_images(data, assets_dir)
    # 列定位:按表头文字找,找不到则按模板默认列序
    def col(*names, **kw):
        for n in names:
            if n in header:
                return header[n]
        return kw.get('default')
    c_type = col('题型', default=1)
    c_stem = col('题干', default=2)
    c_ans = col('答案', default=8)
    c_ana = col('解析', default=9)
    c_cat = col('科目', '分类', default=10)
    opt_cols = {}
    for letter in 'ABCDE':
        opt_cols[letter] = col('选项' + letter, default=2 + (ord(letter) - ord('A')) + 1)
    for rno, row in enumerate(rows[1:], start=2):
        stem = (row.get(c_stem) or '').strip()
        if not stem and not (row.get(c_type) or '').strip():
            continue
        opts = {}
        for letter in 'ABCDE':
            v = (row.get(opt_cols[letter]) or '').strip()
            if v:
                opts[letter] = v
        q = {
            'type': (row.get(c_type) or '').strip(),
            'stem': stem,
            'options': opts,
            'answer': (row.get(c_ans) or '').strip(),
            'analysis': (row.get(c_ana) or '').strip(),
            'category': (row.get(c_cat) or '').strip(),
            'image': images_by_row.get(rno, ''),
        }
        err = qmod.validate_question(q)
        if err:
            bad_list.append({'row': rno, 'error': err})
        else:
            q['type'] = qmod.normalize_type(q['type'])
            ok_list.append(q)
    return ok_list, bad_list


def _extract_images(data, assets_dir):
    """从 xlsx 的 drawing 里按锚定行取图,写入 assets_dir,返回 {行号: 文件名}。"""
    import io
    out = {}
    try:
        os.makedirs(assets_dir)
    except OSError:
        pass
    zf = zipfile.ZipFile(io.BytesIO(data))
    # media 文件
    media = {}
    for name in zf.namelist():
        if name.startswith('xl/media/'):
            media[os.path.basename(name)] = name
    if not media:
        return out
    # drawing rels: rId -> media
    rels = {}
    try:
        rel_root = ET.fromstring(zf.read('xl/drawings/_rels/drawing1.xml.rels'))
        for rel in rel_root:
            target = rel.get('Target') or ''
            if 'media/' in target:
                rels[rel.get('Id')] = os.path.basename(target)
    except KeyError:
        pass
    try:
        droot = ET.fromstring(zf.read('xl/drawings/drawing1.xml'))
    except KeyError:
        return out
    for anchor in droot:
        # oneCellAnchor / twoCellAnchor
        frm = anchor.find('.//{http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing}from')
        pic = anchor.find('.//{http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing}pic')
        if frm is None or pic is None:
            continue
        row_el = frm.find('{http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing}row')
        if row_el is None or row_el.text is None:
            continue
        row_no = int(row_el.text) + 1
        blip = pic.find('.//{http://schemas.openxmlformats.org/drawingml/2006/main}blip')
        if blip is None:
            continue
        rid = blip.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed')
        fname = rels.get(rid)
        if not fname or fname not in media:
            continue
        ext = os.path.splitext(fname)[1] or '.png'
        save_name = 'qimg_{0}{1}'.format(row_no, ext)
        try:
            with open(os.path.join(assets_dir, save_name), 'wb') as f:
                f.write(zf.read(media[fname]))
            out[row_no] = save_name
        except (OSError, KeyError):
            pass
    return out


def parse_user_xlsx(data):
    """用户批量导入:列 用户名/姓名/部门/角色/密码。
    返回 (ok_list, bad_list);ok_list 元素 {username, name, department, role, password}。"""
    rows, errors = parse_xlsx_bytes(data)
    ok_list = []
    bad_list = []
    for e in errors:
        bad_list.append({'row': 0, 'error': e})
    if not rows:
        bad_list.append({'row': 0, 'error': '文件为空或无工作表'})
        return ok_list, bad_list
    header = _header_map(rows[0])

    def col(*names, **kw):
        for n in names:
            if n in header:
                return header[n]
        return kw.get('default')
    c_user = col('用户名', default=1)
    c_name = col('姓名', default=2)
    c_dept = col('部门', default=3)
    c_role = col('角色', default=4)
    c_pw = col('密码', '初始密码', default=5)
    role_map = {'管理员': 'admin', 'admin': 'admin', '考官': 'examiner',
                'examiner': 'examiner', '学员': 'student', 'student': 'student',
                '民警': 'student'}
    for rno, row in enumerate(rows[1:], start=2):
        username = (row.get(c_user) or '').strip()
        name = (row.get(c_name) or '').strip()
        if not username and not name:
            continue
        if not username:
            bad_list.append({'row': rno, 'error': '用户名为空'})
            continue
        if not name:
            bad_list.append({'row': rno, 'error': '姓名不能为空'})
            continue
        pw = (row.get(c_pw) or '').strip() or '123456'
        if len(pw) < 6:
            bad_list.append({'row': rno, 'error': '密码至少 6 位'})
            continue
        role = role_map.get((row.get(c_role) or '').strip(), 'student')
        ok_list.append({'username': username, 'name': name,
                        'department': (row.get(c_dept) or '').strip(),
                        'role': role, 'password': pw})
    return ok_list, bad_list
