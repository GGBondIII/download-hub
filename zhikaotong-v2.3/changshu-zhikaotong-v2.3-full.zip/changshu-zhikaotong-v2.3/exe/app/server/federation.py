# -*- coding: utf-8 -*-
"""常熟站智考通 v2.3 — 跨主机联邦共享:登记/测试/删除、目录、打包(SHA-256)、拉取。

照抄刷题宝 v0.7 server.py 1517–1553、2141、2675–2822、3103–3307 行的逻辑。
只开放题库目录与题目,不开放成绩/密码/用户信息;拉取包先验 SHA-256 再入库,
去重后进草稿待审核。Python 3.4 兼容语法(不用 secrets 模块,用 os.urandom)。
"""
import base64
import hashlib
import json
import os
import urllib.error
import urllib.request

import db
import auth
import questions as qmod

FED_TIMEOUT = 10
VERSION = 'v2.3'


def _data_dir():
    return os.path.dirname(db.DB_PATH or '')


def _assets_dir():
    return os.path.join(_data_dir(), 'assets')


def fed_token():
    tok = db.get_setting('fed_token', '')
    if not tok:
        tok = ''.join('%02x' % b for b in bytearray(os.urandom(24)))
        db.set_setting('fed_token', tok)
    return tok


def rotate_token():
    tok = ''.join('%02x' % b for b in bytearray(os.urandom(24)))
    db.set_setting('fed_token', tok)
    return tok


def content_hash(stem, answer, options):
    raw = json.dumps([stem.strip(), str(answer).strip(),
                      [str(o).strip() for o in options]], ensure_ascii=False)
    return hashlib.sha256(raw.encode('utf-8')).hexdigest()


def list_hosts():
    conn = db.get_conn()
    with db.DB_LOCK:
        rows = conn.execute(
            "SELECT id, name, host, port, status, last_seen, last_error,"
            " last_count, created_at FROM peer_hosts ORDER BY id").fetchall()
    return [db.row_to_dict(r) for r in rows]


def register_host(name, host, port, token):
    name = (name or '').strip()
    host = (host or '').strip()
    token = (token or '').strip()
    try:
        port = int(port or 8766)
    except (TypeError, ValueError):
        return None, "端口要是数字"
    if not name or not host or not token:
        return None, "名称、对方主机地址、共享令牌都要填"
    if '://' in host or '/' in host or ' ' in host:
        return None, "对方主机地址只填 IP 或主机名,不要带 http:// 和路径"
    if not (1 <= port <= 65535):
        return None, "端口应在 1 到 65535 之间"
    conn = db.get_conn()
    with db.DB_LOCK:
        ex = conn.execute("SELECT id FROM peer_hosts WHERE host=? AND port=?",
                          (host, port)).fetchone()
        if ex:
            conn.execute("UPDATE peer_hosts SET name=?, token=?, status='enabled'"
                         " WHERE id=?", (name, token, ex['id']))
            hid = ex['id']
        else:
            cur = conn.execute(
                "INSERT INTO peer_hosts(name, host, port, token, status, created_at)"
                " VALUES(?, ?, ?, ?, 'enabled', datetime('now', 'localtime'))",
                (name, host, port, token))
            hid = cur.lastrowid
        conn.commit()
    return {'host_id': hid}, ""


def delete_host(hid):
    conn = db.get_conn()
    with db.DB_LOCK:
        cur = conn.execute("DELETE FROM peer_hosts WHERE id=?", (hid,))
        conn.commit()
    if cur.rowcount == 0:
        return False, "主机不存在"
    return True, ""


def fed_request(host, port, token, method, api_path, body=None, timeout=FED_TIMEOUT):
    url = "http://{0}:{1}{2}".format(host, port, api_path)
    sep = '&' if '?' in url else '?'
    url = url + sep + "token=" + token
    data = json.dumps(body, ensure_ascii=False).encode('utf-8') if body is not None else None
    req = urllib.request.Request(url, data=data, method=method,
                                 headers={'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read().decode('utf-8'))
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode('utf-8')).get('error',
                                                           "对方返回 HTTP {0}".format(e.code))
        except Exception:
            msg = "对方返回 HTTP {0}".format(e.code)
        raise ValueError(msg)
    except Exception as e:
        raise ValueError("连不上对方主机({0}:{1}):{2}".format(host, port, e))


def test_host(hid):
    conn = db.get_conn()
    with db.DB_LOCK:
        h = conn.execute("SELECT * FROM peer_hosts WHERE id=?", (hid,)).fetchone()
    if h is None:
        return None, "主机不存在"
    try:
        cat = fed_request(h['host'], h['port'], h['token'], 'GET',
                          '/api/v2/federation/catalog')
        n = (cat.get('catalog') or {}).get('question_count', 0)
        with db.DB_LOCK:
            conn.execute(
                "UPDATE peer_hosts SET last_seen=datetime('now', 'localtime'),"
                " last_error='', last_count=? WHERE id=?", (n, hid))
            conn.commit()
        return {'catalog': cat.get('catalog')}, ""
    except Exception as e:
        with db.DB_LOCK:
            conn.execute("UPDATE peer_hosts SET last_error=? WHERE id=?",
                         (str(e)[:200], hid))
            conn.commit()
        return None, str(e)


def catalog_data():
    """本机题库目录(只给对方主机拉目录用,调用方须先验 fed_token)。"""
    conn = db.get_conn()
    with db.DB_LOCK:
        n = conn.execute(
            "SELECT COUNT(*) FROM questions WHERE status='启用'").fetchone()[0]
        subs = [r[0] for r in conn.execute(
            "SELECT DISTINCT category FROM questions WHERE status='启用'"
            " AND category<>'' ORDER BY category").fetchall()]
    return {'name': '常熟站智考通', 'version': VERSION,
            'question_count': n, 'subjects': subs}


def build_package(body):
    """打包已发布题(只发题目+选项+图片,不发成绩/密码/用户信息)。返回 (pkg, sha)。"""
    conn = db.get_conn()
    qids = body.get('question_ids') or []
    rows = []
    with db.DB_LOCK:
        if qids:
            for x in qids[:500]:
                try:
                    row = qmod.get_question(int(x))
                except (TypeError, ValueError):
                    row = None
                if row is not None and row['status'] == '启用':
                    rows.append(row)
        else:
            subj = (body.get('subject') or '').strip()
            try:
                limit = min(max(int(body.get('limit') or 50), 1), 500)
            except (TypeError, ValueError):
                limit = 50
            if subj:
                ids = conn.execute(
                    "SELECT id FROM questions WHERE status='启用' AND category=?"
                    " ORDER BY id LIMIT ?", (subj, limit)).fetchall()
            else:
                ids = conn.execute(
                    "SELECT id FROM questions WHERE status='启用'"
                    " ORDER BY id LIMIT ?", (limit,)).fetchall()
            rows = [qmod.get_question(r[0]) for r in ids]
            rows = [r for r in rows if r is not None]
    pkg_qs = []
    for row in rows:
        q = qmod.question_to_dict(row)
        opts = q.get('options') or {}
        opt_list = [opts[k] for k in sorted(opts.keys())]
        assets = []
        img = q.get('image') or ''
        if img:
            fp = os.path.join(_assets_dir(), os.path.basename(img))
            if os.path.isfile(fp):
                try:
                    with open(fp, 'rb') as f:
                        assets.append({'filename': os.path.basename(fp),
                                       'mime': 'image/png',
                                       'option_label': None,
                                       'data_b64': base64.b64encode(f.read()).decode()})
                except OSError:
                    pass
        pkg_qs.append({'type': q['type'], 'stem': q['stem'], 'answer': q['answer'],
                       'explanation': q.get('analysis') or '',
                       'subject': q.get('category') or '',
                       'difficulty': q.get('difficulty') or 3,
                       'knowledge': [q.get('category') or '未分类'],
                       'rubric': q.get('rubric') or '',
                       'max_score': q.get('max_score') or 10,
                       'options': opt_list, 'assets': assets})
    pkg = {'from': '常熟站智考通', 'version': VERSION,
           'exported_at': auth.now_iso(), 'questions': pkg_qs}
    sha = hashlib.sha256(
        json.dumps(pkg, ensure_ascii=False, sort_keys=True).encode('utf-8')).hexdigest()
    return pkg, sha


def pull_from_host(host_id, body, username):
    """从对方主机拉取题库包:验 SHA-256、去重、进草稿待审核。"""
    import import_jobs
    conn = db.get_conn()
    with db.DB_LOCK:
        h = conn.execute("SELECT * FROM peer_hosts WHERE id=?", (host_id,)).fetchone()
    if h is None:
        return None, "对方主机不存在"
    if h['status'] != 'enabled':
        return None, "该主机已停用,请先在登记里恢复"
    try:
        res = fed_request(h['host'], h['port'], h['token'], 'POST',
                          '/api/v2/federation/package',
                          {'question_ids': body.get('question_ids') or [],
                           'subject': body.get('subject') or '',
                           'limit': body.get('limit') or 50})
    except Exception as e:
        return None, str(e)
    pkg = res.get('package') or {}
    sha = res.get('sha256', '')
    expect = hashlib.sha256(
        json.dumps(pkg, ensure_ascii=False, sort_keys=True).encode('utf-8')).hexdigest()
    if sha != expect:
        return None, "共享包哈希校验失败,已拒绝导入(可能传输中被改动)"
    incoming = pkg.get('questions') or []
    if not incoming:
        return None, "对方题库里没有可拉取的题目"
    peer_label = "联邦:{0}".format(h['name'])
    with db.DB_LOCK:
        cur = conn.execute(
            "INSERT INTO import_jobs(filename, file_type, total_rows, ok_rows,"
            " bad_rows, status, created_by, created_at)"
            " VALUES(?, 'federation', ?, 0, 0, 'parsed', ?,"
            " datetime('now', 'localtime'))",
            ("联邦包@{0}({1} 题)".format(h['name'], len(incoming)),
             len(incoming), username))
        job_id = cur.lastrowid
        existing = {}
        for r in conn.execute("SELECT id, stem, answer FROM questions").fetchall():
            opts = []
            try:
                od = json.loads(conn.execute(
                    "SELECT options FROM questions WHERE id=?", (r[0],)).fetchone()[0] or '{}')
                opts = [od[k] for k in sorted(od.keys())]
            except Exception:
                opts = []
            existing[content_hash(r[1], r[2], opts)] = r[0]
        imported = 0
        skipped = 0
        for i, q in enumerate(incoming):
            opts = q.get('options') or []
            hh = content_hash(q.get('stem', ''), q.get('answer', ''), opts)
            if hh in existing:
                skipped += 1
                continue
            d = {'row_no': i + 1, 'stem': q.get('stem', ''),
                 'type': q.get('type', '单选'), 'answer': q.get('answer', ''),
                 'explanation': q.get('explanation', ''),
                 'subject': q.get('subject', '未分类'),
                 'knowledge': q.get('knowledge') or ['未分类'],
                 'difficulty': q.get('difficulty', 3),
                 'rubric': q.get('rubric', ''),
                 'max_score': q.get('max_score', 10),
                 'options_list': opts}
            cleaned, verr = import_jobs.validate_row(d)
            if verr:
                conn.execute(
                    "INSERT INTO import_items(job_id, row_no, raw_json, error, status)"
                    " VALUES(?, ?, ?, ?, 'bad')",
                    (job_id, i + 1, json.dumps(d, ensure_ascii=False), verr))
                continue
            qid = import_jobs.insert_cleaned_question(conn, cleaned,
                                                      peer_label, username)
            for a in q.get('assets') or []:
                try:
                    blob = base64.b64decode(a.get('data_b64', ''))
                    if blob:
                        import pairing as pairing_mod
                        pairing_mod.save_asset(conn, qid, blob,
                                               a.get('filename', 'image.png'),
                                               a.get('mime', 'image/png'),
                                               a.get('option_label'))
                except Exception:
                    continue
            conn.execute(
                "INSERT INTO import_items(job_id, row_no, raw_json, error, status)"
                " VALUES(?, ?, ?, '', 'ok')",
                (job_id, i + 1, json.dumps(cleaned, ensure_ascii=False)))
            conn.execute(
                "INSERT INTO review_queue(job_id, question_id, row_no, reason, status)"
                " VALUES(?, ?, ?, '联邦拉取,待审核', 'pending')",
                (job_id, qid, i + 1))
            existing[hh] = qid
            imported += 1
        conn.execute(
            "UPDATE import_jobs SET ok_rows=?, bad_rows=? WHERE id=?",
            (imported, len(incoming) - imported - skipped, job_id))
        conn.execute(
            "INSERT INTO federation_packages(host_id, direction, filename, sha256,"
            " question_count, status, created_by, created_at)"
            " VALUES(?, 'in', ?, ?, ?, 'ok', ?, datetime('now', 'localtime'))",
            (host_id, "联邦包@{0}".format(h['name']), sha, imported, username))
        conn.commit()
    db.audit(username, 'fed_pull',
             "从 {0} 拉取联邦包:新题 {1},去重跳过 {2},进草稿待审核(任务 {3})".format(
                 h['name'], imported, skipped, job_id))
    return {'job_id': job_id, 'imported': imported, 'skipped_dup': skipped,
            'total': len(incoming), 'sha256': sha,
            'message': "已拉取 {0} 道新题进草稿(去重 {1} 道),请在“题库导入”里审核后发布".format(
                imported, skipped)}, ""


def list_packages():
    conn = db.get_conn()
    with db.DB_LOCK:
        rows = conn.execute(
            "SELECT * FROM federation_packages ORDER BY id DESC LIMIT 100").fetchall()
    return [db.row_to_dict(r) for r in rows]


def lan_ip():
    try:
        import socket
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return '127.0.0.1'
