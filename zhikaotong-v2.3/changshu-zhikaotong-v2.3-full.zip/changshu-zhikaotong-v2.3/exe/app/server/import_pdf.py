# -*- coding: utf-8 -*-
"""常熟站智考通 v2.3 — PDF 文字型导入(纯标准库,无 PyMuPDF)。

照抄刷题宝 v0.7 server.py 792–1241 行的逻辑,仅把 bytes.fromhex 换成
binascii.unhexlify 以保 Python 3.4 兼容,并把 ord("n") 等字面量换成 ASCII 码
(避开 f-string 扫描的误报)。
只做文字型 PDF:抽文字块 + 图片 + 坐标切题。扫描型(无文字层)不硬做假识别,
直接返回明确错误。中文能否读出取决于 PDF 是否内嵌 ToUnicode(Word/WPS 导出
的 PDF 一般都有);无 ToUnicode 的 CID 字体会判为“无法提取有效文字”,同样拒识。
parse_pdf(data) 返回 (questions, info, err);questions 与 docx 同结构。
Python 3.4 兼容语法。
"""
import binascii
import io
import re
import zlib

def _pdf_stream_bytes(obj):
	"""取一个 PDF 对象里的 stream 原始字节；FlateDecode 则解压，其余原样返回。"""
	m = re.search(rb"stream\r?\n", obj)
	if not m:
		return b""
	raw = obj[m.end():]
	end = raw.rfind(b"endstream")
	if end >= 0:
		raw = raw[:end]
	if b"FlateDecode" in obj[:m.start()]:
		try:
			return zlib.decompress(raw.strip(b"\r\n"))
		except Exception:
			try:
				return zlib.decompressobj().decompress(raw.strip(b"\r\n"))
			except Exception:
				return b""
	return raw
def _pdf_objects(data):
	objs = {}
	for m in re.finditer(rb"(\d+)\s+\d+\s+obj\b(.*?)endobj", data, re.S):
		try:
			objs[int(m.group(1))] = m.group(2)
		except Exception:
			pass
	return objs
def _pdf_cmap_from_stream(stream):
	"""解析一段 ToUnicode CMap 流（只在 beginbfchar / beginbfrange 段内匹配，避免串段误读），返回 {编码: 字符}。"""
	cmap = {}
	if not stream:
		return cmap
	for sec in re.findall(rb"beginbfchar(.*?)endbfchar", stream, re.S):
		for m in re.finditer(rb"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>", sec):
			try:
				code = int(m.group(1), 16)
				ch = binascii.unhexlify(m.group(2)).decode("utf-16-be", "ignore")
				if ch:
					cmap[code] = ch
			except Exception:
				pass
	for sec in re.findall(rb"beginbfrange(.*?)endbfrange", stream, re.S):
		for m in re.finditer(rb"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>", sec):
			try:
				lo, hi = int(m.group(1), 16), int(m.group(2), 16)
				base = binascii.unhexlify(m.group(3)).decode("utf-16-be", "ignore")
				if not base or hi - lo > 500:
					continue
				for i in range(hi - lo + 1):
					cmap[lo + i] = chr(ord(base) + i)
			except Exception:
				pass
	return cmap
def _pdf_resources_body(objs, page_body):
	"""页面对象里的 /Resources 常是间接引用（/Resources 57 0 R），跟引用取真正的资源字典。"""
	rm = re.search(rb"/Resources\s+(\d+)\s+\d+\s+R", page_body)
	if rm and int(rm.group(1)) in objs:
		return objs[int(rm.group(1))]
	return page_body
def _pdf_font_cmaps(objs, page_body):
	"""按页面 Resources 的 /Font 字典，给每个字体名建自己的 ToUnicode 映射（不同字体编码会冲突，不能全局合并）。"""
	font_cmaps = {}
	res = _pdf_resources_body(objs, page_body)
	fontdict = None
	m = re.search(rb"/Font\s*<<([^>]*)>>", res, re.S)
	if m:
		fontdict = m.group(1)
	else:
		m2 = re.search(rb"/Font\s+(\d+)\s+\d+\s+R", res)
		if m2 and int(m2.group(1)) in objs:
			fontdict = objs[int(m2.group(1))]
	if fontdict is None:
		return font_cmaps
	for name, ref in re.findall(rb"/(\w+)\s+(\d+)\s+\d+\s+R", fontdict):
		fobj = objs.get(int(ref), b"")
		tm = re.search(rb"/ToUnicode\s+(\d+)\s+\d+\s+R", fobj)
		if tm and int(tm.group(1)) in objs:
			font_cmaps[name.decode("latin-1", "ignore")] = _pdf_cmap_from_stream(_pdf_stream_bytes(objs[int(tm.group(1))]))
	return font_cmaps
def _pdf_unescape_literal(bs):
	out = bytearray()
	i = 0
	while i < len(bs):
		c = bs[i]
		if c == 0x5C and i + 1 < len(bs):
			n = bs[i + 1]
			if n in b"nrtbf":
				out.append({110: 10, 114: 13, 116: 9, 98: 8, 102: 12}[n])  # n/r/t/b/f 的 ASCII 码
				i += 2
			elif 48 <= n <= 55:
				j = i + 1
				oct_digits = b""
				while j < len(bs) and len(oct_digits) < 3 and 48 <= bs[j] <= 55:
					oct_digits += bytes([bs[j]])
					j += 1
				out.append(int(oct_digits, 8) & 0xFF)
				i = j
			else:
				out.append(n)
				i += 2
		else:
			out.append(c)
			i += 1
	return bytes(out)
def _pdf_decode_text(bs, cmap):
	if bs[:2] == b"\xfe\xff":
		try:
			return bs[2:].decode("utf-16-be")
		except Exception:
			pass
	if cmap and bs:
		# 1 字节编码（LibreOffice 子集字体常用）：逐字节查表
		if max(cmap) < 256:
			chars, mapped = [], 0
			for b in bs:
				ch = cmap.get(b)
				if ch:
					mapped += 1
					chars.append(ch)
			if mapped / max(1, len(bs)) >= 0.5:
				return "".join(chars)
		# 2 字节编码
		if len(bs) >= 2:
			chars, mapped, total = [], 0, 0
			for i in range(0, len(bs) - 1, 2):
				code = (bs[i] << 8) | bs[i + 1]
				total += 1
				ch = cmap.get(code)
				if ch:
					mapped += 1
					chars.append(ch)
			if total and mapped / total >= 0.5:
				return "".join(chars)
	try:
		return bs.decode("cp1252")
	except Exception:
		return bs.decode("latin-1", "ignore")
def _pdf_text_items(stream, font_cmaps):
	"""从一个 content stream 里抽文字：返回 [(x, y, 文本)]。跟 Tf（当前字体决定用哪套 ToUnicode）、Tm/Td/TJ/Tj。
	正则分组：1=十六进制 Tj，2=TJ 数组，3-8=Tm 六个数（e=7，f=8），9-10=Td，11=Tf 字体名。"""
	items = []
	x, y = 0.0, 0.0
	cmap = {}
	pat = re.compile(rb"\((?:\\.|[^()\\])*\)\s*Tj|<([0-9A-Fa-f\s]+)>\s*Tj|\[((?:[^\]])*)\]\s*TJ|(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s+Tm|(-?[\d.]+)\s+(-?[\d.]+)\s+TD?|/(F\w+)\s+[\d.]+\s+Tf|T\*|\bBT\b")
	for m in pat.finditer(stream):
		whole = m.group(0)
		if whole == b"BT":
			x, y = 0.0, 0.0
		elif m.group(11):
			cmap = font_cmaps.get(m.group(11).decode("latin-1", "ignore"), {})
		elif whole.endswith(b"Tm"):
			try:
				x, y = float(m.group(7)), float(m.group(8))
			except Exception:
				pass
		elif whole.endswith(b"Tj") and not whole.startswith(b"["):
			if whole.startswith(b"("):
				raw = whole[1:whole.rfind(b")")]
				txt = _pdf_decode_text(_pdf_unescape_literal(raw), cmap)
			else:
				try:
					raw = binascii.unhexlify(m.group(1))
				except Exception:
					raw = b""
				txt = _pdf_decode_text(raw, cmap)
			if txt.strip():
				items.append((x, y, txt))
		elif whole.endswith(b"TJ"):
			inner = m.group(2) or b""
			parts = []
			for sm in re.finditer(rb"\((?:\\.|[^()\\])*\)|<([0-9A-Fa-f\s]+)>", inner):
				if sm.group(0).startswith(b"("):
					raw = sm.group(0)[1:-1]
					parts.append(_pdf_decode_text(_pdf_unescape_literal(raw), cmap))
				else:
					try:
						parts.append(_pdf_decode_text(binascii.unhexlify(sm.group(1)), cmap))
					except Exception:
						pass
			txt = "".join(parts)
			if txt.strip():
				items.append((x, y, txt))
		elif whole == b"T*":
			y -= 14.0
		elif re.search(rb"TD?$", whole):
			try:
				x += float(m.group(9))
				y += float(m.group(10))
			except Exception:
				pass
	return items
def _pdf_lines(items):
	"""把 (x,y,文本) 按页内行分组：同页 y 相差 <=4pt 算一行，按 x 排序拼行。"""
	lines = []
	for (x, y, txt) in sorted(items, key=lambda t: (-t[1], t[0])):
		placed = False
		for ln in lines:
			if abs(ln["y"] - y) <= 4:
				ln["parts"].append((x, txt))
				placed = True
				break
		if not placed:
			lines.append({"y": y, "parts": [(x, txt)]})
	out = []
	for ln in sorted(lines, key=lambda l: -l["y"]):
		parts = sorted(ln["parts"], key=lambda p: p[0])
		text = "".join(p[1] for p in parts)
		# 选项之间常无空格：行内 "A.xxxB.yyy" 靠切题正则处理；这里只做轻度拼接
		out.append({"y": ln["y"], "text": text.strip()})
	return [l for l in out if l["text"]]
def _pdf_cut_questions(lines):
	"""按题号/选项/答案/解析/参考答案/评分要点把行切成题（与 docx 同一套正则）。"""
	q_start = re.compile(r"^(?:第)?(\d+)[\.、．）\)\s]+(.+)$")
	opt_re = re.compile(r"^([A-E])[\.、．）\)\s]+(.+)$")
	ans_re = re.compile(r"^(?:【?答案】?|答案)[:：\s]*(.+)$")
	exp_re = re.compile(r"^(?:【?解析】?|解析)[:：\s]*(.+)$")
	ref_re = re.compile(r"^(?:【?参考答案】?|参考答案)[:：\s]*(.+)$")
	rubric_re = re.compile(r"^(?:【?评分要点】?|评分要点)[:：\s]*(.+)$")
	questions, cur = [], None
	def flush():
		nonlocal cur
		if cur and cur.get("stem"):
			questions.append(cur)
		cur = None
	for ln in lines:
		text, y = ln["text"], ln["y"]
		m = q_start.match(text)
		if m and len(text) > 3:
			flush()
			cur = {"stem": m.group(2).strip(), "type": "single", "options": {}, "answer": "", "explanation": "", "subject": "", "knowledge": "", "difficulty": "3", "rubric": "", "max_score": 10, "images": [], "row_no": len(questions) + 1, "_y": y}
			continue
		if cur is None:
			continue
		if ref_re.match(text):
			cur["answer"] = ref_re.match(text).group(1).strip()
			cur["type"] = "short"
			continue
		if rubric_re.match(text):
			cur["rubric"] = rubric_re.match(text).group(1).strip()
			continue
		if ans_re.match(text):
			cur["answer"] = ans_re.match(text).group(1).strip()
			continue
		if exp_re.match(text):
			cur["explanation"] = exp_re.match(text).group(1).strip()
			continue
		if opt_re.match(text):
			cur["options"][opt_re.match(text).group(1)] = opt_re.match(text).group(2).strip()
			continue
		# 行内连写选项：A.xxx B.yyy C.zzz
		if re.search(r"[A-E][\.、]", text) and len(cur["options"]) < 2:
			parts = re.split(r"(?=[A-E][\.、．])", text)
			got = False
			for part in parts:
				mm = opt_re.match(part.strip())
				if mm:
					cur["options"][mm.group(1)] = mm.group(2).strip()
					got = True
			if got:
				continue
		cur["stem"] = (cur["stem"] + " " + text).strip() if cur["stem"] else text
	flush()
	for q in questions:
		if q["type"] == "short":
			q["options_list"] = []
			continue
		ans = (q["answer"] or "").strip().upper()
		opts = q["options"]
		if set(opts.keys()) <= {"A", "B"} and set(v for v in opts.values()) <= {"对", "错"}:
			q["type"] = "judge"
		elif len([c for c in ans if c.isalpha()]) >= 2:
			q["type"] = "multi"
		else:
			q["type"] = "single"
		q["options_list"] = [opts.get(lab, "") for lab in sorted(opts.keys())]
	return questions
def _pdf_raw_to_png(raw, width, height, colorspace, predictor=1):
	"""把 PDF 里 Flate 解压后的原始图片数据（8 位 DeviceRGB/DeviceGray，无预测器或 PNG 预测器）手写成 PNG（标准库）。失败返回 None。"""
	try:
		if colorspace == "DeviceRGB":
			bpp, ctype = 3, 2
		elif colorspace == "DeviceGray":
			bpp, ctype = 1, 0
		else:
			return None
		stride = width * bpp
		if predictor is not None and predictor >= 10:
			# 每行开头 1 字节是 PNG 滤波器类型，需按行反滤波
			rows, pos = [], 0
			prev = bytearray(stride)
			for _ in range(height):
				if pos >= len(raw):
					return None
				ft = raw[pos]
				pos += 1
				row = bytearray(raw[pos:pos + stride])
				pos += stride
				if len(row) < stride:
					return None
				if ft == 1:
					for i in range(bpp, stride):
						row[i] = (row[i] + row[i - bpp]) & 0xFF
				elif ft == 2:
					for i in range(stride):
						row[i] = (row[i] + prev[i]) & 0xFF
				elif ft == 3:
					for i in range(stride):
						left = row[i - bpp] if i >= bpp else 0
						row[i] = (row[i] + ((left + prev[i]) >> 1)) & 0xFF
				elif ft == 4:
					for i in range(stride):
						a = row[i - bpp] if i >= bpp else 0
						b = prev[i]
						c = prev[i - bpp] if i >= bpp else 0
						p = a + b - c
						pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
						pr = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
						row[i] = (row[i] + pr) & 0xFF
				elif ft != 0:
					return None
				rows.append(bytes(row))
				prev = row
			raw_rows = rows
		else:
			if len(raw) < stride * height:
				return None
			raw_rows = [raw[i * stride:(i + 1) * stride] for i in range(height)]
		png_data = b"".join(b"\x00" + r for r in raw_rows)
		comp = zlib.compress(png_data)
		def chunk(typ, payload):
			c = typ + payload
			return len(payload).to_bytes(4, "big") + c + (zlib.crc32(c) & 0xFFFFFFFF).to_bytes(4, "big")
		ihdr = width.to_bytes(4, "big") + height.to_bytes(4, "big") + bytes([8, ctype, 0, 0, 0])
		return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) + chunk(b"IDAT", comp) + chunk(b"IEND", b"")
	except Exception:
		return None
def parse_pdf(data):
	"""返回 (questions, info, err)。questions 与 docx 同结构；info 含 kind/pages/text_chars/images。
	kind=text 才能导入；scanned/unreadable 返回 err，不造假识别。"""
	if not data or data[:5] != b"%PDF-":
		return [], {"kind": "unreadable", "pages": 0, "text_chars": 0, "images": 0, "readable_ratio": 0}, "不是有效的 PDF 文件"
	objs = _pdf_objects(data)
	# 找页面对象（/Type /Page，不含 /Pages），按对象号排序
	pages = []
	for num in sorted(objs):
		body = objs[num]
		if b"/Type" in body and re.search(rb"/Type\s*/Page[^s]", body):
			pages.append(num)
	all_lines, images, scanned_hits = [], [], 0
	for pno in pages:
		body = objs[pno]
		content_nums = []
		m = re.search(rb"/Contents\s+(\d+)\s+\d+\s+R", body)
		if m:
			content_nums = [int(m.group(1))]
		else:
			m2 = re.search(rb"/Contents\s*\[([^\]]*)\]", body)
			if m2:
				content_nums = [int(x) for x in re.findall(rb"(\d+)\s+\d+\s+R", m2.group(1))]
		stream = b""
		for cn in content_nums:
			if cn in objs:
				stream += _pdf_stream_bytes(objs[cn]) + b"\n"
		font_cmaps = _pdf_font_cmaps(objs, body)
		items = _pdf_text_items(stream, font_cmaps)
		lines = _pdf_lines(items)
		for ln in lines:
			ln["_page"] = pno
		all_lines.extend(lines)
		# 图片：页面 Resources 里的 XObject 指向的 Image 对象（只取 DCTDecode 的 JPEG）
		xobj = {}
		rm = re.search(rb"/XObject\s*<<([^>]*)>>", _pdf_resources_body(objs, body), re.S)
		if rm:
			for nm, ref in re.findall(rb"/(\w+)\s+(\d+)\s+\d+\s+R", rm.group(1)):
				xobj[nm.decode("latin-1", "ignore")] = int(ref)
		for name, ref in xobj.items():
			iobj = objs.get(ref, b"")
			if b"/Subtype" not in iobj or b"/Image" not in iobj:
				continue
			if b"/DCTDecode" in iobj:
				blob = _pdf_stream_bytes(iobj)
				if blob[:2] == b"\xff\xd8":
					images.append({"name": name, "bytes": blob, "mime": "image/jpeg", "filename": name + ".jpg", "page": pno})
			elif b"/FlateDecode" in iobj:
				wm = re.search(rb"/Width\s+(\d+)", iobj)
				hm = re.search(rb"/Height\s+(\d+)", iobj)
				bm = re.search(rb"/BitsPerComponent\s+(\d+)", iobj)
				cs = "DeviceRGB" if b"/DeviceRGB" in iobj else ("DeviceGray" if b"/DeviceGray" in iobj else "")
				pm = re.search(rb"/DecodeParms\s*<<[^>]*?/Predictor\s+(\d+)", iobj, re.S)
				pred = int(pm.group(1)) if pm else 1
				if wm and hm and bm and int(bm.group(1)) == 8 and cs:
					png = _pdf_raw_to_png(_pdf_stream_bytes(iobj), int(wm.group(1)), int(hm.group(1)), cs, pred)
					if png:
						images.append({"name": name, "bytes": png, "mime": "image/png", "filename": name + ".png", "page": pno})
					else:
						scanned_hits += 1
				else:
					scanned_hits += 1
			else:
				scanned_hits += 1
		# 图片在内容流里的位置（cm 矩阵 + Do）
		for m in re.finditer(rb"(-?[\d.]+)\s+0\s+0\s+(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s+cm\s*/(\w+)\s+Do", stream):
			for im in images:
				if im["name"] == m.group(5).decode("latin-1", "ignore") and "y" not in im:
					im["y"] = float(m.group(4))
	questions = _pdf_cut_questions(all_lines)
	text_chars = sum(len(ln["text"]) for ln in all_lines)
	total_chars = max(1, text_chars)
	cjk = sum(1 for ln in all_lines for ch in ln["text"] if "\u4e00" <= ch <= "\u9fff")
	alnum = sum(1 for ln in all_lines for ch in ln["text"] if ch.isalnum() and not ("\u4e00" <= ch <= "\u9fff"))
	readable = (cjk + alnum) / total_chars
	info = {"kind": "text", "pages": len(pages), "text_chars": text_chars, "images": len(images), "images_skipped": scanned_hits, "readable_ratio": round(readable, 2)}
	if not pages:
		info["kind"] = "unreadable"
		return [], info, "该 PDF 无法提取有效文字（可能是扫描型、无文字层，或字体未内嵌 ToUnicode），暂不支持自动识别；请改用 Word/Excel 导入，或等 OCR 功能上线后再试。不要硬做假识别。"
	if text_chars < 20 and images:
		info["kind"] = "scanned"
		return [], info, "该 PDF 是扫描型（图片型、无文字层），暂不支持自动识别；扫描识别需本地 OCR，目前为后置功能。请改用 Word/Excel 导入。"
	if text_chars < 20 or readable < 0.5:
		info["kind"] = "unreadable"
		return [], info, "该 PDF 无法提取有效文字（可能是扫描型、无文字层，或字体未内嵌 ToUnicode），暂不支持自动识别；请改用 Word/Excel 导入，或等 OCR 功能上线后再试。不要硬做假识别。"
	if text_chars < 30 * max(1, len(pages)) and images:
		info["kind"] = "scanned"
		return [], info, "该 PDF 是扫描型（图片型、无文字层），暂不支持自动识别；扫描识别需本地 OCR，目前为后置功能。请改用 Word/Excel 导入。"
	# 图片按 y 坐标挂到最近的题干上，换算成 dist 档（<20pt=0，<60=1，<150=2，<300=3，否则 4）
	for im in images:
		if "y" not in im or not questions:
			im["dist"] = None
			continue
		best, best_dy = None, None
		for q in questions:
			dy = abs(im["y"] - q.get("_y", 0))
			if best_dy is None or dy < best_dy:
				best, best_dy = q, dy
		if best_dy is None:
			im["dist"] = None
		elif best_dy < 20:
			im["dist"] = 0
		elif best_dy < 60:
			im["dist"] = 1
		elif best_dy < 150:
			im["dist"] = 2
		elif best_dy < 300:
			im["dist"] = 3
		else:
			im["dist"] = 4
		best["images"].append({"filename": im["filename"], "bytes": im["bytes"], "mime": im["mime"], "dist": im["dist"]})
	for q in questions:
		q.pop("_y", None)
	return questions, info, ""

