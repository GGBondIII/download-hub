# -*- coding: utf-8 -*-
"""常熟站智考通 v2.3 — Word(.docx)导入:纯标准库(zipfile + xml)。

段落格式:
  1. 题干……        (题号开头)
  A. 选项内容
  B. 选项内容
  答案:B            (多选如 ABC;判断填 对/错)
  解析:……
图片插在题干段落附近即可,按出现顺序挂到当前题上,图片存入 data/assets/。
.doc 旧格式不支持:先离线转 .docx(本机 Word/WPS 另存为,或
soffice --headless --convert-to docx)再导入。
Python 3.4 兼容语法。
"""
import os
import re
import zipfile
import xml.etree.ElementTree as ET

import questions as qmod

W_NS = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main'
R_NS = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships'


def _para_text(p):
    parts = []
    for node in p.iter('{%s}t' % W_NS):
        parts.append(node.text or '')
    return ''.join(parts)


def _para_has_image(p):
    for node in p.iter('{%s}blip' % 'http://schemas.openxmlformats.org/drawingml/2006/main'):
        return node.get('{%s}embed' % R_NS)
    return None


def parse_docx_bytes(data, assets_dir=''):
    """返回 (ok_list, bad_list)。ok_list 元素同 questions.create_question 入参。"""
    import io
    ok_list = []
    bad_list = []
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile:
        bad_list.append({'row': 0, 'error': '不是有效的 .docx 文件'})
        return ok_list, bad_list
    try:
        doc_root = ET.fromstring(zf.read('word/document.xml'))
    except KeyError:
        bad_list.append({'row': 0, 'error': 'docx 内缺少 word/document.xml'})
        return ok_list, bad_list
    # 图片 rels
    rels = {}
    try:
        rel_root = ET.fromstring(zf.read('word/_rels/document.xml.rels'))
        for rel in rel_root:
            rels[rel.get('Id')] = rel.get('Target') or ''
    except KeyError:
        pass
    paras = doc_root.findall('.//{%s}p' % W_NS)
    current = None
    img_seq = 0

    def flush():
        if current is None:
            return
        q = dict(current)
        qtype = qmod.normalize_type(q.get('type') or '')
        if not qtype:
            # 未写“题型:”行时按内容推断:选项恰为 对/错 且答案为 对/错 → 判断;
            # 题干含 ____ → 填空;有选项 → 单选;否则留空由校验报错
            opts = q.get('options') or {}
            if (set(opts.keys()) == set(['A', 'B'])
                    and (opts.get('A') or '').strip() == '对'
                    and (opts.get('B') or '').strip() == '错'
                    and (q.get('answer') or '').strip() in ('对', '错')):
                qtype = '判断'
            elif '____' in (q.get('stem') or ''):
                qtype = '填空'
            elif opts:
                qtype = '单选'
        q['type'] = qtype
        err = qmod.validate_question(q)
        if err:
            bad_list.append({'row': q.get('_row', 0), 'error': err})
        else:
            q.pop('_row', None)
            ok_list.append(q)

    for idx, p in enumerate(paras, start=1):
        text = _para_text(p).strip()
        rid = _para_has_image(p)
        if rid and current is not None and assets_dir:
            target = rels.get(rid, '')
            if target.startswith('media/'):
                img_seq += 1
                ext = os.path.splitext(target)[1] or '.png'
                save_name = 'docx_img_{0}{1}'.format(img_seq, ext)
                try:
                    os.makedirs(assets_dir)
                except OSError:
                    pass
                try:
                    with open(os.path.join(assets_dir, save_name), 'wb') as f:
                        f.write(zf.read('word/' + target))
                    current['image'] = save_name
                except (OSError, KeyError):
                    pass
        if not text:
            continue
        m = re.match(r'^(\d+)[.、．]\s*(.+)$', text)
        if m:
            flush()
            current = {'type': '', 'stem': m.group(2), 'options': {},
                       'answer': '', 'analysis': '', 'category': '',
                       'image': '', '_row': idx}
            continue
        if current is None:
            continue
        m = re.match(r'^([A-E])[.、．]\s*(.+)$', text)
        if m:
            current['options'][m.group(1)] = m.group(2)
            continue
        m = re.match(r'^答案[:：]\s*(.+)$', text)
        if m:
            current['answer'] = m.group(1).strip()
            continue
        m = re.match(r'^解析[:：]\s*(.+)$', text)
        if m:
            current['analysis'] = m.group(1).strip()
            continue
        m = re.match(r'^(?:科目|分类)[:：]\s*(.+)$', text)
        if m:
            current['category'] = m.group(1).strip()
            continue
        m = re.match(r'^题型[:：]\s*(.+)$', text)
        if m:
            current['type'] = m.group(1).strip()
            continue
        # 否则视为题干续行
        current['stem'] += text
    flush()
    if not ok_list and not bad_list:
        bad_list.append({'row': 0, 'error': '未解析出任何题目,请按“题号. 题干 / A. 选项 / 答案: / 解析:”格式排版'})
    return ok_list, bad_list
