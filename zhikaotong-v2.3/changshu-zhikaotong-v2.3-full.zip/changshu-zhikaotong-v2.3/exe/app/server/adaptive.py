# -*- coding: utf-8 -*-
"""常熟站智考通 v2.3 — 个性化自适应:FSRS 复习调度 + Elo 掌握度 + 自适应出题。

照抄刷题宝 v0.7 server.py 211–335 行的逻辑,改成 v1 的数据模型:
题型用中文(单选/多选/判断/填空/简答);知识点取题目的 category(并读
question_knowledge 有则并用);判分复用 questions.grade_answer。
简答不进自适应出题池(与 v07 排除 short/material 一致)。
Python 3.4 兼容语法。
"""
import json
import random
from datetime import datetime, timedelta

import db
import questions as qmod

FSRS_STEPS = [1, 3, 7, 14, 30]
AUTO_TYPES = ('单选', '多选', '判断', '填空')


def knowledge_of(conn, qid, category=''):
    """一道题的知识点列表:question_knowledge 有则用,否则取 category。"""
    try:
        rows = conn.execute(
            "SELECT kn.name FROM knowledge_nodes kn"
            " JOIN question_knowledge qk ON qk.knowledge_id=kn.id"
            " WHERE qk.question_id=?", (qid,)).fetchall()
        names = [r[0] for r in rows if r[0]]
        if names:
            return names
    except Exception:
        pass
    if category:
        return [category]
    return ['未分类']


def set_knowledge(conn, qid, names, subject=''):
    for kn in names or []:
        kn = (kn or '').strip()
        if not kn:
            continue
        conn.execute("INSERT OR IGNORE INTO knowledge_nodes(name, subject) VALUES(?, ?)",
                     (kn, subject or ''))
        kid = conn.execute("SELECT id FROM knowledge_nodes WHERE name=?", (kn,)).fetchone()
        if kid:
            conn.execute(
                "INSERT OR IGNORE INTO question_knowledge(question_id, knowledge_id)"
                " VALUES(?, ?)", (qid, kid[0]))


def update_mastery(conn, user_id, knowledge_list, is_correct, difficulty):
    for kn in knowledge_list or ['未分类']:
        row = conn.execute(
            "SELECT * FROM mastery_states WHERE user_id=? AND knowledge=?",
            (user_id, kn)).fetchone()
        if not row:
            conn.execute(
                "INSERT INTO mastery_states(user_id, knowledge, total, correct, elo, updated_at)"
                " VALUES(?, ?, 0, 0, 1500, datetime('now', 'localtime'))", (user_id, kn))
            row = conn.execute(
                "SELECT * FROM mastery_states WHERE user_id=? AND knowledge=?",
                (user_id, kn)).fetchone()
        b = 1200 + int(difficulty or 3) * 100
        elo = row['elo']
        expected = 1.0 / (1.0 + 10 ** ((b - elo) / 400.0))
        actual = 1.0 if is_correct else 0.0
        new_elo = int(round(elo + 32 * (actual - expected)))
        sc = (row['streak_correct'] or 0) + 1 if is_correct else 0
        sw = 0 if is_correct else (row['streak_wrong'] or 0) + 1
        td = 3 + (1 if sc >= 3 else 0) - (1 if sw >= 3 else 0)
        td = max(1, min(5, td))
        conn.execute(
            "UPDATE mastery_states SET total=total+1, correct=correct+?, elo=?,"
            " updated_at=datetime('now', 'localtime'),"
            " recent_total=COALESCE(recent_total,0)+1,"
            " recent_correct=COALESCE(recent_correct,0)+?,"
            " last_attempt_at=datetime('now', 'localtime'),"
            " streak_correct=?, streak_wrong=?, target_difficulty=? WHERE id=?",
            (1 if is_correct else 0, new_elo, 1 if is_correct else 0,
             sc, sw, td, row['id']))


def update_review_schedule(conn, user_id, qid, is_correct):
    row = conn.execute(
        "SELECT * FROM review_schedule WHERE user_id=? AND question_id=?",
        (user_id, qid)).fetchone()
    cur = row['interval_days'] if row else 1
    if is_correct:
        if cur in FSRS_STEPS:
            nxt = FSRS_STEPS[min(FSRS_STEPS.index(cur) + 1, len(FSRS_STEPS) - 1)]
        else:
            nxt = 3
    else:
        nxt = 1
    next_date = (datetime.now() + timedelta(days=nxt)).strftime("%Y-%m-%d")
    if row:
        conn.execute("UPDATE review_schedule SET next_review=?, interval_days=? WHERE id=?",
                     (next_date, nxt, row['id']))
    else:
        conn.execute(
            "INSERT INTO review_schedule(user_id, question_id, next_review, interval_days)"
            " VALUES(?, ?, ?, ?)", (user_id, qid, next_date, nxt))


def streak_days(conn, user_id):
    dates = set([r[0] for r in conn.execute(
        "SELECT DISTINCT substr(answered_at, 1, 10) FROM attempts WHERE user_id=?",
        (user_id,)).fetchall()])
    today = datetime.now().date()
    streak = 0
    d = today
    if d.strftime("%Y-%m-%d") not in dates:
        d = d - timedelta(days=1)
    while d.strftime("%Y-%m-%d") in dates:
        streak += 1
        d = d - timedelta(days=1)
    return streak


def adaptive_profile(conn, user_id):
    total = conn.execute(
        "SELECT COUNT(*) FROM attempts WHERE user_id=? AND mode IN ('practice', 'exam')",
        (user_id,)).fetchone()[0]
    rows = conn.execute(
        "SELECT q.category k, COUNT(*) t, COALESCE(SUM(a.is_correct), 0) c,"
        " COALESCE(MAX(m.elo), 1500) elo, COALESCE(MAX(m.target_difficulty), 3) td"
        " FROM attempts a JOIN questions q ON q.id=a.question_id"
        " LEFT JOIN mastery_states m ON m.user_id=a.user_id AND m.knowledge=q.category"
        " WHERE a.user_id=? AND a.mode IN ('practice', 'exam')"
        " AND q.category<>'' GROUP BY q.category",
        (user_id,)).fetchall()
    per = []
    for r in rows:
        acc = round(r[2] / r[1], 3) if r[1] else 0
        if r[1] < 5:
            status = 'insufficient'
        elif acc < 0.60:
            status = 'weak'
        elif acc > 0.85 and r[1] >= 10:
            status = 'mastered'
        else:
            status = 'normal'
        per.append({'knowledge': r[0], 'total': r[1], 'correct': r[2],
                    'accuracy': acc, 'elo': r[3], 'target_difficulty': r[4],
                    'status': status})
    weak = [x['knowledge'] for x in per if x['status'] == 'weak']
    mastered = [x['knowledge'] for x in per if x['status'] == 'mastered']
    due = conn.execute(
        "SELECT COUNT(*) FROM review_schedule WHERE user_id=? AND date(next_review)<=date('now')",
        (user_id,)).fetchone()[0]
    cold = total < 20
    if cold:
        ratio = {'weak_pct': 50, 'review_pct': 30, 'new_pct': 20}
        note = "样本不足(已答 {0} 题,不足 20 题):先按默认比例 50/30/20 出题,满 20 题后开始个性化。".format(total)
    elif weak:
        ratio = {'weak_pct': 65, 'review_pct': 15, 'new_pct': 20}
        note = "薄弱类占比已自动提到 65%(最近≥5题且正确率<60%),已掌握类降到 10% 以下,新题保持 20%。"
    else:
        ratio = {'weak_pct': 30, 'review_pct': 30, 'new_pct': 40}
        note = "暂无明显薄弱类(正确率均≥60% 或样本不足),多给新题保持进度。"
    return {'total_attempts': total, 'cold_start': cold, 'per_knowledge': per,
            'weak_knowledge': weak, 'mastered_knowledge': mastered,
            'ratio': ratio, 'sample_note': note, 'due_count': due,
            'streak_days': streak_days(conn, user_id)}


def record_attempt(user_id, question_id, mode, user_answer, is_correct,
                   exam_session_id=None):
    """作答后统一记账:attempts + 掌握度 + FSRS + 质量分 + 错题本(含 wrong_count)。
    is_correct 为 None(简答未批阅)时只记 attempts,不更新掌握度/错题本。
    调用方须在 DB_LOCK 内或自行保证;本函数自己加锁并提交。"""
    import quality as quality_mod
    conn = db.get_conn()
    row = qmod.get_question(question_id)
    if row is None:
        return False
    q = qmod.question_to_dict(row)
    with db.DB_LOCK:
        conn.execute(
            "INSERT INTO attempts(user_id, question_id, mode, exam_session_id,"
            " user_answer, is_correct, version_id, answered_at)"
            " VALUES(?, ?, ?, ?, ?, ?, ?, datetime('now', 'localtime'))",
            (user_id, question_id, mode if mode in ('practice', 'exam') else 'practice',
             exam_session_id, user_answer or '',
             None if is_correct is None else (1 if is_correct else 0),
             q.get('version_id')))
        if is_correct is not None:
            kn = knowledge_of(conn, question_id, q.get('category') or '')
            update_mastery(conn, user_id, kn, is_correct, q.get('difficulty') or 3)
            update_review_schedule(conn, user_id, question_id, is_correct)
            quality_mod.refresh_quality_for(conn, question_id)
            if not is_correct:
                ex = conn.execute(
                    "SELECT wrong_count FROM wrong_book WHERE user_id=? AND question_id=?",
                    (user_id, question_id)).fetchone()
                if ex is None:
                    conn.execute(
                        "INSERT INTO wrong_book(user_id, question_id, added_at,"
                        " wrong_count, last_wrong_at, mastered)"
                        " VALUES(?, ?, datetime('now', 'localtime'), 1,"
                        " datetime('now', 'localtime'), 0)",
                        (user_id, question_id))
                else:
                    conn.execute(
                        "UPDATE wrong_book SET wrong_count=wrong_count+1,"
                        " last_wrong_at=datetime('now', 'localtime'), mastered=0"
                        " WHERE user_id=? AND question_id=?",
                        (user_id, question_id))
            else:
                # 答对:移出错题本(v1 原有行为)
                conn.execute(
                    "DELETE FROM wrong_book WHERE user_id=? AND question_id=?",
                    (user_id, question_id))
        conn.commit()
    return True


def _pub_question(conn, qid):
    row = qmod.get_question(qid)
    if row is None:
        return None
    q = qmod.question_to_dict(row)
    return {'id': q['id'], 'type': q['type'], 'stem': q['stem'],
            'category': q.get('category') or '', 'difficulty': q.get('difficulty') or 3,
            'knowledge': knowledge_of(conn, qid, q.get('category') or ''),
            'image': q.get('image') or '',
            'options': q.get('options') or {}}


def adaptive_pick(conn, user_id, total):
    """自适应出题:薄弱/复习/新题按画像比例取,不足用其余启用题补足。"""
    import quality as quality_mod
    prof = adaptive_profile(conn, user_id)
    sus = quality_mod.suspect_qids(conn)
    rows = conn.execute(
        "SELECT id FROM questions WHERE status='启用' AND type IN ('单选', '多选', '判断', '填空')"
        " ORDER BY id").fetchall()
    all_q = [_pub_question(conn, r[0]) for r in rows]
    all_q = [q for q in all_q if q is not None and q['id'] not in sus]
    target = dict([(x['knowledge'], x['target_difficulty']) for x in prof['per_knowledge']])

    def diff_key(q):
        tds = [target.get(k, 3) for k in q['knowledge']] or [3]
        return min(abs((q['difficulty'] or 3) - t) for t in tds)

    weak_q = sorted([q for q in all_q
                     if any(k in q['knowledge'] for k in prof['weak_knowledge'])],
                    key=diff_key)
    due_ids = [r[0] for r in conn.execute(
        "SELECT question_id FROM review_schedule WHERE user_id=?"
        " AND date(next_review)<=date('now') ORDER BY next_review",
        (user_id,)).fetchall()]
    wrong_ids = [r[0] for r in conn.execute(
        "SELECT question_id FROM wrong_book WHERE user_id=? AND mastered=0",
        (user_id,)).fetchall()]
    review_all = [_pub_question(conn, qid) for qid in set(due_ids + wrong_ids)]
    review_q = [q for q in review_all
                if q is not None and q['id'] in due_ids + wrong_ids]
    done_ids = [r[0] for r in conn.execute(
        "SELECT DISTINCT question_id FROM attempts WHERE user_id=?",
        (user_id,)).fetchall()]
    new_q = [q for q in all_q if q['id'] not in done_ids]
    random.shuffle(weak_q)
    random.shuffle(review_q)
    random.shuffle(new_q)
    r = prof['ratio']
    n_w = total * r['weak_pct'] // 100
    n_r = total * r['review_pct'] // 100
    n_n = total - n_w - n_r
    picked = weak_q[:n_w] + review_q[:n_r] + new_q[:n_n]
    seen = set([q['id'] for q in picked])
    rest = [q for q in all_q if q['id'] not in seen]
    random.shuffle(rest)
    picked += rest[:max(0, total - len(picked))]
    return picked[:total], prof


def practice_modes(user_id):
    """学习方法五环节入口数据:顺序/随机/错题回顾/薄弱分析/阶段考核。"""
    conn = db.get_conn()
    with db.DB_LOCK:
        total_q = conn.execute(
            "SELECT COUNT(*) FROM questions WHERE status='启用'").fetchone()[0]
        wrong_n = conn.execute(
            "SELECT COUNT(*) FROM wrong_book WHERE user_id=? AND mastered=0",
            (user_id,)).fetchone()[0]
        due_n = conn.execute(
            "SELECT COUNT(*) FROM review_schedule WHERE user_id=?"
            " AND date(next_review)<=date('now')", (user_id,)).fetchone()[0]
        exams = conn.execute(
            "SELECT COUNT(*) FROM exams WHERE status='已发布'").fetchone()[0]
    prof = adaptive_profile(conn, user_id)
    return {
        'modes': [
            {'key': '顺序', 'label': '顺序练习', 'total': total_q,
             'desc': '按题号顺序过一遍题库'},
            {'key': '随机', 'label': '随机练习', 'total': total_q,
             'desc': '打乱顺序随机抽题'},
            {'key': '错题回顾', 'label': '错题回顾', 'total': wrong_n,
             'desc': '重练错题本里未掌握的题'},
            {'key': '薄弱分析', 'label': '薄弱分析', 'total': due_n,
             'desc': '按 FSRS 到期复习 + 薄弱知识点出题'},
            {'key': '阶段考核', 'label': '阶段考核', 'total': exams,
             'desc': '参加已发布的正式考试'},
        ],
        'wrong_count': wrong_n,
        'due_count': due_n,
        'weak_knowledge': prof['weak_knowledge'],
        'streak_days': prof['streak_days'],
        'cold_start': prof['cold_start'],
        'sample_note': prof['sample_note'],
    }
