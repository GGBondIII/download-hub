# -*- coding: utf-8 -*-
"""生成 question-import-template.xlsx(常熟站智考通版)。
纯标准库:zipfile + 手工 XML,inlineStr 单元格,与 import_xlsx.py 的解析器兼容。
只在构建时跑一次,不属于服务器运行时代码。
"""
import os
import zipfile

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                   'question-import-template.xlsx')

HEADERS = ['题型', '题干', '选项A', '选项B', '选项C', '选项D', '选项E',
           '答案', '解析', '科目', '知识点', '难度', '来源', '题干图片说明']
EXAMPLE = ['单选', '执勤中发现旅客所持证件疑似伪造,第一步最恰当的做法是?',
           '直接放行,避免耽误时间', '先稳住旅客,按程序核查并报告带班领导',
           '当场没收证件并让旅客离开', '自行判断真伪后放行', '',
           'B', '疑似伪造证件应按程序核查、报告,不可凭个人判断放行。',
           '证件查验', '证件核查程序', '2', '常熟站智考通样题', '']
NOTES = [
    '填写说明(导入前请读完)——常熟站智考通 v2.3',
    '1. 题型填 单选/多选/判断/填空/简答;答案:单选填单个字母如 B,多选填多个字母如 ABC,判断填 对/错,填空填标准答案文本,简答填参考答案。',
    '2. 单选至少填 2 个选项,多选至少填 2 个选项;中间不能空;选项里不要再写 A. B. 前缀。',
    '3. 题干和答案不能为空;解析可空,建议填;科目不硬编码,填什么就是什么。',
    '4. 填空题题干中用 ____ 标出空位;简答题选项列留空。',
    '5. Excel 带图:把图片拖到题所在行即可,浮动图按锚定行挂到对应题上;图片会存到主机 data/assets/,题里只存引用。',
    '6. 校验:缺答案、选项数不对、答案越界、题干为空、题型不识别,该行导入失败并在结果里列出原因,其他行照常导入,不整批失败。',
    '7. 导入后题目直接进入启用题库(本题库无审核发布流程);导入前请先核对。',
]


def _esc(s):
    return (s.replace('&', '&amp;').replace('<', '&lt;').replace('>', '&gt;')
             .replace('"', '&quot;'))


def _col_letter(i):
    # 1-based
    s = ''
    while i > 0:
        i, r = divmod(i - 1, 26)
        s = chr(65 + r) + s
    return s


def _sheet_xml(rows, widths):
    cols = ''.join(
        '<col width="{0}" customWidth="1" min="{1}" max="{1}"/>'.format(w, i + 1)
        for i, w in enumerate(widths))
    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
           '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">',
           '<sheetPr><outlinePr summaryBelow="1" summaryRight="1"/></sheetPr>',
           '<sheetFormatPr baseColWidth="8" defaultRowHeight="15"/>',
           '<cols>' + cols + '</cols>', '<sheetData>']
    for rno, row in enumerate(rows, start=1):
        out.append('<row r="{0}">'.format(rno))
        for cno, val in enumerate(row, start=1):
            if val == '':
                continue
            out.append('<c r="{0}{1}" t="inlineStr"><is><t>{2}</t></is></c>'.format(
                _col_letter(cno), rno, _esc(val)))
        out.append('</row>')
    out.append('</sheetData></worksheet>')
    return ''.join(out)


CONTENT_TYPES = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/worksheets/sheet2.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/><Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/></Types>'''
RELS = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>'''
WORKBOOK = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="题库" sheetId="1" r:id="rId1"/><sheet name="填写说明" sheetId="2" r:id="rId2"/></sheets></workbook>'''
WB_RELS = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet2.xml"/></Relationships>'''
CORE = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>常熟站智考通-题库导入模板</dc:title><dc:creator>常熟站智考通</dc:creator></cp:coreProperties>'''
APP = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>常熟站智考通</Application></Properties>'''


def main():
    widths = [12, 60, 28, 28, 28, 28, 28, 16, 40, 16, 22, 8, 16, 20]
    s1 = _sheet_xml([HEADERS, EXAMPLE], widths)
    s2 = _sheet_xml([[n] for n in NOTES], [120])
    with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED) as zf:
        zf.writestr('[Content_Types].xml', CONTENT_TYPES)
        zf.writestr('_rels/.rels', RELS)
        zf.writestr('xl/workbook.xml', WORKBOOK)
        zf.writestr('xl/_rels/workbook.xml.rels', WB_RELS)
        zf.writestr('xl/worksheets/sheet1.xml', s1)
        zf.writestr('xl/worksheets/sheet2.xml', s2)
        zf.writestr('docProps/core.xml', CORE)
        zf.writestr('docProps/app.xml', APP)
    print('wrote ' + OUT)


if __name__ == '__main__':
    main()
