# -*- coding: utf-8 -*-
"""常熟站智考通 v2.3 — 图文错位修复:置信度分流 + 配对复核(确认/拒绝)。

照抄刷题宝 v0.7 server.py 348–366、1719–1741、2494–2564 行的逻辑。
置信度:锚点与目标题相距 0 行=0.97,1 行=0.85,2 行=0.72,3 行=0.62,
≥4 行=0.45;无锚点=0.40。≥0.90 自动通过,0.70–0.90 复核,<0.70 人工指定。
save_asset 供 import_jobs 与配对确认共用。
Python 3.4 兼容语法。
"""
import hashlib
import os

import db
import auth


def _data_dir():
    return os.path.dirname(db.DB_PATH or '')


def _assets_dir():
    return os.path.join(_data_dir(), 'assets')


def _upload_dir():
    return os.path.join(_data_dir(), 'uploads')


def pairing_confidence(dist):
    if dist is None:
        return 0.40
    if dist <= 0:
        return 0.97
    if dist == 1:
        return 0.85
    if dist == 2:
        return 0.72
    if dist == 3:
        return 0.62
    return 0.45


def pairing_status(conf):
    if conf >= 0.90:
        return 'auto'
    if conf >= 0.70:
        return 'review'
    return 'manual'


def save_asset(conn, question_id, blob, filename, mime, option_label=None):
    h = hashlib.sha256(blob).hexdigest()[:16]
    ext = (filename.split('.')[-1].lower() if '.' in filename else 'png')
    if ext not in ('png', 'jpg', 'jpeg', 'gif', 'bmp'):
        ext = 'png'
    fname = "{0}.{1}".format(h, ext)
    adir = _assets_dir()
    try:
        os.makedirs(adir)
    except OSError:
        pass
    path = os.path.join(adir, fname)
    if not os.path.exists(path):
        with open(path, 'wb') as f:
            f.write(blob)
    cur = conn.execute(
        "INSERT INTO question_assets(question_id, option_label, filename, mime, path,"
        " created_at) VALUES(?, ?, ?, ?, ?, datetime('now', 'localtime'))",
        (question_id, option_label, filename, mime, fname))
    return cur.lastrowid


def list_pairings(job_id):
    conn = db.get_conn()
    with db.DB_LOCK:
        job = conn.execute("SELECT * FROM import_jobs WHERE id=?", (job_id,)).fetchone()
        if job is None:
            return None, "导入任务不存在"
        rows = conn.execute(
            "SELECT ip.*, q.stem, a.path AS asset_path FROM image_pairings ip"
            " LEFT JOIN questions q ON q.id=ip.question_id"
            " LEFT JOIN question_assets a ON a.id=ip.asset_id"
            " WHERE ip.job_id=? ORDER BY ip.confidence ASC, ip.id",
            (job_id,)).fetchall()
        try:
            import json
            report = json.loads(job['pairing_report_json'] or '{}')
        except Exception:
            report = {}
    return {'job_id': int(job_id), 'filename': job['filename'],
            'pairing': {'auto': job['pairing_auto'], 'review': job['pairing_review'],
                        'manual': job['pairing_manual']},
            'report': report,
            'pairings': [db.row_to_dict(r) for r in rows]}, ""


def confirm_pairing(pid, target_qid, username=''):
    conn = db.get_conn()
    with db.DB_LOCK:
        row = conn.execute("SELECT * FROM image_pairings WHERE id=?", (pid,)).fetchone()
    if row is None:
        return None, "配对记录不存在"
    with db.DB_LOCK:
        if row['question_id'] is None:
            if not target_qid:
                return None, "该图暂无对应题目,请指定目标题号"
            tq = conn.execute("SELECT id FROM questions WHERE id=?",
                              (target_qid,)).fetchone()
            if not tq:
                return None, "目标题目不存在"
            ppath = os.path.join(_upload_dir(),
                                 os.path.basename(row['pending_path'] or ''))
            if not row['pending_path'] or not os.path.isfile(ppath):
                return None, "待指派图片文件已不存在,请重新导入"
            with open(ppath, 'rb') as f:
                blob = f.read()
            ext = (row['filename'].split('.')[-1].lower()
                   if '.' in row['filename'] else 'png')
            mime = {'png': 'image/png', 'jpg': 'image/jpeg',
                    'jpeg': 'image/jpeg', 'gif': 'image/gif'}.get(ext, 'image/png')
            aid = save_asset(conn, int(target_qid), blob, row['filename'], mime)
            try:
                os.remove(ppath)
            except OSError:
                pass
            conn.execute(
                "UPDATE image_pairings SET asset_id=?, question_id=?, status='confirmed'"
                " WHERE id=?", (aid, int(target_qid), pid))
        elif target_qid and int(target_qid) != row['question_id']:
            tq = conn.execute("SELECT id FROM questions WHERE id=?",
                              (target_qid,)).fetchone()
            if not tq:
                return None, "目标题目不存在"
            if row['asset_id']:
                conn.execute("UPDATE question_assets SET question_id=? WHERE id=?",
                             (int(target_qid), row['asset_id']))
            conn.execute(
                "UPDATE image_pairings SET question_id=?, status='confirmed' WHERE id=?",
                (int(target_qid), pid))
        else:
            conn.execute("UPDATE image_pairings SET status='confirmed' WHERE id=?",
                         (pid,))
        conn.commit()
    db.audit(username, 'pairing_confirm', "配对 {0} 已确认".format(pid))
    return {'confirmed': True}, ""


def reject_pairing(pid, username=''):
    conn = db.get_conn()
    with db.DB_LOCK:
        row = conn.execute("SELECT * FROM image_pairings WHERE id=?", (pid,)).fetchone()
    if row is None:
        return None, "配对记录不存在"
    with db.DB_LOCK:
        if row['asset_id']:
            conn.execute("DELETE FROM question_assets WHERE id=?", (row['asset_id'],))
        if row['pending_path']:
            try:
                os.remove(os.path.join(_upload_dir(),
                                       os.path.basename(row['pending_path'])))
            except OSError:
                pass
        conn.execute("UPDATE image_pairings SET status='rejected' WHERE id=?", (pid,))
        conn.commit()
    db.audit(username, 'pairing_reject', "配对 {0} 已驳回(图片移除)".format(pid))
    return {'rejected': True}, ""
