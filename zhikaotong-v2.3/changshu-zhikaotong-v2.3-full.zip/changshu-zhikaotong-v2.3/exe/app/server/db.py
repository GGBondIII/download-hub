# -*- coding: utf-8 -*-
"""常熟站智考通 v2.3 — SQLite 数据模型(规格书§三 + 合并方案§三)。

单文件 SQLite,全局线程锁:exe 内嵌服务器线程与 UI 线程共用同一连接,
全部写操作都在 DB_LOCK 内完成。Python 3.4 兼容语法。
"""
import json
import os
import sqlite3
import threading

DB_LOCK = threading.RLock()
_CONN = None
DB_PATH = None


def configure(db_path):
    """指定数据库文件路径(须在 init_db 之前调用)。

    环境变量 ZHIKAOTONG_DATA_DIR 有值时覆盖目录:数据库文件落在该目录下
    (文件名仍用传入路径的文件名,默认为 zhikaotong.db);无值时保持原行为。
    exe 版 tkinter 客户端用它把内嵌服务器数据库指到 exe 文件夹根目录的
    data/ 下(见 client/app/main.py)。
    """
    global DB_PATH
    override = os.environ.get("ZHIKAOTONG_DATA_DIR")
    if override:
        DB_PATH = os.path.join(override, os.path.basename(db_path))
    else:
        DB_PATH = db_path


def get_conn():
    global _CONN
    if _CONN is None:
        if not DB_PATH:
            raise RuntimeError("db path not configured, call db.configure() first")
        parent = os.path.dirname(DB_PATH)
        if parent:
            try:
                os.makedirs(parent)
            except OSError:
                pass
        _CONN = sqlite3.connect(DB_PATH, check_same_thread=False)
        _CONN.row_factory = sqlite3.Row
        _CONN.execute("PRAGMA journal_mode=WAL")
        _CONN.execute("PRAGMA foreign_keys=ON")
    return _CONN


def row_to_dict(row):
    if row is None:
        return None
    return dict(row)


def rows_to_dicts(rows):
    return [dict(r) for r in rows]


def init_db():
    conn = get_conn()
    with DB_LOCK:
        c = conn.cursor()
        c.executescript("""
        CREATE TABLE IF NOT EXISTS users(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            name TEXT NOT NULL,
            department TEXT DEFAULT '',
            role TEXT NOT NULL DEFAULT 'student',
            status TEXT NOT NULL DEFAULT '正常',
            created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS questions(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            no TEXT NOT NULL,
            type TEXT NOT NULL,
            category TEXT DEFAULT '',
            stem TEXT NOT NULL,
            options TEXT DEFAULT '{}',
            answer TEXT NOT NULL,
            analysis TEXT DEFAULT '',
            image TEXT DEFAULT '',
            status TEXT NOT NULL DEFAULT '启用',
            created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS exams(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            subject TEXT DEFAULT '',
            duration_min INTEGER NOT NULL DEFAULT 60,
            shuffle INTEGER NOT NULL DEFAULT 0,
            mode TEXT NOT NULL DEFAULT 'fixed',
            qcounts TEXT DEFAULT '{}',
            qscores TEXT DEFAULT '{}',
            start_at TEXT DEFAULT '',
            end_at TEXT DEFAULT '',
            status TEXT NOT NULL DEFAULT '草稿',
            fixed_paper TEXT DEFAULT '',
            created_by INTEGER DEFAULT 0,
            created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS exam_members(
            exam_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            PRIMARY KEY(exam_id, user_id));
        CREATE TABLE IF NOT EXISTS exam_attempts(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            exam_id INTEGER NOT NULL,
            user_id INTEGER NOT NULL,
            answers TEXT DEFAULT '{}',
            score REAL,
            status TEXT NOT NULL DEFAULT '进行中',
            started_at TEXT NOT NULL,
            submitted_at TEXT DEFAULT '',
            paper TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS practice_records(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            question_id INTEGER NOT NULL,
            mode TEXT NOT NULL DEFAULT '顺序',
            user_answer TEXT DEFAULT '',
            correct INTEGER NOT NULL DEFAULT 0,
            answered_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS wrong_book(
            user_id INTEGER NOT NULL,
            question_id INTEGER NOT NULL,
            added_at TEXT NOT NULL,
            PRIMARY KEY(user_id, question_id));
        CREATE TABLE IF NOT EXISTS mock_attempts(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            config TEXT DEFAULT '{}',
            questions TEXT DEFAULT '[]',
            answers TEXT DEFAULT '{}',
            score REAL,
            status TEXT NOT NULL DEFAULT '进行中',
            started_at TEXT NOT NULL,
            submitted_at TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS reports(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            question_id INTEGER NOT NULL,
            type TEXT NOT NULL,
            detail TEXT DEFAULT '',
            status TEXT NOT NULL DEFAULT '待处理',
            reply TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            handled_at TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS settings(
            key TEXT PRIMARY KEY,
            value TEXT DEFAULT '');
        CREATE TABLE IF NOT EXISTS versions(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            platform TEXT NOT NULL,
            version TEXT NOT NULL,
            note TEXT DEFAULT '',
            filename TEXT DEFAULT '',
            status TEXT NOT NULL DEFAULT '生效中',
            created_at TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS knowledge_nodes(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL, parent_id INTEGER, subject TEXT);
        CREATE TABLE IF NOT EXISTS question_options(id INTEGER PRIMARY KEY AUTOINCREMENT, question_id INTEGER NOT NULL, label TEXT NOT NULL, content TEXT NOT NULL, asset_id INTEGER);
        CREATE TABLE IF NOT EXISTS question_assets(id INTEGER PRIMARY KEY AUTOINCREMENT, question_id INTEGER, option_label TEXT, filename TEXT NOT NULL, mime TEXT, path TEXT NOT NULL, created_at TEXT);
        CREATE TABLE IF NOT EXISTS question_knowledge(id INTEGER PRIMARY KEY AUTOINCREMENT, question_id INTEGER NOT NULL, knowledge_id INTEGER NOT NULL, UNIQUE(question_id, knowledge_id));
        CREATE TABLE IF NOT EXISTS bank_versions(id INTEGER PRIMARY KEY AUTOINCREMENT, version_no TEXT UNIQUE NOT NULL, note TEXT, question_count INTEGER DEFAULT 0, is_current INTEGER DEFAULT 0, created_by TEXT, created_at TEXT);
        CREATE TABLE IF NOT EXISTS bank_version_items(id INTEGER PRIMARY KEY AUTOINCREMENT, version_id INTEGER NOT NULL, question_id INTEGER NOT NULL, UNIQUE(version_id, question_id));
        CREATE TABLE IF NOT EXISTS import_jobs(id INTEGER PRIMARY KEY AUTOINCREMENT, filename TEXT, file_type TEXT, total_rows INTEGER DEFAULT 0, ok_rows INTEGER DEFAULT 0, bad_rows INTEGER DEFAULT 0, status TEXT DEFAULT 'parsed', created_by TEXT, created_at TEXT, pairing_report_json TEXT DEFAULT '', pairing_auto INTEGER DEFAULT 0, pairing_review INTEGER DEFAULT 0, pairing_manual INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS import_items(id INTEGER PRIMARY KEY AUTOINCREMENT, job_id INTEGER NOT NULL, row_no INTEGER, raw_json TEXT, error TEXT, status TEXT DEFAULT 'pending');
        CREATE TABLE IF NOT EXISTS review_queue(id INTEGER PRIMARY KEY AUTOINCREMENT, job_id INTEGER, question_id INTEGER, row_no INTEGER, reason TEXT, status TEXT DEFAULT 'pending', reviewer TEXT, reviewed_at TEXT);
        CREATE TABLE IF NOT EXISTS papers(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, subject TEXT, question_count INTEGER, minutes INTEGER, created_by TEXT, created_at TEXT, rules_json TEXT DEFAULT '', template_id INTEGER);
        CREATE TABLE IF NOT EXISTS paper_items(id INTEGER PRIMARY KEY AUTOINCREMENT, paper_id INTEGER NOT NULL, question_id INTEGER NOT NULL, sort_order INTEGER);
        CREATE TABLE IF NOT EXISTS exam_sessions(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, paper_id INTEGER, title TEXT, question_ids_json TEXT, started_at TEXT, ends_at TEXT, submitted_at TEXT, score REAL, total INTEGER, status TEXT DEFAULT 'ongoing');
        CREATE TABLE IF NOT EXISTS attempts(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, question_id INTEGER NOT NULL, mode TEXT DEFAULT 'practice', exam_session_id INTEGER, user_answer TEXT, is_correct INTEGER, version_id INTEGER, answered_at TEXT);
        CREATE TABLE IF NOT EXISTS attempt_answers(id INTEGER PRIMARY KEY AUTOINCREMENT, attempt_id INTEGER, question_id INTEGER, user_answer TEXT, is_correct INTEGER);
        CREATE TABLE IF NOT EXISTS review_schedule(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, question_id INTEGER NOT NULL, next_review TEXT, interval_days INTEGER DEFAULT 1);
        CREATE TABLE IF NOT EXISTS mastery_states(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, knowledge TEXT NOT NULL, total INTEGER DEFAULT 0, correct INTEGER DEFAULT 0, elo INTEGER DEFAULT 1500, updated_at TEXT, recent_total INTEGER DEFAULT 0, recent_correct INTEGER DEFAULT 0, last_attempt_at TEXT, streak_correct INTEGER DEFAULT 0, streak_wrong INTEGER DEFAULT 0, target_difficulty INTEGER DEFAULT 3, UNIQUE(user_id, knowledge));
        CREATE TABLE IF NOT EXISTS audit_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, user TEXT, action TEXT, detail TEXT, created_at TEXT);
        CREATE TABLE IF NOT EXISTS backups_meta(id INTEGER PRIMARY KEY AUTOINCREMENT, filename TEXT, note TEXT, created_at TEXT, size_bytes INTEGER DEFAULT 0, status TEXT DEFAULT 'ok');
        CREATE TABLE IF NOT EXISTS quality_scores(question_id INTEGER PRIMARY KEY, total INTEGER DEFAULT 0, correct INTEGER DEFAULT 0, accuracy REAL DEFAULT 0, flag TEXT DEFAULT 'normal', updated_at TEXT);
        CREATE TABLE IF NOT EXISTS paper_templates(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, subject TEXT DEFAULT '', total_count INTEGER DEFAULT 10, rules_json TEXT DEFAULT '{}', created_by TEXT, created_at TEXT);
        CREATE TABLE IF NOT EXISTS exam_appeals(id INTEGER PRIMARY KEY AUTOINCREMENT, session_id INTEGER, user_id INTEGER, question_id INTEGER, reason TEXT DEFAULT '', status TEXT DEFAULT 'pending', created_at TEXT);
        CREATE TABLE IF NOT EXISTS study_plans(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, team TEXT DEFAULT '', target_count INTEGER DEFAULT 0, due_date TEXT, created_by TEXT, created_at TEXT, knowledge TEXT DEFAULT '', daily_count INTEGER DEFAULT 0, scope TEXT DEFAULT 'team', target_user_id INTEGER);
        CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY AUTOINCREMENT, plan_id INTEGER, user_id INTEGER, title TEXT, status TEXT DEFAULT 'pending', created_at TEXT, due_date TEXT);
        CREATE TABLE IF NOT EXISTS peer_hosts(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, host TEXT, port INTEGER DEFAULT 8765, token TEXT DEFAULT '', status TEXT DEFAULT 'disabled', created_at TEXT, last_seen TEXT DEFAULT '', last_error TEXT DEFAULT '', last_count INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS ai_jobs(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, input_json TEXT DEFAULT '{}', status TEXT DEFAULT 'pending', result_json TEXT DEFAULT '', created_at TEXT);
        CREATE TABLE IF NOT EXISTS review_scores(id INTEGER PRIMARY KEY AUTOINCREMENT, question_id INTEGER, user_id INTEGER, score REAL, comment TEXT DEFAULT '', reviewer TEXT, created_at TEXT, attempt_id INTEGER, status TEXT DEFAULT 'pending', max_score REAL DEFAULT 10, reviewed_at TEXT);
        CREATE TABLE IF NOT EXISTS team_memberships(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, team TEXT NOT NULL, from_at TEXT, to_at TEXT, is_current INTEGER DEFAULT 1);
        CREATE TABLE IF NOT EXISTS image_pairings(id INTEGER PRIMARY KEY AUTOINCREMENT, job_id INTEGER NOT NULL, asset_id INTEGER, question_id INTEGER, filename TEXT DEFAULT '', confidence REAL DEFAULT 0, status TEXT DEFAULT 'review', reason TEXT DEFAULT '', pending_path TEXT DEFAULT '', created_at TEXT);
        CREATE TABLE IF NOT EXISTS federation_packages(id INTEGER PRIMARY KEY AUTOINCREMENT, host_id INTEGER, direction TEXT DEFAULT 'in', filename TEXT DEFAULT '', sha256 TEXT DEFAULT '', question_count INTEGER DEFAULT 0, status TEXT DEFAULT 'ok', created_by TEXT, created_at TEXT);
        """)
        conn.commit()
        # v2 新增列(旧库兼容:PRAGMA 查到缺列才 ALTER)
        _add_col(c, 'questions', 'difficulty', "INTEGER DEFAULT 3")
        _add_col(c, 'questions', 'source', "TEXT DEFAULT '系统样题'")
        _add_col(c, 'questions', 'version_id', "INTEGER")
        _add_col(c, 'questions', 'rubric', "TEXT DEFAULT ''")
        _add_col(c, 'questions', 'max_score', "REAL DEFAULT 10")
        _add_col(c, 'questions', 'parent_id', "INTEGER")
        _add_col(c, 'wrong_book', 'wrong_count', "INTEGER DEFAULT 1")
        _add_col(c, 'wrong_book', 'last_wrong_at', "TEXT")
        _add_col(c, 'wrong_book', 'mastered', "INTEGER DEFAULT 0")
        _add_col(c, 'exams', 'template_id', "INTEGER")
        conn.commit()
        # 默认设置:学员注册邀请码 CS2026(规格书§四-1/§四-6)
        c.execute("INSERT OR IGNORE INTO settings(key, value) VALUES('invite_code', 'CS2026')")
        c.execute("INSERT OR IGNORE INTO settings(key, value) VALUES('app_name', '常熟站智考通')")
        c.execute("INSERT OR IGNORE INTO settings(key, value) VALUES('app_version', 'v2.3')")
        c.execute("INSERT OR IGNORE INTO settings(key, value) VALUES('backup_keep', '7')")
        conn.commit()


def _add_col(cursor, table, col, ddl):
    """旧库兼容:列不存在才 ALTER TABLE ADD COLUMN。"""
    rows = cursor.execute("PRAGMA table_info({0})".format(table)).fetchall()
    names = [r[1] for r in rows]
    if col not in names:
        cursor.execute("ALTER TABLE {0} ADD COLUMN {1} {2}".format(table, col, ddl))


def close_conn():
    """关闭全局连接(备份恢复时用:先关连接再覆盖库文件,之后 get_conn 会重开)。"""
    global _CONN
    if _CONN is not None:
        try:
            _CONN.close()
        except Exception:
            pass
        _CONN = None


def get_setting(key, default=''):
    conn = get_conn()
    with DB_LOCK:
        row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
    if row is None:
        return default
    return row[0]


def set_setting(key, value):
    conn = get_conn()
    with DB_LOCK:
        conn.execute("INSERT OR REPLACE INTO settings(key, value) VALUES(?, ?)", (key, value))
        conn.commit()


def audit(user, action, detail=''):
    """写审计日志(audit_logs);失败静默,不影响主流程。"""
    try:
        import time
        conn = get_conn()
        with DB_LOCK:
            conn.execute(
                "INSERT INTO audit_logs(user, action, detail, created_at) VALUES(?, ?, ?, ?)",
                (user or '', action or '', detail or '',
                 time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())))
            conn.commit()
    except Exception:
        pass
