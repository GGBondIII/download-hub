# -*- coding: utf-8 -*-
"""
改名工具 (rebrand.py) -- v2.3

用途：把程序的站名与程序名一键换成别的站（给别的站用）。
与主程序共用便携文件夹里的 Python 3.4 运行时；由同目录的
32 位启动器 rebrand-tool.exe 双击启动（也可直接 python rebrand.py）。

关键设计：
  * 当前名字绝不在代码里写死，一律从同目录的 branding.json 读；
    改名成功后把新名字写回 branding.json，改过一次还能再改。
  * 核心逻辑是独立函数（scan_target / apply_rename / restore_backup /
    list_backups / load_branding / save_branding），不依赖界面，
    可直接 import 后调用做自测。
  * 替换顺序：先全名（当前程序名 -> 新程序名），再站名
    （当前站名 -> 新站名），避免全名被站名替换拆散。
  * 只做纯文本替换，不改文件结构；不碰题库数据文件
    （*.db / *.sqlite）与题目内容；不碰 backup-*/ 目录；
    不碰工具自己的 rebrand.py 与 rebrand-tool/ 目录。

Python 3.4 兼容语法：无 f-string、无 async/await、无 :=、
无 removeprefix 等 3.5+ 语法与库。
"""

import codecs
import json
import os
import shutil
import sys
import time

# ---------------------------------------------------------------------------
# 常量（注意：这里没有任何站名 / 程序名写死）
# ---------------------------------------------------------------------------

TOOL_DIR = os.path.dirname(os.path.abspath(__file__))
BRANDING_FILENAME = "branding.json"
TOOL_SCRIPT_NAME = "rebrand.py"
TOOL_DIR_NAME = "rebrand-tool"
TOOL_EXE_NAME = "rebrand-tool.exe"

# 扫描与替换的文件后缀（纯文本文件）。
SCAN_EXTS = (".py", ".html", ".js", ".css", ".md", ".txt", ".bat", ".sh")

# 绝不碰的文件后缀（题库数据与二进制）。
SKIP_EXTS = (".db", ".sqlite", ".sqlite3", ".exe", ".dll", ".pyd",
             ".pyc", ".png", ".jpg", ".jpeg", ".gif", ".ico", ".zip",
             ".xlsx", ".docx", ".pdf")

# 扫描时跳过的目录名（相对路径中任一段命中即跳过）。
SKIP_DIR_NAMES = ("backup-", "__pycache__", ".git", TOOL_DIR_NAME)

# 启动器 exe 改名时认定的“旧启动器文件名”（英文名 + 当前程序名）。
LEGACY_EXE_STEM = "changshu-zhikaotong"

# 藏青金配色（与主程序一致）。
NAVY = "#24425F"
NAVY_DARK = "#1A3149"
NAVY_DEEP = "#13222F"
GOLD = "#D9A55C"
GOLD_DARK = "#B9894A"
GOLD_LIGHT = "#F6E8D2"
BG = "#F4F6F9"
CARD = "#FFFFFF"
PRIMARY_LIGHT = "#E9EEF5"
GREEN = "#16A34A"
RED = "#DC2626"

APP_SUFFIX = "智考通"


# ---------------------------------------------------------------------------
# branding.json 读写
# ---------------------------------------------------------------------------

def branding_path(tool_dir=None):
    """返回 branding.json 的完整路径（默认工具所在目录）。"""
    if tool_dir is None:
        tool_dir = TOOL_DIR
    return os.path.join(tool_dir, BRANDING_FILENAME)


def load_branding(tool_dir=None):
    """读 branding.json，返回 dict。

    文件不存在或损坏时返回空 dict，不静默用写死的值；
    调用方（界面）据此留空让用户自己填。
    """
    path = branding_path(tool_dir)
    try:
        with codecs.open(path, "r", encoding="utf-8-sig") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return {}


def save_branding(station_name, app_name, tool_dir=None, version=None):
    """把新名字写回 branding.json（保留原有 version 字段）。"""
    if tool_dir is None:
        tool_dir = TOOL_DIR
    old = load_branding(tool_dir)
    if version is None:
        version = old.get("version", "v2.3")
    data = {"station_name": station_name,
            "app_name": app_name,
            "version": version}
    path = branding_path(tool_dir)
    with codecs.open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write("\n")
    return path


# ---------------------------------------------------------------------------
# 编码读写（UTF-8 / UTF-8-SIG / GBK）
# ---------------------------------------------------------------------------

def read_text_file(path):
    """读纯文本文件，返回 (text, encoding)。

    依次尝试 utf-8-sig（带 BOM）、utf-8、gbk；
    三种都失败返回 (None, None)，调用方跳过并记录。
    """
    with open(path, "rb") as f:
        raw = f.read()
    if raw.startswith(codecs.BOM_UTF8):
        try:
            return raw.decode("utf-8-sig"), "utf-8-sig"
        except UnicodeDecodeError:
            pass
    for enc in ("utf-8", "gbk"):
        try:
            return raw.decode(enc), enc
        except UnicodeDecodeError:
            continue
    return None, None


def write_text_file(path, text, encoding):
    """按原编码写回（utf-8-sig 会原样写回 BOM；gbk 按 GBK 写回）。"""
    with open(path, "wb") as f:
        if encoding == "utf-8-sig":
            f.write(codecs.BOM_UTF8)
            f.write(text.encode("utf-8"))
        else:
            f.write(text.encode(encoding))


def _is_skipped_dir(rel_path):
    """相对路径是否落在跳过目录里（backup-*/__pycache__/.git/工具目录）。"""
    parts = rel_path.replace("\\", "/").split("/")
    for part in parts:
        if part.startswith("backup-"):
            return True
        if part in ("__pycache__", ".git", TOOL_DIR_NAME):
            return True
    return False


# ---------------------------------------------------------------------------
# 扫描
# ---------------------------------------------------------------------------

def scan_target(target_dir, old_app, old_station):
    """扫描目标目录，列出将要改动的文件与替换次数。

    返回 list，每项为 dict：
      {"path": 完整路径, "rel": 相对路径,
       "full_count": 全名出现次数, "station_count": 站名出现次数,
       "encoding": 编码}
    跳过的文件记在 scan_target.skipped（list of (rel, reason)）。
    不改任何文件。
    """
    target_dir = os.path.abspath(target_dir)
    results = []
    skipped = []
    for root, dirs, files in os.walk(target_dir):
        # 剪掉跳过目录，避免往里走。
        dirs[:] = [d for d in dirs
                   if not d.startswith("backup-")
                   and d not in ("__pycache__", ".git", TOOL_DIR_NAME)]
        for name in sorted(files):
            full = os.path.join(root, name)
            rel = os.path.relpath(full, target_dir)
            if _is_skipped_dir(rel):
                continue
            ext = os.path.splitext(name)[1].lower()
            if ext in SKIP_EXTS:
                continue
            if ext not in SCAN_EXTS:
                continue
            text, encoding = read_text_file(full)
            if text is None:
                skipped.append((rel, "无法按 UTF-8/GBK 解码，已跳过"))
                continue
            full_count = 0
            station_count = 0
            if old_app:
                full_count = text.count(old_app)
            if old_station:
                # 站名次数按“替换后剩余”的口径计：先扣掉全名里自带的站名。
                station_count = text.count(old_station) - full_count
                if station_count < 0:
                    station_count = 0
            if full_count or station_count:
                results.append({"path": full, "rel": rel,
                                "full_count": full_count,
                                "station_count": station_count,
                                "encoding": encoding})
    results.sort(key=lambda r: r["rel"])
    scan_target.skipped = skipped
    return results


def scan_summary(results):
    """汇总扫描结果：返回 (文件数, 全名总处数, 站名总处数)。"""
    files = len(results)
    full_total = sum(r["full_count"] for r in results)
    station_total = sum(r["station_count"] for r in results)
    return files, full_total, station_total


def format_scan_lines(results):
    """把扫描结果格式化为每文件一行的人类可读文本。"""
    lines = []
    for r in results:
        lines.append(u"{0}  全名 {1} 处  站名 {2} 处".format(
            r["rel"], r["full_count"], r["station_count"]))
    return lines


# ---------------------------------------------------------------------------
# 备份 / 恢复
# ---------------------------------------------------------------------------

def _timestamp():
    return time.strftime("%Y%m%d-%H%M%S")


def _unique_backup_dir(tool_dir, suffix=""):
    """生成不重名的备份目录（同一秒内多次改名也不撞名）。"""
    root = _backup_root(tool_dir)
    base = "backup-{0}{1}".format(_timestamp(), suffix)
    path = os.path.join(root, base)
    n = 2
    while os.path.exists(path):
        path = os.path.join(root, "{0}-{1}".format(base, n))
        n += 1
    return path


def _backup_root(tool_dir=None):
    """备份目录的父目录：工具所在目录的上一级（即程序根目录旁）。"""
    if tool_dir is None:
        tool_dir = TOOL_DIR
    return os.path.dirname(os.path.abspath(tool_dir))


def list_backups(tool_dir=None):
    """列出已有的 backup-*/ 目录（按时间倒序），返回完整路径 list。"""
    root = _backup_root(tool_dir)
    found = []
    if os.path.isdir(root):
        for name in sorted(os.listdir(root), reverse=True):
            if name.startswith("backup-"):
                full = os.path.join(root, name)
                if os.path.isdir(full):
                    found.append(full)
    return found


def _copy_to_backup(src, backup_dir, rel):
    """把 src 按相对路径拷进备份目录（保留相对路径）。"""
    dest = os.path.join(backup_dir, rel)
    dest_dir = os.path.dirname(dest)
    if dest_dir and not os.path.isdir(dest_dir):
        os.makedirs(dest_dir)
    shutil.copy2(src, dest)


def _write_manifest(backup_dir, target_dir, branding_files, rel_files,
                   exe_renamed=None):
    """在备份目录里写一份恢复清单，供 restore_backup 使用。"""
    manifest = {"target_dir": os.path.abspath(target_dir),
                "branding_files": branding_files,
                "files": rel_files,
                "exe_renamed": exe_renamed or []}
    path = os.path.join(backup_dir, "restore-manifest.json")
    with codecs.open(path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)
        f.write("\n")


def _read_manifest(backup_dir):
    path = os.path.join(backup_dir, "restore-manifest.json")
    try:
        with codecs.open(path, "r", encoding="utf-8-sig") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except Exception:
        pass
    return {}


def restore_backup(backup_dir, target_dir=None, tool_dir=None):
    """把某次备份拷回去（恢复）。

    恢复前先把当前文件再备一份到
    backup-<时间>-before-restore/，防止恢复本身出错。
    恢复时 branding.json 也一并恢复（改名前备份里含它），
    所以恢复后 branding.json 里的名字回到改名前。

    返回 dict：{"restored": 恢复文件数, "pre_backup": 恢复前备份目录,
                "missing": 未找到原文件而跳过的数量, "errors": [错误文本]}。
    """
    if tool_dir is None:
        tool_dir = TOOL_DIR
    backup_dir = os.path.abspath(backup_dir)
    manifest = _read_manifest(backup_dir)
    if target_dir is None:
        target_dir = manifest.get("target_dir") or _backup_root(tool_dir)
    target_dir = os.path.abspath(target_dir)
    rel_files = manifest.get("files") or []
    branding_files = manifest.get("branding_files") or []
    exe_renamed = manifest.get("exe_renamed") or []
    # 兼容老备份（清单里没有 exe 改名记录）：用备份里的 branding.json
    # 与当前 branding.json 的程序名推断改过名的 exe。
    if not exe_renamed:
        try:
            with codecs.open(os.path.join(backup_dir, BRANDING_FILENAME),
                             "r", encoding="utf-8-sig") as f:
                old_brand = json.load(f)
            cur_brand = load_branding(tool_dir)
            old_app = old_brand.get("app_name", "")
            cur_app = cur_brand.get("app_name", "")
            if old_app and cur_app and old_app != cur_app:
                exe_renamed = [[old_app + ".exe", cur_app + ".exe"]]
        except Exception:
            pass

    # 没有清单的老备份：按备份目录结构直接推断相对路径。
    if not rel_files and not branding_files:
        for root, dirs, files in os.walk(backup_dir):
            for name in files:
                if name == "restore-manifest.json":
                    continue
                full = os.path.join(root, name)
                rel_files.append(os.path.relpath(full, backup_dir))

    # 1. 恢复前先备一份当前文件。
    pre_backup = _unique_backup_dir(tool_dir, suffix="-before-restore")
    os.makedirs(pre_backup)
    pre_files = []
    for rel in rel_files:
        cur = os.path.join(target_dir, rel)
        if os.path.isfile(cur):
            _copy_to_backup(cur, pre_backup, rel)
            pre_files.append(rel)
    # 改过名的 exe：当前是新名字，也先备一份（恢复时会删掉新名字）。
    for pair in exe_renamed:
        if len(pair) == 2:
            _new_rel = pair[1]
            cur_exe = os.path.join(target_dir, _new_rel)
            if os.path.isfile(cur_exe):
                _copy_to_backup(cur_exe, pre_backup, _new_rel)
                pre_files.append(_new_rel)
    for bpath in branding_files:
        if os.path.isfile(bpath):
            _copy_to_backup(bpath, pre_backup,
                            "branding-" + os.path.basename(
                                os.path.dirname(bpath)) + ".json")
    _write_manifest(pre_backup, target_dir, branding_files, pre_files)

    # 2. 把备份拷回去。
    restored = 0
    missing = 0
    errors = []
    for rel in rel_files:
        src = os.path.join(backup_dir, rel)
        dest = os.path.join(target_dir, rel)
        if not os.path.isfile(src):
            missing += 1
            continue
        try:
            dest_dir = os.path.dirname(dest)
            if dest_dir and not os.path.isdir(dest_dir):
                os.makedirs(dest_dir)
            shutil.copy2(src, dest)
            restored += 1
        except Exception as e:
            errors.append(u"{0}: {1}".format(rel, e))
    # branding.json：备份里以 branding.json（工具目录那份）存放，
    # 有多份时按清单里的绝对路径逐个恢复。
    brand_src = os.path.join(backup_dir, BRANDING_FILENAME)
    if branding_files:
        if os.path.isfile(brand_src):
            for bpath in branding_files:
                try:
                    shutil.copy2(brand_src, bpath)
                    restored += 1
                except Exception as e:
                    errors.append(u"{0}: {1}".format(bpath, e))
        else:
            # 兼容：备份里按相对路径存的 branding.json。
            for bpath in branding_files:
                rel_b = os.path.relpath(bpath, target_dir)
                src_b = os.path.join(backup_dir, rel_b)
                if os.path.isfile(src_b):
                    try:
                        shutil.copy2(src_b, bpath)
                        restored += 1
                    except Exception as e:
                        errors.append(u"{0}: {1}".format(bpath, e))
    # 改过名的 exe：旧名字已从备份拷回，删掉当前的新名字文件，
    # 否则新旧两个 exe 会同时存在。
    for pair in exe_renamed:
        if len(pair) == 2:
            old_rel, new_rel = pair[0], pair[1]
            if old_rel == new_rel:
                continue
            new_path = os.path.join(target_dir, new_rel)
            if os.path.isfile(new_path):
                try:
                    os.remove(new_path)
                except Exception as e:
                    errors.append(u"{0}: {1}".format(new_rel, e))
    return {"restored": restored, "pre_backup": pre_backup,
            "missing": missing, "errors": errors}


# ---------------------------------------------------------------------------
# 一键改名
# ---------------------------------------------------------------------------

def apply_rename(target_dir, old_app, old_station,
                 new_app, new_station, rename_exe=True,
                 scan_result=None, tool_dir=None):
    """执行改名。

    步骤：扫描（未给扫描结果时自动扫）-> 备份被改文件与 branding.json
    -> 先全名后站名做纯文本替换 -> 写回 branding.json -> 给 exe 改名。
    返回 dict：{"files": 改动文件数, "full_count": 全名处数,
      "station_count": 站名处数, "backup_dir": 备份目录,
      "exe_renamed": [(旧名, 新名)], "skipped": [(相对路径, 原因)],
      "branding_updated": [写回的 branding.json 路径]}。
    """
    if tool_dir is None:
        tool_dir = TOOL_DIR
    target_dir = os.path.abspath(target_dir)
    if scan_result is None:
        scan_result = scan_target(target_dir, old_app, old_station)
    skipped = list(getattr(scan_target, "skipped", []))

    # 1. 备份目录（工具所在目录旁）。
    backup_dir = _unique_backup_dir(tool_dir)
    os.makedirs(backup_dir)

    # 2. 备份 branding.json（工具目录那份 + 目标目录里如有也备）。
    branding_files = []
    tool_brand = branding_path(tool_dir)
    if os.path.isfile(tool_brand):
        branding_files.append(tool_brand)
        _copy_to_backup(tool_brand, backup_dir, BRANDING_FILENAME)
    target_brand = os.path.join(target_dir, BRANDING_FILENAME)
    if os.path.isfile(target_brand) and target_brand != tool_brand:
        branding_files.append(target_brand)
        _copy_to_backup(target_brand, backup_dir,
                        "target-" + BRANDING_FILENAME)
    rel_files = []

    # 3. 逐文件替换（先全名，后站名）。
    files_changed = 0
    full_total = 0
    station_total = 0
    for item in scan_result:
        path = item["path"]
        rel = item["rel"]
        text, encoding = read_text_file(path)
        if text is None:
            skipped.append((rel, "执行时无法按 UTF-8/GBK 解码，已跳过"))
            continue
        new_text = text
        full_n = 0
        station_n = 0
        if old_app:
            full_n = new_text.count(old_app)
            if full_n:
                new_text = new_text.replace(old_app, new_app)
        if old_station:
            station_n = new_text.count(old_station)
            if station_n:
                new_text = new_text.replace(old_station, new_station)
        if new_text != text:
            _copy_to_backup(path, backup_dir, rel)
            rel_files.append(rel)
            write_text_file(path, new_text, encoding)
            files_changed += 1
            full_total += full_n
            station_total += station_n

    # 4. 写回 branding.json（工具目录那份 + 目标目录那份）。
    branding_updated = []
    version = load_branding(tool_dir).get("version", "v2.3")
    for bpath in branding_files:
        bdir = os.path.dirname(bpath)
        save_branding(new_station, new_app, tool_dir=bdir,
                      version=version)
        branding_updated.append(bpath)
    if not branding_files:
        save_branding(new_station, new_app, tool_dir=tool_dir,
                      version=version)
        branding_updated.append(tool_brand)

    # 5. 给启动器 exe 改名（默认勾上）。
    exe_renamed = []
    if rename_exe:
        new_exe_name = new_app + ".exe"
        for root, dirs, files in os.walk(target_dir):
            dirs[:] = [d for d in dirs
                       if not d.startswith("backup-")
                       and d not in ("__pycache__", ".git", TOOL_DIR_NAME)]
            for name in sorted(files):
                stem, ext = os.path.splitext(name)
                if ext.lower() != ".exe":
                    continue
                if stem == old_app or stem == LEGACY_EXE_STEM:
                    src = os.path.join(root, name)
                    dest = os.path.join(root, new_exe_name)
                    if src == dest:
                        continue
                    if os.path.exists(dest):
                        skipped.append((os.path.relpath(src, target_dir),
                                        "目标 exe 已存在，未改名"))
                        continue
                    # 先备份 exe（二进制原样拷进备份目录）。
                    _copy_to_backup(src, backup_dir,
                                    os.path.relpath(src, target_dir))
                    rel_files.append(os.path.relpath(src, target_dir))
                    os.rename(src, dest)
                    exe_renamed.append(
                        (os.path.relpath(src, target_dir),
                         os.path.relpath(dest, target_dir)))

    _write_manifest(backup_dir, target_dir, branding_files, rel_files,
                    exe_renamed=exe_renamed)
    return {"files": files_changed, "full_count": full_total,
            "station_count": station_total, "backup_dir": backup_dir,
            "exe_renamed": exe_renamed, "skipped": skipped,
            "branding_updated": branding_updated}


# ---------------------------------------------------------------------------
# tkinter 界面
# ---------------------------------------------------------------------------

def _default_target_dir():
    """默认目标文件夹：工具所在目录的上一级（程序根目录）。"""
    return os.path.dirname(os.path.abspath(TOOL_DIR))


def run_gui():
    """启动图形界面。"""
    import tkFileDialog
    import tkMessageBox
    import ttk
    from Tkinter import (Button, Checkbutton, END, Entry, Frame, IntVar,
                         Label, StringVar, Text, Tk)

    branding = load_branding()
    cur_station = branding.get("station_name", "")
    cur_app = branding.get("app_name", "")
    title = (cur_app + u"改名工具") if cur_app else u"改名工具"

    root = Tk()
    root.title(title)
    root.geometry("680x560")
    root.configure(bg=BG)

    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except Exception:
        pass
    style.configure("TButton", font=("Microsoft YaHei", 10),
                    background=NAVY, foreground="white", padding=6)
    style.map("TButton", background=[("active", NAVY_DARK)])
    style.configure("TLabel", background=BG,
                    font=("Microsoft YaHei", 10))
    style.configure("TCheckbutton", background=BG,
                    font=("Microsoft YaHei", 10))
    style.configure("Header.TLabel", background=NAVY, foreground="white",
                    font=("Microsoft YaHei", 12, "bold"))
    style.configure("TEntry", font=("Microsoft YaHei", 10))

    header = ttk.Label(root, text=title, style="Header.TLabel")
    header.pack(fill="x", padx=0, pady=0, ipady=8)
    body = Frame(root, bg=BG)
    body.pack(fill="both", expand=True, padx=14, pady=10)

    row = 0

    def add_row(label_text):
        f = Frame(body, bg=BG)
        f.pack(fill="x", pady=4)
        Label(f, text=label_text, bg=BG, width=14, anchor="w").pack(
            side="left")
        return f

    # 目标文件夹。
    target_var = StringVar(value=_default_target_dir())
    f_target = add_row(u"目标文件夹：")
    Entry(f_target, textvariable=target_var, width=52).pack(side="left",
                                                            fill="x",
                                                            expand=True)

    def on_browse():
        chosen = tkFileDialog.askdirectory(
            initialdir=target_var.get() or _default_target_dir())
        if chosen:
            target_var.set(chosen)
            state["scan"] = None
            log(u"目标文件夹已改为：{0}，请重新扫描预览。".format(chosen))

    Button(f_target, text=u"浏览…", command=on_browse,
           bg=NAVY, fg="white", width=8).pack(side="left", padx=6)

    # 当前名字（只读显示；branding.json 找不到时留空可改）。
    cur_station_var = StringVar(value=cur_station)
    cur_app_var = StringVar(value=cur_app)
    f_cur1 = add_row(u"当前站名：")
    cur_station_entry = Entry(f_cur1, textvariable=cur_station_var,
                              width=52,
                              state="readonly" if cur_station else "normal")
    cur_station_entry.pack(side="left", fill="x", expand=True)
    f_cur2 = add_row(u"当前程序名：")
    cur_app_entry = Entry(f_cur2, textvariable=cur_app_var, width=52,
                          state="readonly" if cur_app else "normal")
    cur_app_entry.pack(side="left", fill="x", expand=True)

    # 新名字。
    new_station_var = StringVar()
    new_app_var = StringVar()
    f_new1 = add_row(u"新站名：")
    Entry(f_new1, textvariable=new_station_var, width=52).pack(
        side="left", fill="x", expand=True)
    f_new2 = add_row(u"新程序名：")
    Entry(f_new2, textvariable=new_app_var, width=52).pack(
        side="left", fill="x", expand=True)

    def on_new_station(*args):
        """新站名每改一次，新程序名自动按「新站名 + 智考通」填好。"""
        station = new_station_var.get().strip()
        if station:
            new_app_var.set(station + APP_SUFFIX)

    new_station_var.trace("w", on_new_station)

    rename_exe_var = IntVar(value=1)
    Checkbutton(body, text=u"同时给启动器 exe 改名（改名后 exe 文件名变成新程序名）",
                variable=rename_exe_var, bg=BG).pack(anchor="w", pady=4)

    state = {"scan": None}

    # 结果 / 状态区。
    status = Text(body, height=16, wrap="word", bg=CARD)
    status.pack(fill="both", expand=True, pady=6)

    def log(msg):
        status.insert(END, msg + "\n")
        status.see(END)
        root.update_idletasks()

    def do_scan():
        target = target_var.get().strip()
        old_app = cur_app_var.get().strip()
        old_station = cur_station_var.get().strip()
        if not target or not os.path.isdir(target):
            tkMessageBox.showerror(title, u"目标文件夹不存在，请先浏览选择。")
            return None
        if not old_app and not old_station:
            tkMessageBox.showerror(
                title, u"当前站名 / 程序名为空：branding.json 找不到，"
                       u"请在上方两个输入框里先填好当前名字。")
            return None
        log(u"正在扫描：{0}".format(target))
        results = scan_target(target, old_app, old_station)
        state["scan"] = results
        files, full_n, station_n = scan_summary(results)
        if not results:
            log(u"扫描完成：没有文件含有当前名字，无需改动。")
        else:
            log(u"扫描完成：将改动 {0} 个文件，全名 {1} 处，站名 {2} 处：".format(
                files, full_n, station_n))
            for line in format_scan_lines(results):
                log(u"  " + line)
        for rel, reason in getattr(scan_target, "skipped", []):
            log(u"跳过：{0}（{1}）".format(rel, reason))
        log(u"请确认无误后点「一键改名」。")
        return results

    def do_rename():
        target = target_var.get().strip()
        old_app = cur_app_var.get().strip()
        old_station = cur_station_var.get().strip()
        new_app = new_app_var.get().strip()
        new_station = new_station_var.get().strip()
        if not new_app or not new_station:
            tkMessageBox.showerror(title, u"请先填写新站名和新程序名。")
            return
        if new_app == old_app and new_station == old_station:
            tkMessageBox.showinfo(title, u"新名字和当前名字相同，无需改动。")
            return
        results = state.get("scan")
        if results is None:
            results = do_scan()
            if results is None:
                return
        files, full_n, station_n = scan_summary(results)
        ok = tkMessageBox.askokcancel(
            title,
            u"确认执行改名吗？\n\n"
            u"当前程序名：{0}\n新程序名：{1}\n"
            u"当前站名：{2}\n新站名：{3}\n\n"
            u"将改动 {4} 个文件，共 {5} 处"
            u"（全名 {6} 处，站名 {7} 处）。\n"
            u"执行前自动备份到程序根目录下的 backup-<日期时间>/。\n"
            u"改名后请重新启动程序生效。".format(
                old_app, new_app, old_station, new_station,
                files, full_n + station_n, full_n, station_n,
                backup_name))
        if not ok:
            log(u"已取消，未做任何改动。")
            return
        result = apply_rename(target, old_app, old_station,
                              new_app, new_station,
                              rename_exe=bool(rename_exe_var.get()),
                              scan_result=results)
        log(u"改名完成：改了 {0} 个文件，共 {1} 处"
            u"（全名 {2} 处，站名 {3} 处）。".format(
                result["files"],
                result["full_count"] + result["station_count"],
                result["full_count"], result["station_count"]))
        log(u"备份目录：{0}".format(result["backup_dir"]))
        for old_name, new_name in result["exe_renamed"]:
            log(u"启动器 exe 已改名：{0} -> {1}".format(old_name, new_name))
        if not result["exe_renamed"] and rename_exe_var.get():
            log(u"未找到需要改名的启动器 exe（未改名）。")
        for rel, reason in result["skipped"]:
            log(u"跳过：{0}（{1}）".format(rel, reason))
        log(u"branding.json 已更新为新名字；请重新启动程序生效。")
        # 刷新界面上的当前名字，改过一次还能再改。
        cur_station_var.set(new_station)
        cur_app_var.set(new_app)
        root.title(new_app + u"改名工具")
        state["scan"] = None

    def do_restore():
        backups = list_backups()
        if not backups:
            tkMessageBox.showinfo(title, u"没有找到任何备份目录。")
            return
        lines = [u"请选择要恢复的备份："]
        for i, b in enumerate(backups):
            lines.append(u"  {0}. {1}".format(i + 1, os.path.basename(b)))
        log("\n".join(lines))
        # 用简单选择框让用户挑一个（序号输入）。
        import tkSimpleDialog
        choice = tkSimpleDialog.askinteger(
            title, u"输入备份序号（1-{0}），恢复前会先把当前文件再备一份：".format(
                len(backups)),
            minvalue=1, maxvalue=len(backups))
        if choice is None:
            return
        backup_dir = backups[choice - 1]
        target = target_var.get().strip()
        ok = tkMessageBox.askokcancel(
            title,
            u"确认恢复备份 {0} 吗？\n恢复前会先把当前文件备到 "
            u"backup-<时间>-before-restore/。".format(
                os.path.basename(backup_dir)))
        if not ok:
            log(u"已取消恢复。")
            return
        result = restore_backup(backup_dir, target_dir=target)
        log(u"恢复完成：恢复了 {0} 个文件。".format(result["restored"]))
        log(u"恢复前备份：{0}".format(result["pre_backup"]))
        if result["missing"]:
            log(u"有 {0} 个备份文件找不到原位置，已跳过。".format(
                result["missing"]))
        for err in result["errors"]:
            log(u"恢复出错：{0}".format(err))
        # 恢复后 branding.json 回到改名前，刷新界面。
        branding = load_branding()
        cur_station_var.set(branding.get("station_name", ""))
        cur_app_var.set(branding.get("app_name", ""))
        state["scan"] = None
        log(u"当前名字已按恢复后的 branding.json 刷新；请重新启动程序生效。")

    btns = Frame(body, bg=BG)
    btns.pack(fill="x", pady=4)
    Button(btns, text=u"扫描预览", command=do_scan,
           bg=NAVY, fg="white", width=12).pack(side="left", padx=4)
    Button(btns, text=u"一键改名", command=do_rename,
           bg=GOLD_DARK, fg="white", width=12).pack(side="left", padx=4)
    Button(btns, text=u"恢复备份", command=do_restore,
           bg=NAVY, fg="white", width=12).pack(side="left", padx=4)

    if not cur_station and not cur_app:
        log(u"提示：同目录下找不到 branding.json，"
            u"请在上方先填好当前站名与当前程序名再扫描。")
    else:
        log(u"当前名字已从 branding.json 读入；"
            u"填好新站名后点「扫描预览」，确认无误再点「一键改名」。")
    root.mainloop()


if __name__ == "__main__":
    run_gui()
