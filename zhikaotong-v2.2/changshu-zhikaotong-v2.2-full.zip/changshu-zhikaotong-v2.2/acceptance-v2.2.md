# 常熟站智考通 v2.2 — 验收记录（启动双路径版）

> 程序名：常熟站智考通，版本 v2.2。v2.1 是诊断版（加 debug.bat / error.log 兜底）；
> v2.2 是启动修复版，相对 v2.1 其余功能不变。mvp-v07 与 mvp-zhikaotong-v1 原样保留，未动；
> v2.0、v2.1 的 zip 与文件也在同一目录下并存。验收日期：2026-11-06。

## 一、为什么出 v2.2

v2.1 的启动器在用户真实 Windows 机上反复弹“找不到 python34\pythonw.exe”，但已确认的事实是：

- v2.1 包是完整的（pythonw.exe 27,648 字节在包里，启动器 md5 5c1024cabd85b26201ac7abb8a0add1c，PE32 GUI）；
- 启动器源码逻辑正确（GetModuleFileNameW 取自身目录拼 python34\pythonw.exe，再 GetFileAttributesW 预检）；
- 用户解出来的 exe/python34/ 里确认有 pythonw.exe（27KB）；
- debug.bat（python.exe 跑 app\main.py）能成功启动服务器（127.0.0.1:8766，/api/version 200），
  说明 Python 与程序代码没问题；
- 但从解出来的 exe 文件夹双击启动器仍弹“找不到 python34\pythonw.exe”。

最可能的解释：用户机器上的安全软件拦截了启动器对 pythonw.exe 的文件访问
（GetFileAttributesW 预检被拦后误报“找不到”），或启动器实际被从别的位置运行。
不再纠结定位，v2.2 直接给两条能用的启动路径：

1. **主用：`启动智考通.bat`**——走 cmd 调用 python 的机制，与已验证能跑的 debug.bat 相同，
   不经过 C 启动器；
2. **备用：C 启动器 `changshu-zhikaotong.exe`**——删掉 GetFileAttributesW 预检，直接
   CreateProcessW 启动，失败时才弹框并写真实 Windows 错误码。

## 二、v2.2 改了什么（相对 v2.1）

| # | 改动 | 位置 |
| --- | --- | --- |
| 1 | 新增 `启动智考通.bat`（GBK + CRLF，无 chcp 65001）：`@echo off` 后 `cd /d "%~dp0"` 切到 bat 所在目录；先判断 python34\pythonw.exe 是否存在，不存在则 echo 中文提示并 pause 停住；存在则 `start "" "python34\pythonw.exe" "app\main.py"` 启动桌面程序，bat 自己退出（无 pause，不留黑窗口） | `exe/启动智考通.bat` |
| 2 | C 启动器删掉 GetFileAttributesW 预检（pythonw.exe 与 main.py 两处都删）：直接 CreateProcessW 启动 pythonw.exe 跑 app\main.py；失败时才弹框，框里写真实 Windows 错误码（GetLastError）与“请先确认已把整个压缩包解压，再进文件夹双击运行”。用 i686-w64-mingw32-gcc -O2 -mwindows -municode 重新交叉编译，放进 exe/ 根目录覆盖旧启动器 | `_build/launcher/launcher.c`、`exe/changshu-zhikaotong.exe` |
| 3 | 版本号统一升到 v2.2：branding.json（exe/ 与 rebrand-tool/ 各一份）、server.py 的 VERSION（web/ 与 exe/app/server/ 两份）、theme.py 的 VERSION/TITLE、app.js/lite.js 的 VERSION 与界面显示、/api/version、db.py 的 app_version 默认值、federation.py 的 VERSION、seed.py 的初始题库版本（v2.2.0）、import_jobs 的新版本号（v2.2.x）、product-intro.md、showcase.html（三份同步）、README、start.bat/start.sh、debug.bat 标题 | 全树 |
| 4 | exe/ 的 README.txt：启动方法改成 v2.2 起主用 bat；product-intro.md 与 showcase.html 加 v2.2 改动说明；showcase 的“exe 双击没反应？”FAQ 更新为 bat 主用 + debug.bat 兜底；改名工具启动器（rebrand-tool/rebrand-launcher.c）不动（它没出问题） | 文档 |
| 5 | 打包注意：exe zip 与完整包里 `启动智考通.bat` 是中文文件名、按 GBK 编码写入 zip（不带 UTF-8 标志），Win7/Win10 中文系统自带解压能正常显示中文名；其余文件全部英文文件名。v0.7 的教训是中文文件名含非法 GBK 字节会报损坏，本次 GBK 编码只产生合法 GBK 字节，不会触发该问题 | 打包 |

其余功能（12 模块、刷题宝 15 项并入功能、改名工具、端口 8766、账号）与 v2.1 完全一致，未动。

## 三、验证结果

### 1. 新启动器（C 启动器）
- `i686-w64-mingw32-gcc -O2 -mwindows -municode` 交叉编译，`file` 确认 `PE32 executable (GUI) Intel 80386, for MS Windows`，17 sections。
- 大小 234,930 字节；md5 `548809470f46bdab0ed0582f7f86a7a5`；SHA-256 `1b78002c73c4404429bdb0f3a428125117ac250d7c5ec8d8f0c9ec05106b418e`。
- 二进制 UTF-16LE 核对：旧文案“找不到 python34”已不在；新文案“启动失败”“错误码”“请先确认已把整个压缩包解压”在。
- `objdump -p` 核对：导入 `CreateProcessW`、`GetModuleFileNameW`、`MessageBoxW`，**不再导入 `GetFileAttributesW`**（预检已删）；Subsystem 2（Windows GUI），MajorOSystemVersion 4 / MajorSubsystemVersion 4（XP 可跑）。
- 改名工具启动器未动（exe/rebrand-tool.exe 与 rebrand-tool/ 副本保持 v2.1 的）。

### 2. 启动智考通.bat
- GBK 编码 + CRLF（10 行全是 CRLF，无单独 LF），无 chcp 65001；`file` 认作 DOS batch file。
- 内容核对：`cd /d "%~dp0"`；`if not exist "python34\pythonw.exe"` 时 echo 中文提示 + pause + `exit /b 1`；
  存在时 `start "" "python34\pythonw.exe" "app\main.py"`，bat 随后退出（无 pause，不留黑窗口）。
- 语法为标准 cmd 批处理，未在真实 Windows 控制台里跑过（见第五节）。

### 3. 版本号 v2.2（全树核对）
- `branding.json` 两份均为 v2.2；`server.py` 两份 VERSION 均为 v2.2；`theme.py` VERSION/TITLE 为 v2.2；
  `app.js` VERSION 为 v2.2；`lite.js` 版本比对为 v2.2；`db.py` app_version 默认值为 v2.2；
  `federation.py` VERSION 为 v2.2；`seed.py` 初始题库版本 v2.2.0；`import_jobs` 新版本号 v2.2.x。
- 其余 v2.1 字样只剩有意的历史表述（“v2.1 新增启动诊断”“v2.1 起应用自己带启动失败兜底”“v2.1 新增 python.exe”等），用户能看到的版本号已全部是 v2.2。
- 网页版干净副本冒烟（Python 3.12，端口 18766）：`/api/version` 返回 `current_version: v2.2`；
  根页、/lite 均 200；Lite 页与根页标题显示 v2.2；民警登录成功。
- `web/` 与 `exe/app/server/` 除 web 独有的 README.md/data/start.bat/start.sh 外逐文件一致。

### 4. 语法与兼容性
- 全部 70 个 .py（web/ + exe/app/ + rebrand.py 两份，排除 `__pycache__` 与 python34/Lib）做 `ast.parse` 全过；
  3.5+ 语法扫描（f-string、async/await、walrus）无真命中（4 处命中全是假警报：check_py34.py 里用来检测
  walrus 的正则本身，以及 rebrand.py 文档字符串里写明的“无 :=”字样）。
- `app.js` 与 `lite.js`（web/ 与 exe/app/server/ 各两份）做 `node --check` 全过。
- 注意：本机已无 Python 3.8，语法检查用系统 Python 3.12 的 ast.parse + 正则扫描，未用
  `ast.parse(feature_version=(3,4))`；本次改动只涉及启动器 C 代码、bat 与版本号字符串，未改应用逻辑。

### 5. 打包
- `changshu-zhikaotong-v2.2-exe.zip`：exe/ 内容平铺打包，`unzip -t` 全过；内含新启动器、
  `启动智考通.bat`（中文名 GBK 编码）、debug.bat、python34/python.exe 与 pythonw.exe。
- `changshu-zhikaotong-v2.2-full.zip`：顶层文件夹 `changshu-zhikaotong-v2.2/` + README.txt + exe/ + web/ +
  product-intro.md + showcase.html + acceptance-v2.2.md，`unzip -t` 全过。
- `changshu-zhikaotong-v2.2-web.zip`：web/ 内容平铺打包，`unzip -t` 全过。
- 包里不含 error.log 与 `__pycache__`（打包前已清掉）。

## 四、让用户做的事（启动步骤）

1. 从 GitHub 公开库下载 `changshu-zhikaotong-v2.2-full.zip`，完整解压（不要直接在压缩包里双击）。
2. 进解出来的 `changshu-zhikaotong-v2.2/exe/` 文件夹，双击 **`启动智考通.bat`**（推荐）。
   也可以双击 `changshu-zhikaotong.exe`，效果一样。
3. 如果 bat 也起不来：再双击 debug.bat，把黑色控制台窗口截图发回来；同时把 exe 文件夹根目录
   自动生成的 error.log（启动失败时生成）的全文发回来。

## 五、已知限制（没有验证过，不要当作已验证）

- **v2.2 的 C 启动器改动与 bat 启动器未在真实 Windows 机上双击验证过**（只交叉编译 + `file` /
  二进制文案核对 + bat 文件格式核对；GUI 未在真实 Windows 点按过）。v2.2 换启动路径的思路
  是对的（bat 走的机制与已验证能跑的 debug.bat 相同），但最终仍需用户在真实 Win7/Win10 机上
  双击一次确认。
- **v2.0/v2.1 静默崩溃的真正根因仍未知**：v2.1 的 debug 结论沿用（服务器与 Python 代码没问题，
  debug.bat 能跑起来）；v2.2 没有也不声称修好了根因，只是绕开疑似被拦的预检、另给一条启动路。
- 32 位 exe 与改名工具启动器未在真实 XP/Win7/Win10 机上双击验证过；真实局域网多机与 150 并发未测；
  浏览器实测未做；Pillow 在真实 XP 上的加载未验证。
- v2.0 的三个旧问题修复（部门对比精确汇总、计划进度去重计数、模板开考含简答题）沿用 v2.0/v2.1
  的验收结论，v2.2 未重测（v2.2 没改这些逻辑，只改了启动与版本标识）。
