# -*- coding: utf-8 -*-
"""常熟站智考通 v2.2 -- 本地配置(服务器地址、显示偏好等)。

配置文件:优先写在客户端目录旁的 client_config.json,
写不进去时回退到用户主目录 ~/.zhikaotong_client.json。
默认服务器地址 http://127.0.0.1:8766(内嵌服务器)。
Python 3.4 兼容语法,仅标准库。
"""
import json
import os

DEFAULT_SERVER = "http://127.0.0.1:8766"
DEFAULTS = {
    "server_url": DEFAULT_SERVER,
    "fullscreen": True,
    "font_size": "standard",      # standard / large
    "shuffle_options": False,
    "smart_analysis": True,
    "last_username": "",
}


def _candidate_paths():
    paths = []
    try:
        here = os.path.dirname(os.path.abspath(__file__))
        paths.append(os.path.join(os.path.dirname(here), "client_config.json"))
    except Exception:
        pass
    paths.append(os.path.join(os.path.expanduser("~"),
                              ".zhikaotong_client.json"))
    return paths


def load():
    cfg = dict(DEFAULTS)
    for path in _candidate_paths():
        try:
            if os.path.exists(path):
                with open(path, "r") as f:
                    data = json.load(f)
                if isinstance(data, dict):
                    cfg.update(data)
                cfg["_path"] = path
                return cfg
        except Exception:
            continue
    cfg["_path"] = _candidate_paths()[0]
    return cfg


def save(cfg):
    data = dict(cfg)
    data.pop("_path", None)
    last_err = None
    for path in _candidate_paths():
        try:
            with open(path, "w") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            cfg["_path"] = path
            return True
        except Exception as e:
            last_err = e
            continue
    return False
