# -*- coding: utf-8 -*-
"""常熟站智考通 v2.2 -- tkinter 桌面客户端入口。

启动时先在后台线程起内嵌服务器(把 app/server/ 当作包来 import,
调服务器的 main() 起 127.0.0.1:8766 线程;若服务器已在跑则直接用),
然后建 tkinter 主窗口:标题「常熟站智考通 v2.2」,minsize 1020x640,
默认全屏启动,F11 切换全屏/窗口(窗口模式 1180x760+100+60),
左导航 + 右内容区。

服务器地址可配置(存在本地配置文件里,登录页可改,默认 127.0.0.1:8766;
局域网其他机器跑同一个 exe、把地址指到主机 IP 即可连主机)。

启动失败兜底(v2.1 新增):全部可能失败的 import 与启动逻辑都在
_main() 里,main() 用 try/except 包住;一旦失败,把完整 traceback
连同 Python 版本与 sys.path 写到 exe 根目录的 error.log,同时用
ctypes 的 MessageBoxW 弹框显示(不用 tkinter.messagebox,因为
tkinter 本身可能就是坏掉的那一环)。再用 debug.bat(控制台版
python.exe 跑本文件)能直接在控制台里看到同样的报错。

Python 3.4 兼容语法,仅标准库。
"""
import os
import sys
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

SERVER_DIR = os.path.join(HERE, "server")
DEFAULT_PORT = 8766


def _report_startup_error(tb_text):
    """启动失败时:写 error.log(在 exe 根目录)并弹框显示。"""
    exe_root = os.path.dirname(HERE)
    log_path = os.path.join(exe_root, "error.log")
    lines = []
    lines.append("常熟站智考通启动失败")
    lines.append("Python: " + sys.version.replace("\n", " "))
    lines.append("sys.path:")
    for p in sys.path:
        lines.append("  " + p)
    lines.append("")
    lines.append(tb_text)
    text = "\n".join(lines)
    try:
        f = open(log_path, "w")
        try:
            f.write(text)
        finally:
            f.close()
    except Exception:
        pass
    try:
        import ctypes
        msg = text
        if len(msg) > 2000:
            msg = msg[:2000] + "\n...(完整内容见 error.log)"
        ctypes.windll.user32.MessageBoxW(
            0, msg, "常熟站智考通 - 启动失败", 0x10)
    except Exception:
        pass
    try:
        sys.stderr.write(text + "\n")
    except Exception:
        pass


def _probe_server(base_url):
    """服务器已在跑则返回 True。"""
    try:
        from urllib.request import urlopen
    except ImportError:
        from urllib2 import urlopen
    try:
        resp = urlopen(base_url.rstrip("/") + "/api/version", timeout=3)
        resp.read()
        return True
    except Exception:
        return False


def ensure_embedded_server(port=DEFAULT_PORT):
    """起内嵌服务器线程(127.0.0.1:端口);已在跑则直接用。返回 True/False。"""
    import threading
    base = "http://127.0.0.1:{0}".format(port)
    if _probe_server(base):
        return True
    if not os.path.isdir(SERVER_DIR):
        return False
    if SERVER_DIR not in sys.path:
        sys.path.insert(0, SERVER_DIR)
    os.environ["ZHIKAOTONG_HOST"] = "127.0.0.1"
    os.environ["ZHIKAOTONG_PORT"] = str(port)
    # 数据目录归位:内嵌服务器数据库建在 exe 文件夹根目录的 data/ 下
    # (即 app/ 的上一级目录下的 data/,用 main.py 自身路径推算),
    # 而不是 app/server/data/。服务器的 db.configure() 与 DATA_DIR
    # 均认 ZHIKAOTONG_DATA_DIR 环境变量。
    exe_root = os.path.dirname(HERE)
    os.environ["ZHIKAOTONG_DATA_DIR"] = os.path.join(exe_root, "data")
    try:
        import server as server_mod
    except Exception as e:
        sys.stderr.write("embedded server import failed: {0}\n".format(e))
        return False

    def run():
        try:
            server_mod.main()
        except Exception as e:
            sys.stderr.write("embedded server stopped: {0}\n".format(e))

    t = threading.Thread(target=run, daemon=True)
    t.start()
    for _ in range(30):
        if _probe_server(base):
            return True
        t.join(0.2)
    return _probe_server(base)


class App(object):
    def __init__(self, root):
        self.root = root
        self.config = config_mod.load()
        self.prefs = self.config
        self.api = ApiClient(self.config.get("server_url",
                                             config_mod.DEFAULT_SERVER))
        self.user = None
        self.page = "login"
        self.ui = {}
        self._space_handler = None
        self._shell = None
        self.content = None
        self.nav_frame = None
        self._apply_window()
        theme.setup_style(root)
        root.bind("<F11>", lambda e: self.toggle_fullscreen())
        root.bind("<space>", self._on_space)
        root.protocol("WM_DELETE_WINDOW", self.quit_app)

    # -- 窗口 --
    def _apply_window(self):
        root = self.root
        root.title(theme.TITLE)
        root.minsize(1020, 640)
        self.apply_display_mode()

    def apply_display_mode(self):
        try:
            if self.config.get("fullscreen"):
                self.root.attributes("-fullscreen", True)
            else:
                self.root.attributes("-fullscreen", False)
                self.root.geometry("1180x760+100+60")
        except Exception:
            pass

    def toggle_fullscreen(self):
        self.config["fullscreen"] = not self.config.get("fullscreen")
        self.save_config()
        self.apply_display_mode()

    def prefs_large(self):
        return self.config.get("font_size") == "large"

    def refresh_style(self):
        theme.setup_style(self.root)
        self.goto(self.page)

    def save_config(self):
        config_mod.save(self.config)

    def quit_app(self):
        try:
            if self.api.token:
                self.api.logout()
        except Exception:
            pass
        self.root.destroy()

    # -- 空格推进 --
    def set_space_handler(self, fn):
        self._space_handler = fn

    def _on_space(self, event):
        widget = event.widget
        try:
            cls = widget.winfo_class()
        except Exception:
            cls = ""
        if cls in ("Entry", "Text", "TCombobox", "Combobox"):
            return
        if self._space_handler:
            self._space_handler()
            return "break"

    # -- 路由 --
    def goto(self, page, **kw):
        if self.user is None and page != "login":
            page = "login"
        if page == "login":
            self.show_login()
            return
        if page == "home":
            self.goto_home()
            return
        self._ensure_shell()
        self._nav_highlight(page)
        self.root.focus_set()
        import views_student
        import views_mock
        import views_exam
        import views_settings
        import views_examiner
        import views_admin
        c = self.content
        if page == "practice":
            views_student.build_practice(self, c, mode=kw.get("mode", "顺序"))
        elif page == "adaptive":
            views_student.build_adaptive(self, c)
        elif page == "modes":
            views_student.build_modes(self, c)
        elif page == "weak":
            views_student.build_weak(self, c)
        elif page == "my_dashboard":
            views_student.build_my_dashboard(self, c)
        elif page == "my_plans":
            views_student.build_my_plans(self, c)
        elif page == "my_essay":
            views_student.build_my_essay(self, c)
        elif page == "wrongbook":
            views_student.build_wrongbook(self, c)
        elif page == "practice_stats":
            views_student.build_practice_stats(self, c)
        elif page == "my_reports":
            views_student.build_my_reports(self, c)
        elif page == "mock":
            views_mock.build_mock(self, c)
        elif page == "mock_resume":
            self._resume_mock(kw.get("attempt_id"))
        elif page == "exam":
            views_exam.build_exams(self, c)
        elif page == "settings":
            views_settings.build_settings(self, c)
        elif page == "exam_manage":
            views_examiner.build_exam_manage(self, c)
        elif page == "question_manage":
            views_examiner.build_question_manage(self, c)
        elif page == "templates":
            views_examiner.build_templates(self, c)
        elif page == "import_jobs":
            views_examiner.build_import_jobs(self, c)
        elif page == "quality":
            views_examiner.build_quality(self, c)
        elif page == "essay_queue":
            views_examiner.build_essay_queue(self, c)
        elif page == "ai_variants":
            views_examiner.build_ai_variants(self, c)
        elif page == "user_manage":
            views_admin.build_user_manage(self, c)
        elif page == "report_manage":
            views_admin.build_report_manage(self, c)
        elif page == "admin_stats":
            views_admin.build_admin_stats(self, c)
        elif page == "admin_dashboard":
            views_admin.build_admin_dashboard(self, c)
        elif page == "plans_admin":
            views_admin.build_plans_admin(self, c)
        elif page == "federation":
            views_admin.build_federation(self, c)
        elif page == "backup":
            views_admin.build_backup(self, c)
        elif page == "version_manage":
            views_admin.build_version_manage(self, c)
        elif page == "examiner_home":
            views_examiner.build_examiner_home(self, c)
        elif page == "admin_home":
            views_admin.build_admin_home(self, c)
        else:
            self.goto_home()

    def _resume_mock(self, attempt_id):
        import views_mock
        try:
            data = self.api.get("/api/mock/{0}".format(attempt_id))
        except ApiError as e:
            from widgets import banner
            banner(self.content, e.message, "error")
            return
        views_mock.MockRunner(self, self.content, data)

    def goto_home(self):
        role = (self.user or {}).get("role", "student")
        self._ensure_shell()
        import views_student
        import views_examiner
        import views_admin
        if role == "admin":
            views_admin.build_admin_home(self, self.content)
        elif role == "examiner":
            views_examiner.build_examiner_home(self, self.content)
        else:
            views_student.build_home(self, self.content)
        self.root.focus_set()

    def show_login(self):
        import views_login
        if self._shell is not None:
            self._shell.destroy()
            self._shell = None
            self.content = None
            self.nav_frame = None
        self.user = None
        self.api.token = None
        self.page = "login"
        views_login.build_login(self, self.root)

    def logout(self):
        try:
            self.api.logout()
        except Exception:
            pass
        self.show_login()

    # -- 主窗口骨架:左导航 + 右内容区 --
    def _ensure_shell(self):
        if self._shell is not None:
            return
        for w in self.root.winfo_children():
            w.destroy()
        try:
            self.root.unbind("<Return>")
        except Exception:
            pass
        shell = Frame(self.root, bg=theme.BG)
        shell.pack(fill="both", expand=True)
        nav = Frame(shell, bg=theme.NAVY, width=190)
        nav.pack(side="left", fill="y")
        nav.pack_propagate(False)
        self.nav_frame = nav
        self.content = Frame(shell, bg=theme.BG)
        self.content.pack(side="right", fill="both", expand=True)
        self._shell = shell
        self._build_nav()

    def _nav_items(self):
        role = (self.user or {}).get("role", "student")
        if role == "admin":
            return [("首页", "admin_home"), ("用户管理", "user_manage"),
                    ("上报处理", "report_manage"),
                    ("统计分析", "admin_stats"),
                    ("统计仪表盘", "admin_dashboard"),
                    ("学习计划", "plans_admin"),
                    ("联邦共享", "federation"),
                    ("备份管理", "backup"),
                    ("客户端更新发布", "version_manage"),
                    ("系统设置", "settings")]
        if role == "examiner":
            return [("首页", "examiner_home"), ("考试管理", "exam_manage"),
                    ("题库管理", "question_manage"),
                    ("组卷模板", "templates"),
                    ("导入任务", "import_jobs"),
                    ("题库质量", "quality"),
                    ("简答批阅", "essay_queue"),
                    ("AI 变式", "ai_variants"),
                    ("系统设置", "settings")]
        return [("首页", "home"), ("日常练习", "practice"),
                ("自适应练习", "adaptive"), ("五环节", "modes"),
                ("薄弱训练", "weak"), ("我的仪表盘", "my_dashboard"),
                ("模拟考试", "mock"), ("正式考试", "exam"),
                ("错题本", "wrongbook"), ("系统设置", "settings")]

    def _build_nav(self):
        nav = self.nav_frame
        for w in nav.winfo_children():
            w.destroy()
        user = self.user or {}
        Label(nav, text="常熟站智考通", bg=theme.NAVY, fg="#FFFFFF",
              font=theme.font(nav, 16, bold=True)).pack(pady=(18, 2))
        Label(nav, text="{0}  {1}".format(user.get("name", ""),
              user.get("role_name", "")), bg=theme.NAVY, fg=theme.GOLD,
              font=theme.font(nav, 12)).pack(pady=(0, 4))
        Label(nav, text=user.get("department", ""), bg=theme.NAVY,
              fg="#B9C6D8", font=theme.font(nav, 11)).pack(pady=(0, 16))
        self._nav_buttons = {}
        for text, page in self._nav_items():
            b = Button(nav, text=text, style="Nav.TButton",
                       command=lambda p=page: self.goto(p))
            b.pack(fill="x", padx=12, pady=4)
            self._nav_buttons[page] = b
        Button(nav, text="退出登录", style="Gold.TButton",
               command=self.logout).pack(side="bottom", fill="x",
                                         padx=12, pady=16)

    def _nav_highlight(self, page):
        pass


def _main():
    # 全部可能失败的 import 都在这里做,包在 main() 的 try/except 里。
    # (原来这些 import 在模块顶层:tkinter 一坏,整个模块导不进来,
    # 兜底根本跑不到,程序就静默退出了。)
    global tk, Frame, Label, Button, config_mod, theme
    global ApiClient, ApiError
    import tkinter as tk
    from tkinter import Frame, Label
    from tkinter.ttk import Button
    import config as config_mod
    import theme
    from api_client import ApiClient, ApiError

    no_embed = os.environ.get("ZKT_NO_EMBED") == "1"
    env_url = os.environ.get("ZKT_SERVER_URL")
    if env_url:
        pass
    if not no_embed:
        port = int(os.environ.get("ZHIKAOTONG_PORT", str(DEFAULT_PORT)))
        ok = ensure_embedded_server(port)
        if not ok:
            sys.stderr.write(
                "warning: embedded server did not start; "
                "will try configured server address\n")
    root = tk.Tk()
    app = App(root)
    if env_url:
        app.config["server_url"] = env_url
        app.api.set_base_url(env_url)
    app.show_login()
    if os.environ.get("ZKT_SELFTEST") == "1":
        import selftest
        root.after(500, lambda: selftest.run(app))
    root.mainloop()


def main():
    try:
        _main()
    except Exception:
        try:
            tb_text = traceback.format_exc()
        except Exception:
            tb_text = "（无法获取 traceback）"
        _report_startup_error(tb_text)
        raise


if __name__ == "__main__":
    main()
