# -*- coding: utf-8 -*-
"""常熟站智考通 v2.2 -- 正式考试(我的考试)。

考试列表、开始考试确认、考试中自动保存、交卷确认、时间到自动交卷、
成绩与解析、考试记录。
Python 3.4 兼容语法,仅标准库。
"""
import time

from tkinter import Frame, Label, StringVar
from tkinter.ttk import Button

from theme import (NAVY, BG, CARD, TEXT, TEXT_MUTED, BORDER, GREEN, RED,
                   font)
from widgets import (clear, banner, stat_card, QuestionPanel,
                     render_results, confirm_dialog)
from api_client import ApiError
from views_mock import _parse_ts, _self_grade_block


def build_exams(app, parent):
    clear(parent)
    app.page = "exam"
    app.set_space_handler(None)
    Label(parent, text="正式考试", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    try:
        exams = app.api.get("/api/exams/mine")
    except ApiError as e:
        banner(parent, e.message, "error")
        return parent
    app.ui["my_exams"] = exams
    if not exams:
        Label(parent, text="暂无可参加的考试,请等待考官发布", bg=BG,
              fg=TEXT_MUTED, font=font(parent, 14)).pack(pady=30)
        return parent
    for ex in exams:
        card = Frame(parent, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1)
        card.pack(fill="x", padx=16, pady=6)
        head = Frame(card, bg=CARD)
        head.pack(fill="x", padx=12, pady=(10, 2))
        Label(head, text=ex.get("name", ""), bg=CARD, fg=NAVY,
              font=font(head, 14, bold=True)).pack(side="left")
        att = ex.get("attempt") or {}
        status = (att.get("status") or "") if att else "未开始"
        if ex.get("status") == "草稿":
            status = "未开考"
        Label(head, text=status, bg=CARD,
              fg=GREEN if status in ("已交卷", "迟交") else NAVY,
              font=font(head, 12, bold=True)).pack(side="left", padx=10)
        Label(card, text="科目:{0}   时长:{1} 分钟   状态:{2}".format(
            ex.get("subject", ""), ex.get("duration_min", ""),
            ex.get("status", "")), bg=CARD, fg=TEXT_MUTED,
            font=font(card, 12), anchor="w").pack(fill="x", padx=12, pady=2)
        row = Frame(card, bg=CARD)
        row.pack(fill="x", padx=12, pady=(2, 10))
        if att and att.get("status") == "进行中":
            Button(row, text="继续考试", style="Navy.TButton",
                   command=lambda eid=ex.get("id"): _start(app, parent, eid)
                   ).pack(side="left", padx=4)
        elif att and att.get("status") in ("已交卷", "迟交"):
            Label(row, text="得分:{0}".format(att.get("score", "")),
                  bg=CARD, fg=NAVY, font=font(row, 12, bold=True)
                  ).pack(side="left", padx=4)
            Button(row, text="查看成绩", style="Navy.TButton",
                   command=lambda eid=ex.get("id"): _show_result(app, parent, eid)
                   ).pack(side="left", padx=4)
        else:
            Button(row, text="开始考试", style="Navy.TButton",
                   command=lambda eid=ex.get("id"): _confirm_start(app, parent, eid)
                   ).pack(side="left", padx=4)
    Label(parent, text="考试记录:开考 / 交卷 / 查看解析(见上方各考试状态)",
          bg=BG, fg=TEXT_MUTED, font=font(parent, 12)).pack(anchor="w",
                                                             padx=16, pady=8)
    return parent


def _confirm_start(app, parent, eid):
    confirm_dialog(parent, "开始考试",
                   "进入后将开始计时,确定开始考试吗?",
                   lambda: _start(app, parent, eid), yes_text="开始考试")


def _start(app, parent, eid):
    try:
        data = app.api.post("/api/exams/{0}/start".format(eid), {})
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    ExamRunner(app, parent, eid, data)


class ExamRunner(object):
    def __init__(self, app, parent, eid, data):
        self.app = app
        self.parent = parent
        self.eid = eid
        self.exam = data.get("exam") or {}
        self.detail = data.get("question_detail") or []
        self.answers = {}
        for k, v in (data.get("answers") or {}).items():
            if isinstance(v, dict):
                self.answers[int(k)] = v.get("a") or ""
            else:
                self.answers[int(k)] = v or ""
        self.duration = self.exam.get("duration_min", 60)
        self.started = _parse_ts(data.get("started_at") or "")
        self.end_at = self.started + self.duration * 60
        self.idx = 0
        self.panel = None
        self.timer_id = None
        self.submitted = False
        app.ui["exam_runner"] = self
        self._render()

    def _render(self):
        clear(self.parent)
        app = self.app
        app.page = "exam_run"
        head = Frame(self.parent, bg=BG)
        head.pack(fill="x", padx=12, pady=(10, 0))
        Label(head, text=self.exam.get("name", "正式考试"), bg=BG, fg=NAVY,
              font=font(head, 16, bold=True)).pack(side="left")
        self.timer_lab = Label(head, text="", bg=BG, fg=RED,
                               font=font(head, 14, bold=True))
        self.timer_lab.pack(side="left", padx=16)
        self.save_lab = Label(head, text="", bg=BG, fg=TEXT_MUTED,
                              font=font(head, 11))
        self.save_lab.pack(side="left", padx=8)
        Button(head, text="交卷", style="Gold.TButton",
               command=self._confirm_submit).pack(side="right", padx=4)
        card = Frame(self.parent, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1)
        card.pack(fill="x", padx=12, pady=6)
        Label(card, text="答题卡", bg=CARD, fg=NAVY,
              font=font(card, 12, bold=True)).pack(anchor="w", padx=10,
                                                    pady=(6, 2))
        self.card_row = Frame(card, bg=CARD)
        self.card_row.pack(anchor="w", padx=10, pady=(0, 8))
        self.body = Frame(self.parent, bg=BG)
        self.body.pack(fill="both", expand=True)
        nav = Frame(self.parent, bg=BG)
        nav.pack(fill="x", padx=12, pady=8)
        Button(nav, text="上一题", style="Ghost.TButton",
               command=self._prev).pack(side="left", padx=4)
        Button(nav, text="下一题", style="Navy.TButton",
               command=self._next).pack(side="left", padx=4)
        app.set_space_handler(self._space)
        self._show_question()
        self._tick()

    def _draw_card(self):
        for w in self.card_row.winfo_children():
            w.destroy()
        for i, q in enumerate(self.detail):
            done = bool(self.answers.get(q.get("id")))
            Button(self.card_row, text=str(i + 1),
                   style="Navy.TButton" if done else "Ghost.TButton",
                   command=lambda ii=i: self._goto(ii)).pack(side="left",
                                                              padx=2)

    def _goto(self, i):
        self._save_current()
        self.idx = i
        self._show_question()

    def _save_current(self):
        if not self.panel:
            return
        ans = self.panel.current_answer()
        q = self.detail[self.idx]
        if ans == self.answers.get(q.get("id"), ""):
            return
        self.answers[q.get("id")] = ans
        try:
            self.app.api.post("/api/exams/{0}/answer".format(self.eid),
                              {"question_id": q.get("id"), "answer": ans})
            self.save_lab.configure(text="已自动保存")
        except ApiError:
            self.save_lab.configure(text="保存失败提示:请检查网络")

    def _show_question(self):
        clear(self.body)
        q = self.detail[self.idx]
        app = self.app

        def on_save(ans, panel):
            self.answers[q.get("id")] = ans
            try:
                app.api.post("/api/exams/{0}/answer".format(self.eid),
                             {"question_id": q.get("id"), "answer": ans})
                self.save_lab.configure(text="已自动保存")
            except ApiError:
                self.save_lab.configure(text="保存失败提示:请检查网络")
            return None

        self.panel = QuestionPanel(app, self.body, q, self.idx,
                                   len(self.detail), on_submit=on_save,
                                   show_feedback=False, lock=False,
                                   shuffle=bool(self.exam.get("shuffle")))
        self.panel.submit_btn.configure(text="保存答案")
        self.panel.set_answer(self.answers.get(q.get("id"), ""))
        self._draw_card()

    def _space(self):
        if self.panel:
            self.panel.submit()
            self._draw_card()

    def _prev(self):
        if self.idx > 0:
            self._save_current()
            self.idx -= 1
            self._show_question()

    def _next(self):
        if self.idx + 1 < len(self.detail):
            self._save_current()
            self.idx += 1
            self._show_question()

    def _tick(self):
        if self.submitted:
            return
        remain = int(self.end_at - time.time())
        if remain <= 0:
            self.timer_lab.configure(text="时间到,自动交卷")
            self._submit(late=True)
            return
        self.timer_lab.configure(text="考试剩余时间 {0:02d}:{1:02d}".format(
            remain // 60, remain % 60))
        self.timer_id = self.parent.after(1000, self._tick)

    def _confirm_submit(self):
        self._save_current()
        unanswered = sum(1 for q in self.detail
                         if not self.answers.get(q.get("id")))
        confirm_dialog(self.parent, "交卷确认",
                       "交卷后将立即判分,不能再修改。还有 {0} 题未作答。".format(unanswered),
                       lambda: self._submit(), yes_text="确认交卷")

    def _submit(self, late=False):
        if self.submitted:
            return
        self.submitted = True
        if self.timer_id:
            try:
                self.parent.after_cancel(self.timer_id)
            except Exception:
                pass
        self.app.set_space_handler(None)
        try:
            res = self.app.api.post("/api/exams/{0}/submit".format(self.eid),
                                    {"late": bool(late)})
        except ApiError as e:
            banner(self.parent, e.message, "error")
            self.submitted = False
            return
        self.app.ui["exam_result"] = res
        _show_exam_result(self.app, self.parent, self.eid, res)


def _show_exam_result(app, parent, eid, res):
    clear(parent)
    app.page = "exam_result"
    Label(parent, text="考试成绩", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    row = Frame(parent, bg=BG)
    row.pack(fill="x", padx=16, pady=6)
    status = res.get("status", "")
    for title, val in (("得分", "{0}/{1}".format(res.get("score"),
                       res.get("full_score"))),
                       ("状态", status),
                       ("已答", "{0}/{1}".format(res.get("answered", ""),
                              res.get("total_questions", "")))):
        stat_card(row, title, str(val)).pack(side="left", fill="x",
                                             expand=True, padx=6)
    if status == "迟交":
        banner(parent, "本次为迟交(时间到系统自动交卷)", "warn")
    pending = res.get("pending_self_grade") or []
    bar = Frame(parent, bg=BG)
    bar.pack(fill="x", padx=16, pady=6)
    Button(bar, text="查看全部", style="Navy.TButton",
           command=lambda: _show_exam_result(app, parent, eid, res)
           ).pack(side="left", padx=4)
    Button(bar, text="只看错题", style="Ghost.TButton",
           command=lambda: _show_exam_result_filtered(app, parent, eid, res)
           ).pack(side="left", padx=4)
    Button(bar, text="返回我的考试", style="Ghost.TButton",
           command=lambda: app.goto("exam")).pack(side="left", padx=4)
    _self_grade_block(app, parent, eid, pending, res, kind="exam")
    render_results(parent, app, res.get("results") or [])


def _show_exam_result_filtered(app, parent, eid, res):
    clear(parent)
    app.page = "exam_result"
    Label(parent, text="考试成绩(只看错题)", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    Button(parent, text="查看全部", style="Navy.TButton",
           command=lambda: _show_exam_result(app, parent, eid, res)
           ).pack(anchor="w", padx=16, pady=6)
    render_results(parent, app, res.get("results") or [], show_only_wrong=True)


def _show_result(app, parent, eid):
    try:
        data = app.api.get("/api/exams/{0}/result".format(eid))
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    _show_exam_result(app, parent, eid, data)
