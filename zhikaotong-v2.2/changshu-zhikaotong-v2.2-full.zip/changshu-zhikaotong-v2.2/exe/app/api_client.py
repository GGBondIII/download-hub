# -*- coding: utf-8 -*-
"""常熟站智考通 v2.2 -- API 客户端(urllib 封装)。

按 API-CONTRACT.md 调用:JSON 信封 {"ok": bool, "data": ...},
身份用 X-Token 请求头,401 时调用方回登录页。
Python 3.4 兼容语法,仅标准库。
"""
import json

try:
    from urllib.request import Request, urlopen
    from urllib.error import HTTPError, URLError
    from urllib.parse import urlencode
except ImportError:  # Python 2 兼容兜底(本程序只跑 Python 3)
    from urllib2 import Request, urlopen, HTTPError, URLError
    from urllib import urlencode


class ApiError(Exception):
    def __init__(self, message, status=None):
        Exception.__init__(self, message)
        self.message = message
        self.status = status


class ApiClient(object):
    def __init__(self, base_url):
        self.base_url = base_url.rstrip("/")
        self.token = None

    def set_base_url(self, base_url):
        self.base_url = base_url.rstrip("/")

    def request(self, method, path, body=None, params=None, raw=False):
        url = self.base_url + path
        if params:
            url = url + "?" + urlencode(params)
        data = None
        headers = {}
        if body is not None:
            data = json.dumps(body).encode("utf-8")
            headers["Content-Type"] = "application/json"
        if self.token:
            headers["X-Token"] = self.token
        req = Request(url, data=data, headers=headers)
        req.get_method = lambda: method
        try:
            resp = urlopen(req, timeout=15)
            payload = resp.read()
            status = resp.getcode()
        except HTTPError as e:
            payload = e.read()
            status = e.code
            if status == 401:
                raise ApiError("未登录或登录已过期,请重新登录", status)
            try:
                obj = json.loads(payload.decode("utf-8"))
                msg = obj.get("error") or obj.get("message") or "请求失败"
            except Exception:
                msg = "请求失败(HTTP {0})".format(status)
            raise ApiError(msg, status)
        except URLError as e:
            raise ApiError("无法连接服务器,请检查服务器地址与网络", None)
        except Exception as e:
            raise ApiError("请求失败:{0}".format(e), None)
        if raw:
            return payload
        try:
            obj = json.loads(payload.decode("utf-8"))
        except Exception:
            raise ApiError("服务器返回数据无法解析", status)
        if isinstance(obj, dict) and obj.get("ok") is False:
            raise ApiError(obj.get("error") or "请求失败", status)
        if isinstance(obj, dict) and "data" in obj:
            return obj["data"]
        return obj

    def get(self, path, params=None):
        return self.request("GET", path, params=params)

    def post(self, path, body=None):
        if body is None:
            body = {}
        return self.request("POST", path, body=body)

    def put(self, path, body=None):
        if body is None:
            body = {}
        return self.request("PUT", path, body=body)

    def delete(self, path, body=None):
        return self.request("DELETE", path, body=body)

    def download(self, path, params=None):
        """二进制下载(导入模板、CSV 导出):返回 bytes。"""
        return self.request("GET", path, params=params, raw=True)

    # -- 便捷封装(登录态) --
    def login(self, username, password):
        data = self.post("/api/auth/login",
                         {"username": username, "password": password})
        if isinstance(data, dict):
            self.token = data.get("token")
            return data.get("user")
        return None

    def logout(self):
        try:
            self.post("/api/auth/logout", {})
        except Exception:
            pass
        self.token = None

    # -- v2 便捷封装(刷题宝并入,见 MERGE-PLAN.md §六) --
    # v07 的处理器返回 {"ok": true, "<名>": ...}(无 "data" 键),v2
    # 契约写 {"ok": true, "data": ...};两种形状都兼容:_unwrap 优先
    # 取具名键,取不到就返回 data 本身(或整个 dict)。
    @staticmethod
    def _unwrap(data, key):
        if isinstance(data, dict):
            if key in data:
                return data[key]
            if "data" in data:
                inner = data["data"]
                if isinstance(inner, dict) and key in inner:
                    return inner[key]
                return inner
        return data

    def _v2get(self, path, key, params=None):
        return self._unwrap(self.get(path, params=params), key)

    def _v2post(self, path, key, body=None):
        return self._unwrap(self.post(path, body or {}), key)

    # 自适应 / 薄弱 / 五环节(学员)
    def v2_adaptive(self):
        return self._v2get("/api/v2/adaptive", "adaptive")

    def v2_adaptive_questions(self, count=20):
        return self._v2get("/api/v2/practice/adaptive", "questions",
                           params={"count": count})

    def v2_weak(self, count=10):
        return self._v2get("/api/v2/weak", "questions",
                           params={"count": count})

    def v2_practice_modes(self):
        return self._v2get("/api/v2/practice/modes", "modes")

    def v2_ai_tip(self, qid):
        return self._v2get("/api/v2/ai/tips/{0}".format(qid), "tip")

    # 题库质量 / 组卷模板 / 成绩单(考官)
    def v2_quality(self):
        return self._v2get("/api/v2/quality", "quality")

    def v2_quality_refresh(self):
        return self._v2post("/api/v2/quality/refresh", "quality", {})

    def v2_question_status(self, qid, status):
        return self.post("/api/v2/questions/{0}/status".format(qid),
                         {"status": status})

    def v2_templates(self):
        return self._v2get("/api/v2/templates", "templates")

    def v2_template(self, tid):
        return self._v2get("/api/v2/templates/{0}".format(tid), "template")

    def v2_template_create(self, title, subject, total_count, rules):
        return self._v2post("/api/v2/templates", "template",
                            {"title": title, "subject": subject,
                             "total_count": total_count, "rules": rules})

    def v2_template_delete(self, tid):
        return self.delete("/api/v2/templates/{0}".format(tid))

    def v2_template_start(self, tid):
        return self._v2post("/api/v2/templates/{0}/start".format(tid),
                            "exam", {})

    def v2_exam_print(self, exam_id):
        """打印成绩单:服务器返回 HTML 文本,用 download 取原始 bytes。"""
        return self.download("/api/v2/exams/{0}/print".format(exam_id))

    # 简答批阅(考官 / 学员)
    def v2_essay_queue(self):
        return self._v2get("/api/v2/essay/queue", "queue")

    def v2_essay_review(self, review_id, score, comment=""):
        return self.post("/api/v2/essay/review",
                         {"review_id": review_id, "score": score,
                          "comment": comment})

    def v2_essay_mine(self):
        return self._v2get("/api/v2/essay/mine", "submissions")

    # 学习计划(考官/管理员下发,学员看自己的)
    def v2_plans(self):
        return self._v2get("/api/v2/plans", "plans")

    def v2_plan_create(self, title, scope, team="", user_id=None,
                       target_count=0, daily_count=0, due_date="",
                       knowledge=""):
        body = {"title": title, "scope": scope, "team": team,
                "target_count": target_count, "daily_count": daily_count,
                "due_date": due_date, "knowledge": knowledge}
        if user_id is not None:
            body["user_id"] = user_id
        return self._v2post("/api/v2/plans", "plan", body)

    def v2_plans_me(self):
        return self._v2get("/api/v2/plans/me", "plans")

    # 导入任务 / 图文配对 / 题库版本(考官)
    def v2_import_jobs(self):
        return self._v2get("/api/v2/import/jobs", "jobs")

    def v2_import_job(self, jid):
        return self._v2get("/api/v2/import/jobs/{0}".format(jid), "items")

    def v2_import_job_approve(self, jid):
        return self.post("/api/v2/import/jobs/{0}/approve".format(jid), {})

    def v2_import_pairings(self, jid):
        return self._v2get("/api/v2/import/jobs/{0}/pairings".format(jid),
                           "pairings")

    def v2_pairing_confirm(self, pid, question_id=None):
        body = {}
        if question_id is not None:
            body["question_id"] = question_id
        return self.post("/api/v2/import/pairings/{0}/confirm".format(pid),
                         body)

    def v2_pairing_reject(self, pid):
        return self.post("/api/v2/import/pairings/{0}/reject".format(pid), {})

    def v2_import_pdf(self, filename, content_b64):
        return self.post("/api/v2/import/pdf",
                         {"filename": filename, "content_b64": content_b64})

    def v2_bank_versions(self):
        return self._v2get("/api/v2/bank/versions", "versions")

    def v2_bank_publish(self, note=""):
        return self.post("/api/v2/bank/publish", {"note": note})

    def v2_bank_rollback(self, version_id):
        return self.post("/api/v2/bank/rollback",
                         {"version_id": version_id})

    # 仪表盘(管理员 / 学员)
    def v2_dashboard_overview(self):
        return self._v2get("/api/v2/dashboard/overview", "overview")

    def v2_dashboard_teams(self):
        return self._v2get("/api/v2/dashboard/teams", "teams")

    def v2_dashboard_user(self, uid):
        return self._v2get("/api/v2/dashboard/user/{0}".format(uid),
                           "report")

    def v2_dashboard_charts(self):
        return self._v2get("/api/v2/dashboard/charts", "charts")

    # 联邦共享(管理员)
    def v2_fed_hosts(self):
        return self._v2get("/api/v2/federation/hosts", "hosts")

    def v2_fed_host_create(self, name, host, port, token):
        return self.post("/api/v2/federation/hosts",
                         {"name": name, "host": host, "port": port,
                          "token": token})

    def v2_fed_host_test(self, hid):
        return self.post("/api/v2/federation/hosts/{0}/test".format(hid), {})

    def v2_fed_host_delete(self, hid):
        return self.post("/api/v2/federation/hosts/{0}/delete".format(hid),
                         {})

    def v2_fed_catalog(self, host_id=None):
        """对方题库目录:服务端 catalog 接口是机对机接口,只认联邦令牌、
        不包 data 信封、不认登录态,客户端不能直调(无对方令牌)。
        改走 hosts/<id>/test,由服务端用登记的令牌代取对方目录,
        返回顶层 catalog(直接读,不要按 data.catalog 读)。"""
        if host_id is None:
            return None
        data = self.post("/api/v2/federation/hosts/{0}/test".format(host_id),
                         {})
        if isinstance(data, dict):
            return data.get("catalog") or data
        return data

    def v2_fed_pull(self, host_id, subject="", limit=50):
        return self.post("/api/v2/federation/pull",
                         {"host_id": host_id, "subject": subject,
                          "limit": limit})

    def v2_fed_token(self):
        return self._v2get("/api/v2/federation/token", "token")

    # 备份管理(管理员)
    def v2_backup_status(self):
        return self._v2get("/api/v2/backup/status", "backup")

    def v2_backup_list(self):
        return self._v2get("/api/v2/backup/list", "backups")

    def v2_backup_create(self, note="手动备份"):
        return self.post("/api/v2/backup/create", {"note": note})

    def v2_backup_restore(self, filename):
        return self.post("/api/v2/backup/restore", {"filename": filename})

    def v2_backup_download(self, fname):
        return self.download("/api/v2/backup/download/{0}".format(fname))

    # AI 变式(考官)
    def v2_ai_variants(self):
        return self._v2get("/api/v2/ai/variants", "variants")

    def v2_ai_variant_create(self, qid, count=2):
        return self.post("/api/v2/ai/variants",
                         {"question_id": qid, "count": count})

    def v2_ai_variant_approve(self, vid):
        return self.post("/api/v2/ai/variants/{0}/approve".format(vid), {})

    def v2_ai_variant_reject(self, vid):
        return self.post("/api/v2/ai/variants/{0}/reject".format(vid), {})
