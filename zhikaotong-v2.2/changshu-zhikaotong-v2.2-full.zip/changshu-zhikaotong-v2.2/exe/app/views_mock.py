# -*- coding: utf-8 -*-
"""常熟站智考通 v2.2 -- 模拟考试。

组卷配置、考试中(剩余时间/答题卡/答案实时保存)、交卷确认、
成绩与逐题解析、填空简答自评、历史成绩横向卡片、断线续考。
Python 3.4 兼容语法,仅标准库。
"""
import time

from tkinter import Frame, Label, StringVar
from tkinter.ttk import Button, Combobox, Entry

from theme import (NAVY, GOLD, BG, CARD, TEXT, TEXT_MUTED, BORDER,
                   PRIMARY_LIGHT, GREEN, RED, font, sizes)
from widgets import (clear, banner, QuestionPanel, render_results,
                     confirm_dialog)
from api_client import ApiError

TYPES = ["单选", "多选", "判断", "填空", "简答"]


def _parse_ts(text):
    try:
        return time.mktime(time.strptime(text, "%Y-%m-%d %H:%M:%S"))
    except Exception:
        return time.time()


def build_mock(app, parent):
    """模拟考试首页:组卷配置 + 历史成绩 + 进行中提示。"""
    clear(parent)
    app.page = "mock"
    app.set_space_handler(None)
    Label(parent, text="模拟考试", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    try:
        current = app.api.get("/api/mock/current")
    except ApiError:
        current = None
    if current:
        bar = banner(parent, "有一场进行中的模拟考试,继续作答", "warn")
        bar.configure(cursor="hand2")
        bar.bind("<Button-1>", lambda e: _open_attempt(app, parent, current))
    try:
        cats = app.api.get("/api/questions/categories")
    except ApiError:
        cats = []
    form = Frame(parent, bg=CARD, highlightbackground=BORDER,
                 highlightthickness=1)
    form.pack(fill="x", padx=16, pady=6)
    Label(form, text="组卷配置:按题型选数量、分类、时长",
          bg=CARD, fg=NAVY, font=font(form, 13, bold=True)
          ).pack(anchor="w", padx=14, pady=(10, 4))
    count_vars = {}
    crow = Frame(form, bg=CARD)
    crow.pack(anchor="w", padx=14, pady=4)
    for t in TYPES:
        Label(crow, text=t, bg=CARD, fg=TEXT,
              font=font(crow, 12)).pack(side="left", padx=(8, 2))
        var = StringVar(value="0")
        Entry(crow, textvariable=var, width=4,
              font=font(crow, 12)).pack(side="left")
        count_vars[t] = var
    cat_var = StringVar(value="全部分类")
    dur_var = StringVar(value="30")
    Label(form, text="分类", bg=CARD, fg=TEXT,
          font=font(form, 12)).pack(anchor="w", padx=14, pady=(6, 0))
    Combobox(form, textvariable=cat_var,
             values=["全部分类"] + list(cats or []), width=20,
             state="readonly").pack(anchor="w", padx=14)
    Label(form, text="时长(分钟)", bg=CARD, fg=TEXT,
          font=font(form, 12)).pack(anchor="w", padx=14, pady=(6, 0))
    Entry(form, textvariable=dur_var, width=8,
          font=font(form, 12)).pack(anchor="w", padx=14)
    msg = Label(form, text="", bg=CARD, fg="#DC2626", font=font(form, 12))
    msg.pack(anchor="w", padx=14, pady=4)
    app.ui["mock_count_vars"] = count_vars
    app.ui["mock_dur_var"] = dur_var
    app.ui["mock_cat_var"] = cat_var
    app.ui["mock_msg"] = msg

    def start():
        counts = {}
        for t, var in count_vars.items():
            try:
                counts[t] = int(var.get())
            except Exception:
                counts[t] = 0
        if sum(counts.values()) <= 0:
            msg.configure(text="请至少设置一种题型的数量")
            return
        try:
            dur = int(dur_var.get())
        except Exception:
            dur = 30
        cat = "" if cat_var.get() in ("全部分类", "") else cat_var.get()
        try:
            data = app.api.post("/api/mock", {"counts": counts,
                                              "category": cat,
                                              "duration_min": dur})
        except ApiError as e:
            msg.configure(text=e.message)
            return
        _open_attempt(app, parent, data, is_new=True)

    Button(form, text="开始模拟考试", style="Navy.TButton",
           command=start).pack(anchor="w", padx=14, pady=12)
    app.ui["mock_start"] = start
    # 历史成绩横向卡片
    Label(parent, text="历史成绩", bg=BG, fg=NAVY,
          font=font(parent, 15, bold=True)).pack(anchor="w", padx=16,
                                                  pady=(10, 4))
    try:
        history = app.api.get("/api/mock/history")
    except ApiError:
        history = []
    app.ui["mock_history"] = history
    if not history:
        Label(parent, text="暂无模拟考试记录,完成一次模拟考试后会显示在这里",
              bg=BG, fg=TEXT_MUTED, font=font(parent, 12)).pack(anchor="w",
                                                                 padx=16)
        return parent
    hrow = Frame(parent, bg=BG)
    hrow.pack(fill="x", padx=16, pady=4)
    for h in history:
        card = Frame(hrow, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1, cursor="hand2")
        card.pack(side="left", padx=6, pady=4)
        Label(card, text="得分 {0}".format(h.get("score")),
              bg=CARD, fg=NAVY, font=font(card, 16, bold=True)
              ).pack(padx=14, pady=(10, 2))
        Label(card, text="{0} 题  {1}".format(h.get("question_count", ""),
              (h.get("submitted_at") or "")[:10]), bg=CARD, fg=TEXT_MUTED,
              font=font(card, 11)).pack(padx=14, pady=(0, 10))
        card.bind("<Button-1>",
                  lambda e, hid=h.get("id"): _open_history(app, parent, hid))
    return parent


class MockRunner(object):
    def __init__(self, app, parent, attempt):
        self.app = app
        self.parent = parent
        self.attempt = attempt
        self.aid = attempt.get("attempt_id") or attempt.get("id")
        self.detail = attempt.get("question_detail") or []
        self.answers = {}
        for k, v in (attempt.get("answers") or {}).items():
            if isinstance(v, dict):
                self.answers[int(k)] = v.get("a") or ""
            else:
                self.answers[int(k)] = v or ""
        cfg = attempt.get("config") or {}
        self.duration = cfg.get("duration_min", 30)
        self.started = _parse_ts(attempt.get("started_at") or "")
        self.end_at = self.started + self.duration * 60
        self.idx = 0
        self.panel = None
        self.timer_id = None
        self.submitted = False
        app.ui["mock_runner"] = self
        self._render()

    def _render(self):
        clear(self.parent)
        app = self.app
        app.page = "mock_run"
        head = Frame(self.parent, bg=BG)
        head.pack(fill="x", padx=12, pady=(10, 0))
        Label(head, text="模拟考试", bg=BG, fg=NAVY,
              font=font(head, 16, bold=True)).pack(side="left")
        self.timer_lab = Label(head, text="", bg=BG, fg=RED,
                               font=font(head, 14, bold=True))
        self.timer_lab.pack(side="left", padx=16)
        Button(head, text="交卷", style="Gold.TButton",
               command=self._confirm_submit).pack(side="right", padx=4)
        Button(head, text="退出(可恢复)", style="Ghost.TButton",
               command=lambda: app.goto("mock")).pack(side="right")
        # 答题卡
        card = Frame(self.parent, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1)
        card.pack(fill="x", padx=12, pady=6)
        Label(card, text="答题卡", bg=CARD, fg=NAVY,
              font=font(card, 12, bold=True)).pack(anchor="w", padx=10,
                                                    pady=(6, 2))
        self.card_row = Frame(card, bg=CARD)
        self.card_row.pack(anchor="w", padx=10, pady=(0, 8))
        self.body = Frame(self.parent, bg=BG)
        self.body.pack(fill="both", expand=True)
        nav = Frame(self.parent, bg=BG)
        nav.pack(fill="x", padx=12, pady=8)
        Button(nav, text="上一题", style="Ghost.TButton",
               command=self._prev).pack(side="left", padx=4)
        Button(nav, text="下一题", style="Navy.TButton",
               command=self._next).pack(side="left", padx=4)
        app.set_space_handler(self._space)
        self._show_question()
        self._tick()

    def _draw_card(self):
        for w in self.card_row.winfo_children():
            w.destroy()
        for i, q in enumerate(self.detail):
            done = bool(self.answers.get(q.get("id")))
            b = Button(self.card_row, text=str(i + 1),
                       style="Navy.TButton" if done else "Ghost.TButton",
                       command=lambda ii=i: self._goto(ii))
            b.pack(side="left", padx=2)

    def _goto(self, i):
        self._save_current()
        self.idx = i
        self._show_question()

    def _save_current(self):
        if not self.panel:
            return
        ans = self.panel.current_answer()
        q = self.detail[self.idx]
        if ans == self.answers.get(q.get("id"), ""):
            return
        self.answers[q.get("id")] = ans
        try:
            self.app.api.post("/api/mock/{0}/answer".format(self.aid),
                              {"question_id": q.get("id"), "answer": ans})
        except ApiError:
            pass

    def _show_question(self):
        clear(self.body)
        q = self.detail[self.idx]
        app = self.app

        def on_save(ans, panel):
            self.answers[q.get("id")] = ans
            try:
                app.api.post("/api/mock/{0}/answer".format(self.aid),
                             {"question_id": q.get("id"), "answer": ans})
            except ApiError:
                pass
            return None

        self.panel = QuestionPanel(app, self.body, q, self.idx,
                                   len(self.detail), on_submit=on_save,
                                   show_feedback=False, lock=False,
                                   shuffle=bool(app.prefs.get("shuffle_options")))
        self.panel.submit_btn.configure(text="保存答案")
        self.panel.set_answer(self.answers.get(q.get("id"), ""))
        self._draw_card()

    def _space(self):
        if self.panel:
            self.panel.submit()
            self._draw_card()

    def _prev(self):
        if self.idx > 0:
            self._save_current()
            self.idx -= 1
            self._show_question()

    def _next(self):
        if self.idx + 1 < len(self.detail):
            self._save_current()
            self.idx += 1
            self._show_question()

    def _tick(self):
        if self.submitted:
            return
        remain = int(self.end_at - time.time())
        if remain <= 0:
            self.timer_lab.configure(text="时间到,自动交卷")
            self._submit(late=True)
            return
        self.timer_lab.configure(text="剩余时间 {0:02d}:{1:02d}".format(
            remain // 60, remain % 60))
        self.timer_id = self.parent.after(1000, self._tick)

    def _confirm_submit(self):
        self._save_current()
        unanswered = sum(1 for q in self.detail
                         if not self.answers.get(q.get("id")))
        confirm_dialog(self.parent, "交卷确认",
                       "交卷后将立即判分,不能再修改。还有 {0} 题未作答。".format(unanswered),
                       lambda: self._submit(), yes_text="确认交卷")

    def _submit(self, late=False):
        if self.submitted:
            return
        self.submitted = True
        if self.timer_id:
            try:
                self.parent.after_cancel(self.timer_id)
            except Exception:
                pass
        self.app.set_space_handler(None)
        try:
            res = self.app.api.post("/api/mock/{0}/submit".format(self.aid), {})
        except ApiError as e:
            banner(self.parent, e.message, "error")
            self.submitted = False
            return
        self.app.ui["mock_result"] = res
        _show_mock_result(self.app, self.parent, self.aid, res)


def _open_attempt(app, parent, attempt, is_new=False):
    if not attempt.get("question_detail"):
        try:
            attempt = app.api.get("/api/mock/{0}".format(
                attempt.get("attempt_id") or attempt.get("id")))
        except ApiError as e:
            banner(parent, e.message, "error")
            return
    MockRunner(app, parent, attempt)


def _show_mock_result(app, parent, aid, res):
    clear(parent)
    app.page = "mock_result"
    Label(parent, text="模拟考试成绩", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    row = Frame(parent, bg=BG)
    row.pack(fill="x", padx=16, pady=6)
    for title, val in (("得分", "{0}/{1}".format(res.get("score"),
                       res.get("full_score"))),
                       ("正确率", "{0}%".format(res.get("accuracy", 0))),
                       ("客观题总数", str(res.get("objective_total", "")))):
        from widgets import stat_card
        stat_card(row, title, str(val)).pack(side="left", fill="x",
                                             expand=True, padx=6)
    pending = res.get("pending_self_grade") or []
    if pending:
        banner(parent, "有 {0} 道填空/简答题待自评,对照参考答案自评后计入总分".format(
            len(pending)), "warn")
    only_var = StringVar(value="全部")
    bar = Frame(parent, bg=BG)
    bar.pack(fill="x", padx=16, pady=6)
    Button(bar, text="查看全部", style="Navy.TButton",
           command=lambda: _show_mock_result(app, parent, aid, res)
           ).pack(side="left", padx=4)
    Button(bar, text="只看错题", style="Ghost.TButton",
           command=lambda: _show_mock_result_filtered(app, parent, aid, res)
           ).pack(side="left", padx=4)
    Button(bar, text="返回模拟考试", style="Ghost.TButton",
           command=lambda: app.goto("mock")).pack(side="left", padx=4)
    _self_grade_block(app, parent, aid, pending, res)
    render_results(parent, app, res.get("results") or [])
    app.ui["mock_result"] = res


def _show_mock_result_filtered(app, parent, aid, res):
    clear(parent)
    app.page = "mock_result"
    Label(parent, text="模拟考试成绩(只看错题)", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    Button(parent, text="查看全部", style="Navy.TButton",
           command=lambda: _show_mock_result(app, parent, aid, res)
           ).pack(anchor="w", padx=16, pady=6)
    render_results(parent, app, res.get("results") or [], show_only_wrong=True)


def _self_grade_block(app, parent, aid, pending, res, kind="mock"):
    if not pending:
        return
    results = dict((r.get("question_id"), r) for r in (res.get("results") or []))
    for qid in pending:
        r = results.get(qid) or {}
        card = Frame(parent, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1)
        card.pack(fill="x", padx=16, pady=6)
        Label(card, text="{0} {1}".format(r.get("no", ""), r.get("type", "")),
              bg=CARD, fg=NAVY, font=font(card, 13, bold=True),
              anchor="w").pack(fill="x", padx=12, pady=(8, 2))
        Label(card, text=r.get("stem", ""), bg=CARD, fg=TEXT,
              font=font(card, 12), wraplength=860, justify="left",
              anchor="w").pack(fill="x", padx=12)
        Label(card, text="参考答案:{0}   你的答案:{1}".format(
            r.get("correct_answer", ""), r.get("user_answer", "")),
            bg=CARD, fg=NAVY, font=font(card, 12), anchor="w",
            wraplength=860, justify="left").pack(fill="x", padx=12, pady=4)
        row = Frame(card, bg=CARD)
        row.pack(anchor="w", padx=12, pady=(0, 10))

        def grade(ok, q=qid, c=card, k=kind):
            if k == "exam":
                url = "/api/exams/{0}/selfgrade".format(aid)
            else:
                url = "/api/mock/{0}/selfgrade".format(aid)
            try:
                app.api.post(url, {"question_id": q, "correct": bool(ok)})
            except ApiError as e:
                banner(parent, e.message, "error")
                return
            for w in c.winfo_children():
                try:
                    w.configure(state="disabled")
                except Exception:
                    pass
            banner(parent, "自评已记录", "ok")

        Button(row, text="我答对了", style="Navy.TButton",
               command=lambda: grade(True)).pack(side="left", padx=4)
        Button(row, text="我答错了", style="Ghost.TButton",
               command=lambda: grade(False)).pack(side="left", padx=4)


def _open_history(app, parent, hid):
    try:
        data = app.api.get("/api/mock/{0}/detail".format(hid))
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    _show_mock_result(app, parent, hid, data)
