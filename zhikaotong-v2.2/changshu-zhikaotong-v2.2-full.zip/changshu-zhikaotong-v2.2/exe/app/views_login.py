# -*- coding: utf-8 -*-
"""常熟站智考通 v2.2 -- 登录页与注册页。

全屏藏青底 + 白色表单卡 + Canvas 自绘 logo、标题「常熟站智考通」、
副标题「一站式备考」、服务器地址/用户名/密码、登录按钮、
「没有账号?学员注册」、版本号 v2.2、退出、发现新版本提示条。
Python 3.4 兼容语法。
"""
import threading

from tkinter import Frame, Label, Entry, StringVar
from tkinter.ttk import Button, Combobox

from theme import (NAVY, NAVY_DARK, GOLD, GOLD_LIGHT, BG, CARD, TEXT,
                   TEXT_MUTED, VERSION, font, sizes)
from logo import draw_logo
from tkinter import Canvas
from widgets import banner, show_banner
from api_client import ApiError


def build_login(app, parent):
    """登录页。返回 frame;关键控件挂在 app.ui 供自测驱动。"""
    for w in parent.winfo_children():
        w.destroy()
    app.page = "login"
    app.set_space_handler(None)
    root = app.root
    outer = Frame(parent, bg=NAVY)
    outer.pack(fill="both", expand=True)
    # 右上角退出
    topbar = Frame(outer, bg=NAVY)
    topbar.pack(fill="x")
    Button(topbar, text="退出", style="Gold.TButton",
           command=app.quit_app).pack(side="right", padx=16, pady=12)
    center = Frame(outer, bg=NAVY)
    center.pack(expand=True)
    card = Frame(center, bg=CARD, highlightbackground=GOLD,
                 highlightthickness=2)
    card.pack(padx=20, pady=10)
    cv = Canvas(card, width=84, height=84, bg=CARD, highlightthickness=0)
    cv.pack(pady=(22, 4))
    draw_logo(cv, 4, 4, 76)
    Label(card, text="常熟站智考通", bg=CARD, fg=NAVY,
          font=font(card, 22, bold=True)).pack()
    Label(card, text="一站式备考", bg=CARD, fg=TEXT_MUTED,
          font=font(card, 12)).pack(pady=(2, 12))
    msg = Label(card, text="", bg=CARD, fg="#DC2626",
                font=font(card, 12), wraplength=320, justify="left")
    msg.pack(fill="x", padx=28)
    form = Frame(card, bg=CARD)
    form.pack(padx=28, pady=6)
    server_var = StringVar(value=app.config.get("server_url", ""))
    user_var = StringVar(value=app.config.get("last_username", ""))
    pass_var = StringVar()
    for label, var, show in (("服务器地址", server_var, ""),
                             ("用户名", user_var, ""),
                             ("密码", pass_var, "*")):
        Label(form, text=label, bg=CARD, fg=TEXT,
              font=font(form, 12)).pack(anchor="w", pady=(6, 2))
        Entry(form, textvariable=var, show=show,
              font=font(form, 13), width=30).pack(fill="x")
    app.ui["login_server"] = server_var
    app.ui["login_user"] = user_var
    app.ui["login_pass"] = pass_var
    app.ui["login_msg"] = msg

    def do_login():
        server = server_var.get().strip()
        username = user_var.get().strip()
        password = pass_var.get()
        if not server or not username or not password:
            msg.configure(text="请填写服务器地址、用户名和密码")
            return
        app.config["server_url"] = server
        app.config["last_username"] = username
        app.save_config()
        app.api.set_base_url(server)
        try:
            user = app.api.login(username, password)
        except ApiError as e:
            msg.configure(text=e.message)
            return
        except Exception as e:
            msg.configure(text="登录失败:{0}".format(e))
            return
        app.user = user
        app.goto_home()

    login_btn = Button(card, text="登  录", style="Navy.TButton",
                       command=do_login)
    login_btn.pack(fill="x", padx=28, pady=(12, 6))
    app.ui["login_button"] = login_btn
    reg = Label(card, text="没有账号?学员注册", bg=CARD, fg=NAVY,
                font=font(card, 12), cursor="hand2")
    reg.pack(pady=(2, 6))
    reg.bind("<Button-1>", lambda e: build_register(app, parent))
    update_bar = Label(card, text="", bg=GOLD_LIGHT, fg=NAVY,
                       font=font(card, 12))
    app.ui["login_update"] = update_bar
    Label(card, text="版本 {0}".format(VERSION), bg=CARD, fg=TEXT_MUTED,
          font=font(card, 11)).pack(pady=(4, 16))
    root.bind("<Return>", lambda e: do_login())
    app.ui["login_root_binding"] = True
    _check_update(app, update_bar)
    return outer


def _check_update(app, label_widget):
    """后台查服务器最新版本,有新版时在版本号上方显示提示条。"""
    def work():
        try:
            data = app.api.get("/api/version",
                               params={"platform": "win7-32"})
        except Exception:
            return
        latest = None
        if isinstance(data, dict):
            latest = data.get("latest")
        if latest and latest.get("version") and latest.get("version") != "v" + VERSION.lstrip("v") and latest.get("version") != VERSION:
            text = "发现新版本 {0}:立即更新".format(latest.get("version"))
            try:
                label_widget.after(0, lambda: _show_update(label_widget, text))
            except Exception:
                pass

    threading.Thread(target=work, daemon=True).start()


def _show_update(label_widget, text):
    label_widget.configure(text=text)
    label_widget.pack(fill="x", padx=28, pady=(0, 4))


def build_register(app, parent):
    for w in parent.winfo_children():
        w.destroy()
    app.page = "register"
    outer = Frame(parent, bg=NAVY)
    outer.pack(fill="both", expand=True)
    center = Frame(outer, bg=NAVY)
    center.pack(expand=True)
    card = Frame(center, bg=CARD, highlightbackground=GOLD,
                 highlightthickness=2)
    card.pack(padx=20, pady=10)
    Label(card, text="学员注册", bg=CARD, fg=NAVY,
          font=font(card, 20, bold=True)).pack(pady=(18, 4))
    Label(card, text="邀请码请向管理员索取", bg=CARD, fg=TEXT_MUTED,
          font=font(card, 12)).pack(pady=(0, 8))
    msg = Label(card, text="", bg=CARD, fg="#DC2626",
                font=font(card, 12), wraplength=320, justify="left")
    msg.pack(fill="x", padx=28)
    form = Frame(card, bg=CARD)
    form.pack(padx=28, pady=6)
    vars_ = {}
    for label, key in (("姓名 *", "name"), ("部门 *", "department"),
                       ("用户名", "username"), ("密码(至少 6 位)", "password"),
                       ("邀请码", "invite_code")):
        Label(form, text=label, bg=CARD, fg=TEXT,
              font=font(form, 12)).pack(anchor="w", pady=(6, 2))
        var = StringVar()
        show = "*" if key == "password" else ""
        Entry(form, textvariable=var, show=show,
              font=font(form, 13), width=30).pack(fill="x")
        vars_[key] = var
    app.ui["reg_vars"] = vars_
    app.ui["reg_msg"] = msg

    def do_register():
        payload = dict((k, v.get().strip()) for k, v in vars_.items())
        if not payload["name"] or not payload["department"]:
            msg.configure(text="姓名、部门必填")
            return
        if not payload["username"]:
            msg.configure(text="请填写用户名")
            return
        if len(payload["password"]) < 6:
            msg.configure(text="密码至少 6 位")
            return
        try:
            app.api.post("/api/auth/register", payload)
        except ApiError as e:
            msg.configure(text=e.message)
            return
        msg.configure(text="注册成功,请登录", fg="#16A34A")
        app.root.after(1200, lambda: build_login(app, parent))

    Button(card, text="注  册", style="Navy.TButton",
           command=do_register).pack(fill="x", padx=28, pady=(12, 4))
    app.ui["register_button"] = None
    back = Label(card, text="返回登录", bg=CARD, fg=NAVY,
                 font=font(card, 12), cursor="hand2")
    back.pack(pady=(2, 16))
    back.bind("<Button-1>", lambda e: build_login(app, parent))
    return outer
