# -*- coding: utf-8 -*-
"""常熟站智考通 v2.2 -- 通用界面组件。

页面内提示条(不用 messagebox 滥弹)、确认对话框、Canvas 自绘选项行、
答题面板(练习/模拟考/正式考试共用)、成绩逐题解析、简易柱状图。
Python 3.4 兼容语法,仅标准库 tkinter/ttk。
"""
import random

from tkinter import (Canvas, Entry, Frame, Label, Scrollbar, Text, Toplevel,
                     StringVar)
from tkinter.ttk import Button, Combobox

from theme import (NAVY, NAVY_DARK, GOLD, GOLD_LIGHT, BG, CARD, GREEN, RED,
                   TEXT, TEXT_MUTED, BORDER, PRIMARY_LIGHT, font, sizes)


def clear(frame):
    for w in frame.winfo_children():
        w.destroy()


def banner(parent, text, kind="info"):
    """页面内提示条。kind: info / ok / warn / error。返回 Label。"""
    colors = {"info": (PRIMARY_LIGHT, NAVY), "ok": ("#DCFCE7", "#166534"),
              "warn": (GOLD_LIGHT, "#92400E"), "error": ("#FEE2E2", "#991B1B")}
    bg, fg = colors.get(kind, colors["info"])
    lab = Label(parent, text=text, bg=bg, fg=fg, anchor="w",
                font=font(parent, 12), wraplength=900, justify="left")
    lab.pack(fill="x", padx=12, pady=6)
    return lab


def show_banner(parent, text, kind="info"):
    """在 parent 顶部显示提示条并返回它(调用方自行 pack 顺序管理)。"""
    return banner(parent, text, kind)


def confirm_dialog(parent, title, text, on_yes, yes_text="确定"):
    """自定义确认对话框(Toplevel,不用 messagebox)。"""
    top = Toplevel(parent)
    top.title(title)
    top.geometry("420x190+300+220")
    top.configure(bg=CARD)
    top.transient(parent)
    top.grab_set()
    Label(top, text=text, bg=CARD, fg=TEXT, font=font(top, 12),
          wraplength=360, justify="left").pack(padx=20, pady=20, fill="x")
    row = Frame(top, bg=CARD)
    row.pack(pady=8)

    def _yes():
        top.destroy()
        on_yes()

    Button(row, text=yes_text, style="Navy.TButton",
           command=_yes).pack(side="left", padx=8)
    Button(row, text="取消", style="Ghost.TButton",
           command=top.destroy).pack(side="left", padx=8)
    top.focus_set()
    return top


def stat_card(parent, title, value, accent=None):
    card = Frame(parent, bg=CARD, highlightbackground=BORDER,
                 highlightthickness=1)
    Label(card, text=title, bg=CARD, fg=TEXT_MUTED,
          font=font(parent, 11)).pack(anchor="w", padx=14, pady=(10, 0))
    Label(card, text=value, bg=CARD, fg=accent or NAVY,
          font=font(parent, 20, bold=True)).pack(anchor="w", padx=14,
                                                  pady=(2, 10))
    return card


def bar_chart(parent, items, title=""):
    """纯 Canvas 简易柱状图。items: [(标签, 数值)]。"""
    frame = Frame(parent, bg=CARD, highlightbackground=BORDER,
                  highlightthickness=1)
    if title:
        Label(frame, text=title, bg=CARD, fg=NAVY,
              font=font(parent, 13, bold=True)).pack(anchor="w", padx=12,
                                                      pady=(8, 0))
    cv = Canvas(frame, width=520, height=180, bg=CARD,
                highlightthickness=0)
    cv.pack(padx=8, pady=8)
    if not items:
        cv.create_text(260, 90, text="暂无数据", fill=TEXT_MUTED,
                       font=font(parent, 12))
        return frame
    top = max([v for _, v in items] + [1])
    n = len(items)
    step = 520.0 / n
    for i, (label, val) in enumerate(items):
        h = 130.0 * val / top
        x0 = step * i + 14
        x1 = step * (i + 1) - 14
        cv.create_rectangle(x0, 150 - h, x1, 150, fill=NAVY, outline=NAVY)
        cv.create_text((x0 + x1) / 2, 150 - h - 10, text=str(val),
                       fill=NAVY, font=font(parent, 11, bold=True))
        cv.create_text((x0 + x1) / 2, 165, text=label[:6], fill=TEXT_MUTED,
                       font=font(parent, 10))
    return frame


def radar_chart(parent, items, title=""):
    """纯 Canvas 雷达图。items: [(标签, 0..1 或 0..100 的掌握度)]。

    值 >1 按百分制换算;少于 3 个维度时退化为横条展示。
    """
    frame = Frame(parent, bg=CARD, highlightbackground=BORDER,
                  highlightthickness=1)
    if title:
        Label(frame, text=title, bg=CARD, fg=NAVY,
              font=font(parent, 13, bold=True)).pack(anchor="w", padx=12,
                                                      pady=(8, 0))
    if not items:
        Label(frame, text="暂无数据", bg=CARD, fg=TEXT_MUTED,
              font=font(parent, 12)).pack(pady=20)
        return frame
    vals = []
    for label, v in items:
        try:
            f = float(v)
        except Exception:
            f = 0.0
        if f > 1.0:
            f = f / 100.0
        vals.append((label, max(0.0, min(1.0, f))))
    if len(vals) < 3:
        for label, f in vals:
            row = Frame(frame, bg=CARD)
            row.pack(fill="x", padx=12, pady=3)
            Label(row, text=label[:10], bg=CARD, fg=TEXT,
                  font=font(parent, 11)).pack(side="left")
            Label(row, text="{0}%".format(int(round(f * 100))), bg=CARD,
                  fg=NAVY, font=font(parent, 11, bold=True)).pack(side="right")
        return frame
    import math
    size = 260
    cx = cy = size / 2 + 10
    r = 95.0
    cv = Canvas(frame, width=size + 120, height=size + 20, bg=CARD,
                highlightthickness=0)
    cv.pack(padx=8, pady=8)
    n = len(vals)
    pts_outer = []
    for i, (label, f) in enumerate(vals):
        ang = -math.pi / 2 + 2 * math.pi * i / n
        x = cx + r * math.cos(ang)
        y = cy + r * math.sin(ang)
        pts_outer.append((x, y))
        lx = cx + (r + 34) * math.cos(ang)
        ly = cy + (r + 34) * math.sin(ang)
        cv.create_text(lx, ly, text=label[:8], fill=TEXT,
                       font=font(parent, 10))
    for ring in (0.33, 0.66, 1.0):
        pts = []
        for (x, y) in pts_outer:
            pts.append(cx + (x - cx) * ring)
            pts.append(cy + (y - cy) * ring)
        cv.create_polygon(pts, outline=BORDER, fill="", width=1)
    for i in range(n):
        cv.create_line(cx, cy, pts_outer[i][0], pts_outer[i][1],
                       fill=BORDER)
    pts = []
    for i, (label, f) in enumerate(vals):
        ang = -math.pi / 2 + 2 * math.pi * i / n
        pts.append(cx + r * f * math.cos(ang))
        pts.append(cy + r * f * math.sin(ang))
    cv.create_polygon(pts, outline=GOLD, fill=NAVY, width=2)
    for i, (label, f) in enumerate(vals):
        ang = -math.pi / 2 + 2 * math.pi * i / n
        cv.create_text(cx + r * f * math.cos(ang),
                       cy + r * f * math.sin(ang) - 10,
                       text="{0}%".format(int(round(f * 100))),
                       fill=NAVY, font=font(parent, 10, bold=True))
    return frame


def donut_chart(parent, parts, title=""):
    """纯 Canvas 环形图。parts: [(标签, 数值, 颜色)]。"""
    frame = Frame(parent, bg=CARD, highlightbackground=BORDER,
                  highlightthickness=1)
    if title:
        Label(frame, text=title, bg=CARD, fg=NAVY,
              font=font(parent, 13, bold=True)).pack(anchor="w", padx=12,
                                                      pady=(8, 0))
    total = sum([v for _, v, _ in parts])
    cv = Canvas(frame, width=200, height=200, bg=CARD,
                highlightthickness=0)
    cv.pack(side="left", padx=8, pady=8)
    if not parts or total <= 0:
        cv.create_text(100, 100, text="暂无数据", fill=TEXT_MUTED,
                       font=font(parent, 12))
    else:
        import math
        start = -90.0
        for label, v, color in parts:
            extent = 360.0 * v / total
            cv.create_arc(20, 20, 180, 180, start=start, extent=extent,
                          fill=color, outline=CARD, width=2, style="pieslice")
            start += extent
        cv.create_oval(65, 65, 135, 135, fill=CARD, outline=CARD)
        cv.create_text(100, 100, text="{0}".format(total), fill=NAVY,
                       font=font(parent, 16, bold=True))
    leg = Frame(frame, bg=CARD)
    leg.pack(side="left", padx=8, pady=8, anchor="w")
    for label, v, color in parts:
        row = Frame(leg, bg=CARD)
        row.pack(fill="x", pady=2)
        Canvas(row, width=14, height=14, bg=color,
               highlightthickness=0).pack(side="left")
        Label(row, text="{0} {1} ({2}%)".format(
            label, v, int(round(100.0 * v / total)) if total else 0),
            bg=CARD, fg=TEXT, font=font(parent, 11)).pack(side="left",
                                                           padx=6)
    return frame


def trend_chart(parent, items, title=""):
    """纯 Canvas 折线趋势图。items: [(标签, 数值)]。"""
    frame = Frame(parent, bg=CARD, highlightbackground=BORDER,
                  highlightthickness=1)
    if title:
        Label(frame, text=title, bg=CARD, fg=NAVY,
              font=font(parent, 13, bold=True)).pack(anchor="w", padx=12,
                                                      pady=(8, 0))
    cv = Canvas(frame, width=520, height=180, bg=CARD,
                highlightthickness=0)
    cv.pack(padx=8, pady=8)
    if not items:
        cv.create_text(260, 90, text="暂无数据", fill=TEXT_MUTED,
                       font=font(parent, 12))
        return frame
    top = max([v for _, v in items] + [1])
    n = len(items)
    step = 500.0 / max(1, n - 1) if n > 1 else 500.0
    pts = []
    for i, (label, val) in enumerate(items):
        x = 10 + step * i
        y = 150 - 120.0 * val / top
        pts.append((x, y))
    cv.create_line(10, 150, 510, 150, fill=BORDER)
    for i in range(len(pts) - 1):
        cv.create_line(pts[i][0], pts[i][1], pts[i + 1][0], pts[i + 1][1],
                       fill=NAVY, width=2)
    for i, (x, y) in enumerate(pts):
        cv.create_oval(x - 4, y - 4, x + 4, y + 4, fill=GOLD,
                       outline=GOLD)
        cv.create_text(x, y - 12, text=str(items[i][1]), fill=NAVY,
                       font=font(parent, 10, bold=True))
        cv.create_text(x, 168, text=items[i][0][:6], fill=TEXT_MUTED,
                       font=font(parent, 10))
    return frame


def heatmap_chart(parent, heat, title=""):
    """纯 Canvas 热力图。heat: {知识点: {部门: 0..1 正确率}}。

    颜色按正确率分档:>=0.85 绿、>=0.6 藏青、<0.6 红;无数据为灰。
    """
    frame = Frame(parent, bg=CARD, highlightbackground=BORDER,
                  highlightthickness=1)
    if title:
        Label(frame, text=title, bg=CARD, fg=NAVY,
              font=font(parent, 13, bold=True)).pack(anchor="w", padx=12,
                                                      pady=(8, 0))
    if not heat:
        Label(frame, text="暂无数据", bg=CARD, fg=TEXT_MUTED,
              font=font(parent, 12)).pack(pady=20)
        return frame
    teams = []
    for kn in heat:
        for t in (heat.get(kn) or {}):
            if t not in teams:
                teams.append(t)
    rows = sorted(heat.keys())
    cell_w, cell_h = 90, 30
    w = 160 + cell_w * max(1, len(teams))
    h = 30 + cell_h * len(rows)
    cv = Canvas(frame, width=w, height=h, bg=CARD, highlightthickness=0)
    cv.pack(padx=8, pady=8)
    for j, t in enumerate(teams):
        cv.create_text(160 + cell_w * j + cell_w / 2, 15, text=t[:8],
                       fill=NAVY, font=font(parent, 11, bold=True))
    for i, kn in enumerate(rows):
        y = 30 + cell_h * i
        cv.create_text(150, y + cell_h / 2, text=kn[:10], fill=TEXT,
                       font=font(parent, 11), anchor="e")
        for j, t in enumerate(teams):
            x = 160 + cell_w * j
            v = (heat.get(kn) or {}).get(t)
            if v is None:
                color, txt = "#E5E7EB", "-"
            elif v >= 0.85:
                color, txt = "#DCFCE7", "{0}%".format(int(round(v * 100)))
            elif v >= 0.6:
                color, txt = "#DBEAFE", "{0}%".format(int(round(v * 100)))
            else:
                color, txt = "#FEE2E2", "{0}%".format(int(round(v * 100)))
            cv.create_rectangle(x + 2, y + 2, x + cell_w - 2,
                                y + cell_h - 2, fill=color, outline=CARD)
            cv.create_text(x + cell_w / 2, y + cell_h / 2, text=txt,
                           fill=TEXT, font=font(parent, 11))
    return frame


def option_letters(options):
    return sorted(options.keys())


class QuestionPanel(object):
    """答题面板:题号/题型 pill/题干/题图/选项行/提交/判分反馈。

    由练习、模拟考、正式考试共用。
    - q: 题目 dict(练习题单不含答案)。
    - on_submit(answer, self_correct): 提交回调,返回判分 dict 或 None。
      面板自行渲染判分结果(正确答案/解析/智能分析)。
    - on_space: 面板注册空格推进回调到 app。
    - shuffle: 是否打乱选项顺序;editable: 提交前是否可改。
    """

    def __init__(self, app, parent, q, index, total, on_submit=None,
                 show_feedback=True, shuffle=False, lock=True):
        self.app = app
        self.parent = parent
        self.q = q
        self.index = index
        self.total = total
        self.on_submit = on_submit
        self.show_feedback = show_feedback
        self.lock = lock
        self.submitted = False
        self.result = None
        self.selected = set()
        self.single = None
        self.frame = Frame(parent, bg=CARD, highlightbackground=BORDER,
                           highlightthickness=1)
        self.frame.pack(fill="both", expand=True, padx=12, pady=8)
        self._build(shuffle)

    def _build(self, shuffle):
        app = self.app
        sz = sizes(app.prefs_large())
        q = self.q
        top = Frame(self.frame, bg=CARD)
        top.pack(fill="x", padx=14, pady=(12, 4))
        Label(top, text="第 {0}/{1} 题".format(self.index + 1, self.total),
              bg=CARD, fg=NAVY, font=font(top, sz["h2"], bold=True)
              ).pack(side="left")
        Label(top, text=q.get("no", ""), bg=CARD, fg=TEXT_MUTED,
              font=font(top, sz["small"])).pack(side="left", padx=10)
        pill = Label(top, text=q.get("type", ""), bg=NAVY, fg="#FFFFFF",
                     font=font(top, sz["pill"], bold=True), padx=10, pady=2)
        pill.pack(side="left", padx=6)
        Label(top, text=q.get("category", ""), bg=PRIMARY_LIGHT, fg=NAVY,
              font=font(top, sz["pill"]), padx=8, pady=2).pack(side="left")
        stem = Label(self.frame, text=q.get("stem", ""), bg=CARD, fg=TEXT,
                     font=font(self.frame, sz["stem"]), wraplength=860,
                     justify="left", anchor="w")
        stem.pack(fill="x", padx=14, pady=6)
        if q.get("image"):
            img = Label(self.frame, text="题图:{0} (点击放大)".format(
                q.get("image")), bg=GOLD_LIGHT, fg=NAVY,
                font=font(self.frame, sz["small"]), padx=8, pady=4,
                cursor="hand2")
            img.pack(anchor="w", padx=14, pady=4)
            img.bind("<Button-1>", lambda e: self._zoom_image())
        self.opt_area = Frame(self.frame, bg=CARD)
        self.opt_area.pack(fill="x", padx=14, pady=4)
        self.entry_var = None
        self.text_widget = None
        self.letters = []
        qtype = q.get("type", "")
        if qtype in ("单选", "判断"):
            opts = dict(q.get("options") or {})
            if qtype == "判断":
                opts = {"A": "对", "B": "错"}
            self.letters = option_letters(opts)
            if shuffle:
                random.shuffle(self.letters)
            for letter in self.letters:
                self._option_row(letter, opts[letter], "single")
        elif qtype == "多选":
            opts = dict(q.get("options") or {})
            self.letters = option_letters(opts)
            if shuffle:
                random.shuffle(self.letters)
            for letter in self.letters:
                self._option_row(letter, opts[letter], "multi")
        elif qtype == "填空":
            Label(self.opt_area, text="请填写答案:", bg=CARD, fg=TEXT_MUTED,
                  font=font(self.opt_area, sz["small"])).pack(anchor="w")
            self.entry_var = StringVar()
            Entry(self.opt_area, textvariable=self.entry_var,
                  font=font(self.opt_area, sz["option"]),
                  width=40).pack(anchor="w", pady=4)
        elif qtype == "简答":
            Label(self.opt_area, text="请作答(交卷后对照参考答案自评):",
                  bg=CARD, fg=TEXT_MUTED,
                  font=font(self.opt_area, sz["small"])).pack(anchor="w")
            self.text_widget = Text(self.opt_area, height=5, width=80,
                                    font=font(self.opt_area, sz["option"]))
            self.text_widget.pack(fill="x", pady=4)
        self.btn_row = Frame(self.frame, bg=CARD)
        self.btn_row.pack(fill="x", padx=14, pady=8)
        self.submit_btn = Button(self.btn_row, text="提交答案",
                                 style="Navy.TButton",
                                 command=self.submit)
        self.submit_btn.pack(side="left")
        # 点完按钮把焦点还给主窗口,避免空格被按钮抢走
        self.submit_btn.bind("<Button-1>",
                             lambda e: self.frame.after(50, self._refocus))
        self.feedback = Frame(self.frame, bg=CARD)
        self.feedback.pack(fill="x", padx=14, pady=4)
        self.self_row = Frame(self.frame, bg=CARD)

    def _refocus(self):
        try:
            self.app.root.focus_set()
        except Exception:
            pass

    def _zoom_image(self):
        top = Toplevel(self.frame)
        top.title("题图")
        top.geometry("640x420+200+120")
        top.configure(bg=CARD)
        Label(top, text="题图文件:{0}".format(self.q.get("image", "")),
              bg=CARD, fg=NAVY, font=font(top, 13)).pack(pady=12)
        Label(top, text="图片文件位于服务器 data/assets/ 目录。\n"
              "本客户端不内置图片解码,仅显示文件名。",
              bg=CARD, fg=TEXT_MUTED, font=font(top, 12),
              justify="left").pack(pady=12)
        Button(top, text="关闭", style="Navy.TButton",
               command=top.destroy).pack(pady=10)

    def _option_row(self, letter, text, kind):
        row = Frame(self.opt_area, bg=CARD, highlightbackground=BORDER,
                    highlightthickness=1)
        row.pack(fill="x", pady=3)
        cv = Canvas(row, width=30, height=30, bg=CARD,
                    highlightthickness=0)
        cv.pack(side="left", padx=6, pady=4)
        lab = Label(row, text="{0}. {1}".format(letter, text), bg=CARD,
                    fg=TEXT, font=font(row, sizes(self.app.prefs_large())["option"]),
                    anchor="w", justify="left", wraplength=780)
        lab.pack(side="left", fill="x", expand=True, padx=4, pady=4)
        row._letter = letter
        row._kind = kind
        row._cv = cv
        row._lab = lab
        row._selected = False
        self._draw_mark(row)
        for w in (row, cv, lab):
            w.bind("<Button-1>", lambda e, r=row: self._toggle(r))
        if not hasattr(self, "rows"):
            self.rows = []
        self.rows.append(row)

    def _draw_mark(self, row):
        cv = row._cv
        cv.delete("all")
        sel = row._selected
        if self.submitted and self.result:
            correct = self.result.get("correct_answer") or ""
            letter = row._letter
            if letter in correct:
                fill, outline = GREEN, GREEN
            elif sel:
                fill, outline = RED, RED
            else:
                fill, outline = CARD, TEXT_MUTED
        else:
            fill = NAVY if sel else CARD
            outline = NAVY if sel else TEXT_MUTED
        if row._kind == "single":
            cv.create_oval(5, 5, 25, 25, outline=outline, width=2,
                           fill=CARD)
            if sel or (self.submitted and self.result and
                       row._letter in (self.result.get("correct_answer") or "")):
                cv.create_oval(10, 10, 20, 20, fill=fill, outline=fill)
        else:
            cv.create_rectangle(5, 5, 25, 25, outline=outline, width=2,
                                fill=CARD)
            if sel:
                cv.create_line(8, 15, 13, 20, 18, 9, fill=NAVY, width=3)
                cv.create_line(13, 20, 23, 8, fill=NAVY, width=3)
        # 选中态:藏青底白字;判分后正确绿、错选红
        if self.submitted and self.result:
            correct = self.result.get("correct_answer") or ""
            if row._letter in correct:
                bg, fg = "#DCFCE7", "#166534"
            elif row._selected:
                bg, fg = "#FEE2E2", "#991B1B"
            else:
                bg, fg = CARD, TEXT
        elif row._selected:
            bg, fg = NAVY, "#FFFFFF"
        else:
            bg, fg = CARD, TEXT
        row.configure(bg=bg)
        row._cv.configure(bg=bg)
        row._lab.configure(bg=bg, fg=fg)

    def _toggle(self, row):
        if self.submitted:
            return
        if row._kind == "single":
            for r in self.rows:
                r._selected = (r is row)
                self._draw_mark(r)
            self.single = row._letter
        else:
            row._selected = not row._selected
            if row._selected:
                self.selected.add(row._letter)
            else:
                self.selected.discard(row._letter)
            self._draw_mark(row)

    def current_answer(self):
        qtype = self.q.get("type", "")
        if qtype in ("单选", "判断"):
            if self.single is None:
                return ""
            if qtype == "判断":
                return "对" if self.single == "A" else "错"
            return self.single
        if qtype == "多选":
            return "".join(sorted(self.selected))
        if qtype == "填空":
            return (self.entry_var.get() if self.entry_var else "").strip()
        if qtype == "简答":
            if self.text_widget:
                return self.text_widget.get("1.0", "end").strip()
            return ""
        return ""

    def set_answer(self, answer):
        """断线恢复:回填已保存答案。"""
        if not answer:
            return
        qtype = self.q.get("type", "")
        if qtype in ("单选", "判断") and hasattr(self, "rows"):
            letter = answer
            if qtype == "判断":
                letter = "A" if answer == "对" else "B"
            for r in self.rows:
                if r._letter == letter:
                    self._toggle(r)
        elif qtype == "多选" and hasattr(self, "rows"):
            for r in self.rows:
                if r._letter in answer and not r._selected:
                    self._toggle(r)
        elif qtype == "填空" and self.entry_var:
            self.entry_var.set(answer)
        elif qtype == "简答" and self.text_widget:
            self.text_widget.delete("1.0", "end")
            self.text_widget.insert("1.0", answer)

    def submit(self):
        if self.submitted:
            return None
        ans = self.current_answer()
        if not self.lock:
            # 考试模式:提交 = 保存答案,不锁定、不判分、不出反馈
            if self.on_submit:
                return self.on_submit(ans, self)
            return None
        self.submitted = True
        result = None
        if self.on_submit:
            result = self.on_submit(ans, self)
        if result is not None:
            self.result = result
        else:
            self.result = {}
        if hasattr(self, "rows"):
            for r in self.rows:
                self._draw_mark(r)
        self.submit_btn.configure(state="disabled")
        if self.show_feedback:
            self._render_feedback()
        self._refocus()
        return self.result

    def _render_feedback(self):
        clear(self.feedback)
        r = self.result or {}
        sz = sizes(self.app.prefs_large())
        correct = r.get("correct")
        if correct is True:
            Label(self.feedback, text="回答正确", bg="#DCFCE7",
                  fg="#166534", font=font(self.feedback, sz["h2"], bold=True),
                  anchor="w").pack(fill="x", pady=2)
        elif correct is False:
            Label(self.feedback, text="回答错误", bg="#FEE2E2",
                  fg="#991B1B", font=font(self.feedback, sz["h2"], bold=True),
                  anchor="w").pack(fill="x", pady=2)
        if r.get("correct_answer") is not None:
            Label(self.feedback,
                  text="正确答案:{0}".format(r.get("correct_answer")),
                  bg=CARD, fg=NAVY, font=font(self.feedback, sz["body"], bold=True),
                  anchor="w", wraplength=860, justify="left").pack(fill="x", pady=2)
        if r.get("analysis"):
            Label(self.feedback, text="解析:{0}".format(r.get("analysis")),
                  bg=CARD, fg=TEXT, font=font(self.feedback, sz["body"]),
                  anchor="w", wraplength=860, justify="left").pack(fill="x", pady=2)
        if r.get("in_wrong_book"):
            Label(self.feedback, text="本题已加入错题本",
                  bg=CARD, fg=TEXT_MUTED,
                  font=font(self.feedback, sz["small"]), anchor="w"
                  ).pack(fill="x", pady=2)
        sa = r.get("smart_analysis") or {}
        sat = r.get("smart_analysis_text") or ""
        if self.app.prefs.get("smart_analysis", True) and (sa or sat):
            box = Frame(self.feedback, bg=GOLD_LIGHT,
                        highlightbackground=GOLD, highlightthickness=1)
            box.pack(fill="x", pady=6)
            Label(box, text="智能分析", bg=GOLD_LIGHT, fg=NAVY,
                  font=font(box, sz["h2"], bold=True), anchor="w"
                  ).pack(fill="x", padx=10, pady=(6, 2))
            if isinstance(sa, dict):
                for head, key in (("错因分析", "wrong_reason"),
                                  ("逐选项辨析", "option_notes"),
                                  ("答案关键点", "key_points"),
                                  ("理解与记忆建议", "advice")):
                    val = sa.get(key)
                    if not val:
                        continue
                    if isinstance(val, list):
                        val = "\n".join(val)
                    Label(box, text="{0}:{1}".format(head, val),
                          bg=GOLD_LIGHT, fg=TEXT,
                          font=font(box, sz["body"]), anchor="w",
                          wraplength=840, justify="left").pack(fill="x",
                                                               padx=10, pady=2)
            elif sat:
                Label(box, text=sat, bg=GOLD_LIGHT, fg=TEXT,
                      font=font(box, sz["body"]), anchor="w", wraplength=840,
                      justify="left").pack(fill="x", padx=10, pady=2)
            Label(box, text="", bg=GOLD_LIGHT).pack(pady=2)


def render_results(parent, app, results, show_only_wrong=False):
    """逐题解析列表。results 为契约 result 对象数组。"""
    frame = Frame(parent, bg=BG)
    frame.pack(fill="both", expand=True)
    shown = 0
    for r in results or []:
        if show_only_wrong and r.get("correct") is not False:
            continue
        shown += 1
        card = Frame(frame, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1)
        card.pack(fill="x", padx=12, pady=6)
        head = Frame(card, bg=CARD)
        head.pack(fill="x", padx=12, pady=(8, 2))
        mark = "正确" if r.get("correct") is True else (
            "错误" if r.get("correct") is False else "待自评")
        fg = GREEN if r.get("correct") is True else (
            RED if r.get("correct") is False else TEXT_MUTED)
        Label(head, text="{0} {1}".format(r.get("no", ""), r.get("type", "")),
              bg=CARD, fg=NAVY, font=font(head, 13, bold=True)).pack(side="left")
        Label(head, text=mark, bg=CARD, fg=fg,
              font=font(head, 12, bold=True)).pack(side="left", padx=10)
        Label(head, text="得分 {0}/{1}".format(r.get("score", 0),
              r.get("full_score", 0)), bg=CARD, fg=TEXT_MUTED,
              font=font(head, 11)).pack(side="right")
        Label(card, text=r.get("stem", ""), bg=CARD, fg=TEXT,
              font=font(card, 13), wraplength=860, justify="left",
              anchor="w").pack(fill="x", padx=12, pady=2)
        if r.get("options"):
            for letter in sorted(r.get("options").keys()):
                Label(card, text="{0}. {1}".format(letter, r["options"][letter]),
                      bg=CARD, fg=TEXT_MUTED, font=font(card, 12),
                      anchor="w", wraplength=860, justify="left"
                      ).pack(fill="x", padx=24)
        Label(card, text="你的答案:{0}   正确答案:{1}".format(
            r.get("user_answer", ""), r.get("correct_answer", "")),
            bg=CARD, fg=NAVY, font=font(card, 12, bold=True),
            anchor="w").pack(fill="x", padx=12, pady=2)
        if r.get("analysis"):
            Label(card, text="解析:{0}".format(r.get("analysis")),
                  bg=CARD, fg=TEXT, font=font(card, 12), anchor="w",
                  wraplength=860, justify="left").pack(fill="x", padx=12,
                                                        pady=(0, 8))
    if shown == 0:
        Label(frame, text="全部答对,没有错题", bg=BG, fg=GREEN,
              font=font(frame, 14)).pack(pady=20)
    return frame
