# -*- coding: utf-8 -*-
"""常熟站智考通 v2.2 — 题目上报:学员提交、我的上报、管理员处理。

上报类型:题干有歧义 / 答案有误 / 解析有误 / 其他问题。
处理动作:已解决 / 驳回 / 停用该题(同时把题目状态置为停用)。
Python 3.4 兼容语法。
"""
import db
import questions as qmod

REPORT_TYPES = ('题干有歧义', '答案有误', '解析有误', '其他问题')


def submit_report(user_id, question_id, rtype, detail=''):
    if rtype not in REPORT_TYPES:
        return None, "上报类型不合法"
    if qmod.get_question(question_id) is None:
        return None, "题目不存在"
    conn = db.get_conn()
    with db.DB_LOCK:
        cur = conn.execute(
            "INSERT INTO reports(user_id, question_id, type, detail, status, reply, created_at, handled_at)"
            " VALUES(?, ?, ?, ?, '待处理', '', datetime('now', 'localtime'), '')",
            (user_id, question_id, rtype, detail or ''))
        conn.commit()
        rid = cur.lastrowid
    return {'id': rid, 'status': '待处理'}, ""


def _report_dict(row, with_question=False):
    d = db.row_to_dict(row)
    if with_question:
        q = qmod.get_question(d['question_id'])
        d['question'] = qmod.question_to_dict(q) if q is not None else None
    conn = db.get_conn()
    with db.DB_LOCK:
        u = conn.execute("SELECT username, name, department FROM users WHERE id=?",
                         (d['user_id'],)).fetchone()
    if u is not None:
        d['reporter'] = {'username': u['username'], 'name': u['name'],
                         'department': u['department']}
    return d


def my_reports(user_id):
    conn = db.get_conn()
    with db.DB_LOCK:
        rows = conn.execute("SELECT * FROM reports WHERE user_id=? ORDER BY id DESC",
                            (user_id,)).fetchall()
    return [_report_dict(r, with_question=True) for r in rows]


def list_reports(status=''):
    conn = db.get_conn()
    with db.DB_LOCK:
        if status:
            rows = conn.execute("SELECT * FROM reports WHERE status=? ORDER BY id",
                                (status,)).fetchall()
        else:
            rows = conn.execute("SELECT * FROM reports ORDER BY id").fetchall()
    return [_report_dict(r, with_question=True) for r in rows]


def handle_report(report_id, action, reply=''):
    """action: 已解决 / 已驳回 / 停用该题。停用该题 = 标记已解决 + 题目停用。"""
    if action not in ('已解决', '已驳回', '停用该题'):
        return False, "处理动作不合法"
    conn = db.get_conn()
    with db.DB_LOCK:
        row = conn.execute("SELECT * FROM reports WHERE id=?", (report_id,)).fetchone()
        if row is None:
            return False, "上报不存在"
        if row['status'] != '待处理':
            return False, "该上报已处理过"
        status = '已解决' if action == '停用该题' else action
        conn.execute(
            "UPDATE reports SET status=?, reply=?, handled_at=datetime('now', 'localtime') WHERE id=?",
            (status, reply or '', report_id))
        if action == '停用该题':
            conn.execute("UPDATE questions SET status='停用' WHERE id=?",
                         (row['question_id'],))
        conn.commit()
    return True, ""
