# -*- coding: utf-8 -*-
"""常熟站智考通 v2.2 — 运维备份自动化:一键备份、保留 7 份、恢复前再备一份、
每日自动备份守护线程、磁盘状态。

照抄刷题宝 v0.7 server.py 3130–3288、3391 行的逻辑。
Python 3.4 兼容:不用 sqlite3.Connection.backup(3.7+ 才有),恢复用“关连接、
拷文件、重开连接”的方式;备份包里的数据库文件名为 zhikaotong.db。
"""
import os
import shutil
import sqlite3
import threading
import time
import zipfile
from datetime import datetime

import db

AUTO_BACKUP_KEEP = 7


def _data_dir():
    return os.path.dirname(db.DB_PATH or '')


def _backup_dir():
    return os.path.join(_data_dir(), 'backups')


def _assets_dir():
    return os.path.join(_data_dir(), 'assets')


def _upload_dir():
    return os.path.join(_data_dir(), 'uploads')


def disk_status():
    try:
        du = shutil.disk_usage(_data_dir() or '.')
        return {'total_gb': round(du.total / 1024 ** 3, 1),
                'free_gb': round(du.free / 1024 ** 3, 1),
                'used_pct': round(100 * (du.total - du.free) / du.total, 1) if du.total else 0}
    except Exception:
        return {'total_gb': 0, 'free_gb': 0, 'used_pct': 0}


def list_backups():
    conn = db.get_conn()
    with db.DB_LOCK:
        rows = conn.execute(
            "SELECT * FROM backups_meta ORDER BY id DESC").fetchall()
    return [db.row_to_dict(r) for r in rows]


def make_backup(note, user):
    """一键备份:数据库 + 题库附件 + 待指派图片,打成带时间戳的 zip。"""
    bdir = _backup_dir()
    try:
        os.makedirs(bdir)
    except OSError:
        pass
    conn = db.get_conn()
    try:
        conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
    except Exception:
        pass
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    fname = "backup-{0}.zip".format(ts)
    fpath = os.path.join(bdir, fname)
    n = 2
    while os.path.exists(fpath):
        fname = "backup-{0}-{1}.zip".format(ts, n)
        fpath = os.path.join(bdir, fname)
        n += 1
    with zipfile.ZipFile(fpath, "w", zipfile.ZIP_DEFLATED) as z:
        if os.path.isfile(db.DB_PATH):
            z.write(db.DB_PATH, "zhikaotong.db")
        for folder, prefix in ((_assets_dir(), "assets"), (_upload_dir(), "uploads")):
            if os.path.isdir(folder):
                for fn in sorted(os.listdir(folder)):
                    fp = os.path.join(folder, fn)
                    if os.path.isfile(fp):
                        z.write(fp, "{0}/{1}".format(prefix, fn))
    size = os.path.getsize(fpath)
    with db.DB_LOCK:
        conn.execute(
            "INSERT INTO backups_meta(filename, note, created_at, size_bytes, status)"
            " VALUES(?, ?, datetime('now', 'localtime'), ?, 'ok')",
            (fname, note, size))
        conn.commit()
    return {'ok': True, 'filename': fname, 'size_bytes': size, 'note': note}


def keep_count():
    try:
        return int(db.get_setting('backup_keep', '7') or 7)
    except (TypeError, ValueError):
        return AUTO_BACKUP_KEEP


def prune_backups(keep=None):
    """只保留最近 keep 份备份,旧的连文件带记录一起删。返回删掉的份数。"""
    if keep is None:
        keep = keep_count()
    rows = list_backups()
    removed = 0
    for r in rows[keep:]:
        try:
            fp = os.path.join(_backup_dir(), r['filename'])
            if os.path.isfile(fp):
                os.remove(fp)
            conn = db.get_conn()
            with db.DB_LOCK:
                conn.execute("DELETE FROM backups_meta WHERE id=?", (r['id'],))
                conn.commit()
            removed += 1
        except Exception:
            continue
    return removed


def restore_backup_file(fname, user):
    """恢复备份:先自动再备一份当前库防丢,再用文件覆盖方式恢复数据库与附件。
    (Python 3.4 没有 sqlite3.Connection.backup,故关连接后直接拷库文件。)"""
    safe = os.path.basename(fname or '')
    if not safe.endswith('.zip') or '/' in fname or '\\' in fname:
        return {'ok': False, 'error': '备份文件名不正确'}
    fpath = os.path.join(_backup_dir(), safe)
    if not os.path.isfile(fpath):
        return {'ok': False, 'error': '备份文件不存在'}
    tmpd = os.path.join(_backup_dir(), '_restore_tmp')
    shutil.rmtree(tmpd, ignore_errors=True)
    try:
        os.makedirs(tmpd)
    except OSError:
        pass
    try:
        with zipfile.ZipFile(fpath) as z:
            names = z.namelist()
            if 'zhikaotong.db' not in names:
                return {'ok': False, 'error': '备份包里没有数据库文件,无法恢复'}
            z.extractall(tmpd)
    except Exception as e:
        return {'ok': False, 'error': '备份包损坏,无法解包:{0}'.format(e)}
    auto = make_backup("恢复前自动备份(恢复 " + safe + " 之前)", user)
    try:
        src_db = os.path.join(tmpd, 'zhikaotong.db')
        conn = db.get_conn()
        try:
            conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
        except Exception:
            pass
        db.close_conn()
        for suf in ('-wal', '-shm'):
            try:
                os.remove(db.DB_PATH + suf)
            except OSError:
                pass
        shutil.copyfile(src_db, db.DB_PATH)
        for folder, prefix in ((_assets_dir(), 'assets'), (_upload_dir(), 'uploads')):
            src_folder = os.path.join(tmpd, prefix)
            if os.path.isdir(src_folder):
                shutil.rmtree(folder, ignore_errors=True)
                shutil.copytree(src_folder, folder)
        shutil.rmtree(tmpd, ignore_errors=True)
        db.init_db()
    except Exception as e:
        shutil.rmtree(tmpd, ignore_errors=True)
        return {'ok': False,
                'error': '恢复失败:{0}(已先自动备份当前库:{1})'.format(
                    e, auto.get('filename', ''))}
    # 恢复把源库时间点的记录表整个换回来,之后建的备份(文件还在磁盘上)记录会丢,
    # 扫一遍磁盘重新记回来。
    try:
        conn = db.get_conn()
        have = set([r[0] for r in conn.execute(
            "SELECT filename FROM backups_meta").fetchall()])
        with db.DB_LOCK:
            for fn in sorted(os.listdir(_backup_dir())):
                if fn.endswith('.zip') and fn not in have:
                    fp = os.path.join(_backup_dir(), fn)
                    note = "恢复前自动备份" if fn == auto.get('filename') else "恢复后重新发现的备份文件"
                    created = datetime.fromtimestamp(
                        os.path.getmtime(fp)).strftime("%Y-%m-%d %H:%M:%S")
                    conn.execute(
                        "INSERT INTO backups_meta(filename, note, created_at,"
                        " size_bytes, status) VALUES(?, ?, ?, ?, 'ok')",
                        (fn, note, created, os.path.getsize(fp)))
                    have.add(fn)
            conn.commit()
    except Exception:
        pass
    db.audit(user, 'backup_restore',
             "从 {0} 恢复(恢复前已自动备份 {1})".format(safe, auto.get('filename', '')))
    return {'ok': True, 'restored': safe, 'auto_backup': auto.get('filename', '')}


def auto_backup_loop():
    """每日自动备份守护线程:每小时看一次,超过 24 小时没有备份就备一份,
    保留最近 7 份。"""
    while True:
        try:
            time.sleep(3600)
            rows = list_backups()
            last = rows[0]['created_at'] if rows else ''
            need = True
            if last:
                try:
                    need = (datetime.now()
                            - datetime.strptime(last, "%Y-%m-%d %H:%M:%S")).total_seconds() > 24 * 3600
                except Exception:
                    need = True
            if need:
                make_backup("每日自动备份", "system")
                prune_backups()
        except Exception:
            continue


def start_auto_backup_thread():
    if os.environ.get('ZHIKAOTONG_AUTOBACKUP', '1') != '0':
        t = threading.Thread(target=auto_backup_loop)
        t.daemon = True
        t.start()


def backup_status_summary():
    rows = list_backups()
    last = rows[0] if rows else None
    d = disk_status()
    return {'count': len(rows),
            'last_filename': last['filename'] if last else '',
            'last_at': last['created_at'] if last else '',
            'last_size': last.get('size_bytes', 0) if last else 0,
            'auto': os.environ.get('ZHIKAOTONG_AUTOBACKUP', '1') != '0',
            'keep': keep_count(), 'disk': d}
