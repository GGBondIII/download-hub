/* 常熟站智考通 v2.2 网页版 — 现代版单页应用（ES6） */
'use strict';
const API = '';
const VERSION = 'v2.2';
const $ = (s, r) => (r || document).querySelector(s);
const $$ = (s, r) => Array.from((r || document).querySelectorAll(s));
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmtTime = sec => { sec = Math.max(0, Math.floor(sec)); const h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60; return (h ? h + ':' : '') + String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0'); };
const TYPES = ['单选', '多选', '判断', '填空', '简答'];
const REPORT_TYPES = ['题干有歧义', '答案有误', '解析有误', '其他问题'];

const state = {
  token: localStorage.getItem('zk_token') || '',
  user: null,
  view: 'home',
  prefs: JSON.parse(localStorage.getItem('zk_prefs') || '{"font":"标准","shuffle":false,"showAnalysis":true}'),
  practice: null,   // {mode, category, type, questions, idx, correct, wrong, submitted, result, selfDone}
  mock: null,       // {id, questions, answers, idx, timer, config, startedAt, duration}
  exam: null,       // {id, exam, questions, answers, idx, timer, duration}
  timerId: null,
};

function savePrefs() { localStorage.setItem('zk_prefs', JSON.stringify(state.prefs)); applyPrefs(); }
function applyPrefs() { document.body.classList.toggle('font-xl', state.prefs.font === '特大'); }

/* ---------- 提示条与确认框（不用原生 alert/confirm） ---------- */
let toastTimer = null;
function toast(msg, isErr) {
  const t = $('#toast'); t.textContent = msg; t.classList.toggle('err', !!isErr); t.classList.add('show');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 3200);
}
function confirmDlg(msg) {
  return new Promise(resolve => {
    const old = $('#confirm-bar'); if (old) old.remove();
    const bar = document.createElement('div'); bar.id = 'confirm-bar';
    bar.innerHTML = '<div>' + esc(msg) + '</div><div class="row"><button class="btn ghost" id="cf-no">取消</button><button class="btn" id="cf-yes">确定</button></div>';
    document.body.appendChild(bar);
    $('#cf-yes').onclick = () => { bar.remove(); resolve(true); };
    $('#cf-no').onclick = () => { bar.remove(); resolve(false); };
  });
}
function modal(html) {
  const root = $('#modal-root');
  root.innerHTML = '<div class="modal-bg" id="modal-bg"><div class="modal">' + html + '</div></div>';
  $('#modal-bg').addEventListener('click', e => { if (e.target.id === 'modal-bg') closeModal(); });
}
function closeModal() { $('#modal-root').innerHTML = ''; }

/* ---------- API ---------- */
async function api(path, opts) {
  opts = opts || {};
  const headers = { 'Content-Type': 'application/json' };
  if (state.token) headers['X-Token'] = state.token;
  let res;
  try {
    res = await fetch(API + path, { method: opts.method || 'GET', headers, body: opts.body ? JSON.stringify(opts.body) : undefined });
  } catch (e) { throw new Error('无法连接服务器，请检查服务器地址与网络'); }
  const ct = res.headers.get('content-type') || '';
  if (ct.indexOf('application/json') === -1) return { ok: res.ok, raw: res, data: null };
  const json = await res.json();
  if (res.status === 401) { logout(true); throw new Error('登录已过期，请重新登录'); }
  if (!json.ok) throw new Error(json.error || '请求失败');
  return json;
}
async function apiGet(path) { return (await api(path)).data; }
async function apiPost(path, body) { return (await api(path, { method: 'POST', body: body || {} })).data; }
async function apiPut(path, body) { return (await api(path, { method: 'PUT', body: body || {} })).data; }
async function apiDel(path, body) { return (await api(path, { method: 'DELETE', body: body || {} })).data; }

/* ---------- 登录 / 注册 ---------- */
function logout(silent) {
  if (state.token) apiPost('/api/auth/logout', {}).catch(() => {});
  state.token = ''; state.user = null; localStorage.removeItem('zk_token');
  stopTimer(); state.practice = null; state.mock = null; state.exam = null;
  if (!silent) toast('已退出登录');
  renderLogin();
}
async function renderLogin() {
  applyPrefs();
  let latest = null;
  try { latest = (await apiGet('/api/version')).latest; } catch (e) { /* 离线时不提示更新 */ }
  const showUpdate = latest && latest.version !== VERSION;
  $('#app').innerHTML = `
  <div class="login-page">
    <button class="exit-link" onclick="window.close();toast('请直接关闭浏览器窗口退出')">退出 ✕</button>
    <div class="login-card">
      <img class="logo" src="/static/logo.svg" alt="常熟站智考通 logo">
      <h1>常熟站智考通</h1>
      <div class="sub">一站式备考</div>
      ${showUpdate ? `<div class="update-bar">发现新版本 ${esc(latest.version)}：${esc(latest.note || '')}<button class="btn small gold" onclick="toast('新版本由服务器统一发布，请联系管理员获取更新包')">立即更新</button></div>` : ''}
      <form id="login-form">
        <label for="server">服务器地址</label>
        <input type="text" id="server" placeholder="默认本机，如 http://192.168.1.10:8766" value="${esc(localStorage.getItem('zk_server') || '')}">
        <label for="username">用户名</label>
        <input type="text" id="username" autocomplete="username" placeholder="请输入用户名">
        <label for="password">密码</label>
        <input type="password" id="password" autocomplete="current-password" placeholder="请输入密码">
        <div style="margin-top:20px"><button class="btn block" type="submit">登录</button></div>
      </form>
      <div class="links">没有账号？<a href="#" id="go-register">学员注册</a> &nbsp;·&nbsp; <a href="/lite">Lite 版（老浏览器）</a></div>
      <div class="ver">常熟站智考通 v2.2</div>
    </div>
  </div>`;
  $('#go-register').onclick = e => { e.preventDefault(); renderRegister(); };
  $('#login-form').onsubmit = async e => {
    e.preventDefault();
    const server = $('#server').value.trim();
    const username = $('#username').value.trim();
    const password = $('#password').value;
    if (!username || !password) { toast('请填写用户名和密码', true); return; }
    if (server) localStorage.setItem('zk_server', server);
    try {
      const data = await apiPost('/api/auth/login', { username, password });
      state.token = data.token; state.user = data.user;
      localStorage.setItem('zk_token', data.token);
      toast('登录成功，你好，' + data.user.name);
      renderApp();
    } catch (err) { toast(err.message, true); }
  };
}
function renderRegister() {
  $('#app').innerHTML = `
  <div class="login-page">
    <div class="login-card">
      <img class="logo" src="/static/logo.svg" alt="常熟站智考通 logo">
      <h1>学员注册</h1>
      <div class="sub">一站式备考</div>
      <form id="reg-form">
        <label for="r-name">姓名 *</label><input type="text" id="r-name" placeholder="请输入姓名">
        <label for="r-dept">部门 *</label><input type="text" id="r-dept" placeholder="请输入部门">
        <label for="r-user">用户名 *</label><input type="text" id="r-user" placeholder="请输入用户名">
        <label for="r-pass">密码（至少 6 位）*</label><input type="password" id="r-pass" placeholder="请输入密码">
        <label for="r-invite">邀请码（向管理员索取）*</label><input type="text" id="r-invite" placeholder="请输入邀请码">
        <div style="margin-top:20px"><button class="btn block" type="submit">注册</button></div>
      </form>
      <div class="links"><a href="#" id="back-login">返回登录</a></div>
      <div class="ver">常熟站智考通 v2.2</div>
    </div>
  </div>`;
  $('#back-login').onclick = e => { e.preventDefault(); renderLogin(); };
  $('#reg-form').onsubmit = async e => {
    e.preventDefault();
    const body = { name: $('#r-name').value.trim(), department: $('#r-dept').value.trim(), username: $('#r-user').value.trim(), password: $('#r-pass').value, invite_code: $('#r-invite').value.trim() };
    if (!body.name || !body.department || !body.username) { toast('请填写姓名、部门和用户名', true); return; }
    if (body.password.length < 6) { toast('密码至少 6 位', true); return; }
    try { await apiPost('/api/auth/register', body); toast('注册成功，请登录'); renderLogin(); }
    catch (err) { toast(err.message, true); }
  };
}

/* ---------- 顶栏 / 导航 ---------- */
function navItems() {
  const r = state.user.role;
  if (r === 'admin') return [['home', '首页'], ['users', '用户管理'], ['reports', '上报处理'], ['stats', '统计分析'], ['dashboard', '统计仪表盘'], ['plans', '学习计划'], ['federation', '联邦共享'], ['backup', '备份管理'], ['bank', '题库版本'], ['versions', '客户端更新发布'], ['settings', '系统设置']];
  if (r === 'examiner') return [['home', '首页'], ['exams', '考试管理'], ['questions', '题库管理'], ['templates', '组卷模板'], ['import', '导入任务'], ['quality', '题库质量'], ['essay', '简答批阅'], ['aivariants', 'AI 变式'], ['settings', '系统设置']];
  return [['home', '日常练习'], ['practice2', '自适应练习'], ['report', '我的成绩'], ['plans', '学习计划'], ['mock', '模拟考试'], ['myexams', '正式考试'], ['settings', '系统设置']];
}
function renderApp() {
  applyPrefs();
  const u = state.user;
  $('#app').innerHTML = `
  <header class="topbar">
    <img class="logo" src="/static/logo-small.svg" alt="logo">
    <div class="title">常熟站智考通 <span>v2.2</span></div>
    <div class="spacer"></div>
    <span class="who">${esc(u.name)} · ${esc(u.department)} · ${esc(u.role_name)}</span>
    <button id="btn-logout">退出登录</button>
  </header>
  <nav class="nav" id="nav"></nav>
  <main class="main" id="view"></main>`;
  $('#btn-logout').onclick = () => logout();
  const nav = $('#nav');
  navItems().forEach(([key, label]) => {
    const b = document.createElement('button');
    b.textContent = label; b.dataset.view = key;
    b.onclick = () => go(key);
    nav.appendChild(b);
  });
  go(state.view === 'login' ? 'home' : state.view);
}
function go(view) {
  state.view = view; stopTimer();
  if (state._countRafs) { state._countRafs.forEach(id => cancelAnimationFrame(id)); state._countRafs = []; }
  $$('#nav button').forEach(b => b.classList.toggle('active', b.dataset.view === view));
  const v = $('#view'); if (!v) return;
  v.innerHTML = '<div class="card empty">加载中…</div>';
  const fn = { home: viewHome, practice2: viewPractice2, report: viewMyReport, plans: state.user.role === 'admin' ? viewPlansAdmin : viewPlansMe, mock: viewMock, myexams: viewMyExams, settings: viewSettings, exams: viewAdminExams, questions: viewQuestions, templates: viewTemplates, import: viewImportJobs, quality: viewQuality, essay: viewEssayQueue, aivariants: viewAIVariants, users: viewUsers, reports: viewAdminReports, stats: viewStats, dashboard: viewDashboard, federation: viewFederation, backup: viewBackup, bank: viewBankVersions, versions: viewVersions }[view] || viewHome;
  fn(v).catch(err => { v.innerHTML = '<div class="card empty">加载失败：' + esc(err.message) + '</div>'; });
}
function stopTimer() { if (state.timerId) { clearInterval(state.timerId); state.timerId = null; } }

/* ---------- SVG 图表 ---------- */
function barChart(data, opts) {
  // data: [{label, value}]
  opts = opts || {};
  const max = Math.max.apply(null, data.map(d => d.value).concat([1]));
  const W = 560, H = 180, pad = 28, bw = Math.min(48, (W - pad * 2) / Math.max(data.length, 1) - 10);
  let bars = '', labels = '';
  data.forEach((d, i) => {
    const h = Math.max(2, (d.value / max) * (H - pad * 2 - 20));
    const x = pad + i * ((W - pad * 2) / data.length) + ((W - pad * 2) / data.length - bw) / 2;
    bars += `<rect x="${x}" y="${H - pad - h}" width="${bw}" height="${h}" rx="4" fill="#24425F"><title>${esc(d.label)}：${d.value}</title></rect>`;
    labels += `<text class="bar-label" x="${x + bw / 2}" y="${H - 8}" text-anchor="middle">${esc(d.label)}</text>`;
    bars += `<text class="bar-label" x="${x + bw / 2}" y="${H - pad - h - 4}" text-anchor="middle">${d.value}</text>`;
  });
  return `<svg class="chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="柱状图">${bars}${labels}</svg>`;
}
function donut(percent, label) {
  const r = 52, c = 2 * Math.PI * r, off = c * (1 - percent / 100);
  return `<svg class="chart" viewBox="0 0 140 140" style="max-width:160px" role="img" aria-label="${esc(label)}">
    <circle cx="70" cy="70" r="${r}" fill="none" stroke="#E9EEF5" stroke-width="14"/>
    <circle cx="70" cy="70" r="${r}" fill="none" stroke="#D9A55C" stroke-width="14" stroke-dasharray="${c}" stroke-dashoffset="${off}" stroke-linecap="round" transform="rotate(-90 70 70)"/>
    <text x="70" y="66" text-anchor="middle" font-size="22" font-weight="700" fill="#24425F">${percent}%</text>
    <text x="70" y="86" text-anchor="middle" font-size="12" fill="#5B6B7B">${esc(label)}</text></svg>`;
}

/* ---------- 智能分析展示 ---------- */
function analysisHtml(sa, text) {
  if (!sa && !text) return '';
  if (sa) {
    return `<div class="analysis"><h4>本地智能分析</h4>
      <p><b>错因分析</b><br>${esc(sa.wrong_reason || '')}</p>
      <p><b>逐选项辨析</b><br>${(sa.option_notes || []).map(esc).join('<br>')}</p>
      <p><b>答案关键点</b><br>${(sa.key_points || []).map(esc).join('<br>')}</p>
      <p><b>理解与记忆建议</b><br>${esc(sa.advice || '')}</p></div>`;
  }
  return `<div class="analysis"><h4>本地智能分析</h4><p>${esc(text)}</p></div>`;
}
function optionLetters(q) { return Object.keys(q.options || {}).sort(); }
function shuffleOpts(q) {
  if (!state.prefs.shuffle || !q.options) return q;
  const keys = Object.keys(q.options);
  const shuffled = keys.slice().sort(() => Math.random() - 0.5);
  const map = {}, newOpts = {};
  shuffled.forEach((old, i) => { const nl = String.fromCharCode(65 + i); map[old] = nl; newOpts[nl] = q.options[old]; });
  const copy = Object.assign({}, q, { options: newOpts, _optMap: map });
  return copy;
}
function qImageHtml(q) {
  if (!q.image) return '';
  return `<img class="q-img" src="/assets/${esc(q.image)}" alt="题图" onclick="window.open(this.src,'_blank')" onerror="this.outerHTML='<p class=\\'muted\\'>题图加载失败（服务器缺图或图片无法解析）</p>'">`;
}

/* ---------- 学员首页 ---------- */
async function viewHome(v) {
  const data = await apiGet('/api/home/stats');
  const p = data.practice || { total: 0, correct: 0, accuracy: 0, wrong_count: 0 };
  const u = data.user || state.user;
  const ongoing = data.ongoing_mock;
  if (state.user.role === 'admin') {
    v.innerHTML = `<div class="card"><h2>你好，${esc(u.name)}</h2><p class="muted">${esc(u.department)} · 管理员 · 常熟站智考通 v2.2</p>
      <p>请使用上方导航管理用户、上报、统计与客户端版本。学员注册邀请码可在「系统设置」中查看与更换。</p></div>`;
    return;
  }
  if (state.user.role === 'examiner') {
    v.innerHTML = `<div class="card"><h2>你好，${esc(u.name)}</h2><p class="muted">${esc(u.department)} · 考官 · 常熟站智考通 v2.2</p>
      <p>请使用上方导航管理考试与题库。还没有考试时，点击右上角创建。</p></div>`;
    return;
  }
  v.innerHTML = `
  ${ongoing ? `<div class="card"><b>有一场进行中的模拟考试，继续作答</b><div style="margin-top:8px"><button class="btn gold" id="btn-resume-mock">继续作答</button></div></div>` : ''}
  <div class="card"><h2>你好，${esc(u.name)}</h2><p class="muted">${esc(u.department)} · 一站式备考</p>
    <div class="grid4" style="margin-top:16px">
      <div class="stat"><div class="num">${p.total}</div><div class="lbl">已练习题</div></div>
      <div class="stat"><div class="num">${p.correct}</div><div class="lbl">答对题数</div></div>
      <div class="stat"><div class="num">${p.accuracy || 0}%</div><div class="lbl">正确率</div></div>
      <div class="stat"><div class="num">${p.wrong_count}</div><div class="lbl">错题数</div></div>
    </div></div>
  <div class="grid2">
    <button class="module" data-mode="顺序"><span class="ico">顺</span><span><b>顺序刷题</b><span>按题库题号全量顺序，断点续刷</span></span></button>
    <button class="module" data-mode="随机"><span class="ico">随</span><span><b>随机刷题</b><span>全量随机抽题，顺序打乱</span></span></button>
    <button class="module" data-mode="错题"><span class="ico">错</span><span><b>错题刷题</b><span>做对一题自动移出错题本</span></span></button>
    <button class="module" data-mode="题型"><span class="ico">题</span><span><b>题型练习</b><span>选定题型后刷完该题型全部题目</span></span></button>
  </div>
  <div class="card" id="v2-home"><h3>五环节 · 自适应</h3>
    <p class="muted">顺序 / 随机 / 错题回顾 / 薄弱分析 / 阶段考核 + 自适应练习（按掌握度动态调权重与难度）。</p>
    <div class="toolbar">
      <button class="btn" data-v2mode="sequential">顺序</button>
      <button class="btn" data-v2mode="random">随机</button>
      <button class="btn" data-v2mode="wrong">错题回顾</button>
      <button class="btn" data-v2mode="weak">薄弱分析</button>
      <button class="btn" data-v2mode="exam">阶段考核</button>
      <button class="btn gold" data-v2mode="adaptive">自适应练习</button>
    </div><div id="v2-profile"><p class="muted">自适应画像加载中…</p></div></div>
  <div class="card"><div class="toolbar">
    <button class="btn ghost" id="btn-wrongbook">我的错题本</button>
    <button class="btn ghost" id="btn-pstats">练习统计</button>
    <button class="btn ghost" id="btn-myreports">我的上报</button>
  </div><div id="home-sub"></div></div>`;
  if (ongoing) $('#btn-resume-mock').onclick = () => openMock(ongoing.id);
  $$('.module').forEach(b => b.onclick = () => startPracticeSetup(b.dataset.mode));
  $('#btn-wrongbook').onclick = () => viewWrongBook($('#home-sub'));
  $('#btn-pstats').onclick = () => viewPracticeStats($('#home-sub'));
  $('#btn-myreports').onclick = () => viewMyReports($('#home-sub'));
  $$('#v2-home [data-v2mode]').forEach(b => b.onclick = () => v2ModeAction(b.dataset.v2mode));
  loadAdaptiveProfile($('#v2-profile'));
}

/* ---------- 练习 ---------- */
async function startPracticeSetup(mode) {
  const cats = await apiGet('/api/questions/categories');
  const catOpts = ['<option value="">全部分类</option>'].concat(cats.map(c => `<option>${esc(c)}</option>`)).join('');
  const typeOpts = TYPES.map(t => `<option>${t}</option>`).join('');
  modal(`<h2>${esc(mode)}刷题</h2>
    <form id="pr-setup">
      <label>分类</label><select id="pr-cat">${catOpts}</select>
      ${mode === '题型' ? `<label>题型</label><select id="pr-type">${typeOpts}</select>
      <label>顺序</label><select id="pr-order"><option value="">顺序</option><option value="rand">随机</option></select>` : ''}
      ${mode !== '题型' && mode !== '错题' ? `<label>题数（留空为全部，也可直接输入自定义数量）</label><input type="number" id="pr-count" min="1" placeholder="全部">` : ''}
      <div class="row"><button type="button" class="btn ghost" onclick="closeModal()">取消</button>
      <button class="btn" type="submit">开始练习</button></div>
    </form>`);
  $('#pr-setup').onsubmit = async e => {
    e.preventDefault();
    const q = new URLSearchParams({ mode });
    const cat = $('#pr-cat').value; if (cat) q.set('category', cat);
    if (mode === '题型') { q.set('type', $('#pr-type').value); if ($('#pr-order').value === 'rand') q.set('seed', String(Date.now() % 100000)); }
    else if (mode !== '错题') { const c = $('#pr-count').value; if (c) q.set('count', c); }
    if (mode === '随机') q.set('seed', String(Date.now() % 100000));
    closeModal();
    try {
      const data = await apiGet('/api/practice/list?' + q.toString());
      if (!data.questions.length) { toast(mode === '错题' ? '暂无错题，继续加油' : '该条件下暂无题目', true); return; }
      const saved = JSON.parse(localStorage.getItem('zk_practice_break_' + mode) || '0');
      let startIdx = 0;
      if (mode === '顺序' && saved > 0 && saved < data.questions.length) {
        if (await confirmDlg('上次刷到第 ' + (saved + 1) + ' 题，继续作答吗？（取消则从头开始）')) startIdx = saved;
      }
      state.practice = { mode, questions: data.questions, idx: startIdx, correct: 0, wrong: 0, submitted: false, result: null, sel: null, input: '', selfDone: false };
      renderPractice();
    } catch (err) { toast(err.message, true); }
  };
}
function curQ() { const p = state.practice; return p.questions[p.idx]; }
function renderPractice() {
  const p = state.practice, q = shuffleOpts(curQ());
  const total = p.questions.length;
  const v = $('#view');
  const sel = p.sel;
  const res = p.result;
  let body = '';
  if (q.type === '填空') {
    body = `<input type="text" id="fill-in" placeholder="请输入答案，回车或按空格提交" value="${esc(p.input || '')}" ${res ? 'disabled' : ''}>`;
  } else if (q.type === '简答') {
    body = `<textarea id="fill-in" rows="4" placeholder="请写出你的作答" ${res ? 'disabled' : ''}>${esc(p.input || '')}</textarea>`;
  } else {
    body = optionLetters(q).map(L => {
      let cls = 'opt' + (q.type === '多选' ? ' multi' : '');
      let mark = q.type === '多选' ? (sel && sel.indexOf(L) >= 0 ? '✓' : '') : (sel === L ? '●' : '');
      if (res) {
        const ans = res.correct_answer || '';
        if (ans.indexOf(L) >= 0) { cls += ' right'; mark = '✓'; }
        else if ((q.type === '多选' ? (sel || []).indexOf(L) >= 0 : sel === L)) { cls += ' wrong'; mark = '✕'; }
      } else if (q.type === '多选' ? (sel || []).indexOf(L) >= 0 : sel === L) { cls += ' sel'; }
      return `<button class="${cls}" data-letter="${L}" ${res ? 'disabled' : ''}><span class="mark">${mark}</span><span>${esc(L)}. ${esc(q.options[L])}</span></button>`;
    }).join('');
  }
  let resultHtml = '';
  if (res) {
    const ok = res.correct;
    resultHtml = `<div class="answer-box">
      <p class="${ok === true ? 'correct' : ok === false ? 'wrong' : ''}">${ok === true ? '✓ 答对了' : ok === false ? '✕ 答错了' : '请自评'}</p>
      <p>正确答案：<b>${esc(res.correct_answer || '')}</b></p>
      ${res.analysis ? `<p>解析：${esc(res.analysis)}</p>` : ''}
      ${q.type === '简答' && ok === null ? `<div class="toolbar"><button class="btn" id="sg-right">我做对了</button><button class="btn ghost" id="sg-wrong">我做错了</button></div>` : ''}
      ${state.prefs.showAnalysis && ok === false ? analysisHtml(res.smart_analysis, res.smart_analysis_text) : ''}
      ${ok === false ? `<p class="muted">答错的题目已自动加入错题本，可在错题本中复习并查看智能分析。</p>` : ''}
    </div>`;
  }
  v.innerHTML = `<div class="card">
    <div class="q-head"><span class="pill">${esc(p.mode)}</span><span class="pill gold">${esc(q.type)}</span>
      <span class="muted">第 ${p.idx + 1} / ${total} 题 · ${esc(q.no || '')}</span>
      <span style="flex:1"></span><span class="muted">已答对 ${p.correct} · 答错 ${p.wrong}</span></div>
    <div class="q-stem">${esc(q.stem)}</div>
    ${qImageHtml(q)}
    <div id="opt-area">${body}</div>
    ${resultHtml}
    <div class="q-nav">
      <button class="btn ghost" id="btn-prev">上一题</button>
      <button class="btn ghost" id="btn-next">下一题</button>
      <span class="muted">跳转到 <input type="number" id="jump-to" min="1" max="${total}" style="width:70px;display:inline-block"> 题</span>
      <button class="btn ghost small" id="btn-jump">跳转</button>
      <span class="spacer"></span>
      ${!res ? `<button class="btn" id="btn-submit">提交答案</button>` : ''}
      <button class="btn ghost" id="btn-tip">易错提示</button>
      <button class="btn gold" id="btn-end">结束练习</button>
      <button class="btn ghost" id="btn-report">上报题目问题</button>
    </div>
    <p class="muted" style="margin-top:12px">按 <span class="kbd">空格</span> 推进：未提交时提交答案，已提交时下一题。</p>
  </div>`;
  if (!res) {
    $$('#opt-area .opt').forEach(b => b.onclick = () => {
      const L = b.dataset.letter;
      if (q.type === '多选') {
        p.sel = p.sel || [];
        const i = p.sel.indexOf(L);
        if (i >= 0) p.sel.splice(i, 1); else p.sel.push(L);
      } else p.sel = L;
      renderPractice();
    });
    const fi = $('#fill-in');
    if (fi) fi.addEventListener('keydown', e => { if (e.key === 'Enter' && q.type === '填空') { e.preventDefault(); submitPractice(); } });
  }
  $('#btn-submit') && ($('#btn-submit').onclick = submitPractice);
  const tipBtn = $('#btn-tip'); if (tipBtn) tipBtn.onclick = showAiTip;
  $('#btn-prev').onclick = () => { if (p.idx > 0) { p.idx--; p.submitted = false; p.result = null; p.sel = null; p.input = ''; renderPractice(); } };
  $('#btn-next').onclick = () => nextPractice();
  $('#btn-jump').onclick = () => { const n = parseInt($('#jump-to').value, 10); if (n >= 1 && n <= total) { p.idx = n - 1; p.result = null; p.sel = null; p.input = ''; renderPractice(); } else toast('请输入 1 到 ' + total + ' 之间的题号', true); };
  $('#btn-end').onclick = async () => { if (await confirmDlg('结束本次练习吗？')) endPractice(); };
  $('#btn-report').onclick = () => reportDialog(q.id);
  const sgR = $('#sg-right'), sgW = $('#sg-wrong');
  if (sgR) sgR.onclick = () => selfGradePractice(true);
  if (sgW) sgW.onclick = () => selfGradePractice(false);
}
async function submitPractice() {
  const p = state.practice, q = curQ();
  let ans = '';
  if (q.type === '填空' || q.type === '简答') { ans = ($('#fill-in') ? $('#fill-in').value : '').trim(); p.input = ans; }
  else if (q.type === '多选') ans = (p.sel || []).slice().sort().join('');
  else ans = p.sel || '';
  if (q.type === '简答') {
    // 简答先提交文本，再自评
    try {
      const res = await apiPost('/api/practice/answer', { question_id: q.id, mode: p.mode, user_answer: ans, self_correct: null });
      p.result = res; renderPractice();
    } catch (err) { toast(err.message, true); }
    return;
  }
  try {
    const res = await apiPost('/api/practice/answer', { question_id: q.id, mode: p.mode, user_answer: ans });
    p.result = res;
    if (res.correct === true) p.correct++; else if (res.correct === false) p.wrong++;
    renderPractice();
  } catch (err) { toast(err.message, true); }
}
async function selfGradePractice(ok) {
  const p = state.practice, q = curQ();
  try {
    const res = await apiPost('/api/practice/answer', { question_id: q.id, mode: p.mode, user_answer: p.input || '', self_correct: ok });
    p.result = res;
    if (res.correct === true) p.correct++; else if (res.correct === false) p.wrong++;
    renderPractice();
  } catch (err) { toast(err.message, true); }
}
function nextPractice() {
  const p = state.practice;
  localStorage.setItem('zk_practice_break_' + p.mode, String(p.idx + 1));
  if (p.idx + 1 >= p.questions.length) { endPractice(); return; }
  p.idx++; p.result = null; p.sel = null; p.input = ''; renderPractice();
}
function endPractice() {
  const p = state.practice;
  localStorage.removeItem('zk_practice_break_' + p.mode);
  const v = $('#view');
  v.innerHTML = `<div class="card" style="text-align:center">
    <h2>练习完成</h2>
    <p>答对 <b style="color:var(--green)">${p.correct}</b> 题，答错 <b style="color:var(--red)">${p.wrong}</b> 题（共 ${p.questions.length} 题）</p>
    <p class="muted">答错的题目已自动加入错题本，可在错题本中复习并查看智能分析。</p>
    <div class="toolbar" style="justify-content:center"><button class="btn" id="btn-again">再练一组</button>
    <button class="btn ghost" id="btn-back-home">返回首页</button></div></div>`;
  $('#btn-again').onclick = () => startPracticeSetup(p.mode);
  $('#btn-back-home').onclick = () => go('home');
}
async function viewWrongBook(el) {
  const items = await apiGet('/api/wrongbook');
  if (!items.length) { el.innerHTML = '<div class="empty">暂无错题，继续加油</div>'; return; }
  el.innerHTML = `<div class="toolbar"><button class="btn" id="wb-redo">重做全部错题</button></div>` +
    items.map(q => `<div class="list-row"><div class="grow"><b>${esc(q.no || '')} · ${esc(q.type)}</b><br>${esc(q.stem)}
      <br><span class="muted">正确答案：${esc(q.answer || '')}　${q.analysis ? '解析：' + esc(q.analysis) : ''}</span>
      ${q.smart_analysis_text ? analysisHtml(q.smart_analysis, q.smart_analysis_text) : ''}</div>
      <button class="btn ghost small" data-remove="${q.id}">移除</button></div>`).join('');
  $('#wb-redo').onclick = () => {
    state.practice = { mode: '错题', questions: items, idx: 0, correct: 0, wrong: 0, submitted: false, result: null, sel: null, input: '' };
    renderPractice();
  };
  $$('[data-remove]', el).forEach(b => b.onclick = async () => { await apiPost('/api/wrongbook/remove', { question_id: parseInt(b.dataset.remove, 10) }); toast('已移除'); viewWrongBook(el); });
}
async function viewPracticeStats(el) {
  const s = await apiGet('/api/practice/stats');
  el.innerHTML = `<div class="grid4">
    <div class="stat"><div class="num">${s.total}</div><div class="lbl">做题总数</div></div>
    <div class="stat"><div class="num">${s.correct}</div><div class="lbl">答对题数</div></div>
    <div class="stat"><div class="num">${s.accuracy || 0}%</div><div class="lbl">正确率</div></div>
    <div class="stat"><div class="num">${s.wrong_count}</div><div class="lbl">错题数</div></div></div>
    <h3 style="margin-top:16px">各题型正确率</h3>
    ${(s.by_type || []).length ? barChart(s.by_type.map(t => ({ label: t.type, value: t.accuracy || 0 }))) : '<p class="muted">暂无数据</p>'}
    <h3 style="margin-top:16px">近期练习趋势（近 14 天做题数）</h3>
    ${(s.trend || []).length ? barChart(s.trend.map(t => ({ label: t.date.slice(5), value: t.total }))) : '<p class="muted">暂无数据</p>'}`;
}
async function viewMyReports(el) {
  const items = await apiGet('/api/reports/mine');
  if (!items.length) { el.innerHTML = '<div class="empty">暂无上报记录</div>'; return; }
  el.innerHTML = items.map(r => `<div class="list-row"><div class="grow"><b>${esc(r.type)}</b> <span class="pill">${esc(r.status)}</span><br>
    ${esc(r.question ? r.question.stem : '')}<br><span class="muted">${esc(r.detail || '')} · ${esc(r.created_at || '')}</span>
    ${r.reply ? `<br>管理员回复：${esc(r.reply)}` : ''}</div></div>`).join('');
}
function reportDialog(questionId) {
  modal(`<h2>上报题目问题</h2><form id="rep-form">
    <label>问题类型</label><select id="rep-type">${REPORT_TYPES.map(t => `<option>${t}</option>`).join('')}</select>
    <label>补充说明（选填）</label><textarea id="rep-detail" rows="3" placeholder="请补充说明"></textarea>
    <div class="row"><button type="button" class="btn ghost" onclick="closeModal()">取消</button>
    <button class="btn" type="submit">提交上报</button></div></form>`);
  $('#rep-form').onsubmit = async e => {
    e.preventDefault();
    try { await apiPost('/api/reports', { question_id: questionId, type: $('#rep-type').value, detail: $('#rep-detail').value }); closeModal(); toast('上报成功，感谢反馈'); }
    catch (err) { toast(err.message, true); }
  };
}

/* ---------- 模拟考试 ---------- */
async function viewMock(v) {
  const cats = await apiGet('/api/questions/categories');
  const cur = await apiGet('/api/mock/current').catch(() => null);
  const hist = await apiGet('/api/mock/history');
  v.innerHTML = `
  ${cur ? `<div class="card"><b>有一场进行中的模拟考试，继续作答</b><div style="margin-top:8px"><button class="btn gold" id="btn-resume">继续作答</button></div></div>` : ''}
  <div class="card"><h2>模拟考试</h2><p class="muted">按题型选数量、分类、时长，服务端随机组卷；开始后立即计时，中途退出可恢复。</p>
    <form id="mock-form">
      <label>分类（可选）</label><select id="mk-cat"><option value="">全部分类</option>${cats.map(c => `<option>${esc(c)}</option>`).join('')}</select>
      ${TYPES.map(t => `<label>${t}数量</label><input type="number" id="mk-${t}" min="0" value="${t === '单选' ? 5 : t === '判断' ? 3 : t === '多选' ? 2 : 0}">`).join('')}
      <label>时长（分钟）</label><input type="number" id="mk-dur" min="1" value="30">
      <div style="margin-top:16px"><button class="btn" type="submit">开始模拟考试</button></div>
    </form></div>
  <div class="card"><h3>历史成绩</h3>
    ${hist.length ? `<div style="display:flex;gap:12px;overflow-x:auto">${hist.map(h => `<button class="card" style="min-width:200px;text-align:left;margin:0" data-hist="${h.id}">
      <b>${esc(h.config && h.config.category ? h.config.category : '模拟考试')}</b><br>
      <span class="score-big" style="font-size:28px">${h.score == null ? '—' : h.score}</span> 分<br>
      <span class="muted">${h.question_count} 题 · ${esc(h.submitted_at || '')}</span></button>`).join('')}</div>`
    : '<div class="empty">暂无模拟考试记录，完成一次模拟考试后会显示在这里</div>'}
  </div>`;
  if (cur) $('#btn-resume').onclick = () => openMock(cur.id);
  $$('[data-hist]', v).forEach(b => b.onclick = () => viewMockDetail(parseInt(b.dataset.hist, 10)));
  $('#mock-form').onsubmit = async e => {
    e.preventDefault();
    const counts = {};
    TYPES.forEach(t => { counts[t] = parseInt($('#mk-' + t).value, 10) || 0; });
    if (Object.values(counts).every(n => n <= 0)) { toast('请至少设置一种题型的数量', true); return; }
    if (!await confirmDlg('确定开始模拟考试吗？点击后立即计时。')) return;
    try {
      const data = await apiPost('/api/mock', { counts, category: $('#mk-cat').value, duration_min: parseInt($('#mk-dur').value, 10) || 30 });
      openMockSession(data);
    } catch (err) { toast(err.message, true); }
  };
}
function openMockSession(data) {
  state.mock = { id: data.attempt_id, questions: data.question_detail, answers: {}, idx: 0, config: data.config, startedAt: data.started_at, duration: (data.config.duration_min || 30) * 60 };
  renderMock();
}
async function openMock(id) {
  const data = await apiGet('/api/mock/' + id);
  const elapsed = data.started_at ? Math.floor((Date.now() - new Date(data.started_at.replace(' ', 'T')).getTime()) / 1000) : 0;
  state.mock = { id: data.id, questions: data.question_detail, answers: data.answers || {}, idx: 0, config: data.config, startedAt: data.started_at, duration: (data.config.duration_min || 30) * 60, elapsed };
  renderMock();
}
function renderMock() {
  const m = state.mock, q = m.questions[m.idx];
  const total = m.questions.length;
  const v = $('#view');
  const ans = (m.answers[q.id] || {}).a || '';
  let body = '';
  if (q.type === '填空' || q.type === '简答') {
    body = q.type === '填空'
      ? `<input type="text" id="mk-in" value="${esc(ans)}" placeholder="请输入答案">`
      : `<textarea id="mk-in" rows="4" placeholder="请写出你的作答">${esc(ans)}</textarea>`;
  } else {
    body = optionLetters(q).map(L => {
      const sel = q.type === '多选' ? ans.indexOf(L) >= 0 : ans === L;
      return `<button class="opt${q.type === '多选' ? ' multi' : ''}${sel ? ' sel' : ''}" data-letter="${L}"><span class="mark">${sel ? (q.type === '多选' ? '✓' : '●') : ''}</span><span>${esc(L)}. ${esc(q.options[L])}</span></button>`;
    }).join('');
  }
  const answered = m.questions.filter(x => { const a = (m.answers[x.id] || {}).a; return a !== undefined && a !== null && a !== ''; }).length;
  v.innerHTML = `<div class="card">
    <div class="q-head"><span class="pill">模拟考试</span><span class="pill gold">${esc(q.type)}</span>
      <span class="muted">第 ${m.idx + 1} / ${total} 题</span><span style="flex:1"></span>
      <span class="timer" id="mk-timer"></span></div>
    <div class="q-stem">${esc(q.stem)}</div>${qImageHtml(q)}
    <div id="opt-area">${body}</div>
    <div class="q-nav">
      <button class="btn ghost" id="mk-prev">上一题</button>
      <button class="btn ghost" id="mk-next">下一题</button>
      <span class="spacer"></span>
      <span class="muted">已作答 ${answered} / ${total}</span>
      <button class="btn gold" id="mk-submit">交卷</button>
    </div>
    <p class="muted">按 <span class="kbd">空格</span> 到下一题；答案实时保存，断线重连后可继续作答。</p>
    <h3>答题卡</h3><div class="ans-grid">${m.questions.map((x, i) => {
      const a = (m.answers[x.id] || {}).a;
      return `<button data-idx="${i}" class="${a ? 'done' : ''} ${i === m.idx ? 'cur' : ''}">${i + 1}</button>`;
    }).join('')}</div>
  </div>`;
  const save = async () => {
    const val = $('#mk-in') ? $('#mk-in').value : ans;
    try { await apiPost('/api/mock/' + m.id + '/answer', { question_id: q.id, answer: val }); } catch (e) { toast('保存失败，请检查网络', true); }
  };
  $$('#opt-area .opt').forEach(b => b.onclick = async () => {
    const L = b.dataset.letter;
    if (q.type === '多选') {
      const cur = (m.answers[q.id] || {}).a || '';
      m.answers[q.id] = { a: cur.indexOf(L) >= 0 ? cur.replace(L, '') : (cur + L).split('').sort().join(''), s: null };
    } else { m.answers[q.id] = { a: L, s: null }; await save(); }
    renderMock();
  });
  const fi = $('#mk-in');
  if (fi) fi.addEventListener('change', () => { m.answers[q.id] = { a: fi.value, s: null }; save(); });
  $('#mk-prev').onclick = () => { if (m.idx > 0) { m.idx--; renderMock(); } };
  $('#mk-next').onclick = () => { if (m.idx + 1 < total) { m.idx++; renderMock(); } };
  $$('.ans-grid button').forEach(b => b.onclick = () => { m.idx = parseInt(b.dataset.idx, 10); renderMock(); });
  $('#mk-submit').onclick = () => submitMock(false);
  startExamTimer('mk-timer', m, () => submitMock(true));
}
async function submitMock(auto) {
  const m = state.mock;
  const unanswered = m.questions.filter(x => { const a = (m.answers[x.id] || {}).a; return !a; }).length;
  if (!auto && unanswered > 0 && !await confirmDlg('还有 ' + unanswered + ' 题未作答，确定交卷吗？')) return;
  if (auto) toast('时间到，系统自动交卷');
  stopTimer();
  try {
    const res = await apiPost('/api/mock/' + m.id + '/submit', {});
    state.mock = null;
    viewResult($('#view'), { kind: 'mock', id: m.id, score: res.score, full: res.full_score, correct: res.correct, objectiveTotal: res.objective_total, accuracy: res.accuracy, pending: res.pending_self_grade, results: res.results });
  } catch (err) { toast(err.message, true); renderMock(); }
}
async function viewMockDetail(id) {
  const v = $('#view');
  try {
    const d = await apiGet('/api/mock/' + id + '/detail');
    viewResult(v, { kind: 'mock', id, score: d.score, full: d.full_score, correct: null, objectiveTotal: null, accuracy: null, pending: d.pending_self_grade, results: d.results });
  } catch (err) { toast(err.message, true); }
}

/* ---------- 正式考试 ---------- */
async function viewMyExams(v) {
  const list = await apiGet('/api/exams/mine');
  if (!list.length) { v.innerHTML = '<div class="card empty">暂无可参加的考试，请等待考官发布</div>'; return; }
  v.innerHTML = list.map(e => {
    const at = e.attempt;
    const status = at ? (at.status === '已交卷' || at.status === '迟交' ? '已交卷' : '进行中') : (e.status === '已发布' ? '未开始' : e.status);
    const pill = status === '已交卷' ? 'green' : status === '进行中' ? 'gold' : 'grey';
    return `<div class="card"><div class="list-row"><div class="grow"><b>${esc(e.name)}</b> <span class="pill ${pill}">${esc(status)}</span><br>
      <span class="muted">${esc(e.subject)} · 时长 ${e.duration_min} 分钟 · ${e.mode === 'fixed' ? '全员同一份卷' : '每人随机抽题'}${at && at.score != null ? ' · 得分 ' + at.score : ''}</span></div>
      ${at && (at.status === '已交卷' || at.status === '迟交')
        ? `<button class="btn" data-result="${e.id}">查看成绩</button>`
        : `<button class="btn gold" data-start="${e.id}">${at ? '继续考试' : '开始考试'}</button>`}
    </div></div>`;
  }).join('');
  $$('[data-start]', v).forEach(b => b.onclick = async () => {
    if (!await confirmDlg('进入考试后将开始计时，确定开始吗？')) return;
    try {
      const data = await apiPost('/api/exams/' + b.dataset.start + '/start', {});
      openExamSession(data);
    } catch (err) { toast(err.message, true); }
  });
  $$('[data-result]', v).forEach(b => b.onclick = () => viewExamResult(parseInt(b.dataset.result, 10)));
}
function openExamSession(data) {
  const dur = (data.exam.duration_min || 60) * 60;
  const elapsed = data.started_at ? Math.floor((Date.now() - new Date(data.started_at.replace(' ', 'T')).getTime()) / 1000) : 0;
  state.exam = { id: data.exam.id, exam: data.exam, questions: data.question_detail, answers: data.answers || {}, idx: 0, duration: dur, elapsed, attemptId: data.attempt_id };
  renderExam();
}
function renderExam() {
  const m = state.exam, q = m.questions[m.idx];
  const total = m.questions.length;
  const v = $('#view');
  const ans = (m.answers[q.id] || {}).a || '';
  let body = '';
  if (q.type === '填空' || q.type === '简答') {
    body = q.type === '填空'
      ? `<input type="text" id="ex-in" value="${esc(ans)}" placeholder="请输入答案">`
      : `<textarea id="ex-in" rows="4" placeholder="请写出你的作答">${esc(ans)}</textarea>`;
  } else {
    body = optionLetters(q).map(L => {
      const sel = q.type === '多选' ? ans.indexOf(L) >= 0 : ans === L;
      return `<button class="opt${q.type === '多选' ? ' multi' : ''}${sel ? ' sel' : ''}" data-letter="${L}"><span class="mark">${sel ? (q.type === '多选' ? '✓' : '●') : ''}</span><span>${esc(L)}. ${esc(q.options[L])}</span></button>`;
    }).join('');
  }
  const answered = m.questions.filter(x => { const a = (m.answers[x.id] || {}).a; return a; }).length;
  v.innerHTML = `<div class="card">
    <div class="q-head"><span class="pill">${esc(m.exam.name)}</span><span class="pill gold">${esc(q.type)}</span>
      <span class="muted">第 ${m.idx + 1} / ${total} 题</span><span style="flex:1"></span>
      <span class="timer" id="ex-timer"></span> <span class="muted" id="save-state">已自动保存</span></div>
    <div class="q-stem">${esc(q.stem)}</div>${qImageHtml(q)}
    <div id="opt-area">${body}</div>
    <div class="q-nav">
      <button class="btn ghost" id="ex-prev">上一题</button>
      <button class="btn ghost" id="ex-next">下一题</button>
      <span class="spacer"></span>
      <span class="muted">已作答 ${answered} / ${total}</span>
      <button class="btn gold" id="ex-submit">交卷</button>
    </div>
    <p class="muted">按 <span class="kbd">空格</span> 到下一题；答案自动保存。</p>
    <h3>答题卡</h3><div class="ans-grid">${m.questions.map((x, i) => {
      const a = (m.answers[x.id] || {}).a;
      return `<button data-idx="${i}" class="${a ? 'done' : ''} ${i === m.idx ? 'cur' : ''}">${i + 1}</button>`;
    }).join('')}</div>
  </div>`;
  const save = async val => {
    try { await apiPost('/api/exams/' + m.id + '/answer', { question_id: q.id, answer: val }); const s = $('#save-state'); if (s) s.textContent = '已自动保存'; }
    catch (e) { const s = $('#save-state'); if (s) s.textContent = '保存失败，请检查网络'; }
  };
  $$('#opt-area .opt').forEach(b => b.onclick = async () => {
    const L = b.dataset.letter;
    if (q.type === '多选') {
      const cur = (m.answers[q.id] || {}).a || '';
      m.answers[q.id] = { a: cur.indexOf(L) >= 0 ? cur.replace(L, '') : (cur + L).split('').sort().join(''), s: null };
      await save(m.answers[q.id].a);
    } else { m.answers[q.id] = { a: L, s: null }; await save(L); }
    renderExam();
  });
  const fi = $('#ex-in');
  if (fi) fi.addEventListener('change', () => { m.answers[q.id] = { a: fi.value, s: null }; save(fi.value); });
  $('#ex-prev').onclick = () => { if (m.idx > 0) { m.idx--; renderExam(); } };
  $('#ex-next').onclick = () => { if (m.idx + 1 < total) { m.idx++; renderExam(); } };
  $$('.ans-grid button').forEach(b => b.onclick = () => { m.idx = parseInt(b.dataset.idx, 10); renderExam(); });
  $('#ex-submit').onclick = () => submitExam(false);
  startExamTimer('ex-timer', m, () => submitExam(true));
}
async function submitExam(auto) {
  const m = state.exam;
  const unanswered = m.questions.filter(x => { const a = (m.answers[x.id] || {}).a; return !a; }).length;
  if (!auto) {
    if (!await confirmDlg('交卷后将立即判分，不能再修改' + (unanswered ? '，还有 ' + unanswered + ' 题未作答' : '') + '，确定交卷吗？')) return;
  } else toast('时间到，系统按已保存答案自动交卷（迟交）');
  stopTimer();
  try {
    const res = await apiPost('/api/exams/' + m.id + '/submit', { late: !!auto });
    state.exam = null;
    viewResult($('#view'), { kind: 'exam', id: m.id, score: res.score, full: res.full_score, correct: null, objectiveTotal: null, accuracy: res.total_questions ? Math.round(res.answered / res.total_questions * 1000) / 10 : null, pending: res.pending_self_grade, results: res.results, status: res.status });
  } catch (err) { toast(err.message, true); renderExam(); }
}
async function viewExamResult(examId) {
  const v = $('#view');
  try {
    const d = await apiGet('/api/exams/' + examId + '/result');
    viewResult(v, { kind: 'exam', id: examId, score: d.score, full: d.full_score, correct: null, objectiveTotal: null, accuracy: null, pending: d.pending_self_grade, results: d.results, status: d.status });
  } catch (err) { toast(err.message, true); }
}

/* ---------- 成绩与逐题解析（模拟考 / 正式考试共用） ---------- */
function viewResult(v, r) {
  const wrong = (r.results || []).filter(x => x.correct === false);
  const acc = r.accuracy != null ? r.accuracy : (r.results && r.results.length ? Math.round(r.results.filter(x => x.correct === true).length / r.results.length * 1000) / 10 : 0);
  v.innerHTML = `<div class="card" style="text-align:center">
    <h2>考试成绩</h2>
    <div class="score-big">${r.score == null ? '—' : r.score} <span style="font-size:18px;color:var(--text2)">/ ${r.full}</span></div>
    <p class="muted">正确率 ${acc}%${r.status ? ' · ' + esc(r.status) : ''}${r.objectiveTotal != null ? ' · 客观题 ' + r.correct + ' / ' + r.objectiveTotal + ' 正确' : ''}</p>
    ${(r.pending && r.pending.length) ? `<p><b>以下填空 / 简答题需自评：</b>对照参考答案自评后计入总分。</p>` : ''}
    <div class="toolbar" style="justify-content:center">
      <button class="btn" id="res-wrong">只看错题</button>
      <button class="btn ghost" id="res-all">查看全部</button>
      <button class="btn ghost" id="res-back">返回</button>
    </div></div>
    <div id="res-list"></div><div id="essay-mine-sec"></div>`;
  const renderList = onlyWrong => {
    const list = onlyWrong ? (r.results || []).filter(x => x.correct === false) : (r.results || []);
    if (!list.length) { $('#res-list').innerHTML = onlyWrong ? '<div class="card empty">全部答对，没有错题</div>' : '<div class="card empty">暂无解析</div>'; return; }
    $('#res-list').innerHTML = list.map(x => {
      const pending = r.pending && r.pending.indexOf(x.question_id) >= 0;
      return `<div class="card"><div class="q-head"><span class="pill">${esc(x.type)}</span><span class="pill ${x.correct === true ? 'green' : x.correct === false ? 'red' : 'gold'}">${x.correct === true ? '答对' : x.correct === false ? '答错' : '待自评'}</span>
        <span class="muted">${esc(x.no || '')} · 得分 ${x.score} / ${x.full_score}</span></div>
        <div class="q-stem">${esc(x.stem)}</div>
        ${x.options ? Object.keys(x.options).sort().map(L => `<p style="margin:2px 0">${esc(L)}. ${esc(x.options[L])}</p>`).join('') : ''}
        <p>你的答案：<b>${esc(x.user_answer || '未作答')}</b></p>
        <p>正确答案：<b style="color:var(--green)">${esc(x.correct_answer || '')}</b></p>
        ${x.analysis ? `<p>解析：${esc(x.analysis)}</p>` : ''}
        ${pending ? `<div class="toolbar"><button class="btn small" data-sg="${x.question_id}" data-ok="1">我答对了</button><button class="btn ghost small" data-sg="${x.question_id}" data-ok="0">我答错了</button></div>` : ''}
      </div>`;
    }).join('');
    $$('[data-sg]', $('#res-list')).forEach(b => b.onclick = async () => {
      const qid = parseInt(b.dataset.sg, 10), ok = b.dataset.ok === '1';
      try {
        await apiPost(r.kind === 'mock' ? '/api/mock/' + r.id + '/selfgrade' : '/api/exams/' + r.id + '/selfgrade', { question_id: qid, correct: ok });
        toast('自评已计入总分');
        r.pending = r.pending.filter(id => id !== qid);
        const x = (r.results || []).find(y => y.question_id === qid);
        if (x) { x.correct = ok; x.score = ok ? x.full_score : 0; }
        renderList(onlyWrong);
      } catch (err) { toast(err.message, true); }
    });
  };
  renderList(false);
  if (state.user && state.user.role === 'student') {
    const sec = document.getElementById('essay-mine-sec');
    if (sec) {
      sec.innerHTML = '<div class="card"><h3>简答 / 材料题批阅结果</h3><p class="muted">加载中…</p></div>';
      v2get('/api/v2/essay/mine').then(d => { sec.innerHTML = '<div class="card"><h3>简答 / 材料题批阅结果</h3><p class="muted">与选择题分开列示；≥60% 满分算对。</p>' + essayMineHtml(v2list(d, ['submissions', 'items', 'list'])) + '</div>'; }).catch(err => { sec.innerHTML = '<div class="card"><h3>简答 / 材料题批阅结果</h3><div class="empty">暂无批阅记录（' + esc(err.message) + '）</div></div>'; });
    }
  }
  $('#res-wrong').onclick = () => renderList(true);
  $('#res-all').onclick = () => renderList(false);
  $('#res-back').onclick = () => go(r.kind === 'mock' ? 'mock' : 'myexams');
}

/* ---------- 倒计时 ---------- */
function startExamTimer(elId, sess, onTimeout) {
  stopTimer();
  const el = document.getElementById(elId);
  if (!el) return;
  let remain = sess.duration - (sess.elapsed || 0);
  const tick = () => {
    remain--;
    if (remain <= 0) { stopTimer(); el.textContent = '00:00'; onTimeout(); return; }
    el.textContent = '剩余 ' + fmtTime(remain);
    el.classList.toggle('low', remain <= 300);
  };
  el.textContent = '剩余 ' + fmtTime(remain);
  state.timerId = setInterval(tick, 1000);
}

/* ---------- 系统设置 ---------- */
async function viewSettings(v) {
  const u = state.user;
  let invite = '';
  if (u.role === 'admin') { try { invite = (await apiGet('/api/settings/invite-code')).invite_code; } catch (e) {} }
  let latest = null;
  try { latest = (await apiGet('/api/version')).latest; } catch (e) {}
  v.innerHTML = `
  <div class="card"><h2>系统设置</h2>
    <h3>显示模式</h3>
    <div class="toolbar"><button class="btn" id="set-full">全屏</button><button class="btn ghost" id="set-win">窗口</button>
    <span class="muted">默认全屏启动；切换立即生效并记住。</span></div>
    <h3>答题偏好</h3>
    <label>题干与选项字号</label>
    <select id="set-font"><option ${state.prefs.font === '标准' ? 'selected' : ''}>标准</option><option ${state.prefs.font === '特大' ? 'selected' : ''}>特大</option></select>
    <label class="checkline"><input type="checkbox" id="set-shuffle" ${state.prefs.shuffle ? 'checked' : ''}> 练习与模拟考试中打乱选项顺序（保存后下次生效）</label>
    <label class="checkline"><input type="checkbox" id="set-analysis" ${state.prefs.showAnalysis ? 'checked' : ''}> 答错时显示本地智能分析（关闭则只显示正确答案与解析）</label>
    <h3>修改密码</h3>
    <form id="pw-form">
      <label>当前密码</label><input type="password" id="pw-old">
      <label>新密码（至少 6 位）</label><input type="password" id="pw-new">
      <label>确认新密码</label><input type="password" id="pw-confirm">
      <div style="margin-top:12px"><button class="btn" type="submit">修改密码</button></div>
    </form>
    <h3>账号与服务器</h3>
    <p>当前用户：${esc(u.name)}（${esc(u.username)}）<br>部门：${esc(u.department)}<br>角色：${esc(u.role_name)}<br>
    服务器：${esc(localStorage.getItem('zk_server') || '本机')} · 软件版本：${esc(VERSION)}<br>
    ${u.role === 'admin' ? '学员注册邀请码：<b id="invite-code">' + esc(invite) + '</b> <button class="btn small ghost" id="btn-invite">更换邀请码</button>' : ''}</p>
    <h3>客户端更新</h3>
    <p class="muted">软件升级由服务器统一发布，无需重新安装；本机启动时自动检查并升级。</p>
    <p>${latest ? '服务器最新版本：<b>' + esc(latest.version) + '</b>（' + esc(latest.note || '') + '）' : '正在检查… / 已是最新版本'}</p>
    ${latest && latest.version !== VERSION ? '<button class="btn gold" onclick="toast(\'新版本由服务器统一发布，请联系管理员获取更新包\')">立即更新</button>' : '<button class="btn ghost" onclick="toast(\'已是最新版本\')">检查更新</button>'}
  </div>`;
  $('#set-full').onclick = () => { if (document.documentElement.requestFullscreen) document.documentElement.requestFullscreen().catch(() => toast('浏览器不允许全屏')); localStorage.setItem('zk_fullscreen', '1'); toast('已切换全屏'); };
  $('#set-win').onclick = () => { if (document.exitFullscreen) document.exitFullscreen().catch(() => {}); localStorage.setItem('zk_fullscreen', '0'); toast('已切换窗口'); };
  $('#set-font').onchange = e => { state.prefs.font = e.target.value; savePrefs(); toast('字号已保存'); };
  $('#set-shuffle').onchange = e => { state.prefs.shuffle = e.target.checked; savePrefs(); toast('已保存，下次练习生效'); };
  $('#set-analysis').onchange = e => { state.prefs.showAnalysis = e.target.checked; savePrefs(); toast('已保存'); };
  $('#pw-form').onsubmit = async e => {
    e.preventDefault();
    const np = $('#pw-new').value, cf = $('#pw-confirm').value;
    if (np.length < 6) { toast('新密码至少 6 位', true); return; }
    if (np !== cf) { toast('两次输入不一致', true); return; }
    try { await apiPost('/api/auth/change-password', { old_password: $('#pw-old').value, new_password: np, confirm_password: cf }); toast('密码修改成功，下次登录请使用新密码'); e.target.reset(); }
    catch (err) { toast(err.message, true); }
  };
  const bi = $('#btn-invite');
  if (bi) bi.onclick = () => {
    modal(`<h2>更换学员注册邀请码</h2><form id="invite-form">
      <label>新邀请码</label><input type="text" id="invite-new" placeholder="请输入新邀请码">
      <div class="row"><button type="button" class="btn ghost" onclick="closeModal()">取消</button>
      <button class="btn" type="submit">确定更换</button></div></form>`);
    $('#invite-form').onsubmit = async e2 => {
      e2.preventDefault();
      const code = $('#invite-new').value.trim();
      if (!code) { toast('请填写新邀请码', true); return; }
      try { const d = await apiPost('/api/settings/invite-code', { invite_code: code }); closeModal(); $('#invite-code').textContent = d.invite_code; toast('邀请码已更换'); }
      catch (err) { toast(err.message, true); }
    };
  };
}

/* ---------- 考官：考试管理 ---------- */
async function viewAdminExams(v) {
  const list = await apiGet('/api/admin/exams');
  const counts = { '草稿': 0, '已发布': 0, '已结束': 0 };
  list.forEach(e => counts[e.status] = (counts[e.status] || 0) + 1);
  v.innerHTML = `<div class="card"><div class="toolbar"><h2 style="flex:1">考试管理</h2>
    <button class="btn" id="btn-new-exam">创建考试</button></div>
    <p class="muted">草稿 ${counts['草稿'] || 0} · 已发布 ${counts['已发布'] || 0} · 已结束 ${counts['已结束'] || 0}</p>
    ${list.length ? list.map(e => `<div class="list-row"><div class="grow"><b>${esc(e.name)}</b> <span class="pill">${esc(e.status)}</span><br>
      <span class="muted">${esc(e.subject)} · ${e.duration_min} 分钟 · ${e.mode === 'fixed' ? '全员同一份卷' : '每人随机抽题'} · 名单 ${e.members ? e.members.length : 0} 人</span></div>
      <button class="btn ghost small" data-exam-results="${e.id}">成绩</button>
      <button class="btn ghost small" data-exam-edit="${e.id}">编辑</button>
      ${e.status === '草稿' ? `<button class="btn small" data-exam-pub="${e.id}">发布</button>` : ''}
      ${e.status === '已发布' ? `<button class="btn small gold" data-exam-end="${e.id}">结束</button>` : ''}
      <button class="btn danger small" data-exam-del="${e.id}">删除</button></div>`).join('')
    : '<div class="empty">还没有考试，点击右上角创建</div>'}
  </div><div id="exam-sub"></div>`;
  $('#btn-new-exam').onclick = () => examForm(null);
  $$('[data-exam-edit]', v).forEach(b => b.onclick = async () => { const e = list.find(x => x.id === parseInt(b.dataset.examEdit, 10)); examForm(e); });
  $$('[data-exam-pub]', v).forEach(b => b.onclick = async () => { await apiPost('/api/admin/exams/' + b.dataset.examPub + '/publish', {}); toast('已发布'); go('exams'); });
  $$('[data-exam-end]', v).forEach(b => b.onclick = async () => { await apiPost('/api/admin/exams/' + b.dataset.examEnd + '/end', {}); toast('已结束'); go('exams'); });
  $$('[data-exam-del]', v).forEach(b => b.onclick = async () => {
    const id = parseInt(b.dataset.examDel, 10);
    let info = { submitted: 0, total_members: 0 };
    try { info = await apiGet('/api/admin/exams/' + id + '/results'); } catch (e) {}
    const ongoing = Math.max(0, (info.total_members || 0) - (info.submitted || 0));
    if (!await confirmDlg('确定删除这场考试吗？已有 ' + (info.submitted || 0) + ' 人交卷' + (ongoing ? '、还有 ' + ongoing + ' 人正在考试' : '') + '，其作答将作废；删除后连同名单、试卷、成绩一起清掉，不可恢复。')) return;
    await apiDel('/api/admin/exams/' + id, {});
    toast('考试已删除'); go('exams');
  });
  $$('[data-exam-results]', v).forEach(b => b.onclick = () => viewExamResults(parseInt(b.dataset.examResults, 10)));
}
async function examForm(e) {
  const students = await apiGet('/api/users/students').catch(() => []);
  const sel = new Set(e && e.members ? e.members : []);
  const qc = (e && e.qcounts) || { '单选': 8, '多选': 2, '判断': 0, '填空': 0, '简答': 0 };
  const qs = (e && e.qscores) || { '单选': 5, '多选': 10, '判断': 5, '填空': 5, '简答': 10 };
  modal(`<h2>${e ? '编辑考试' : '创建考试'}</h2><form id="exam-form">
    <label>考试名称</label><input type="text" id="ex-name" value="${esc(e ? e.name : '')}">
    <label>考试科目</label><select id="ex-subject"><option>自定义</option><option ${e && e.subject === '基础法规' ? 'selected' : ''}>基础法规</option><option ${e && e.subject === '业务技能' ? 'selected' : ''}>业务技能</option></select>
    <input type="text" id="ex-subject-custom" placeholder="自定义科目名称" value="${esc(e && e.subject !== '基础法规' && e.subject !== '业务技能' ? e.subject : '')}" style="margin-top:6px">
    <label>时长（分钟）</label><input type="number" id="ex-dur" value="${e ? e.duration_min : 60}">
    <label class="checkline"><input type="checkbox" id="ex-shuffle" ${e && e.shuffle ? 'checked' : ''}> 题目乱序</label>
    <label>试卷模式</label><select id="ex-mode"><option value="fixed" ${e && e.mode === 'fixed' ? 'selected' : ''}>全员同一份卷</option><option value="random" ${e && e.mode === 'random' ? 'selected' : ''}>每人开考时随机抽题</option></select>
    ${TYPES.map(t => `<div style="display:flex;gap:8px"><label style="flex:1">${t}数量<input type="number" id="ex-qc-${t}" value="${qc[t] || 0}"></label><label style="flex:1">${t}每题分<input type="number" id="ex-qs-${t}" value="${qs[t] || 0}"></label></div>`).join('')}
    <label>可考开始时间（选填，格式 YYYY-MM-DD HH:MM:SS）</label><input type="text" id="ex-start" value="${esc(e ? e.start_at || '' : '')}">
    <label>结束时间（选填）</label><input type="text" id="ex-end" value="${esc(e ? e.end_at || '' : '')}">
    <h3>考试名单（按部门分组，全选所有学员）</h3>
    <label class="checkline"><input type="checkbox" id="ex-all"> 全选所有学员</label>
    ${students.map(u => `<label class="checkline"><input type="checkbox" class="ex-member" value="${u.id}" ${sel.has(u.id) ? 'checked' : ''}> ${esc(u.name)}（${esc(u.username)} · ${esc(u.department)}）</label>`).join('') || '<p class="muted">暂无学员</p>'}
    ${e && e.mode === 'fixed' ? `<div class="toolbar"><button type="button" class="btn gold" id="ex-fixed">生成固定试卷</button><button type="button" class="btn ghost" id="ex-view-fixed">查看固定试卷</button></div>` : ''}
    <div class="row"><button type="button" class="btn ghost" onclick="closeModal()">取消</button><button class="btn" type="submit">${e ? '保存' : '创建'}</button></div>
  </form>`);
  $('#ex-all').onchange = ev => $$('.ex-member').forEach(c => c.checked = ev.target.checked);
  const fixedBtn = $('#ex-fixed');
  if (fixedBtn) fixedBtn.onclick = async () => {
    try { const d = await apiPost('/api/admin/exams/' + e.id + '/fixed-paper', {}); toast(d.message || '已生成固定试卷，所有考生将使用这份相同的试卷'); }
    catch (err) { toast(err.message, true); }
  };
  const viewFixed = $('#ex-view-fixed');
  if (viewFixed) viewFixed.onclick = async () => {
    const d = await apiGet('/api/admin/exams/' + e.id + '/fixed-paper');
    modal(`<h2>固定试卷</h2>${(d.questions || []).length ? d.questions.map((q, i) => `<p>${i + 1}. ${esc(q.no || '')} · ${esc(q.type)} · ${esc(q.stem)}</p>`).join('') : '<p class="muted">尚未生成固定试卷</p>'}<div class="row"><button class="btn" onclick="closeModal()">关闭</button></div>`);
  };
  $('#exam-form').onsubmit = async e2 => {
    e2.preventDefault();
    const subjectSel = $('#ex-subject').value;
    const qcounts = {}, qscores = {};
    TYPES.forEach(t => { qcounts[t] = parseInt($('#ex-qc-' + t).value, 10) || 0; qscores[t] = parseInt($('#ex-qs-' + t).value, 10) || 0; });
    const body = { name: $('#ex-name').value.trim(), subject: subjectSel === '自定义' ? ($('#ex-subject-custom').value.trim() || '自定义') : subjectSel,
      duration_min: parseInt($('#ex-dur').value, 10) || 60, shuffle: $('#ex-shuffle').checked, mode: $('#ex-mode').value,
      qcounts, qscores, start_at: $('#ex-start').value.trim(), end_at: $('#ex-end').value.trim(),
      members: $$('.ex-member').filter(c => c.checked).map(c => parseInt(c.value, 10)) };
    if (!body.name) { toast('请填写考试名称', true); return; }
    try {
      if (e) await apiPut('/api/admin/exams/' + e.id, body); else await apiPost('/api/admin/exams', body);
      closeModal(); toast(e ? '考试已更新' : '考试已创建（草稿）'); go('exams');
    } catch (err) { toast(err.message, true); }
  };
}
async function viewExamResults(examId) {
  const v = $('#view');
  const d = await apiGet('/api/admin/exams/' + examId + '/results');
  v.innerHTML = `<div class="card"><h2>${esc(d.exam.name)} · 成绩</h2>
    <p class="muted">应考 ${d.total_members} 人 · 已交卷 ${d.submitted} 人 · 平均分 ${d.average == null ? '—' : d.average}</p>
    <div class="toolbar"><a class="btn gold" href="/api/admin/exams/${examId}/results.csv">导出 CSV</a>
    <button class="btn gold" id="btn-print">打印成绩单</button>
    <button class="btn ghost" id="back-exams">返回考试管理</button></div>
    <table><tr><th>姓名</th><th>用户名</th><th>部门</th><th>状态</th><th>交卷时间</th><th>得分</th><th></th></tr>
    ${d.list.map(r => `<tr><td>${esc(r.name)}</td><td>${esc(r.username)}</td><td>${esc(r.department)}</td><td>${esc(r.status)}</td><td>${esc(r.submitted_at || '')}</td><td>${r.score == null ? '—' : r.score}</td>
    <td>${r.status === '已交卷' || r.status === '迟交' ? `<button class="btn ghost small" data-review="${r.user_id}">阅卷回看</button>` : ''}</td></tr>`).join('')}</table></div>`;
  $('#back-exams').onclick = () => go('exams');
  // 成绩单打印：GET /api/v2/exams/<id>/print 返回 text/html（不是 JSON），
  // api() 对非 JSON 响应返回 {raw: Response}，取文本后在新窗口打开打印。
  $('#btn-print').onclick = async () => {
    try {
      const r = await api('/api/v2/exams/' + examId + '/print');
      if (!r.raw) { toast('成绩单返回异常', true); return; }
      const html = await r.raw.text();
      const w = window.open('', '_blank');
      if (!w) { toast('浏览器拦截了新窗口，请允许弹窗后重试', true); return; }
      w.document.write(html); w.document.close();
    } catch (err) { toast(err.message, true); }
  };
  $$('[data-review]', v).forEach(b => b.onclick = async () => {
    const r = await apiGet('/api/admin/exams/' + examId + '/review/' + b.dataset.review);
    const host = $('#view');
    viewResult(host, { kind: 'exam', id: examId, score: r.score, full: r.full_score, correct: null, objectiveTotal: null, accuracy: null, pending: r.pending_self_grade, results: r.results, status: r.status });
  });
}

/* ---------- 考官：题库管理 ---------- */
async function viewQuestions(v) {
  let page = 1, q = '', type = '', category = '';
  const cats = await apiGet('/api/questions/categories');
  const load = async () => {
    const params = new URLSearchParams({ page: String(page), page_size: '20' });
    if (q) params.set('q', q); if (type) params.set('type', type); if (category) params.set('category', category);
    const d = await apiGet('/api/questions?' + params.toString());
    v.innerHTML = `<div class="card"><div class="toolbar"><h2 style="flex:1">题库管理</h2>
      <a class="btn ghost" href="/api/questions/template">下载导入模板</a>
      <button class="btn ghost" id="btn-import">导入</button>
      <button class="btn" id="btn-new-q">新增题目</button></div>
      <div class="toolbar">
        <input type="text" id="q-search" placeholder="搜索题干 / 题号 / 分类" value="${esc(q)}">
        <select id="q-type"><option value="">全部题型</option>${TYPES.map(t => `<option ${t === type ? 'selected' : ''}>${t}</option>`).join('')}</select>
        <select id="q-cat"><option value="">全部分类</option>${cats.map(c => `<option ${c === category ? 'selected' : ''}>${esc(c)}</option>`).join('')}</select>
        <button class="btn" id="q-go">搜索</button></div>
      <p class="muted">题库共 ${d.total} 题</p>
      <table><tr><th>题号</th><th>题干</th><th>题型</th><th>分类</th><th>答案</th><th>状态</th><th></th></tr>
      ${d.items.map(it => `<tr><td>${esc(it.no)}</td><td>${esc(it.stem.slice(0, 60))}${it.stem.length > 60 ? '…' : ''}</td><td>${esc(it.type)}</td><td>${esc(it.category)}</td><td>${esc(it.answer)}</td><td>${esc(it.status)}</td>
      <td><button class="btn ghost small" data-q-edit="${it.id}">编辑</button>
      <button class="btn ghost small" data-q-status="${it.id}" data-cur="${it.status}">${it.status === '启用' ? '停用' : '启用'}</button>
      <button class="btn danger small" data-q-del="${it.id}">删除</button></td></tr>`).join('')}</table>
      <div class="pager"><button class="btn ghost small" id="q-prev" ${page <= 1 ? 'disabled' : ''}>上一页</button>
      <span class="muted">第 ${page} 页</span>
      <button class="btn ghost small" id="q-next" ${d.items.length < 20 ? 'disabled' : ''}>下一页</button></div>
    </div>`;
    $('#q-go').onclick = () => { q = $('#q-search').value.trim(); type = $('#q-type').value; category = $('#q-cat').value; page = 1; load(); };
    $('#q-prev').onclick = () => { page--; load(); };
    $('#q-next').onclick = () => { page++; load(); };
    $('#btn-new-q').onclick = () => questionForm(null, load);
    $('#btn-import').onclick = () => importDialog(load);
    $$('[data-q-edit]', v).forEach(b => b.onclick = async () => { const it = await apiGet('/api/questions/' + b.dataset.qEdit); questionForm(it, load); });
    $$('[data-q-status]', v).forEach(b => b.onclick = async () => { await apiPost('/api/questions/' + b.dataset.qStatus + '/status', { status: b.dataset.cur === '启用' ? '停用' : '启用' }); toast('状态已更新'); load(); });
    $$('[data-q-del]', v).forEach(b => b.onclick = async () => { if (await confirmDlg('确定删除这道题吗？')) { await apiDel('/api/questions', { ids: [parseInt(b.dataset.qDel, 10)] }); toast('已删除'); load(); } });
  };
  await load();
}
function questionForm(it, reload) {
  const opts = it && it.options ? it.options : { A: '', B: '', C: '', D: '' };
  modal(`<h2>${it ? '编辑题目' : '新增题目'}</h2><form id="q-form">
    <label>题号（可空，空则自动生成）</label><input type="text" id="qf-no" value="${esc(it ? it.no : '')}">
    <label>题型</label><select id="qf-type">${TYPES.map(t => `<option ${it && it.type === t ? 'selected' : ''}>${t}</option>`).join('')}</select>
    <label>分类</label><input type="text" id="qf-cat" value="${esc(it ? it.category : '')}">
    <label>题干 *</label><textarea id="qf-stem" rows="3">${esc(it ? it.stem : '')}</textarea>
    ${['A', 'B', 'C', 'D'].map(L => `<label>选项 ${L}</label><input type="text" id="qf-opt-${L}" value="${esc(opts[L] || '')}">`).join('')}
    <label>正确答案 *</label><input type="text" id="qf-ans" value="${esc(it ? it.answer : '')}" placeholder="单选字母 / 多选字母串 / 判断 对或错 / 填空文本 / 简答参考答案">
    <label>解析</label><textarea id="qf-analysis" rows="2">${esc(it ? it.analysis || '' : '')}</textarea>
    <label>图片文件名（需已在服务器目录）</label><input type="text" id="qf-img" value="${esc(it ? it.image || '' : '')}">
    ${it && it.image ? `<p>当前题图预览：</p><img class="q-img" src="/assets/${esc(it.image)}" alt="题图" onerror="this.outerHTML='<p class=\\'muted\\'>题图加载失败</p>'">` : ''}
    <div class="row"><button type="button" class="btn ghost" onclick="closeModal()">取消</button><button class="btn" type="submit">保存</button></div>
  </form>`);
  $('#q-form').onsubmit = async e => {
    e.preventDefault();
    const body = { no: $('#qf-no').value.trim(), type: $('#qf-type').value, category: $('#qf-cat').value.trim(),
      stem: $('#qf-stem').value.trim(), options: {}, answer: $('#qf-ans').value.trim(),
      analysis: $('#qf-analysis').value.trim(), image: $('#qf-img').value.trim() };
    ['A', 'B', 'C', 'D'].forEach(L => { const val = $('#qf-opt-' + L).value.trim(); if (val) body.options[L] = val; });
    if (!body.stem) { toast('题干不能为空', true); return; }
    if (!body.answer) { toast('答案不能为空', true); return; }
    try {
      if (it) await apiPut('/api/questions/' + it.id, body); else await apiPost('/api/questions', body);
      closeModal(); toast('题目已保存'); reload();
    } catch (err) { toast(err.message, true); }
  };
}
function importDialog(reload) {
  modal(`<h2>导入题库</h2><p class="muted">支持 Excel（.xlsx）/ Word（.docx）。先下载导入模板，按模板填写后再上传。</p>
    <form id="imp-form"><label>选择文件</label><input type="file" id="imp-file" accept=".xlsx,.docx">
    <div class="row"><button type="button" class="btn ghost" onclick="closeModal()">取消</button><button class="btn" type="submit">开始导入</button></div></form>
    <div id="imp-result"></div>`);
  $('#imp-form').onsubmit = e => {
    e.preventDefault();
    const file = $('#imp-file').files[0];
    if (!file) { toast('请先选择文件', true); return; }
    const reader = new FileReader();
    reader.onload = async () => {
      const b64 = reader.result.split(',')[1];
      try {
        const d = await apiPost('/api/questions/import', { filename: file.name, content_b64: b64 });
        $('#imp-result').innerHTML = `<p>${esc(d.message || '')}</p>` + (d.errors || []).map(x => `<p class="muted">第 ${x.row} 行：${esc(x.error)}</p>`).join('');
        toast('导入完成：成功 ' + d.ok_count + ' 条，失败 ' + d.bad_count + ' 条'); reload();
      } catch (err) { toast(err.message, true); }
    };
    reader.readAsDataURL(file);
  };
}

/* ---------- 管理员：用户管理 ---------- */
async function viewUsers(v) {
  let page = 1, q = '', dept = '';
  const load = async () => {
    const params = new URLSearchParams({ page: String(page), page_size: '20' });
    if (q) params.set('q', q); if (dept) params.set('department', dept);
    const d = await apiGet('/api/admin/users?' + params.toString());
    const depts = d.departments || [];
    v.innerHTML = `<div class="card"><div class="toolbar"><h2 style="flex:1">用户管理</h2>
      <button class="btn ghost" id="btn-user-import">批量导入</button>
      <button class="btn" id="btn-new-user">新增用户</button></div>
      <div class="toolbar">
        <input type="text" id="u-search" placeholder="搜索用户名 / 姓名" value="${esc(q)}">
        <select id="u-dept"><option value="">全部部门</option>${depts.map(x => `<option ${x === dept ? 'selected' : ''}>${esc(x)}</option>`).join('')}</select>
        <button class="btn" id="u-go">搜索</button></div>
      <p class="muted">共 ${d.total} 名用户 · 全选只作用于当前可见</p>
      <div class="toolbar">
        <button class="btn ghost small" id="u-all">全选</button>
        <button class="btn ghost small" id="u-edit-one">编辑所选</button>
        <button class="btn ghost small" id="u-disable">停用所选</button>
        <button class="btn ghost small" id="u-enable">恢复所选</button>
        <button class="btn ghost small" id="u-reset">重置密码</button>
        <button class="btn danger small" id="u-delete">删除所选</button>
      </div>
      <table><tr><th></th><th>用户名</th><th>姓名</th><th>部门</th><th>角色</th><th>状态</th></tr>
      ${d.items.map(u => `<tr><td><input type="checkbox" class="u-check" value="${u.id}"></td><td>${esc(u.username)}</td><td>${esc(u.name)}</td><td>${esc(u.department)}</td><td>${esc(u.role_name)}</td><td>${esc(u.status)}</td></tr>`).join('')}</table>
      <div class="pager"><button class="btn ghost small" id="u-prev" ${page <= 1 ? 'disabled' : ''}>上一页</button>
      <span class="muted">第 ${page} 页</span>
      <button class="btn ghost small" id="u-next" ${d.items.length < 20 ? 'disabled' : ''}>下一页</button></div>
    </div>`;
    const checked = () => $$('.u-check').filter(c => c.checked).map(c => parseInt(c.value, 10));
    const need = () => { const ids = checked(); if (!ids.length) { toast('请先勾选用户', true); return null; } return ids; };
    $('#u-go').onclick = () => { q = $('#u-search').value.trim(); dept = $('#u-dept').value; page = 1; load(); };
    $('#u-prev').onclick = () => { page--; load(); };
    $('#u-next').onclick = () => { page++; load(); };
    $('#u-all').onclick = () => $$('.u-check').forEach(c => c.checked = true);
    $('#btn-new-user').onclick = () => userForm(null, load);
    $('#btn-user-import').onclick = () => userImportDialog(load);
    $('#u-edit-one').onclick = async () => {
      const ids = need(); if (!ids) return;
      if (ids.length > 1) { toast('编辑所选只能针对单个用户', true); return; }
      const u = d.items.find(x => x.id === ids[0]); userForm(u, load);
    };
    $('#u-disable').onclick = async () => { const ids = need(); if (!ids) return; await apiPost('/api/admin/users/batch', { action: 'disable', ids }); toast('已停用所选用户'); load(); };
    $('#u-enable').onclick = async () => { const ids = need(); if (!ids) return; await apiPost('/api/admin/users/batch', { action: 'enable', ids }); toast('已恢复所选用户'); load(); };
    $('#u-reset').onclick = async () => {
      const ids = need(); if (!ids) return;
      if (!await confirmDlg('将所选 ' + ids.length + ' 名用户的密码重置为 123456 吗？')) return;
      for (const id of ids) await apiPost('/api/admin/users/' + id + '/reset-password', { password: '123456' });
      toast('密码已重置为 123456'); load();
    };
    $('#u-delete').onclick = async () => {
      const ids = need(); if (!ids) return;
      if (!await confirmDlg('确定删除所选 ' + ids.length + ' 名用户吗？其考试记录将一并删除，且不可恢复。')) return;
      await apiPost('/api/admin/users/batch', { action: 'delete', ids }); toast('已删除所选用户'); load();
    };
  };
  await load();
}
function userForm(u, reload) {
  modal(`<h2>${u ? '编辑用户' : '新增用户'}</h2><form id="user-form">
    <label>用户名${u ? '（不可修改）' : ''}</label><input type="text" id="uf-user" value="${esc(u ? u.username : '')}" ${u ? 'disabled' : ''}>
    <label>姓名 *</label><input type="text" id="uf-name" value="${esc(u ? u.name : '')}">
    <label>密码${u ? '（留空表示不改动）' : '（初始密码，至少 6 位）'}</label><input type="password" id="uf-pass" placeholder="${u ? '留空不改' : '123456'}">
    <label>部门</label><input type="text" id="uf-dept" value="${esc(u ? u.department : '')}">
    <label>角色</label><select id="uf-role">
      <option value="student" ${!u || u.role === 'student' ? 'selected' : ''}>学员</option>
      <option value="examiner" ${u && u.role === 'examiner' ? 'selected' : ''}>考官</option>
      <option value="admin" ${u && u.role === 'admin' ? 'selected' : ''}>管理员</option></select>
    <div class="row"><button type="button" class="btn ghost" onclick="closeModal()">取消</button><button class="btn" type="submit">保存</button></div>
  </form>`);
  $('#user-form').onsubmit = async e => {
    e.preventDefault();
    const name = $('#uf-name').value.trim();
    const pass = $('#uf-pass').value;
    if (!name) { toast('姓名不能为空', true); return; }
    if (pass && pass.length < 6) { toast('密码至少 6 位', true); return; }
    try {
      if (u) {
        const body = { name, department: $('#uf-dept').value.trim(), role: $('#uf-role').value };
        if (pass) body.password = pass;
        await apiPut('/api/admin/users/' + u.id, body);
      } else {
        if (!$('#uf-user').value.trim()) { toast('请填写用户名', true); return; }
        if (!pass || pass.length < 6) { toast('新建用户密码至少 6 位', true); return; }
        await apiPost('/api/admin/users', { username: $('#uf-user').value.trim(), name, department: $('#uf-dept').value.trim(), role: $('#uf-role').value, password: pass });
      }
      closeModal(); toast('用户信息已更新'); reload();
    } catch (err) { toast(err.message, true); }
  };
}
function userImportDialog(reload) {
  modal(`<h2>批量导入用户</h2><p class="muted">只支持 .xlsx：列为 用户名 / 姓名 / 部门 / 角色（管理员 / 考官 / 学员，默认学员）/ 密码（留空默认 123456）。</p>
    <form id="uimp-form"><label>选择文件</label><input type="file" id="uimp-file" accept=".xlsx">
    <div class="row"><button type="button" class="btn ghost" onclick="closeModal()">取消</button><button class="btn" type="submit">开始导入</button></div></form>
    <div id="uimp-result"></div>`);
  $('#uimp-form').onsubmit = e => {
    e.preventDefault();
    const file = $('#uimp-file').files[0];
    if (!file) { toast('请先选择文件', true); return; }
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const d = await apiPost('/api/admin/users/import', { filename: file.name, content_b64: reader.result.split(',')[1] });
        $('#uimp-result').innerHTML = `<p>${esc(d.message || '')}</p>` + (d.errors || []).map(x => `<p class="muted">第 ${x.row} 行：${esc(x.error)}</p>`).join('');
        toast('导入完成：成功 ' + d.ok_count + ' 条，失败 ' + d.bad_count + ' 条'); reload();
      } catch (err) { toast(err.message, true); }
    };
    reader.readAsDataURL(file);
  };
}

/* ---------- 管理员：上报处理 ---------- */
async function viewAdminReports(v) {
  const list = await apiGet('/api/admin/reports');
  const pending = list.filter(r => r.status === '待处理');
  const done = list.filter(r => r.status !== '待处理');
  const card = r => {
    const q = r.question || {};
    return `<div class="card"><div class="q-head"><span class="pill">${esc(r.status)}</span><span class="pill gold">${esc(r.type)}</span>
      <span class="muted">上报用户 ${esc(r.reporter ? r.reporter.name : '')} · ${esc(r.created_at || '')}</span></div>
      <p><b>${esc(q.no || '')} · ${esc(q.type || '')}</b></p>
      <p>${esc(q.stem || '')}</p>
      ${q.options ? Object.keys(q.options).sort().map(L => `<p style="margin:2px 0">${esc(L)}. ${esc(q.options[L])}</p>`).join('') : ''}
      <p class="muted">正确答案：${esc(q.answer || '')}${q.analysis ? ' · 解析：' + esc(q.analysis) : ''}</p>
      ${q.image ? `<img class="q-img" src="/assets/${esc(q.image)}" alt="题图">` : ''}
      <p>上报内容：${esc(r.detail || '（无补充说明）')}</p>
      ${r.status === '待处理' ? `<form class="handle-form" data-id="${r.id}">
        <label>处理回复</label><textarea rows="2" class="handle-reply" placeholder="回复学员的处理说明"></textarea>
        <div class="toolbar" style="margin-top:8px">
          <button type="button" class="btn" data-act="已解决">标记已解决</button>
          <button type="button" class="btn ghost" data-act="已驳回">驳回（无需处理）</button>
          <button type="button" class="btn gold" data-act="停用该题">同时停用该题</button>
        </div></form>`
      : `<p class="muted">处理于 ${esc(r.handled_at || '')}${r.reply ? ' · 处理回复：' + esc(r.reply) : ''}</p>`}
    </div>`;
  };
  v.innerHTML = `<h2 style="margin-bottom:12px">上报处理</h2>
    ${pending.length ? pending.map(card).join('') : '<div class="card empty">暂无待处理的上报</div>'}
    ${done.length ? `<h3 style="margin:16px 0 8px">已处理记录</h3>` + done.map(card).join('') : ''}`;
  $$('.handle-form', v).forEach(f => {
    $$('[data-act]', f).forEach(b => b.onclick = async () => {
      try {
        await apiPost('/api/admin/reports/' + f.dataset.id + '/handle', { action: b.dataset.act, reply: $('.handle-reply', f).value });
        toast('已处理'); go('reports');
      } catch (err) { toast(err.message, true); }
    });
  });
}

/* ---------- 管理员：统计分析 ---------- */
async function viewStats(v) {
  const d = await apiGet('/api/admin/stats');
  v.innerHTML = `<div class="card"><h2>统计分析</h2>
    <div class="grid4">
      <div class="stat"><div class="num">${d.student_count}</div><div class="lbl">学员总数</div></div>
      <div class="stat"><div class="num">${d.practice_total}</div><div class="lbl">练习总题次</div></div>
      <div class="stat"><div class="num">${d.accuracy || 0}%</div><div class="lbl">全站正确率</div></div>
      <div class="stat"><div class="num">${d.pending_reports}</div><div class="lbl">待处理上报</div></div>
    </div></div>
  <div class="grid2">
    <div class="card"><h3>学员部门分布</h3>${(d.students_by_department || []).length ? barChart(d.students_by_department.map(x => ({ label: x.department, value: x.count }))) : '<div class="empty">暂无数据</div>'}</div>
    <div class="card"><h3>题库构成（按题型）</h3>${(d.questions_by_type || []).length ? barChart(d.questions_by_type.map(x => ({ label: x.type, value: x.count }))) : '<div class="empty">暂无数据</div>'}</div>
  </div>
  <div class="card"><h3>题库构成（按分类）</h3>${(d.questions_by_category || []).length ? barChart(d.questions_by_category.map(x => ({ label: x.category, value: x.count }))) : '<div class="empty">暂无数据</div>'}</div>
  <div class="card"><h3>考试成绩（最近 5 场）</h3>
    ${(d.recent_exams || []).length ? `<table><tr><th>考试</th><th>已考人数</th><th>平均分</th></tr>${d.recent_exams.map(x => `<tr><td>${esc(x.name)}</td><td>${x.submitted}</td><td>${x.average == null ? '—' : x.average}</td></tr>`).join('')}</table>
    ${barChart(d.recent_exams.map(x => ({ label: x.name.slice(0, 6), value: x.average || 0 })))}` : '<div class="empty">暂无数据</div>'}</div>`;
}

/* ---------- 管理员：客户端更新发布 ---------- */
async function viewVersions(v) {
  const list = await apiGet('/api/admin/versions');
  v.innerHTML = `<div class="card"><h2>客户端更新发布</h2>
    <p class="muted">发布新版本后，各终端启动软件时自动检查并升级，无需逐台重新安装；同一平台一次只保留一个生效版本。</p>
    <form id="ver-form">
      <label>目标平台</label><select id="ver-platform"><option value="win7-32">win7-32</option><option value="win10-64">win10-64</option><option value="xp-32">xp-32</option></select>
      <label>版本号</label><input type="text" id="ver-version" value="v2.2">
      <label>更新说明</label><textarea id="ver-note" rows="2"></textarea>
      <label>客户端程序 / 安装包文件名（可选）</label><input type="text" id="ver-file" placeholder="如 changshu-zhikaotong.exe">
      <div style="margin-top:12px"><button class="btn" type="submit">发布新版本</button></div>
    </form></div>
  <div class="card"><h3>已发布版本</h3>
    ${list.length ? list.map(x => `<div class="list-row"><div class="grow"><b>${esc(x.version)}</b> <span class="pill ${x.status === '生效中' ? 'green' : 'grey'}">${esc(x.status)}</span><br>
      <span class="muted">${esc(x.platform)} · ${esc(x.note || '')}${x.filename ? ' · ' + esc(x.filename) : ''} · ${esc(x.created_at || '')}</span></div>
      ${x.status !== '生效中' ? `<button class="btn small" data-ver-act="${x.id}">设为生效版本</button>` : `<button class="btn ghost small" data-ver-deact="${x.id}">下架</button>`}
      <button class="btn danger small" data-ver-del="${x.id}">删除记录</button></div>`).join('')
    : '<div class="empty">尚未发布任何版本</div>'}
  </div>`;
  $('#ver-form').onsubmit = async e => {
    e.preventDefault();
    try {
      await apiPost('/api/admin/versions', { platform: $('#ver-platform').value, version: $('#ver-version').value.trim(), note: $('#ver-note').value.trim(), filename: $('#ver-file').value.trim() });
      toast('新版本已发布'); go('versions');
    } catch (err) { toast(err.message, true); }
  };
  $$('[data-ver-act]', v).forEach(b => b.onclick = async () => { await apiPost('/api/admin/versions/' + b.dataset.verAct + '/activate', {}); toast('已设为生效版本'); go('versions'); });
  $$('[data-ver-deact]', v).forEach(b => b.onclick = async () => { await apiPost('/api/admin/versions/' + b.dataset.verDeact + '/deactivate', {}); toast('已下架'); go('versions'); });
  $$('[data-ver-del]', v).forEach(b => b.onclick = async () => {
    if (!await confirmDlg('确定删除这条版本记录吗？生效中的版本需先下架才能删除。')) return;
    try { await apiDel('/api/admin/versions/' + b.dataset.verDel, {}); toast('已删除'); go('versions'); }
    catch (err) { toast(err.message, true); }
  });
}

/* ================= v2.0 合并：刷题宝功能并入（B 工人，网页版 UI） =================
   契约：MERGE-PLAN.md §六（/api/v2/*）。A 工人并行写服务端；接口未就绪时
   本文件所有 v2 视图一律显示友好空态（“接口未就绪”+原因），不白屏、不抛错。
   字段假设（按 v07 对应处理器返回形状，见汇总）：见各函数上方的注释。 */
function v2unwrap(j) {
  if (j && j.data !== undefined && j.data !== null) return j.data;
  if (!j || typeof j !== 'object') return j;
  const out = {};
  Object.keys(j).forEach(k => { if (k !== 'ok' && k !== 'error') out[k] = j[k]; });
  return out;
}
async function v2get(path) { return v2unwrap(await api(path)); }
async function v2post(path, body) { return v2unwrap(await api(path, { method: 'POST', body: body || {} })); }
async function v2del(path, body) { return v2unwrap(await api(path, { method: 'DELETE', body: body || {} })); }
function v2list(d, keys) {
  if (Array.isArray(d)) return d;
  if (!d || typeof d !== 'object') return [];
  const ks = keys || [];
  for (let i = 0; i < ks.length; i++) if (Array.isArray(d[ks[i]])) return d[ks[i]];
  if (Array.isArray(d.questions)) return d.questions;
  if (Array.isArray(d.items)) return d.items;
  return [];
}
function v2empty(msg, sub) {
  return '<div class="card empty">' + esc(msg) + (sub ? '<br><span class="muted">' + esc(sub) + '</span>' : '') + '</div>';
}
function v2errHtml(title, err) {
  return '<div class="card"><h2>' + esc(title) + '</h2>' + v2empty('接口暂未就绪或加载失败', (err && err.message ? err.message : '请稍后刷新重试；服务端 /api/v2/* 由 A 工人并行开发中。')) + '</div>';
}
/* v07 题目形状 → v1 形状：类型 single/multi/judge/short/material/fill → 单选/多选/判断/简答/填空；
   options 可能是 [{label, content}] 数组；assets 可能是 [{path}]。 */
const V2_TYPE_MAP = { single: '单选', multi: '多选', judge: '判断', short: '简答', material: '简答', fill: '填空' };
function normV2Q(q) {
  if (!q) return q;
  const c = Object.assign({}, q);
  c.type = V2_TYPE_MAP[c.type] || c.type || '单选';
  if (Array.isArray(c.options)) {
    const o = {};
    c.options.forEach(it => { if (it && it.label) o[it.label] = it.content; });
    c.options = o;
  }
  if (!c.no) c.no = c.id ? ('Q' + c.id) : '';
  if (!c.image && Array.isArray(c.assets) && c.assets.length) c.image = c.assets[0].path || c.assets[0].filename || c.assets[0].name || '';
  if ((c.answer === null || c.answer === undefined) && c.correct_answer !== undefined) c.answer = c.correct_answer;
  return c;
}
function normV2Qs(list) { return (list || []).map(normV2Q); }
function pctNum(x) { // 0.85 或 85 都转成 0–100 的百分数
  const n = parseFloat(x);
  if (isNaN(n)) return 0;
  return n <= 1 ? Math.round(n * 1000) / 10 : n;
}
function fmtCount(n) { return (Math.round(n * 10) / 10).toString(); }

/* ---------- 数字滚动（可打断、尊重减弱动效） ---------- */
function animateCounts(root) {
  if (state._countRafs) state._countRafs.forEach(id => cancelAnimationFrame(id));
  state._countRafs = [];
  const reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  $$('.num[data-count]', root || document).forEach(el => {
    const target = parseFloat(el.dataset.count) || 0;
    const suffix = el.dataset.suffix || '';
    if (reduced) { el.textContent = fmtCount(target) + suffix; return; }
    const start = performance.now(), dur = 600;
    const step = now => {
      const t = Math.min(1, (now - start) / dur);
      const e = 1 - Math.pow(1 - t, 3);
      el.textContent = fmtCount(target * e) + suffix;
      if (t < 1) state._countRafs.push(requestAnimationFrame(step));
    };
    state._countRafs.push(requestAnimationFrame(step));
  });
}

/* ---------- 纯 SVG 图表（零 CDN） ---------- */
function radarChart(items) {
  // items: [{label, value}] value 为 0–100 百分数
  const W = 320, H = 260, cx = 160, cy = 130, R = 85;
  const n = Math.max(items.length, 3);
  const pt = (i, r) => { const a = -Math.PI / 2 + i * 2 * Math.PI / n; return [cx + r * Math.cos(a), cy + r * Math.sin(a)]; };
  let grid = '';
  [0.25, 0.5, 0.75, 1].forEach(f => {
    grid += '<polygon points="' + Array.from({ length: n }, (_, i) => pt(i, R * f).join(',')).join(' ') + '" fill="none" stroke="#DCE3EB" stroke-width="1"/>';
  });
  let axes = '', labels = '';
  items.forEach((d, i) => {
    const p = pt(i, R);
    axes += '<line x1="' + cx + '" y1="' + cy + '" x2="' + p[0] + '" y2="' + p[1] + '" stroke="#DCE3EB"/>';
    const lp = pt(i, R + 18);
    labels += '<text x="' + lp[0] + '" y="' + lp[1] + '" text-anchor="middle" font-size="12" fill="#5B6B7B">' + esc(d.label) + '</text>';
  });
  const poly = items.map((d, i) => pt(i, R * Math.max(0, Math.min(100, d.value)) / 100).join(',')).join(' ');
  const dots = items.map((d, i) => { const p = pt(i, R * Math.max(0, Math.min(100, d.value)) / 100); return '<circle cx="' + p[0] + '" cy="' + p[1] + '" r="3.5" fill="#D9A55C"/>'; }).join('');
  return '<svg class="chart chart-anim" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="雷达图">' + grid + axes + '<polygon points="' + poly + '" fill="rgba(36,66,95,.25)" stroke="#24425F" stroke-width="2"/>' + dots + labels + '</svg>';
}
function trendChart(items) {
  // items: [{label, value}]，label 为日期
  const W = 560, H = 180, pad = 30;
  if (!items.length) return '<p class="muted">暂无趋势数据</p>';
  const max = Math.max.apply(null, items.map(d => d.value).concat([1]));
  const xs = items.map((d, i) => pad + i * (W - pad * 2) / Math.max(items.length - 1, 1));
  const ys = items.map(d => H - pad - (d.value / max) * (H - pad * 2 - 10));
  const pts = xs.map((x, i) => x + ',' + ys[i]).join(' ');
  const dots = xs.map((x, i) => '<circle cx="' + x + '" cy="' + ys[i] + '" r="3.5" fill="#24425F"><title>' + esc(items[i].label) + '：' + items[i].value + '</title></circle>').join('');
  const labs = xs.map((x, i) => (i % Math.ceil(items.length / 6) === 0 || i === items.length - 1) ? '<text x="' + x + '" y="' + (H - 8) + '" text-anchor="middle" font-size="11" fill="#5B6B7B">' + esc(items[i].label.slice(5)) + '</text>' : '').join('');
  return '<svg class="chart chart-anim" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="趋势图"><line x1="' + pad + '" y1="' + (H - pad) + '" x2="' + (W - pad) + '" y2="' + (H - pad) + '" stroke="#DCE3EB"/><polyline points="' + pts + '" fill="none" stroke="#24425F" stroke-width="2"/>' + dots + labs + '</svg>';
}
function heatmapHtml(d) {
  // 接受：{rows, cols, values:[[n]]} 或 [{row, col, value}] / [{date, hour, value}] / [{label, value}]
  let rows = [], cols = [], grid = [];
  if (d && Array.isArray(d.rows) && Array.isArray(d.cols) && Array.isArray(d.values)) {
    rows = d.rows; cols = d.cols; grid = d.values;
  } else if (Array.isArray(d)) {
    const rset = [], cset = [];
    d.forEach(it => {
      const r = it.row || it.date || it.label || '', c = it.col || it.hour || it.type || '';
      if (rset.indexOf(r) < 0) rset.push(r);
      if (cset.indexOf(c) < 0) cset.push(c);
    });
    rows = rset; cols = cset;
    grid = rset.map(r => cset.map(c => {
      const hit = d.find(it => (it.row || it.date || it.label || '') === r && (it.col || it.hour || it.type || '') === c);
      return hit ? (hit.value != null ? hit.value : hit.total || 0) : 0;
    }));
  }
  if (!rows.length || !cols.length) return '<p class="muted">暂无热力数据</p>';
  let max = 1;
  grid.forEach(r => r.forEach(v => { if (v > max) max = v; }));
  let html = '<table class="heat"><tr><th></th>' + cols.map(c => '<th>' + esc(String(c)) + '</th>').join('') + '</tr>';
  rows.forEach((r, i) => {
    html += '<tr><th>' + esc(String(r)) + '</th>' + grid[i].map(v => {
      const a = Math.max(0.06, v / max);
      return '<td style="background:rgba(36,66,95,' + a.toFixed(2) + ');color:' + (a > 0.55 ? '#fff' : '#1C2733') + '" title="' + esc(String(r)) + ' × ' + '">' + v + '</td>';
    }).join('') + '</tr>';
  });
  return html + '</table><p class="muted">颜色越深表示作答量越大（纯 CSS/表格呈现，无动效）。</p>';
}
function ringChart(items) {
  // items: [{label, value}] 多段环形
  const total = items.reduce((s, d) => s + (d.value || 0), 0) || 1;
  const colors = ['#24425F', '#D9A55C', '#16A34A', '#F59E0B', '#5B6B7B', '#7A5A24'];
  const r = 52, C = 2 * Math.PI * r;
  let off = 0, segs = '';
  items.forEach((d, i) => {
    const len = C * (d.value || 0) / total;
    segs += '<circle cx="70" cy="70" r="' + r + '" fill="none" stroke="' + colors[i % colors.length] + '" stroke-width="14" stroke-dasharray="' + Math.max(0, len - 2) + ' ' + C + '" stroke-dashoffset="' + (-off) + '" transform="rotate(-90 70 70)"><title>' + esc(d.label) + '：' + d.value + '</title></circle>';
    off += len;
  });
  const legend = items.map((d, i) => '<span class="legend-item"><i style="background:' + colors[i % colors.length] + '"></i>' + esc(d.label) + ' ' + d.value + '（' + Math.round((d.value || 0) / total * 100) + '%）</span>').join('');
  return '<div class="ring-wrap"><svg class="chart chart-anim" viewBox="0 0 140 140" style="max-width:170px" role="img" aria-label="环形图"><circle cx="70" cy="70" r="' + r + '" fill="none" stroke="#E9EEF5" stroke-width="14"/>' + segs + '<text x="70" y="66" text-anchor="middle" font-size="20" font-weight="700" fill="#24425F">' + total + '</text><text x="70" y="86" text-anchor="middle" font-size="12" fill="#5B6B7B">总计</text></svg><div class="legend">' + legend + '</div></div>';
}
function chartSeries(d, keys, labelKeys, valueKeys) {
  // 从多种可能字段名里取 [{label, value}]
  const arr = v2list(d, keys);
  return arr.map(it => {
    let label = '';
    (labelKeys || ['label', 'name', 'knowledge', 'type', 'date', 'department', 'team', 'category']).forEach(k => { if (!label && it[k] != null) label = String(it[k]); });
    let value = null;
    (valueKeys || ['value', 'count', 'total', 'accuracy']).forEach(k => { if (value === null && it[k] != null) value = it[k]; });
    return { label: label || '—', value: parseFloat(value) || 0, raw: it };
  });
}
function chartsHtml(d) {
  // 假设：{radar:[{label,value}], trend:[{label/date,value}], bar/by_type:[...], heatmap:{...}|[...], ring/donut:[...]}
  // 兼容 v07 report 形状：by_knowledge（accuracy 0–1）→雷达；trend（date/total）→趋势。
  let radar = chartSeries(d.radar || d.by_knowledge, ['radar', 'by_knowledge']).map(x => ({ label: x.label, value: x.raw && x.raw.accuracy != null && x.raw.accuracy <= 1 ? Math.round(x.raw.accuracy * 1000) / 10 : (x.value <= 1 && x.value > 0 ? Math.round(x.value * 100) : x.value) }));
  if (!radar.length && d && d.radar) radar = chartSeries(d, ['radar']);
  let trend = chartSeries(d.trend, ['trend']).map(x => ({ label: x.raw && x.raw.date ? x.raw.date : x.label, value: x.raw && x.raw.total != null ? x.raw.total : x.value }));
  let bar = chartSeries(d.bar || d.by_type, ['bar', 'by_type']);
  let ring = chartSeries(d.ring || d.donut, ['ring', 'donut']);
  if (!ring.length && bar.length) ring = bar.slice();
  const heat = d.heatmap || d.heat || null;
  return '<div class="grid2">' +
    '<div class="card chart-card"><h3>知识点掌握度（雷达）</h3>' + (radar.length ? radarChart(radar) : '<div class="empty">暂无雷达数据</div>') + '</div>' +
    '<div class="card chart-card"><h3>做题趋势（近 14 天）</h3>' + (trend.length ? trendChart(trend) : '<div class="empty">暂无趋势数据</div>') + '</div>' +
    '<div class="card chart-card"><h3>各题型 / 分类（柱状）</h3>' + (bar.length ? barChart(bar) : '<div class="empty">暂无柱状数据</div>') + '</div>' +
    '<div class="card chart-card"><h3>题型占比（环形）</h3>' + (ring.length ? ringChart(ring) : '<div class="empty">暂无环形数据</div>') + '</div>' +
    '</div><div class="card chart-card"><h3>作答热力</h3>' + (heat ? heatmapHtml(heat) : '<div class="empty">暂无热力数据</div>') + '</div>';
}

/* ---------- 练习：五环节 + 自适应 + 薄弱项 ---------- */
const V2_MODES = [
  { key: 'sequential', label: '顺序', desc: '按题库题号全量顺序，断点续刷' },
  { key: 'random', label: '随机', desc: '全量随机抽题，顺序打乱' },
  { key: 'wrong', label: '错题回顾', desc: '只练错题本，做对一题自动移出' },
  { key: 'weak', label: '薄弱分析', desc: '按掌握度挑薄弱知识点出题' },
  { key: 'exam', label: '阶段考核', desc: '按阶段考核组卷，限时作答' },
];
function v2ModeAction(key) {
  if (key === 'sequential') startPracticeSetup('顺序');
  else if (key === 'random') startPracticeSetup('随机');
  else if (key === 'wrong') startPracticeSetup('错题');
  else if (key === 'weak') startWeak();
  else if (key === 'adaptive') startAdaptive();
  else if (key === 'exam') go('mock');
}
async function viewPractice2(v) {
  let modes = V2_MODES, profile = null;
  try { const d = await v2get('/api/v2/practice/modes'); const m = v2list(d, ['modes']); if (m.length) modes = m.map(x => ({ key: x.key || x.mode || x.label, label: x.label || x.key, desc: x.desc || x.description || '' })); } catch (e) { /* 用内置五环节兜底 */ }
  try { profile = await v2get('/api/v2/adaptive'); } catch (e) { profile = null; }
  const prof = profile && (profile.adaptive || profile);
  v.innerHTML = '<div class="card"><h2>自适应练习 · 学习方法五环节</h2>' +
    '<p class="muted">五环节：顺序 / 随机 / 错题回顾 / 薄弱分析 / 阶段考核。自适应按你的掌握度动态调组卷权重与难度（FSRS 1/3/7/14/30 天复习间隔；薄弱占比动态到 65%；冷启动 20 题）。</p>' +
    '<div class="grid2">' + modes.map((m, i) => '<button class="module" data-v2mode="' + esc(m.key) + '"><span class="ico">' + esc(m.label.slice(0, 1)) + '</span><span><b>' + esc(m.label) + '</b><span>' + esc(m.desc) + '</span></span></button>').join('') +
    '<button class="module" data-v2mode="adaptive"><span class="ico">智</span><span><b>自适应练习</b><span>按掌握度与难度自适应出题</span></span></button></div></div>' +
    '<div class="card" id="v2-profile">' + (prof ? adaptiveProfileHtml(prof) : '<h3>自适应画像</h3><div class="empty">自适应画像暂不可用（接口未就绪，或尚未作答满 20 题冷启动）</div>') + '</div>';
  $$('[data-v2mode]', v).forEach(b => b.onclick = () => v2ModeAction(b.dataset.v2mode));
}
function adaptiveProfileHtml(p) {
  const ratio = p.ratio || {};
  const weak = p.weak_knowledge || [];
  const per = p.per_knowledge || [];
  return '<h3>自适应画像</h3>' +
    '<div class="grid4">' +
    '<div class="stat"><div class="num" data-count="' + (p.total_attempts || 0) + '">0</div><div class="lbl">累计作答</div></div>' +
    '<div class="stat"><div class="num" data-count="' + (p.due_count || 0) + '">0</div><div class="lbl">待复习题</div></div>' +
    '<div class="stat"><div class="num" data-count="' + (p.streak_days || 0) + '">0</div><div class="lbl">连续学习天数</div></div>' +
    '<div class="stat"><div class="num" data-count="' + (ratio.weak_pct || 0) + '" data-suffix="%">0</div><div class="lbl">薄弱占比</div></div></div>' +
    (p.sample_note ? '<p class="muted" style="margin-top:12px">' + esc(p.sample_note) + '</p>' : '') +
    (p.cold_start ? '<p><span class="pill gold">冷启动</span> <span class="muted">样本不足 20 题，先按默认比例出题。</span></p>' : '') +
    (weak.length ? '<p>薄弱知识点：<b>' + weak.map(esc).join('、') + '</b></p>' : '<p class="muted">暂无明显薄弱知识点。</p>') +
    (per.length ? '<table><tr><th>知识点</th><th>作答</th><th>答对</th><th>正确率</th><th>状态</th></tr>' + per.map(x => '<tr><td>' + esc(x.knowledge) + '</td><td>' + (x.total || 0) + '</td><td>' + (x.correct || 0) + '</td><td>' + pctNum(x.accuracy) + '%</td><td>' + esc(x.status || '') + '</td></tr>').join('') + '</table>' : '');
}
async function loadAdaptiveProfile(el) {
  if (!el) return;
  try {
    const d = await v2get('/api/v2/adaptive');
    const prof = d && (d.adaptive || d);
    el.innerHTML = adaptiveProfileHtml(prof);
    animateCounts(el);
  } catch (e) { el.innerHTML = '<h3>自适应画像</h3><div class="empty">自适应画像暂不可用（' + esc(e.message) + '）</div>'; }
}
async function startAdaptive() {
  try {
    const d = await v2get('/api/v2/practice/adaptive');
    const qs = normV2Qs(v2list(d, ['questions']));
    if (!qs.length) { toast('自适应暂无题目（题库为空或接口未返回题目）', true); return; }
    state.practice = { mode: '自适应', questions: qs, idx: 0, correct: 0, wrong: 0, submitted: false, result: null, sel: null, input: '', selfDone: false };
    renderPractice();
  } catch (err) { toast(err.message, true); }
}
async function startWeak() {
  try {
    const d = await v2get('/api/v2/weak');
    const qs = normV2Qs(v2list(d, ['questions']));
    if (!qs.length) { toast('暂无薄弱项题目（先多练几题，满 20 题后开始个性化判断）', true); return; }
    state.practice = { mode: '薄弱项', questions: qs, idx: 0, correct: 0, wrong: 0, submitted: false, result: null, sel: null, input: '', selfDone: false };
    renderPractice();
  } catch (err) { toast(err.message, true); }
}
async function showAiTip() {
  const q = state.practice && curQ();
  if (!q) return;
  try {
    const d = await v2get('/api/v2/ai/tips/' + q.id);
    const tip = d.tip || d.data && d.data.tip || '';
    modal('<h2>易错点提示</h2><p>' + esc(tip || '暂无提示') + '</p>' +
      (d.total != null ? '<p class="muted">全站作答 ' + d.total + ' 人次 · 正确率 ' + (d.accuracy == null ? '—' : d.accuracy + '%') + (d.top_wrong ? ' · 最常见错误答案“' + esc(d.top_wrong.answer) + '”（' + d.top_wrong.count + ' 人次）' : '') + '</p>' : '') +
      '<div class="row"><button class="btn" onclick="closeModal()">知道了</button></div>');
  } catch (err) { toast(err.message, true); }
}

/* ---------- 成绩：简答 / 材料题批阅结果（与选择题分开列示） ---------- */
function essayMineHtml(items) {
  if (!items || !items.length) return '<div class="empty">暂无简答 / 材料题批阅记录</div>';
  return items.map(it => {
    const max = parseFloat(it.max_score) || 10;
    const graded = it.status === 'graded' && it.score !== null && it.score !== undefined;
    const passed = graded && parseFloat(it.score) >= 0.6 * max;
    return '<div class="list-row"><div class="grow"><b>' + esc(it.stem || ('题目 #' + (it.question_id || ''))) + '</b> ' +
      '<span class="pill ' + (graded ? (passed ? 'green' : 'red') : 'gold') + '">' + (graded ? (passed ? '已批阅 · 算对' : '已批阅 · 算错') : '待批阅') + '</span><br>' +
      '<span class="muted">得分 ' + (graded ? it.score + ' / ' + max : '— / ' + max) + '（≥60% 满分算对）' +
      (it.reviewer ? ' · 批阅人 ' + esc(it.reviewer) : '') + (it.reviewed_at ? ' · ' + esc(it.reviewed_at) : '') + (it.created_at ? ' · 提交 ' + esc(it.created_at) : '') + '</span>' +
      (it.comment ? '<br>批阅意见：' + esc(it.comment) : '') + '</div></div>';
  }).join('');
}
async function viewMyReport(v) {
  let charts = null, chartsErr = '';
  try { charts = await v2get('/api/v2/dashboard/charts'); } catch (e) { chartsErr = e.message; }
  let mine = [], mineErr = '';
  try { mine = v2list(await v2get('/api/v2/essay/mine'), ['submissions', 'items', 'list']); } catch (e) { mineErr = e.message; }
  v.innerHTML = '<div class="card"><h2>我的成绩与报告</h2><p class="muted">仪表盘与批阅结果只用你自己的作答数据；数字滚动与图表动效可打断，减弱动效设置下瞬间显示。</p></div>' +
    (charts ? chartsHtml(charts) : v2empty('仪表盘暂不可用', chartsErr || '接口未就绪')) +
    '<div class="card"><h3>简答 / 材料题批阅结果</h3><p class="muted">与选择题分开列示；≥60% 满分算对。</p>' +
    (mineErr ? v2empty('批阅记录暂不可用', mineErr) : essayMineHtml(mine)) + '</div>';
  animateCounts(v);
}

/* ---------- 考官：组卷模板 ---------- */
async function viewTemplates(v) {
  let list = [];
  try { list = v2list(await v2get('/api/v2/templates'), ['templates']); }
  catch (e) { v.innerHTML = v2errHtml('组卷模板', e); return; }
  v.innerHTML = '<div class="card"><div class="toolbar"><h2 style="flex:1">组卷模板</h2><button class="btn" id="btn-new-tpl">新建模板</button></div>' +
    '<p class="muted">按模板开考含全部题型配比（含简答、填空），正式考试交卷后简答进批阅队列，成绩单上选择题与简答题分开列示。</p>' +
    (list.length ? list.map(t => {
      let rules = {};
      try { rules = typeof t.rules_json === 'string' ? JSON.parse(t.rules_json || '{}') : (t.rules || t.rules_json || {}); } catch (e) { rules = {}; }
      const counts = rules.type_counts || rules.counts || rules || {};
      const summary = TYPES.map(x => x + ' ' + (counts[x] || 0)).join(' · ');
      return '<div class="list-row"><div class="grow"><b>' + esc(t.title) + '</b> <span class="pill">' + esc(t.subject || '') + '</span><br>' +
        '<span class="muted">共 ' + (t.total_count || 0) + ' 题 · ' + esc(summary) + ' · 创建 ' + esc(t.created_at || '') + '</span></div>' +
        '<button class="btn gold small" data-tpl-start="' + t.id + '">按模板开考</button>' +
        '<button class="btn ghost small" data-tpl-del="' + t.id + '">删除</button></div>';
    }).join('') : '<div class="empty">还没有组卷模板，点击右上角新建</div>') + '</div>';
  $('#btn-new-tpl').onclick = () => templateForm();
  $$('[data-tpl-del]', v).forEach(b => b.onclick = async () => {
    if (!await confirmDlg('确定删除这个组卷模板吗？')) return;
    try { await v2del('/api/v2/templates/' + b.dataset.tplDel); toast('模板已删除'); go('templates'); }
    catch (err) { toast(err.message, true); }
  });
  $$('[data-tpl-start]', v).forEach(b => b.onclick = async () => {
    try {
      const d = await v2post('/api/v2/templates/' + b.dataset.tplStart + '/start', {});
      if (d && d.question_detail && d.question_detail.length) { openExamSession(d); return; }
      if (d && d.exam && d.exam.id) { toast('已按模板开考，考试 ID ' + d.exam.id + '，学员可在正式考试中参加'); go('exams'); return; }
      toast('已按模板开考' + (d && d.exam_id ? '，考试 ID ' + d.exam_id : '')); go('exams');
    } catch (err) { toast(err.message, true); }
  });
}
function templateForm() {
  modal('<h2>新建组卷模板</h2><form id="tpl-form">' +
    '<label>模板名称 *</label><input type="text" id="tpl-title" placeholder="如 阶段考核 A 卷">' +
    '<label>科目</label><input type="text" id="tpl-subject" placeholder="如 基础法规">' +
    '<label>总题数</label><input type="number" id="tpl-total" value="10">' +
    TYPES.map(t => '<label>' + t + '数量</label><input type="number" id="tpl-c-' + t + '" value="' + (t === '单选' ? 5 : t === '判断' ? 3 : t === '多选' ? 2 : 0) + '">').join('') +
    '<div class="row"><button type="button" class="btn ghost" onclick="closeModal()">取消</button><button class="btn" type="submit">创建模板</button></div></form>');
  $('#tpl-form').onsubmit = async e => {
    e.preventDefault();
    const counts = {};
    TYPES.forEach(t => { counts[t] = parseInt($('#tpl-c-' + t).value, 10) || 0; });
    const total = parseInt($('#tpl-total').value, 10) || 10;
    const title = $('#tpl-title').value.trim();
    if (!title) { toast('请填写模板名称', true); return; }
    try {
      // 服务端收 rules.type_counts（中文题型键，见 /api/v2/templates 契约）；
      // 旧形状 rules.counts 不会被读取，会静默回退为随机补题，故只发 type_counts。
      await v2post('/api/v2/templates', { title, subject: $('#tpl-subject').value.trim(), total_count: total, rules: { type_counts: counts }, rules_json: JSON.stringify({ type_counts: counts }) });
      closeModal(); toast('模板已创建'); go('templates');
    } catch (err) { toast(err.message, true); }
  };
}

/* ---------- 考官：导入任务（含 PDF 与图文配对复核） ---------- */
async function viewImportJobs(v) {
  let jobs = [], queue = [];
  try {
    const d = await v2get('/api/v2/import/jobs');
    jobs = v2list(d.jobs || d, ['jobs']); queue = v2list(d.review_queue || [], ['review_queue']);
  } catch (e) { v.innerHTML = v2errHtml('导入任务', e); return; }
  v.innerHTML = '<div class="card"><div class="toolbar"><h2 style="flex:1">导入任务</h2><button class="btn" id="btn-pdf">PDF 导入</button></div>' +
    '<p class="muted">Excel / Word 导入仍在「题库管理」里。PDF 只做文字型解析，扫描型会明确拒绝、不硬做。图文错位按置信度分流：≥90% 自动配对、70–90% 复核、&lt;70% 人工。</p>' +
    (jobs.length ? jobs.map(j => '<div class="list-row"><div class="grow"><b>' + esc(j.filename || ('任务 #' + j.id)) + '</b> <span class="pill">' + esc(j.status || '') + '</span><br>' +
      '<span class="muted">' + esc(j.file_type || '') + ' · 共 ' + (j.total_rows || 0) + ' 行 · 成功 ' + (j.ok_rows || 0) + ' · 失败 ' + (j.bad_rows || 0) +
      ((j.pairing_auto != null) ? ' · 配对自动 ' + j.pairing_auto + ' / 复核 ' + j.pairing_review + ' / 人工 ' + j.pairing_manual : '') +
      ' · ' + esc(j.created_at || '') + '</span></div>' +
      '<button class="btn ghost small" data-job-detail="' + j.id + '">详情</button>' +
      '<button class="btn ghost small" data-job-pair="' + j.id + '">配对复核</button>' +
      (j.status !== 'approved' ? '<button class="btn small" data-job-approve="' + j.id + '">审核通过并发布</button>' : '') + '</div>').join('')
      : '<div class="empty">暂无导入任务</div>') + '</div>' +
    '<div id="job-sub"></div>' +
    (queue.length ? '<div class="card"><h3>待审核导入（review_queue）</h3>' + queue.map(r => '<div class="list-row"><div class="grow"><b>' + esc(r.stem || ('记录 #' + r.id)) + '</b><br><span class="muted">' + esc(r.status || '') + ' · ' + esc(r.created_at || '') + '</span></div></div>').join('') + '</div>' : '');
  $('#btn-pdf').onclick = () => pdfImportDialog(() => go('import'));
  $$('[data-job-detail]', v).forEach(b => b.onclick = () => viewJobDetail(parseInt(b.dataset.jobDetail, 10)));
  $$('[data-job-pair]', v).forEach(b => b.onclick = () => viewPairings(parseInt(b.dataset.jobPair, 10)));
  $$('[data-job-approve]', v).forEach(b => b.onclick = async () => {
    if (!await confirmDlg('审核通过并发布该导入任务吗？题目将进入当前题库版本。')) return;
    try { await v2post('/api/v2/import/jobs/' + b.dataset.jobApprove + '/approve', {}); toast('已审核通过并发布'); go('import'); }
    catch (err) { toast(err.message, true); }
  });
}
function pdfImportDialog(reload) {
  modal('<h2>PDF 导入（文字型）</h2><p class="muted">只解析文字型 PDF；扫描型图片 PDF 会明确拒绝，不硬做 OCR。</p>' +
    '<form id="pdf-form"><label>选择 PDF 文件</label><input type="file" id="pdf-file" accept=".pdf">' +
    '<div class="row"><button type="button" class="btn ghost" onclick="closeModal()">取消</button><button class="btn" type="submit">开始导入</button></div></form><div id="pdf-result"></div>');
  $('#pdf-form').onsubmit = e => {
    e.preventDefault();
    const file = $('#pdf-file').files[0];
    if (!file) { toast('请先选择 PDF 文件', true); return; }
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const d = await v2post('/api/v2/import/pdf', { filename: file.name, content_b64: reader.result.split(',')[1] });
        $('#pdf-result').innerHTML = '<p>' + esc((d && (d.message || d.note)) || '导入完成') + '</p>';
        toast('PDF 导入完成'); if (reload) reload();
      } catch (err) { toast(err.message, true); }
    };
    reader.readAsDataURL(file);
  };
}
async function viewJobDetail(jobId) {
  const host = $('#job-sub'); if (!host) return;
  host.innerHTML = '<div class="card">加载中…</div>';
  try {
    const d = await v2get('/api/v2/import/jobs/' + jobId);
    const items = v2list(d, ['items']);
    host.innerHTML = '<div class="card"><h3>导入任务 #' + jobId + ' 明细</h3>' +
      (items.length ? '<table><tr><th>行</th><th>题干</th><th>状态</th><th>错误</th></tr>' + items.map(it => '<tr><td>' + (it.row_no || it.row || '') + '</td><td>' + esc((it.stem || '').slice(0, 60)) + '</td><td>' + esc(it.status || '') + '</td><td>' + esc(it.error || '') + '</td></tr>').join('') + '</table>' : '<div class="empty">该任务暂无逐行明细</div>') + '</div>';
  } catch (err) { host.innerHTML = v2empty('任务详情加载失败', err.message); }
}
async function viewPairings(jobId) {
  const host = $('#job-sub'); if (!host) return;
  host.innerHTML = '<div class="card">加载中…</div>';
  try {
    const d = await v2get('/api/v2/import/jobs/' + jobId + '/pairings');
    const list = v2list(d, ['pairings']);
    const stat = d.pairing || {};
    host.innerHTML = '<div class="card"><h3>图文配对复核 · 任务 #' + jobId + '</h3>' +
      '<p class="muted">自动 ' + (stat.auto || 0) + ' · 复核 ' + (stat.review || 0) + ' · 人工 ' + (stat.manual || 0) + '（≥90% 自动、70–90% 复核、&lt;70% 人工）</p>' +
      (list.length ? list.map(p => {
        const conf = p.confidence != null ? Math.round(p.confidence * 100) : null;
        const st = p.status || (conf == null ? '' : conf >= 90 ? 'auto' : conf >= 70 ? 'review' : 'manual');
        return '<div class="list-row"><div class="grow"><b>' + esc(p.filename || p.asset_path || ('配对 #' + p.id)) + '</b> ' +
          '<span class="pill ' + (st === 'confirmed' ? 'green' : st === 'rejected' ? 'red' : 'gold') + '">' + esc(st) + '</span><br>' +
          '<span class="muted">置信度 ' + (conf == null ? '—' : conf + '%') + ' · 对应题目：' + esc(p.stem || (p.question_id ? '#' + p.question_id : '未指派')) + '</span></div>' +
          (st !== 'confirmed' ? '<button class="btn small" data-pair-ok="' + p.id + '" data-qid="' + (p.question_id || '') + '">确认</button>' : '') +
          (st !== 'rejected' ? '<button class="btn ghost small" data-pair-no="' + p.id + '">拒绝（改人工）</button>' : '') + '</div>';
      }).join('') : '<div class="empty">该任务暂无图文配对</div>') + '</div>';
    $$('[data-pair-ok]', host).forEach(b => b.onclick = async () => {
      let qid = b.dataset.qid;
      if (!qid) {
        modal('<h2>确认配对</h2><p class="muted">该图暂无对应题目，请指定目标题号（题目 ID）。</p><form id="pair-form"><label>目标题号</label><input type="number" id="pair-qid"><div class="row"><button type="button" class="btn ghost" onclick="closeModal()">取消</button><button class="btn" type="submit">确认配对</button></div></form>');
        $('#pair-form').onsubmit = async e2 => {
          e2.preventDefault();
          try { await v2post('/api/v2/import/pairings/' + b.dataset.pairOk + '/confirm', { question_id: parseInt($('#pair-qid').value, 10) }); closeModal(); toast('配对已确认'); viewPairings(jobId); }
          catch (err) { toast(err.message, true); }
        };
        return;
      }
      try { await v2post('/api/v2/import/pairings/' + b.dataset.pairOk + '/confirm', { question_id: parseInt(qid, 10) }); toast('配对已确认'); viewPairings(jobId); }
      catch (err) { toast(err.message, true); }
    });
    $$('[data-pair-no]', host).forEach(b => b.onclick = async () => {
      try { await v2post('/api/v2/import/pairings/' + b.dataset.pairNo + '/reject', {}); toast('配对已拒绝，改人工处理'); viewPairings(jobId); }
      catch (err) { toast(err.message, true); }
    });
  } catch (err) { host.innerHTML = v2empty('配对复核加载失败', err.message); }
}

/* ---------- 考官：题库质量闭环 ---------- */
async function viewQuality(v) {
  let list = [];
  try { list = v2list(await v2get('/api/v2/quality'), ['quality']); }
  catch (e) { v.innerHTML = v2errHtml('题库质量', e); return; }
  const suspects = list.filter(x => x.flag && x.flag !== 'normal');
  v.innerHTML = '<div class="card"><div class="toolbar"><h2 style="flex:1">题库质量闭环</h2><button class="btn" id="btn-q-refresh">重算质量分</button></div>' +
    '<p class="muted">疑似错题标红：作答 ≥5 题且正确率 &lt;20%（过难/答案可疑）或 &gt;95%（过易/答案泄露）即标红；停用后不再出题，可恢复。</p>' +
    '<p>共 ' + list.length + ' 题有质量统计 · 疑似错题 ' + suspects.length + ' 题</p>' +
    (list.length ? '<table><tr><th>题号</th><th>题干</th><th>作答</th><th>答对</th><th>正确率</th><th>状态</th><th></th></tr>' + list.map(x => {
      const suspect = x.flag && x.flag !== 'normal';
      return '<tr' + (suspect ? ' style="background:#FEE2E2"' : '') + '><td>' + (x.question_id || '') + '</td><td>' + esc((x.stem || '').slice(0, 40)) + '</td><td>' + (x.total || 0) + '</td><td>' + (x.correct || 0) + '</td><td>' + pctNum(x.accuracy) + '%</td><td>' + (suspect ? '<span class="pill red">疑似错题</span>' : '<span class="pill green">正常</span>') + '</td>' +
        '<td><button class="btn ghost small" data-q-disable="' + x.question_id + '">停用</button> <button class="btn ghost small" data-q-enable="' + x.question_id + '">恢复</button></td></tr>';
    }).join('') + '</table>' : '<div class="empty">暂无质量统计（先重算质量分）</div>') + '</div>';
  $('#btn-q-refresh').onclick = async () => {
    try { await v2post('/api/v2/quality/refresh', {}); toast('质量分已重算'); go('quality'); }
    catch (err) { toast(err.message, true); }
  };
  // 服务端 /api/v2/questions/<id>/status 只收 {status: '启用'|'停用'}（中文值），英文值报 400。
  $$('[data-q-disable]', v).forEach(b => b.onclick = async () => {
    try { await v2post('/api/v2/questions/' + b.dataset.qDisable + '/status', { status: '停用' }); toast('题目已停用'); go('quality'); }
    catch (err) { toast(err.message, true); }
  });
  $$('[data-q-enable]', v).forEach(b => b.onclick = async () => {
    try { await v2post('/api/v2/questions/' + b.dataset.qEnable + '/status', { status: '启用' }); toast('题目已恢复'); go('quality'); }
    catch (err) { toast(err.message, true); }
  });
}

/* ---------- 考官：简答批阅队列（人工打分） ---------- */
async function viewEssayQueue(v) {
  let list = [];
  try { list = v2list(await v2get('/api/v2/essay/queue'), ['queue']); }
  catch (e) { v.innerHTML = v2errHtml('简答批阅队列', e); return; }
  v.innerHTML = '<div class="card"><h2>简答 / 材料题批阅队列</h2>' +
    '<p class="muted">人工打分：≥60% 满分算对；批阅后计入成绩，答错的进错题本。</p>' +
    (list.length ? list.map(it => {
      const max = parseFloat(it.max_score) || 10;
      const who = it.display_name || it.name || it.username || ('用户 #' + (it.user_id || ''));
      return '<div class="list-row"><div class="grow"><b>' + esc(it.stem || ('题目 #' + (it.question_id || ''))) + '</b><br>' +
        '<span class="muted">' + esc(who) + ' · ' + esc(it.team || it.department || '') + ' · 满分 ' + max + ' · ' + esc(it.created_at || '') + '</span>' +
        (it.reference_answer ? '<br>参考答案：' + esc(it.reference_answer) : '') +
        (it.rubric ? '<br>评分标准：' + esc(it.rubric) : '') + '</div>' +
        '<button class="btn gold small" data-essay-review="' + it.id + '" data-max="' + max + '">人工打分</button></div>';
    }).join('') : '<div class="empty">暂无待批阅的简答 / 材料题</div>') + '</div>';
  $$('[data-essay-review]', v).forEach(b => b.onclick = () => {
    const max = parseFloat(b.dataset.max) || 10;
    modal('<h2>人工打分</h2><form id="essay-form"><p class="muted">满分 ' + max + ' 分；≥ ' + (Math.round(max * 0.6 * 10) / 10) + ' 分算对。</p>' +
      '<label>得分（0–' + max + '）*</label><input type="number" id="essay-score" min="0" max="' + max + '" step="0.5">' +
      '<label>批阅意见（选填）</label><textarea id="essay-comment" rows="2"></textarea>' +
      '<div class="row"><button type="button" class="btn ghost" onclick="closeModal()">取消</button><button class="btn" type="submit">提交批阅</button></div></form>');
    $('#essay-form').onsubmit = async e => {
      e.preventDefault();
      const score = parseFloat($('#essay-score').value);
      if (isNaN(score) || score < 0 || score > max) { toast('分数应在 0 到 ' + max + ' 之间', true); return; }
      try {
        // v07 侧收 {review_id, score, comment}。
        const d = await v2post('/api/v2/essay/review', { review_id: parseInt(b.dataset.essayReview, 10), score, comment: $('#essay-comment').value });
        closeModal(); toast('批阅完成：' + (d && d.passed === false ? '算错' : d && d.passed === true ? '算对' : '已提交')); go('essay');
      } catch (err) { toast(err.message, true); }
    };
  });
}

/* ---------- 考官：AI 变式审核（本地规则变式，非 LLM） ---------- */
async function viewAIVariants(v) {
  let list = [];
  try { list = v2list(await v2get('/api/v2/ai/variants'), ['variants']); }
  catch (e) { v.innerHTML = v2errHtml('AI 变式审核', e); return; }
  v.innerHTML = '<div class="card"><div class="toolbar"><h2 style="flex:1">AI 变式审核</h2><button class="btn" id="btn-ai-gen">生成变式</button></div>' +
    '<p class="muted">本地规则变式（只改可替换槽位，不改考点）：选项顺序 / 题干表述 / 题干数字。变式先进草稿，须人工审核通过后才能发布；简答 / 材料题暂不支持变式。</p>' +
    (list.length ? list.map(x => '<div class="list-row"><div class="grow"><b>' + esc((x.stem || '').slice(0, 80)) + '</b><br>' +
      '<span class="muted">' + esc(x.source || '') + ' · 母题 #' + (x.parent_id || '') + ' · 状态 ' + esc(x.status || '') + (x.parent_stem ? ' · 母题：' + esc(x.parent_stem.slice(0, 40)) : '') + '</span></div>' +
      '<button class="btn small" data-ai-ok="' + x.id + '">通过并发布</button> <button class="btn ghost small" data-ai-no="' + x.id + '">拒绝</button></div>').join('')
      : '<div class="empty">暂无待审核变式</div>') + '</div>' +
    '<div class="card"><h3>易错点提示查询</h3><p class="muted">按题号查全站作答统计与最常见错误答案。</p>' +
    '<div class="toolbar"><input type="number" id="ai-tip-qid" placeholder="题目 ID" style="max-width:160px"><button class="btn ghost" id="btn-ai-tip">查询提示</button></div><div id="ai-tip-out"></div></div>';
  $('#btn-ai-gen').onclick = () => {
    modal('<h2>生成变式</h2><form id="ai-form"><label>母题 ID *</label><input type="number" id="ai-qid" placeholder="已发布的选择 / 判断题 ID">' +
      '<label>生成数量（1–3）</label><input type="number" id="ai-count" value="2" min="1" max="3">' +
      '<div class="row"><button type="button" class="btn ghost" onclick="closeModal()">取消</button><button class="btn" type="submit">生成</button></div></form>');
    $('#ai-form').onsubmit = async e => {
      e.preventDefault();
      try {
        const d = await v2post('/api/v2/ai/variants', { question_id: parseInt($('#ai-qid').value, 10), count: parseInt($('#ai-count').value, 10) || 2 });
        closeModal(); toast('变式已生成进草稿' + (d && d.variant_ids ? '（' + d.variant_ids.length + ' 道），须人工审核' : '，须人工审核')); go('aivariants');
      } catch (err) { toast(err.message, true); }
    };
  };
  $('#btn-ai-tip').onclick = async () => {
    const qid = parseInt($('#ai-tip-qid').value, 10);
    if (!qid) { toast('请填写题目 ID', true); return; }
    try {
      const d = await v2get('/api/v2/ai/tips/' + qid);
      $('#ai-tip-out').innerHTML = '<p>' + esc(d.tip || '暂无提示') + '</p><p class="muted">全站作答 ' + (d.total || 0) + ' 人次 · 正确率 ' + (d.accuracy == null ? '—' : d.accuracy + '%') + '</p>';
    } catch (err) { toast(err.message, true); }
  };
  $$('[data-ai-ok]', v).forEach(b => b.onclick = async () => {
    try { await v2post('/api/v2/ai/variants/' + b.dataset.aiOk + '/approve', {}); toast('变式已通过并发布'); go('aivariants'); }
    catch (err) { toast(err.message, true); }
  });
  $$('[data-ai-no]', v).forEach(b => b.onclick = async () => {
    try { await v2post('/api/v2/ai/variants/' + b.dataset.aiNo + '/reject', {}); toast('变式已拒绝'); go('aivariants'); }
    catch (err) { toast(err.message, true); }
  });
}

/* ---------- 管理员：统计分析仪表盘 ---------- */
async function viewDashboard(v) {
  let overview = null, teams = [], charts = null;
  let ovErr = '', tmErr = '', chErr = '';
  try { overview = v2unwrap(await v2get('/api/v2/dashboard/overview')); } catch (e) { ovErr = e.message; }
  try { const d = await v2get('/api/v2/dashboard/teams'); teams = v2list(d.teams || d, ['teams']); } catch (e) { tmErr = e.message; }
  try { charts = await v2get('/api/v2/dashboard/charts'); } catch (e) { chErr = e.message; }
  const ov = overview && (overview.overview || overview);
  const warnings = (ov && (ov.warnings || ov.alerts)) || [];
  v.innerHTML = '<div class="card"><h2>统计分析仪表盘</h2>' +
    (ov ? '<div class="grid4">' +
      '<div class="stat"><div class="num" data-count="' + (ov.total_users || ov.student_count || 0) + '">0</div><div class="lbl">学员总数</div></div>' +
      '<div class="stat"><div class="num" data-count="' + (ov.total_attempts || ov.practice_total || 0) + '">0</div><div class="lbl">累计作答</div></div>' +
      '<div class="stat"><div class="num" data-count="' + pctNum(ov.avg_accuracy != null ? ov.avg_accuracy : ov.accuracy) + '" data-suffix="%">0</div><div class="lbl">全站正确率</div></div>' +
      '<div class="stat"><div class="num" data-count="' + (ov.pending_reports || ov.pending_review || warnings.length || 0) + '">0</div><div class="lbl">待处理 / 预警</div></div></div>' +
      (warnings.length ? '<h3 style="margin-top:16px">预警</h3>' + warnings.map(w => '<p>· ' + esc(w.detail || w.type || '') + (w.display_name ? '（' + esc(w.display_name) + '）' : '') + '</p>').join('') : '')
    : v2empty('总览暂不可用', ovErr || '接口未就绪')) + '</div>' +
    (charts ? chartsHtml(charts) : v2empty('仪表盘图表暂不可用', chErr || '接口未就绪')) +
    '<div class="card"><h3>部门横向对比（精确汇总）</h3><p class="muted">答对数 = 练习 + 考试 + 模拟考逐题重判后的精确汇总，不是「总作答 × 平均正确率」推算。</p>' +
    (tmErr ? v2empty('部门对比暂不可用', tmErr) :
      teams.length ? '<table><tr><th>部门</th><th>人数</th><th>总作答</th><th>答对</th><th>正确率</th><th>近 14 天参与率</th></tr>' + teams.map(t => {
        const acc = t.avg_accuracy != null ? pctNum(t.avg_accuracy) : (t.total_attempts ? Math.round((t.correct || 0) / t.total_attempts * 1000) / 10 : 0);
        return '<tr><td>' + esc(t.team || t.department || '') + '</td><td>' + (t.member_count || 0) + '</td><td>' + (t.total_attempts || 0) + '</td><td>' + (t.correct != null ? t.correct : '—') + '</td><td>' + acc + '%</td><td>' + (t.participation != null ? Math.round(t.participation * 100) + '%' : '—') + '</td></tr>';
      }).join('') + '</table>' + barChart(teams.map(t => ({ label: (t.team || t.department || '').slice(0, 6), value: t.avg_accuracy != null ? pctNum(t.avg_accuracy) : 0 }))) : '<div class="empty">暂无部门数据</div>') + '</div>';
  animateCounts(v);
}

/* ---------- 学习计划（学员看自己 / 管理员下发） ---------- */
function planCardHtml(p) {
  const pct = p.pct != null ? p.pct : 0;
  return '<div class="card"><div class="list-row"><div class="grow"><b>' + esc(p.title) + '</b> ' +
    (p.overdue ? '<span class="pill red">已逾期</span>' : (p.days_left != null ? '<span class="pill">' + (p.days_left >= 0 ? '剩余 ' + p.days_left + ' 天' : '已到期') + '</span>' : '')) + '<br>' +
    '<span class="muted">' + (p.knowledge ? '知识点：' + esc(p.knowledge) + ' · ' : '') + '目标 ' + (p.target || 0) + ' 题 · 已做 ' + (p.done || 0) + ' 题（去重题数，同一题重复做只算 1 道）' +
    (p.due_date ? ' · 截止 ' + esc(p.due_date) : '') + (p.daily_count ? ' · 每天 ' + p.daily_count + ' 题' : '') + '</span>' +
    '<div class="bar-track"><div class="bar-fill" style="width:' + Math.min(100, pct) + '%"></div></div>' +
    '<span class="muted">进度 ' + pct + '%</span></div></div></div>';
}
async function viewPlansMe(v) {
  let list = [];
  try { list = v2list(await v2get('/api/v2/plans/me'), ['plans']); }
  catch (e) { v.innerHTML = v2errHtml('我的学习计划', e); return; }
  v.innerHTML = '<div class="card"><h2>我的学习计划</h2><p class="muted">进度按去重题数算（同一题重复做只算 1 道）；逾期计划会标红提醒。</p></div>' +
    (list.length ? list.map(planCardHtml).join('') : '<div class="empty">暂无学习计划，请等待考官 / 管理员下发</div>');
}
async function viewPlansAdmin(v) {
  let list = [];
  try { list = v2list(await v2get('/api/v2/plans'), ['plans']); }
  catch (e) { v.innerHTML = v2errHtml('学习计划', e); return; }
  v.innerHTML = '<div class="card"><div class="toolbar"><h2 style="flex:1">学习计划</h2><button class="btn" id="btn-new-plan">下发计划</button></div>' +
    '<p class="muted">可按部门或个人下发；进度按去重题数算。</p>' +
    (list.length ? list.map(p => '<div class="list-row"><div class="grow"><b>' + esc(p.title) + '</b><br>' +
      '<span class="muted">' + esc(p.team || '') + ' · 目标 ' + (p.target_count || 0) + ' 题' + (p.due_date ? ' · 截止 ' + esc(p.due_date) : '') + ' · 已指派 ' + (p.assigned || 0) + ' 人 · 已完成 ' + (p.done_count || 0) + ' 人 · 平均进度 ' + (p.avg_pct || 0) + '%</span></div></div>').join('')
      : '<div class="empty">暂无学习计划</div>') + '</div>';
  $('#btn-new-plan').onclick = () => planForm();
}
function planForm() {
  modal('<h2>下发学习计划</h2><form id="plan-form">' +
    '<label>计划名称 *</label><input type="text" id="plan-title" placeholder="如 11 月基础法规强化">' +
    '<label>范围</label><select id="plan-scope"><option value="team">部门</option><option value="personal">个人</option></select>' +
    '<label>部门（范围选部门时填）</label><input type="text" id="plan-team" placeholder="如 一队">' +
    '<label>用户 ID（范围选个人时填）</label><input type="number" id="plan-uid" placeholder="用户 ID">' +
    '<label>知识点（选填，空为全部）</label><input type="text" id="plan-kn" placeholder="如 出入境法规">' +
    '<label>目标题量 *</label><input type="number" id="plan-target" value="50">' +
    '<label>每天题量（选填）</label><input type="number" id="plan-daily" value="10">' +
    '<label>截止日（YYYY-MM-DD，选填）</label><input type="text" id="plan-due" placeholder="2026-11-30">' +
    '<div class="row"><button type="button" class="btn ghost" onclick="closeModal()">取消</button><button class="btn" type="submit">下发</button></div></form>');
  $('#plan-form').onsubmit = async e => {
    e.preventDefault();
    const body = { title: $('#plan-title').value.trim(), scope: $('#plan-scope').value, team: $('#plan-team').value.trim(), knowledge: $('#plan-kn').value.trim(), target_count: parseInt($('#plan-target').value, 10) || 0, daily_count: parseInt($('#plan-daily').value, 10) || 0, due_date: $('#plan-due').value.trim() };
    const uid = parseInt($('#plan-uid').value, 10);
    if (uid) body.user_id = uid;
    if (!body.title) { toast('请填写计划名称', true); return; }
    if (!body.target_count) { toast('目标题量要是大于 0 的整数', true); return; }
    try {
      const d = await v2post('/api/v2/plans', body);
      closeModal(); toast('计划已下发' + (d && d.assigned != null ? '给 ' + d.assigned + ' 人' : '')); go('plans');
    } catch (err) { toast(err.message, true); }
  };
}

/* ---------- 管理员：联邦共享 ---------- */
async function viewFederation(v) {
  let hosts = [], tokenInfo = null;
  let hErr = '', tErr = '';
  try { hosts = v2list(await v2get('/api/v2/federation/hosts'), ['hosts']); } catch (e) { hErr = e.message; }
  try { tokenInfo = await v2get('/api/v2/federation/token'); } catch (e) { tErr = e.message; }
  v.innerHTML = '<div class="card"><div class="toolbar"><h2 style="flex:1">联邦共享</h2><button class="btn" id="btn-new-host">登记主机</button></div>' +
    '<p class="muted">跨主机题库联邦共享：登记 + 令牌 + SHA-256 包 + 去重 + 审计。拉取时按题号去重，已有题目不重复入库。</p>' +
    (tokenInfo ? '<p>本机联邦令牌：<code>' + esc(tokenInfo.token || '') + '</code><br><span class="muted">局域网地址：' + esc(tokenInfo.lan_url || '') + ' · 对方拉取本机目录时需带上本令牌（?token=…）。</span></p>' : '<p class="muted">本机令牌暂不可用（' + esc(tErr) + '）</p>') +
    (hErr ? v2empty('主机列表加载失败', hErr) :
      hosts.length ? hosts.map(h => '<div class="list-row"><div class="grow"><b>' + esc(h.name || h.host) + '</b> <span class="pill">' + esc(h.status || '') + '</span><br>' +
        '<span class="muted">' + esc(h.host) + ':' + (h.port || '') + ' · 上次同步 ' + esc(h.last_seen || '') + ' · 上次题数 ' + (h.last_count != null ? h.last_count : '—') + (h.last_error ? ' · 错误：' + esc(h.last_error) : '') + '</span></div>' +
        '<button class="btn ghost small" data-host-test="' + h.id + '">连通测试</button>' +
        '<button class="btn ghost small" data-host-pull="' + h.id + '">拉取题库</button>' +
        '<button class="btn danger small" data-host-del="' + h.id + '">删除</button></div>').join('') : '<div class="empty">暂无登记主机</div>') + '</div>' +
    '<div class="card"><h3>对方题库目录</h3><p class="muted">本机目录用本机联邦令牌访问（?token=…，目录接口是机对机接口、不包 data 信封、不认登录态）；对方目录请点主机行的「连通测试」查看。</p><div class="toolbar"><button class="btn ghost" id="btn-catalog">查看本机可共享目录</button></div><div id="fed-catalog"></div></div>';
  $('#btn-new-host').onclick = () => {
    modal('<h2>登记联邦主机</h2><form id="host-form"><label>名称 *</label><input type="text" id="host-name" placeholder="如 兄弟站主机">' +
      '<label>主机地址 *</label><input type="text" id="host-addr" placeholder="如 192.168.1.20">' +
      '<label>端口</label><input type="number" id="host-port" value="8766">' +
      '<div class="row"><button type="button" class="btn ghost" onclick="closeModal()">取消</button><button class="btn" type="submit">登记</button></div></form>');
    $('#host-form').onsubmit = async e => {
      e.preventDefault();
      try { await v2post('/api/v2/federation/hosts', { name: $('#host-name').value.trim(), host: $('#host-addr').value.trim(), port: parseInt($('#host-port').value, 10) || 8766 }); closeModal(); toast('主机已登记'); go('federation'); }
      catch (err) { toast(err.message, true); }
    };
  };
  $('#btn-catalog').onclick = async () => {
    const out = $('#fed-catalog');
    try {
      // 目录接口不包 data 信封、只认联邦令牌：v2unwrap 去掉 ok 键后返回 {catalog}，
      // 这里读顶层 d.catalog；必须带上本机令牌，否则 401。
      const tok = (tokenInfo && tokenInfo.token) || '';
      if (!tok) { out.innerHTML = '<p class="muted">本机联邦令牌暂不可用，无法查看目录。</p>'; return; }
      const d = await v2get('/api/v2/federation/catalog?token=' + encodeURIComponent(tok));
      const c = d.catalog || d;
      out.innerHTML = '<p>可共享：<b>' + esc(c.name || '') + '</b> · 版本 ' + esc(c.version || '') + ' · 题目 ' + (c.question_count || 0) + ' 道<br><span class="muted">科目：' + (c.subjects || []).map(esc).join('、') + '</span></p>';
    } catch (err) { out.innerHTML = '<p class="muted">目录加载失败（' + esc(err.message) + '）。</p>'; }
  };
  $$('[data-host-test]', v).forEach(b => b.onclick = async () => {
    try { const d = await v2post('/api/v2/federation/hosts/' + b.dataset.hostTest + '/test', {}); const cat = d && d.catalog; toast('连通测试通过' + (cat ? '：对方题库 ' + (cat.question_count || 0) + ' 道' : '')); go('federation'); }
    catch (err) { toast(err.message, true); }
  });
  $$('[data-host-pull]', v).forEach(b => b.onclick = async () => {
    if (!await confirmDlg('从该主机拉取题库包吗？按题号去重，已有题目不重复入库，拉取过程记入审计。')) return;
    try { const d = await v2post('/api/v2/federation/pull', { host_id: parseInt(b.dataset.hostPull, 10) }); toast('拉取完成' + (d && d.imported != null ? '，新入库 ' + d.imported + ' 道' : '')); go('federation'); }
    catch (err) { toast(err.message, true); }
  });
  $$('[data-host-del]', v).forEach(b => b.onclick = async () => {
    if (!await confirmDlg('确定删除这台联邦主机登记吗？')) return;
    try { await v2post('/api/v2/federation/hosts/' + b.dataset.hostDel + '/delete', {}); toast('主机已删除'); go('federation'); }
    catch (err) { toast(err.message, true); }
  });
}

/* ---------- 管理员：备份管理 ---------- */
async function viewBackup(v) {
  let status = null, list = [];
  let sErr = '', lErr = '';
  try { const d = await v2get('/api/v2/backup/status'); status = d.backup || d; } catch (e) { sErr = e.message; }
  try { list = v2list(await v2get('/api/v2/backup/list'), ['backups']); } catch (e) { lErr = e.message; }
  const disk = status && status.disk;
  v.innerHTML = '<div class="card"><div class="toolbar"><h2 style="flex:1">备份管理</h2><button class="btn" id="btn-backup">一键备份</button></div>' +
    (status ? '<p>已有备份 <b>' + (status.count || 0) + '</b> 份 · 最近：' + esc(status.last_filename || '—') + '（' + esc(status.last_at || '') + '）· 自动备份 ' + (status.auto ? '开启' : '关闭') + ' · 保留最近 ' + (status.keep || 7) + ' 份' +
      (disk ? '<br>磁盘：共 ' + disk.total_gb + ' GB · 可用 ' + disk.free_gb + ' GB · 已用 ' + disk.used_pct + '%' : '') + '</p>'
      : v2empty('备份状态暂不可用', sErr || '接口未就绪')) +
    (lErr ? v2empty('备份列表加载失败', lErr) :
      list.length ? '<table><tr><th>文件名</th><th>大小</th><th>备注</th><th>创建时间</th><th></th></tr>' + list.map(b => '<tr><td>' + esc(b.filename) + '</td><td>' + (b.size_bytes != null ? Math.round(b.size_bytes / 1024) + ' KB' : '—') + '</td><td>' + esc(b.note || '') + '</td><td>' + esc(b.created_at || '') + '</td>' +
        '<td><a class="btn ghost small" href="/api/v2/backup/download/' + encodeURIComponent(b.filename) + '">下载</a> <button class="btn ghost small" data-restore="' + esc(b.filename) + '">恢复</button></td></tr>').join('') + '</table>' : '<div class="empty">暂无备份</div>') + '</div>';
  $('#btn-backup').onclick = async () => {
    try { const d = await v2post('/api/v2/backup/create', { note: '手动备份' }); toast('备份完成：' + (d && d.filename || '')); go('backup'); }
    catch (err) { toast(err.message, true); }
  };
  $$('[data-restore]', v).forEach(b => b.onclick = async () => {
    if (!await confirmDlg('恢复备份“' + b.dataset.restore + '”吗？恢复前系统会自动再备一份当前库防丢，恢复后当前未备份的数据将被覆盖。')) return;
    try { await v2post('/api/v2/backup/restore', { filename: b.dataset.restore }); toast('已恢复备份，页面即将刷新'); setTimeout(() => location.reload(), 800); }
    catch (err) { toast(err.message, true); }
  });
}

/* ---------- 管理员：题库版本 ---------- */
async function viewBankVersions(v) {
  let list = [];
  try { list = v2list(await v2get('/api/v2/bank/versions'), ['versions']); }
  catch (e) { v.innerHTML = v2errHtml('题库版本', e); return; }
  v.innerHTML = '<div class="card"><div class="toolbar"><h2 style="flex:1">题库版本</h2><button class="btn" id="btn-publish">发布新版本</button></div>' +
    '<p class="muted">导入审核通过、变式审核通过的题目进入当前版本；回滚到指定版本后，之后版本的题目不再出题。</p>' +
    (list.length ? list.map(x => '<div class="list-row"><div class="grow"><b>版本 #' + x.id + '</b> ' + (x.is_current ? '<span class="pill green">当前版本</span>' : '') + '<br>' +
      '<span class="muted">' + esc(x.note || x.name || '') + ' · 题目 ' + (x.question_count || 0) + ' 道 · ' + esc(x.created_at || '') + '</span></div>' +
      (x.is_current ? '' : '<button class="btn ghost small" data-rollback="' + x.id + '">回滚到此版本</button>') + '</div>').join('')
      : '<div class="empty">暂无题库版本</div>') + '</div>';
  $('#btn-publish').onclick = () => {
    modal('<h2>发布新版本</h2><form id="pub-form"><label>版本说明（选填）</label><input type="text" id="pub-note" placeholder="如 11 月新增法规题 30 道">' +
      '<div class="row"><button type="button" class="btn ghost" onclick="closeModal()">取消</button><button class="btn" type="submit">发布</button></div></form>');
    $('#pub-form').onsubmit = async e => {
      e.preventDefault();
      try { await v2post('/api/v2/bank/publish', { note: $('#pub-note').value.trim() }); closeModal(); toast('新版本已发布'); go('bank'); }
      catch (err) { toast(err.message, true); }
    };
  };
  $$('[data-rollback]', v).forEach(b => b.onclick = async () => {
    if (!await confirmDlg('回滚到版本 #' + b.dataset.rollback + ' 吗？之后版本的题目将不再出题。')) return;
    try { await v2post('/api/v2/bank/rollback', { version_id: parseInt(b.dataset.rollback, 10) }); toast('已回滚'); go('bank'); }
    catch (err) { toast(err.message, true); }
  });
}

/* ---------- 空格键推进 ---------- */
document.addEventListener('keydown', e => {
  if (e.code !== 'Space' || e.key !== ' ') return;
  const tag = (e.target.tagName || '').toLowerCase();
  if (tag === 'input' || tag === 'textarea' || tag === 'select' || e.target.isContentEditable) return;
  if (state.practice && $('#view') && state.practice.questions) {
    e.preventDefault();
    if (state.practice.result) nextPractice(); else submitPractice();
    return;
  }
  if (state.mock) { e.preventDefault(); if (state.mock.idx + 1 < state.mock.questions.length) { state.mock.idx++; renderMock(); } return; }
  if (state.exam) { e.preventDefault(); if (state.exam.idx + 1 < state.exam.questions.length) { state.exam.idx++; renderExam(); } }
});

/* ---------- 启动 ---------- */
(async function boot() {
  applyPrefs();
  if (!state.token) { renderLogin(); return; }
  try {
    state.user = await apiGet('/api/me');
    renderApp();
  } catch (e) { renderLogin(); }
})();
