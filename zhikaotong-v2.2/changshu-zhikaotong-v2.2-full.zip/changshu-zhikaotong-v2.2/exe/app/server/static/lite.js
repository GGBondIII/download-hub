/* 常熟站智考通 v2.2 Lite 版 — ES3 兼容（IE8 能跑）
   不用 forEach / addEventListener / querySelectorAll / indexOf / trim / Object.keys */
var ZK = {};
ZK.token = '';
ZK.user = null;
ZK.view = 'home';
ZK.practice = null;
ZK.mock = null;
ZK.exam = null;
ZK.timer = null;
ZK.TYPES = ['单选', '多选', '判断', '填空', '简答'];

function $(id) { return document.getElementById(id); }
function esc(s) {
  s = (s === null || s === undefined) ? '' : String(s);
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
function trim(s) { return String(s).replace(/^\s+|\s+$/g, ''); }
function inArr(arr, v) { var i; for (i = 0; i < arr.length; i++) { if (arr[i] === v) { return true; } } return false; }
function keysOf(obj) { var k, out = []; for (k in obj) { if (obj.hasOwnProperty(k)) { out.push(k); } } return out.sort(); }
function msg(t, isErr) { var m = $('login-msg'); if (m) { m.innerHTML = esc(t); } else { alert(t); } }
function showMsg(t) { var m = $('login-msg'); if (m) { m.innerHTML = esc(t); } }
function fmtTime(sec) {
  sec = sec < 0 ? 0 : Math.floor(sec);
  var h = Math.floor(sec / 3600), m = Math.floor(sec % 3600 / 60), s = sec % 60;
  var mm = (m < 10 ? '0' : '') + m, ss = (s < 10 ? '0' : '') + s;
  return h ? h + ':' + mm + ':' + ss : mm + ':' + ss;
}
function stopTimer() { if (ZK.timer) { clearInterval(ZK.timer); ZK.timer = null; } }

/* ---- AJAX（XMLHttpRequest，IE8 可用） ---- */
function api(method, path, body, ok, fail) {
  var xhr;
  if (window.XMLHttpRequest) { xhr = new XMLHttpRequest(); } else { xhr = new ActiveXObject('Microsoft.XMLHTTP'); }
  xhr.open(method, path, true);
  xhr.setRequestHeader('Content-Type', 'application/json');
  if (ZK.token) { xhr.setRequestHeader('X-Token', ZK.token); }
  xhr.onreadystatechange = function () {
    if (xhr.readyState !== 4) { return; }
    var json = null;
    try { json = JSON.parse(xhr.responseText); } catch (e) { json = null; }
    if (xhr.status === 401) { ZK.token = ''; ZK.user = null; showLogin(); showMsg('登录已过期，请重新登录'); return; }
    if (!json || !json.ok) { if (fail) { fail(json && json.error ? json.error : '请求失败'); } return; }
    if (ok) { ok(json.data); }
  };
  xhr.onerror = function () { if (fail) { fail('无法连接服务器，请检查服务器地址与网络'); } };
  xhr.send(body ? JSON.stringify(body) : null);
}
function apiGet(path, ok, fail) { api('GET', path, null, ok, fail); }
function apiPost(path, body, ok, fail) { api('POST', path, body, ok, fail); }

/* ---- 登录 / 注册 ---- */
function showLogin() {
  $('login-box').style.display = 'block';
  $('main').style.display = 'none';
  apiGet('/api/version', function (d) {
    if (d.latest && d.latest.version !== 'v2.2') {
      var bar = $('update-bar');
      bar.style.display = 'block';
      bar.innerHTML = '发现新版本 ' + esc(d.latest.version) + '：' + esc(d.latest.note || '') + '（请联系管理员获取更新包）';
    }
  }, function () {});
}
function doLogin() {
  var u = trim($('username').value), p = $('password').value;
  if (!u || !p) { showMsg('请填写用户名和密码'); return; }
  apiPost('/api/auth/login', { username: u, password: p }, function (d) {
    ZK.token = d.token; ZK.user = d.user;
    showApp();
  }, function (e) { showMsg(e); });
}
function showRegister() {
  $('login-box').innerHTML =
    '<h1>学员注册</h1><p class="sub">一站式备考</p>' +
    '<form id="reg-form">' +
    '<p><label>姓名 *</label><br><input type="text" id="r-name"></p>' +
    '<p><label>部门 *</label><br><input type="text" id="r-dept"></p>' +
    '<p><label>用户名 *</label><br><input type="text" id="r-user"></p>' +
    '<p><label>密码（至少 6 位）*</label><br><input type="password" id="r-pass"></p>' +
    '<p><label>邀请码（向管理员索取）*</label><br><input type="text" id="r-invite"></p>' +
    '<p><input type="submit" value="注 册" class="btn-big"></p></form>' +
    '<p><a href="#" id="back-login">返回登录</a></p><p class="ver">常熟站智考通 v2.2</p><p id="login-msg" class="msg"></p>';
  $('reg-form').onsubmit = function () {
    var body = { name: trim($('r-name').value), department: trim($('r-dept').value), username: trim($('r-user').value), password: $('r-pass').value, invite_code: trim($('r-invite').value) };
    if (!body.name || !body.department || !body.username) { showMsg('请填写姓名、部门和用户名'); return false; }
    if (body.password.length < 6) { showMsg('密码至少 6 位'); return false; }
    apiPost('/api/auth/register', body, function () { location.reload(); }, function (e) { showMsg(e); });
    return false;
  };
  $('back-login').onclick = function () { location.reload(); return false; };
}
function showApp() {
  $('login-box').style.display = 'none';
  $('main').style.display = 'block';
  $('who').innerHTML = esc(ZK.user.name) + ' · ' + esc(ZK.user.department) + ' · ' + esc(ZK.user.role_name);
  var nav = $('nav'), items, i, html = '';
  if (ZK.user.role === 'admin') { items = [['home', '首页'], ['users', '用户管理'], ['reports', '上报处理'], ['stats', '统计分析'], ['liteplans', '学习计划'], ['versions', '客户端更新发布'], ['settings', '系统设置']]; }
  else if (ZK.user.role === 'examiner') { items = [['home', '首页'], ['exams', '考试管理'], ['questions', '题库管理'], ['settings', '系统设置']]; }
  else { items = [['home', '日常练习'], ['litepractice', '自适应练习'], ['litereport', '我的报告'], ['liteplans', '学习计划'], ['mock', '模拟考试'], ['myexams', '正式考试'], ['settings', '系统设置']]; }
  for (i = 0; i < items.length; i++) { html += '<a href="#" data-view="' + items[i][0] + '">' + items[i][1] + '</a>'; }
  nav.innerHTML = html;
  var links = nav.getElementsByTagName('a');
  for (i = 0; i < links.length; i++) {
    links[i].onclick = function () { go(this.getAttribute('data-view')); return false; };
  }
  go('home');
}
function go(view) {
  ZK.view = view; stopTimer();
  var links = $('nav').getElementsByTagName('a'), i;
  for (i = 0; i < links.length; i++) { links[i].className = (links[i].getAttribute('data-view') === view) ? 'cur' : ''; }
  $('view').innerHTML = '<div class="card">加载中…</div>';
  if (view === 'home') { viewHome(); }
  else if (view === 'mock') { viewMock(); }
  else if (view === 'myexams') { viewMyExams(); }
  else if (view === 'settings') { viewSettings(); }
  else if (view === 'exams') { viewAdminExams(); }
  else if (view === 'questions') { viewQuestions(); }
  else if (view === 'users') { viewUsers(); }
  else if (view === 'reports') { viewAdminReports(); }
  else if (view === 'stats') { viewStats(); }
  else if (view === 'versions') { viewVersions(); }
  else if (view === 'litepractice') { viewLitePractice(); }
  else if (view === 'litereport') { viewLiteReport(); }
  else if (view === 'liteplans') { viewLitePlans(); }
}
function setView(html) { $('view').innerHTML = html; }

/* ---- 首页 ---- */
function viewHome() {
  apiGet('/api/home/stats', function (d) {
    var p = d.practice || { total: 0, correct: 0, accuracy: 0, wrong_count: 0 };
    var u = d.user || ZK.user;
    if (ZK.user.role === 'admin') {
      setView('<div class="card"><h2>你好，' + esc(u.name) + '</h2><p>' + esc(u.department) + ' · 管理员 · 常熟站智考通 v2.2</p><p>请使用上方导航管理用户、上报、统计与客户端版本。</p></div>');
      return;
    }
    if (ZK.user.role === 'examiner') {
      setView('<div class="card"><h2>你好，' + esc(u.name) + '</h2><p>' + esc(u.department) + ' · 考官 · 常熟站智考通 v2.2</p><p>请使用上方导航管理考试与题库。还没有考试时，点击右上角创建。</p></div>');
      return;
    }
    var html = '';
    if (d.ongoing_mock) { html += '<div class="card"><b>有一场进行中的模拟考试，继续作答</b><p><input type="button" value="继续作答" class="btn btn-gold" id="btn-resume-mock"></p></div>'; }
    html += '<div class="card"><h2>你好，' + esc(u.name) + '</h2><p class="muted">' + esc(u.department) + ' · 一站式备考</p>' +
      '<p>已练习题：<b>' + p.total + '</b>　答对题数：<b>' + p.correct + '</b>　正确率：<b>' + (p.accuracy || 0) + '%</b>　错题数：<b>' + p.wrong_count + '</b></p></div>' +
      '<div class="card"><h3>日常练习</h3>' +
      '<p><input type="button" value="顺序刷题" class="btn" data-mode="顺序"> 按题库题号全量顺序，断点续刷</p>' +
      '<p><input type="button" value="随机刷题" class="btn" data-mode="随机"> 全量随机抽题，顺序打乱</p>' +
      '<p><input type="button" value="错题刷题" class="btn" data-mode="错题"> 做对一题自动移出错题本</p>' +
      '<p><input type="button" value="题型练习" class="btn" data-mode="题型"> 选定题型后刷完该题型全部题目</p>' +
      '<p><input type="button" value="自适应练习" class="btn btn-gold" id="btn-lite-adaptive"> 按掌握度动态调权重与难度　<input type="button" value="薄弱项训练" class="btn" id="btn-lite-weak"> 只练薄弱知识点</p></div>' +
      '<div class="card"><p><input type="button" value="我的错题本" class="btn-ghost btn" id="btn-wb"> <input type="button" value="练习统计" class="btn-ghost btn" id="btn-ps"> <input type="button" value="我的上报" class="btn-ghost btn" id="btn-mr"></p><div id="home-sub"></div></div>';
    setView(html);
    if (d.ongoing_mock) { $('btn-resume-mock').onclick = function () { openMock(d.ongoing_mock.id); }; }
    var btns = $('view').getElementsByTagName('input'), i;
    for (i = 0; i < btns.length; i++) {
      if (btns[i].getAttribute('data-mode')) {
        btns[i].onclick = function () { startPractice(this.getAttribute('data-mode')); };
      }
    }
    $('btn-wb').onclick = function () { viewWrongBook($('home-sub')); };
    $('btn-lite-adaptive').onclick = function () { go('litepractice'); };
    $('btn-lite-weak').onclick = function () { liteStartWeak(); };
    $('btn-ps').onclick = function () { viewPracticeStats($('home-sub')); };
    $('btn-mr').onclick = function () { viewMyReports($('home-sub')); };
  }, function (e) { setView('<div class="card">加载失败：' + esc(e) + '</div>'); });
}
function viewWrongBook(el) {
  apiGet('/api/wrongbook', function (items) {
    if (!items.length) { el.innerHTML = '<div class="empty">暂无错题，继续加油</div>'; return; }
    var html = '<p><input type="button" value="重做全部错题" class="btn" id="wb-redo"></p>', i, q;
    for (i = 0; i < items.length; i++) {
      q = items[i];
      html += '<div class="card"><b>' + esc(q.no || '') + ' · ' + esc(q.type) + '</b><p>' + esc(q.stem) + '</p>' +
        '<p class="muted">正确答案：' + esc(q.answer || '') + '　' + (q.analysis ? '解析：' + esc(q.analysis) : '') + '</p>' +
        (q.smart_analysis_text ? '<div class="analysis">' + esc(q.smart_analysis_text) + '</div>' : '') +
        '<p><input type="button" value="移除" class="btn-ghost btn" data-remove="' + q.id + '"></p></div>';
    }
    el.innerHTML = html;
    $('wb-redo').onclick = function () {
      ZK.practice = { mode: '错题', questions: items, idx: 0, correct: 0, wrong: 0, result: null, sel: null, input: '' };
      renderPractice();
    };
    var btns = el.getElementsByTagName('input'), j;
    for (j = 0; j < btns.length; j++) {
      if (btns[j].getAttribute('data-remove')) {
        btns[j].onclick = function () {
          var id = parseInt(this.getAttribute('data-remove'), 10);
          apiPost('/api/wrongbook/remove', { question_id: id }, function () { viewWrongBook(el); }, function (e) { alert(e); });
        };
      }
    }
  }, function (e) { el.innerHTML = '加载失败：' + esc(e); });
}
function viewPracticeStats(el) {
  apiGet('/api/practice/stats', function (s) {
    var html = '<p>做题总数：<b>' + s.total + '</b>　答对：<b>' + s.correct + '</b>　正确率：<b>' + (s.accuracy || 0) + '%</b>　错题：<b>' + s.wrong_count + '</b></p><h3>各题型正确率</h3>';
    var i, t;
    if (s.by_type && s.by_type.length) {
      html += '<table><tr><th>题型</th><th>总数</th><th>答对</th><th>正确率</th></tr>';
      for (i = 0; i < s.by_type.length; i++) { t = s.by_type[i]; html += '<tr><td>' + esc(t.type) + '</td><td>' + t.total + '</td><td>' + t.correct + '</td><td>' + (t.accuracy || 0) + '%</td></tr>'; }
      html += '</table>';
    } else { html += '<p class="muted">暂无数据</p>'; }
    html += '<h3>近期练习趋势（近 14 天）</h3>';
    if (s.trend && s.trend.length) {
      html += '<table><tr><th>日期</th><th>做题数</th><th>答对</th></tr>';
      for (i = 0; i < s.trend.length; i++) { html += '<tr><td>' + esc(s.trend[i].date) + '</td><td>' + s.trend[i].total + '</td><td>' + s.trend[i].correct + '</td></tr>'; }
      html += '</table>';
    } else { html += '<p class="muted">暂无数据</p>'; }
    el.innerHTML = html;
  }, function (e) { el.innerHTML = '加载失败：' + esc(e); });
}
function viewMyReports(el) {
  apiGet('/api/reports/mine', function (items) {
    if (!items.length) { el.innerHTML = '<div class="empty">暂无上报记录</div>'; return; }
    var html = '', i, r;
    for (i = 0; i < items.length; i++) {
      r = items[i];
      html += '<div class="card"><b>' + esc(r.type) + '</b> [' + esc(r.status) + ']<p>' + esc(r.question ? r.question.stem : '') + '</p><p class="muted">' + esc(r.detail || '') + ' · ' + esc(r.created_at || '') + '</p>' + (r.reply ? '<p>管理员回复：' + esc(r.reply) + '</p>' : '') + '</div>';
    }
    el.innerHTML = html;
  }, function (e) { el.innerHTML = '加载失败：' + esc(e); });
}

/* ---- 练习 ---- */
function startPractice(mode) {
  apiGet('/api/questions/categories', function (cats) {
    var catHtml = '<option value="">全部分类</option>', i;
    for (i = 0; i < cats.length; i++) { catHtml += '<option>' + esc(cats[i]) + '</option>'; }
    var typeHtml = '', t;
    for (i = 0; i < ZK.TYPES.length; i++) { t = ZK.TYPES[i]; typeHtml += '<option>' + t + '</option>'; }
    var html = '<div class="card"><h2>' + esc(mode) + '刷题</h2>' +
      '<p><label>分类</label><br><select id="pr-cat">' + catHtml + '</select></p>';
    if (mode === '题型') {
      html += '<p><label>题型</label><br><select id="pr-type">' + typeHtml + '</select></p>' +
        '<p><label>顺序</label><br><select id="pr-order"><option value="">顺序</option><option value="rand">随机</option></select></p>';
    }
    if (mode !== '题型' && mode !== '错题') {
      html += '<p><label>题数（留空为全部，也可直接输入自定义数量）</label><br><input type="number" id="pr-count"></p>';
    }
    html += '<p><input type="button" value="开始练习" class="btn" id="pr-go"> <input type="button" value="返回" class="btn-ghost btn" id="pr-back"></p></div>';
    setView(html);
    $('pr-back').onclick = function () { go('home'); };
    $('pr-go').onclick = function () {
      var qs = 'mode=' + encodeURIComponent(mode);
      var cat = $('pr-cat').value; if (cat) { qs += '&category=' + encodeURIComponent(cat); }
      if (mode === '题型') { qs += '&type=' + encodeURIComponent($('pr-type').value); if ($('pr-order').value === 'rand') { qs += '&seed=' + (new Date().getTime() % 100000); } }
      else if (mode !== '错题') { var c = $('pr-count').value; if (c) { qs += '&count=' + encodeURIComponent(c); } }
      if (mode === '随机') { qs += '&seed=' + (new Date().getTime() % 100000); }
      apiGet('/api/practice/list?' + qs, function (data) {
        if (!data.questions.length) { alert(mode === '错题' ? '暂无错题，继续加油' : '该条件下暂无题目'); return; }
        ZK.practice = { mode: mode, questions: data.questions, idx: 0, correct: 0, wrong: 0, result: null, sel: null, input: '' };
        renderPractice();
      }, function (e) { alert(e); });
    };
  }, function (e) { alert(e); });
}
function renderPractice() {
  var p = ZK.practice, q = p.questions[p.idx], total = p.questions.length;
  var res = p.result, sel = p.sel, i, L, cls, mark, body = '';
  if (q.type === '填空') {
    body = '<input type="text" id="fill-in" value="' + esc(p.input || '') + '"' + (res ? ' disabled' : '') + '>';
  } else if (q.type === '简答') {
    body = '<textarea id="fill-in" rows="4"' + (res ? ' disabled' : '') + '>' + esc(p.input || '') + '</textarea>';
  } else {
    var letters = keysOf(q.options || {});
    for (i = 0; i < letters.length; i++) {
      L = letters[i];
      cls = 'opt'; mark = '';
      if (q.type === '多选') { cls += ''; if (sel && inArr(sel, L)) { mark = '✓'; } }
      else if (sel === L) { mark = '●'; }
      if (res) {
        var ans = res.correct_answer || '';
        if (ans.indexOf(L) >= 0) { cls += ' opt-right'; mark = '✓'; }
        else if (q.type === '多选' ? (sel && inArr(sel, L)) : sel === L) { cls += ' opt-wrong'; mark = '✕'; }
      } else if (q.type === '多选' ? (sel && inArr(sel, L)) : sel === L) { cls += ' opt-sel'; }
      body += '<input type="button" class="' + cls + '" data-letter="' + L + '" value="' + esc(L + '. ' + q.options[L]) + '"' + (res ? ' disabled' : '') + '>';
    }
  }
  var html = '<div class="card"><p><span class="pill">' + esc(p.mode) + '</span><span class="pill">' + esc(q.type) + '</span> 第 ' + (p.idx + 1) + ' / ' + total + ' 题 · ' + esc(q.no || '') + '　已答对 ' + p.correct + ' · 答错 ' + p.wrong + '</p>' +
    '<h2 style="font-size:22px">' + esc(q.stem) + '</h2>' +
    (q.image ? '<p><a href="/assets/' + esc(q.image) + '" target="_blank">查看题图（点击放大）</a></p>' : '') +
    body;
  if (res) {
    html += '<div style="border-top:1px solid #999;margin-top:12px;padding-top:12px">' +
      '<p><b>' + (res.correct === true ? '✓ 答对了' : res.correct === false ? '✕ 答错了' : '请自评') + '</b></p>' +
      '<p>正确答案：<b>' + esc(res.correct_answer || '') + '</b></p>' +
      (res.analysis ? '<p>解析：' + esc(res.analysis) + '</p>' : '');
    if (q.type === '简答' && res.correct === null) {
      html += '<p><input type="button" value="我做对了" class="btn" id="sg-right"> <input type="button" value="我做错了" class="btn-ghost btn" id="sg-wrong"></p>';
    }
    if (res.correct === false && res.smart_analysis_text) {
      html += '<div class="analysis"><b>本地智能分析</b><p>' + esc(res.smart_analysis_text) + '</p></div>';
    }
    if (res.correct === false) { html += '<p class="muted">答错的题目已自动加入错题本，可在错题本中复习并查看智能分析。</p>'; }
    html += '</div>';
  }
  html += '<p><input type="button" value="上一题" class="btn-ghost btn" id="btn-prev"> <input type="button" value="下一题" class="btn-ghost btn" id="btn-next"> 跳转到 <input type="text" id="jump-to" style="width:60px"> 题 <input type="button" value="跳转" class="btn-ghost btn" id="btn-jump"> ' +
    (res ? '' : '<input type="button" value="提交答案" class="btn" id="btn-submit">') +
    ' <input type="button" value="结束练习" class="btn-gold btn" id="btn-end"> <input type="button" value="上报题目问题" class="btn-ghost btn" id="btn-report"></p>' +
    '<p class="muted">按 空格键 推进：未提交时提交答案，已提交时下一题。</p></div>';
  setView(html);
  if (!res) {
    var opts = $('view').getElementsByTagName('input'), j;
    for (j = 0; j < opts.length; j++) {
      if (opts[j].getAttribute('data-letter')) {
        opts[j].onclick = function () {
          var letter = this.getAttribute('data-letter');
          if (q.type === '多选') {
            p.sel = p.sel || [];
            if (inArr(p.sel, letter)) { var arr = [], k; for (k = 0; k < p.sel.length; k++) { if (p.sel[k] !== letter) { arr.push(p.sel[k]); } } p.sel = arr; }
            else { p.sel.push(letter); }
          } else { p.sel = letter; }
          renderPractice();
        };
      }
    }
  }
  var sb = $('btn-submit'); if (sb) { sb.onclick = function () { submitPractice(false); }; }
  $('btn-prev').onclick = function () { if (p.idx > 0) { p.idx--; p.result = null; p.sel = null; p.input = ''; renderPractice(); } };
  $('btn-next').onclick = function () { nextPractice(); };
  $('btn-jump').onclick = function () {
    var n = parseInt($('jump-to').value, 10);
    if (n >= 1 && n <= total) { p.idx = n - 1; p.result = null; p.sel = null; p.input = ''; renderPractice(); }
    else { alert('请输入 1 到 ' + total + ' 之间的题号'); }
  };
  $('btn-end').onclick = function () { if (confirm('结束本次练习吗？')) { endPractice(); } };
  $('btn-report').onclick = function () { reportDialog(q.id); };
  var sr = $('sg-right'), sw = $('sg-wrong');
  if (sr) { sr.onclick = function () { submitPractice(true); }; }
  if (sw) { sw.onclick = function () { submitPractice(false, true); }; }
}
function submitPractice(selfRight, selfWrong) {
  var p = ZK.practice, q = p.questions[p.idx], ans = '';
  if (q.type === '填空' || q.type === '简答') { ans = trim($('fill-in') ? $('fill-in').value : ''); p.input = ans; }
  else if (q.type === '多选') { ans = (p.sel || []).slice().sort().join(''); }
  else { ans = p.sel || ''; }
  var body = { question_id: q.id, mode: p.mode, user_answer: ans };
  if (q.type === '简答') {
    if (selfRight) { body.self_correct = true; }
    else if (selfWrong) { body.self_correct = false; }
    else { body.self_correct = null; }
  }
  apiPost('/api/practice/answer', body, function (res) {
    p.result = res;
    if (res.correct === true) { p.correct++; } else if (res.correct === false) { p.wrong++; }
    renderPractice();
  }, function (e) { alert(e); });
}
function nextPractice() {
  var p = ZK.practice;
  if (p.idx + 1 >= p.questions.length) { endPractice(); return; }
  p.idx++; p.result = null; p.sel = null; p.input = ''; renderPractice();
}
function endPractice() {
  var p = ZK.practice;
  setView('<div class="card" style="text-align:center"><h2>练习完成</h2>' +
    '<p>答对 <b>' + p.correct + '</b> 题，答错 <b>' + p.wrong + '</b> 题（共 ' + p.questions.length + ' 题）</p>' +
    '<p class="muted">答错的题目已自动加入错题本，可在错题本中复习并查看智能分析。</p>' +
    '<p><input type="button" value="再练一组" class="btn" id="btn-again"> <input type="button" value="返回首页" class="btn-ghost btn" id="btn-home"></p></div>');
  $('btn-again').onclick = function () { startPractice(p.mode); };
  $('btn-home').onclick = function () { go('home'); };
}
function reportDialog(questionId) {
  var html = '<div class="card"><h2>上报题目问题</h2>' +
    '<p><label>问题类型</label><br><select id="rep-type"><option>题干有歧义</option><option>答案有误</option><option>解析有误</option><option>其他问题</option></select></p>' +
    '<p><label>补充说明（选填）</label><br><textarea id="rep-detail" rows="3"></textarea></p>' +
    '<p><input type="button" value="提交上报" class="btn" id="rep-go"> <input type="button" value="返回练习" class="btn-ghost btn" id="rep-back"></p></div>';
  var old = $('view').innerHTML;
  setView(html);
  $('rep-back').onclick = function () { renderPractice(); };
  $('rep-go').onclick = function () {
    apiPost('/api/reports', { question_id: questionId, type: $('rep-type').value, detail: $('rep-detail').value }, function () { alert('上报成功，感谢反馈'); renderPractice(); }, function (e) { alert(e); });
  };
}

/* ---- 模拟考试 ---- */
function viewMock() {
  apiGet('/api/questions/categories', function (cats) {
    apiGet('/api/mock/current', function (cur) {
      apiGet('/api/mock/history', function (hist) {
        var catHtml = '<option value="">全部分类</option>', i;
        for (i = 0; i < cats.length; i++) { catHtml += '<option>' + esc(cats[i]) + '</option>'; }
        var html = '';
        if (cur) { html += '<div class="card"><b>有一场进行中的模拟考试，继续作答</b><p><input type="button" value="继续作答" class="btn btn-gold" id="btn-resume"></p></div>'; }
        html += '<div class="card"><h2>模拟考试</h2><p class="muted">按题型选数量、分类、时长，服务端随机组卷；开始后立即计时，中途退出可恢复。</p>' +
          '<p><label>分类（可选）</label><br><select id="mk-cat">' + catHtml + '</select></p>';
        for (i = 0; i < ZK.TYPES.length; i++) {
          var t = ZK.TYPES[i];
          var def = t === '单选' ? 5 : t === '判断' ? 3 : t === '多选' ? 2 : 0;
          html += '<p><label>' + t + '数量</label><br><input type="number" id="mk-' + t + '" value="' + def + '"></p>';
        }
        html += '<p><label>时长（分钟）</label><br><input type="number" id="mk-dur" value="30"></p>' +
          '<p><input type="button" value="开始模拟考试" class="btn" id="mk-go"></p></div>' +
          '<div class="card"><h3>历史成绩</h3>';
        if (hist.length) {
          html += '<table><tr><th>考试</th><th>得分</th><th>题数</th><th>交卷时间</th><th></th></tr>';
          for (i = 0; i < hist.length; i++) {
            html += '<tr><td>' + esc(hist[i].config && hist[i].config.category ? hist[i].config.category : '模拟考试') + '</td><td>' + (hist[i].score === null ? '—' : hist[i].score) + '</td><td>' + hist[i].question_count + '</td><td>' + esc(hist[i].submitted_at || '') + '</td><td><input type="button" value="查看解析" class="btn-ghost btn" data-hist="' + hist[i].id + '"></td></tr>';
          }
          html += '</table>';
        } else { html += '<div class="empty">暂无模拟考试记录，完成一次模拟考试后会显示在这里</div>'; }
        html += '</div>';
        setView(html);
        if (cur) { $('btn-resume').onclick = function () { openMock(cur.id); }; }
        var btns = $('view').getElementsByTagName('input'), j;
        for (j = 0; j < btns.length; j++) {
          if (btns[j].getAttribute('data-hist')) {
            btns[j].onclick = function () { viewMockDetail(parseInt(this.getAttribute('data-hist'), 10)); };
          }
        }
        $('mk-go').onclick = function () {
          var counts = {}, allZero = true, k;
          for (k = 0; k < ZK.TYPES.length; k++) { counts[ZK.TYPES[k]] = parseInt($('mk-' + ZK.TYPES[k]).value, 10) || 0; if (counts[ZK.TYPES[k]] > 0) { allZero = false; } }
          if (allZero) { alert('请至少设置一种题型的数量'); return; }
          if (!confirm('确定开始模拟考试吗？点击后立即计时。')) { return; }
          apiPost('/api/mock', { counts: counts, category: $('mk-cat').value, duration_min: parseInt($('mk-dur').value, 10) || 30 }, function (data) {
            ZK.mock = { id: data.attempt_id, questions: data.question_detail, answers: {}, idx: 0, config: data.config, startedAt: data.started_at, duration: (data.config.duration_min || 30) * 60 };
            renderMock();
          }, function (e) { alert(e); });
        };
      }, function (e) { setView('加载失败：' + esc(e)); });
    }, function () {});
  }, function (e) { setView('加载失败：' + esc(e)); });
}
function openMock(id) {
  apiGet('/api/mock/' + id, function (data) {
    var elapsed = 0;
    if (data.started_at) { elapsed = Math.floor((new Date().getTime() - new Date(data.started_at.replace(' ', 'T')).getTime()) / 1000); }
    ZK.mock = { id: data.id, questions: data.question_detail, answers: data.answers || {}, idx: 0, config: data.config, startedAt: data.started_at, duration: (data.config.duration_min || 30) * 60, elapsed: elapsed };
    renderMock();
  }, function (e) { alert(e); });
}
function renderMock() {
  var m = ZK.mock, q = m.questions[m.idx], total = m.questions.length;
  var ans = (m.answers[q.id] || {}).a || '', i, L, body = '';
  if (q.type === '填空' || q.type === '简答') {
    body = q.type === '填空' ? '<input type="text" id="mk-in" value="' + esc(ans) + '">' : '<textarea id="mk-in" rows="4">' + esc(ans) + '</textarea>';
  } else {
    var letters = keysOf(q.options || {});
    for (i = 0; i < letters.length; i++) {
      L = letters[i];
      var sel = q.type === '多选' ? ans.indexOf(L) >= 0 : ans === L;
      body += '<input type="button" class="opt' + (sel ? ' opt-sel' : '') + '" data-letter="' + L + '" value="' + esc(L + '. ' + q.options[L]) + '">';
    }
  }
  var answered = 0, k;
  for (k = 0; k < m.questions.length; k++) { var a = (m.answers[m.questions[k].id] || {}).a; if (a) { answered++; } }
  var grid = '<p><b>答题卡</b></p><p>';
  for (i = 0; i < total; i++) {
    var done = (m.answers[m.questions[i].id] || {}).a ? ' style="background:#24425F;color:#fff"' : '';
    grid += '<input type="button" value="' + (i + 1) + '" data-idx="' + i + '"' + done + '>';
  }
  grid += '</p>';
  setView('<div class="card"><p><span class="pill">模拟考试</span><span class="pill">' + esc(q.type) + '</span> 第 ' + (m.idx + 1) + ' / ' + total + ' 题　<span class="timer" id="mk-timer"></span></p>' +
    '<h2 style="font-size:22px">' + esc(q.stem) + '</h2>' +
    (q.image ? '<p><a href="/assets/' + esc(q.image) + '" target="_blank">查看题图（点击放大）</a></p>' : '') +
    body +
    '<p><input type="button" value="上一题" class="btn-ghost btn" id="mk-prev"> <input type="button" value="下一题" class="btn-ghost btn" id="mk-next"> 已作答 ' + answered + ' / ' + total + ' <input type="button" value="交卷" class="btn-gold btn" id="mk-submit"></p>' +
    '<p class="muted">按 空格键 到下一题；答案实时保存，断线重连后可继续作答。</p>' + grid + '</div>');
  var save = function (val) { apiPost('/api/mock/' + m.id + '/answer', { question_id: q.id, answer: val }, function () {}, function () { alert('保存失败，请检查网络'); }); };
  var opts = $('view').getElementsByTagName('input'), j;
  for (j = 0; j < opts.length; j++) {
    if (opts[j].getAttribute('data-letter')) {
      opts[j].onclick = function () {
        var letter = this.getAttribute('data-letter');
        if (q.type === '多选') {
          var cur = (m.answers[q.id] || {}).a || '';
          m.answers[q.id] = { a: cur.indexOf(letter) >= 0 ? cur.replace(letter, '') : (cur + letter).split('').sort().join(''), s: null };
        } else { m.answers[q.id] = { a: letter, s: null }; save(letter); }
        renderMock();
      };
    } else if (opts[j].getAttribute('data-idx')) {
      opts[j].onclick = function () { m.idx = parseInt(this.getAttribute('data-idx'), 10); renderMock(); };
    }
  }
  var fi = $('mk-in');
  if (fi) { fi.onchange = function () { m.answers[q.id] = { a: fi.value, s: null }; save(fi.value); }; }
  $('mk-prev').onclick = function () { if (m.idx > 0) { m.idx--; renderMock(); } };
  $('mk-next').onclick = function () { if (m.idx + 1 < total) { m.idx++; renderMock(); } };
  $('mk-submit').onclick = function () { submitMock(false); };
  startTimer('mk-timer', m, function () { submitMock(true); });
}
function submitMock(auto) {
  var m = ZK.mock, unanswered = 0, i;
  for (i = 0; i < m.questions.length; i++) { if (!(m.answers[m.questions[i].id] || {}).a) { unanswered++; } }
  if (!auto && unanswered > 0 && !confirm('还有 ' + unanswered + ' 题未作答，确定交卷吗？')) { return; }
  if (auto) { alert('时间到，系统自动交卷'); }
  stopTimer();
  apiPost('/api/mock/' + m.id + '/submit', {}, function (res) {
    ZK.mock = null;
    viewResult({ kind: 'mock', id: m.id, score: res.score, full: res.full_score, accuracy: res.accuracy, pending: res.pending_self_grade, results: res.results });
  }, function (e) { alert(e); renderMock(); });
}
function viewMockDetail(id) {
  apiGet('/api/mock/' + id + '/detail', function (d) {
    viewResult({ kind: 'mock', id: id, score: d.score, full: d.full_score, accuracy: null, pending: d.pending_self_grade, results: d.results });
  }, function (e) { alert(e); });
}

/* ---- 正式考试 ---- */
function viewMyExams() {
  apiGet('/api/exams/mine', function (list) {
    if (!list.length) { setView('<div class="card empty">暂无可参加的考试，请等待考官发布</div>'); return; }
    var html = '', i, e, at, status;
    for (i = 0; i < list.length; i++) {
      e = list[i]; at = e.attempt;
      status = at ? (at.status === '已交卷' || at.status === '迟交' ? '已交卷' : '进行中') : (e.status === '已发布' ? '未开始' : e.status);
      html += '<div class="card"><b>' + esc(e.name) + '</b> [' + esc(status) + ']<p class="muted">' + esc(e.subject) + ' · 时长 ' + e.duration_min + ' 分钟 · ' + (e.mode === 'fixed' ? '全员同一份卷' : '每人随机抽题') + (at && at.score !== null && at.score !== undefined ? ' · 得分 ' + at.score : '') + '</p>' +
        (at && (at.status === '已交卷' || at.status === '迟交')
          ? '<p><input type="button" value="查看成绩" class="btn" data-result="' + e.id + '"></p>'
          : '<p><input type="button" value="' + (at ? '继续考试' : '开始考试') + '" class="btn btn-gold" data-start="' + e.id + '"></p>') + '</div>';
    }
    setView(html);
    var btns = $('view').getElementsByTagName('input'), j;
    for (j = 0; j < btns.length; j++) {
      if (btns[j].getAttribute('data-start')) {
        btns[j].onclick = function () {
          var id = this.getAttribute('data-start');
          if (!confirm('进入考试后将开始计时，确定开始吗？')) { return; }
          apiPost('/api/exams/' + id + '/start', {}, function (data) {
            var elapsed = 0;
            if (data.started_at) { elapsed = Math.floor((new Date().getTime() - new Date(data.started_at.replace(' ', 'T')).getTime()) / 1000); }
            ZK.exam = { id: data.exam.id, exam: data.exam, questions: data.question_detail, answers: data.answers || {}, idx: 0, duration: (data.exam.duration_min || 60) * 60, elapsed: elapsed };
            renderExam();
          }, function (e) { alert(e); });
        };
      } else if (btns[j].getAttribute('data-result')) {
        btns[j].onclick = function () { viewExamResult(parseInt(this.getAttribute('data-result'), 10)); };
      }
    }
  }, function (e) { setView('加载失败：' + esc(e)); });
}
function renderExam() {
  var m = ZK.exam, q = m.questions[m.idx], total = m.questions.length;
  var ans = (m.answers[q.id] || {}).a || '', i, L, body = '';
  if (q.type === '填空' || q.type === '简答') {
    body = q.type === '填空' ? '<input type="text" id="ex-in" value="' + esc(ans) + '">' : '<textarea id="ex-in" rows="4">' + esc(ans) + '</textarea>';
  } else {
    var letters = keysOf(q.options || {});
    for (i = 0; i < letters.length; i++) {
      L = letters[i];
      var sel = q.type === '多选' ? ans.indexOf(L) >= 0 : ans === L;
      body += '<input type="button" class="opt' + (sel ? ' opt-sel' : '') + '" data-letter="' + L + '" value="' + esc(L + '. ' + q.options[L]) + '">';
    }
  }
  var answered = 0, k;
  for (k = 0; k < m.questions.length; k++) { if ((m.answers[m.questions[k].id] || {}).a) { answered++; } }
  var grid = '<p><b>答题卡</b></p><p>';
  for (i = 0; i < total; i++) {
    var done = (m.answers[m.questions[i].id] || {}).a ? ' style="background:#24425F;color:#fff"' : '';
    grid += '<input type="button" value="' + (i + 1) + '" data-idx="' + i + '"' + done + '>';
  }
  grid += '</p>';
  setView('<div class="card"><p><span class="pill">' + esc(m.exam.name) + '</span><span class="pill">' + esc(q.type) + '</span> 第 ' + (m.idx + 1) + ' / ' + total + ' 题　<span class="timer" id="ex-timer"></span> <span class="muted" id="save-state">已自动保存</span></p>' +
    '<h2 style="font-size:22px">' + esc(q.stem) + '</h2>' +
    (q.image ? '<p><a href="/assets/' + esc(q.image) + '" target="_blank">查看题图（点击放大）</a></p>' : '') +
    body +
    '<p><input type="button" value="上一题" class="btn-ghost btn" id="ex-prev"> <input type="button" value="下一题" class="btn-ghost btn" id="ex-next"> 已作答 ' + answered + ' / ' + total + ' <input type="button" value="交卷" class="btn-gold btn" id="ex-submit"></p>' +
    '<p class="muted">按 空格键 到下一题；答案自动保存。</p>' + grid + '</div>');
  var save = function (val) {
    apiPost('/api/exams/' + m.id + '/answer', { question_id: q.id, answer: val }, function () { var s = $('save-state'); if (s) { s.innerHTML = '已自动保存'; } }, function () { var s = $('save-state'); if (s) { s.innerHTML = '保存失败，请检查网络'; } });
  };
  var opts = $('view').getElementsByTagName('input'), j;
  for (j = 0; j < opts.length; j++) {
    if (opts[j].getAttribute('data-letter')) {
      opts[j].onclick = function () {
        var letter = this.getAttribute('data-letter');
        if (q.type === '多选') {
          var cur = (m.answers[q.id] || {}).a || '';
          m.answers[q.id] = { a: cur.indexOf(letter) >= 0 ? cur.replace(letter, '') : (cur + letter).split('').sort().join(''), s: null };
          save(m.answers[q.id].a);
        } else { m.answers[q.id] = { a: letter, s: null }; save(letter); }
        renderExam();
      };
    } else if (opts[j].getAttribute('data-idx')) {
      opts[j].onclick = function () { m.idx = parseInt(this.getAttribute('data-idx'), 10); renderExam(); };
    }
  }
  var fi = $('ex-in');
  if (fi) { fi.onchange = function () { m.answers[q.id] = { a: fi.value, s: null }; save(fi.value); }; }
  $('ex-prev').onclick = function () { if (m.idx > 0) { m.idx--; renderExam(); } };
  $('ex-next').onclick = function () { if (m.idx + 1 < total) { m.idx++; renderExam(); } };
  $('ex-submit').onclick = function () { submitExam(false); };
  startTimer('ex-timer', m, function () { submitExam(true); });
}
function submitExam(auto) {
  var m = ZK.exam, unanswered = 0, i;
  for (i = 0; i < m.questions.length; i++) { if (!(m.answers[m.questions[i].id] || {}).a) { unanswered++; } }
  if (!auto && !confirm('交卷后将立即判分，不能再修改' + (unanswered ? '，还有 ' + unanswered + ' 题未作答' : '') + '，确定交卷吗？')) { return; }
  if (auto) { alert('时间到，系统按已保存答案自动交卷（迟交）'); }
  stopTimer();
  apiPost('/api/exams/' + m.id + '/submit', { late: !!auto }, function (res) {
    ZK.exam = null;
    viewResult({ kind: 'exam', id: m.id, score: res.score, full: res.full_score, accuracy: null, pending: res.pending_self_grade, results: res.results, status: res.status });
  }, function (e) { alert(e); renderExam(); });
}
function viewExamResult(examId) {
  apiGet('/api/exams/' + examId + '/result', function (d) {
    viewResult({ kind: 'exam', id: examId, score: d.score, full: d.full_score, accuracy: null, pending: d.pending_self_grade, results: d.results, status: d.status });
  }, function (e) { alert(e); });
}

/* ---- 成绩与逐题解析 ---- */
function viewResult(r) {
  var acc = r.accuracy;
  if (acc === null || acc === undefined) {
    var right = 0, total = (r.results || []).length, i;
    for (i = 0; i < total; i++) { if (r.results[i].correct === true) { right++; } }
    acc = total ? Math.round(right / total * 1000) / 10 : 0;
  }
  var html = '<div class="card" style="text-align:center"><h2>考试成绩</h2>' +
    '<p style="font-size:36px;font-weight:bold;color:#24425F">' + (r.score === null ? '—' : r.score) + ' / ' + r.full + '</p>' +
    '<p class="muted">正确率 ' + acc + '%' + (r.status ? ' · ' + esc(r.status) : '') + '</p>' +
    ((r.pending && r.pending.length) ? '<p><b>以下填空 / 简答题需自评：</b>对照参考答案自评后计入总分。</p>' : '') +
    '<p><input type="button" value="只看错题" class="btn" id="res-wrong"> <input type="button" value="查看全部" class="btn-ghost btn" id="res-all"> <input type="button" value="返回" class="btn-ghost btn" id="res-back"></p></div>' +
    '<div id="res-list"></div>';
  setView(html);
  var renderList = function (onlyWrong) {
    var list = [], x, j;
    for (j = 0; j < (r.results || []).length; j++) { x = r.results[j]; if (!onlyWrong || x.correct === false) { list.push(x); } }
    if (!list.length) { $('res-list').innerHTML = onlyWrong ? '<div class="card empty">全部答对，没有错题</div>' : '<div class="card empty">暂无解析</div>'; return; }
    var out = '', q, L, letters, pend;
    for (j = 0; j < list.length; j++) {
      x = list[j];
      pend = r.pending && inArr(r.pending, x.question_id);
      out += '<div class="card"><p><span class="pill">' + esc(x.type) + '</span> [' + (x.correct === true ? '答对' : x.correct === false ? '答错' : '待自评') + '] ' + esc(x.no || '') + ' · 得分 ' + x.score + ' / ' + x.full_score + '</p>' +
        '<p>' + esc(x.stem) + '</p>';
      if (x.options) {
        letters = keysOf(x.options);
        for (var k = 0; k < letters.length; k++) { L = letters[k]; out += '<p>' + esc(L) + '. ' + esc(x.options[L]) + '</p>'; }
      }
      out += '<p>你的答案：<b>' + esc(x.user_answer || '未作答') + '</b></p>' +
        '<p>正确答案：<b>' + esc(x.correct_answer || '') + '</b></p>' +
        (x.analysis ? '<p>解析：' + esc(x.analysis) + '</p>' : '');
      if (pend) { out += '<p><input type="button" value="我答对了" class="btn" data-sg="' + x.question_id + '" data-ok="1"> <input type="button" value="我答错了" class="btn-ghost btn" data-sg="' + x.question_id + '" data-ok="0"></p>'; }
      out += '</div>';
    }
    $('res-list').innerHTML = out;
    var btns = $('res-list').getElementsByTagName('input'), b;
    for (b = 0; b < btns.length; b++) {
      if (btns[b].getAttribute('data-sg')) {
        btns[b].onclick = function () {
          var qid = parseInt(this.getAttribute('data-sg'), 10), ok = this.getAttribute('data-ok') === '1';
          var path = r.kind === 'mock' ? '/api/mock/' + r.id + '/selfgrade' : '/api/exams/' + r.id + '/selfgrade';
          apiPost(path, { question_id: qid, correct: ok }, function () {
            alert('自评已计入总分');
            var np = [], n;
            for (n = 0; n < r.pending.length; n++) { if (r.pending[n] !== qid) { np.push(r.pending[n]); } }
            r.pending = np;
            renderList(onlyWrong);
          }, function (e) { alert(e); });
        };
      }
    }
  };
  renderList(false);
  $('res-wrong').onclick = function () { renderList(true); };
  $('res-all').onclick = function () { renderList(false); };
  $('res-back').onclick = function () { go(r.kind === 'mock' ? 'mock' : 'myexams'); };
}

/* ---- 倒计时 ---- */
function startTimer(elId, sess, onTimeout) {
  stopTimer();
  var el = $(elId);
  if (!el) { return; }
  var remain = sess.duration - (sess.elapsed || 0);
  el.innerHTML = '剩余 ' + fmtTime(remain);
  ZK.timer = setInterval(function () {
    remain--;
    if (remain <= 0) { stopTimer(); el.innerHTML = '00:00'; onTimeout(); return; }
    el.innerHTML = '剩余 ' + fmtTime(remain);
  }, 1000);
}

/* ---- 系统设置 ---- */
function viewSettings() {
  var u = ZK.user;
  apiGet('/api/version', function (ver) {
    var latest = ver.latest;
    var html = '<div class="card"><h2>系统设置</h2>' +
      '<h3>答题偏好</h3><p class="muted">Lite 版不做全屏切换与字号切换（老浏览器能力上限）；偏好请在现代版设置。</p>' +
      '<h3>修改密码</h3>' +
      '<p><label>当前密码</label><br><input type="password" id="pw-old"></p>' +
      '<p><label>新密码（至少 6 位）</label><br><input type="password" id="pw-new"></p>' +
      '<p><label>确认新密码</label><br><input type="password" id="pw-confirm"></p>' +
      '<p><input type="button" value="修改密码" class="btn" id="pw-go"></p>' +
      '<h3>账号与服务器</h3>' +
      '<p>当前用户：' + esc(u.name) + '（' + esc(u.username) + '）<br>部门：' + esc(u.department) + '<br>角色：' + esc(u.role_name) + '<br>软件版本：v2.2</p>';
    if (u.role === 'admin') {
      html += '<p>学员注册邀请码：<b id="invite-code">读取中…</b> <input type="button" value="更换邀请码" class="btn-ghost btn" id="btn-invite"></p>';
    }
    html += '<h3>客户端更新</h3><p class="muted">软件升级由服务器统一发布，无需重新安装；本机启动时自动检查并升级。</p>' +
      '<p>' + (latest ? '服务器最新版本：<b>' + esc(latest.version) + '</b>（' + esc(latest.note || '') + '）' : '已是最新版本') + '</p></div>';
    setView(html);
    $('pw-go').onclick = function () {
      var np = $('pw-new').value, cf = $('pw-confirm').value;
      if (np.length < 6) { alert('新密码至少 6 位'); return; }
      if (np !== cf) { alert('两次输入不一致'); return; }
      apiPost('/api/auth/change-password', { old_password: $('pw-old').value, new_password: np, confirm_password: cf }, function () { alert('密码修改成功，下次登录请使用新密码'); go('settings'); }, function (e) { alert(e); });
    };
    if (u.role === 'admin') {
      apiGet('/api/settings/invite-code', function (d) { $('invite-code').innerHTML = esc(d.invite_code); }, function () {});
      $('btn-invite').onclick = function () {
        var code = prompt('请输入新的学员注册邀请码');
        if (!code) { return; }
        apiPost('/api/settings/invite-code', { invite_code: code }, function (d) { $('invite-code').innerHTML = esc(d.invite_code); alert('邀请码已更换'); }, function (e) { alert(e); });
      };
    }
  }, function () {});
}

/* ---- 考官：考试管理（Lite 简化版） ---- */
function viewAdminExams() {
  apiGet('/api/admin/exams', function (list) {
    var html = '<div class="card"><h2>考试管理</h2>';
    if (!list.length) { html += '<div class="empty">还没有考试，点击右上角创建</div>'; }
    var i, e;
    for (i = 0; i < list.length; i++) {
      e = list[i];
      html += '<div class="card"><b>' + esc(e.name) + '</b> [' + esc(e.status) + ']<p class="muted">' + esc(e.subject) + ' · ' + e.duration_min + ' 分钟 · ' + (e.mode === 'fixed' ? '全员同一份卷' : '每人随机抽题') + ' · 名单 ' + (e.members ? e.members.length : 0) + ' 人</p>' +
        '<p><input type="button" value="成绩" class="btn-ghost btn" data-results="' + e.id + '">' +
        (e.status === '草稿' ? ' <input type="button" value="发布" class="btn" data-pub="' + e.id + '">' : '') +
        (e.status === '已发布' ? ' <input type="button" value="结束" class="btn btn-gold" data-end="' + e.id + '">' : '') +
        ' <input type="button" value="删除" class="btn-danger btn" data-del="' + e.id + '"></p></div>';
    }
    html += '<p><input type="button" value="创建考试" class="btn" id="btn-new-exam"></p></div><div id="exam-sub"></div>';
    setView(html);
    $('btn-new-exam').onclick = function () { examForm(null); };
    var btns = $('view').getElementsByTagName('input'), j;
    for (j = 0; j < btns.length; j++) {
      (function (b) {
        if (b.getAttribute('data-pub')) { b.onclick = function () { apiPost('/api/admin/exams/' + b.getAttribute('data-pub') + '/publish', {}, function () { alert('已发布'); go('exams'); }, function (e) { alert(e); }); }; }
        if (b.getAttribute('data-end')) { b.onclick = function () { apiPost('/api/admin/exams/' + b.getAttribute('data-end') + '/end', {}, function () { alert('已结束'); go('exams'); }, function (e) { alert(e); }); }; }
        if (b.getAttribute('data-del')) {
          b.onclick = function () {
            var id = b.getAttribute('data-del');
            if (!confirm('确定删除这场考试吗？删除后连同名单、试卷、成绩一起清掉，不可恢复。')) { return; }
            api('DELETE', '/api/admin/exams/' + id, null, function () { alert('考试已删除'); go('exams'); }, function (e) { alert(e); });
          };
        }
        if (b.getAttribute('data-results')) { b.onclick = function () { viewExamResultsLite(parseInt(b.getAttribute('data-results'), 10)); }; }
      })(btns[j]);
    }
  }, function (e) { setView('加载失败：' + esc(e)); });
}
function examForm(e) {
  var render = function (students) {
    var list = students || [], i;
    var qc = (e && e.qcounts) || { '单选': 8, '多选': 2, '判断': 0, '填空': 0, '简答': 0 };
    var qs = (e && e.qscores) || { '单选': 5, '多选': 10, '判断': 5, '填空': 5, '简答': 10 };
    var html = '<div class="card"><h2>' + (e ? '编辑考试' : '创建考试') + '</h2>' +
      '<p><label>考试名称</label><br><input type="text" id="ex-name" value="' + esc(e ? e.name : '') + '"></p>' +
      '<p><label>考试科目</label><br><select id="ex-subject"><option>基础法规</option><option>业务技能</option><option>自定义</option></select></p>' +
      '<p><label>时长（分钟）</label><br><input type="number" id="ex-dur" value="' + (e ? e.duration_min : 60) + '"></p>' +
      '<p><label>试卷模式</label><br><select id="ex-mode"><option value="fixed">全员同一份卷</option><option value="random">每人开考时随机抽题</option></select></p>';
    for (i = 0; i < ZK.TYPES.length; i++) {
      var t = ZK.TYPES[i];
      html += '<p><label>' + t + '数量</label><br><input type="number" id="ex-qc-' + t + '" value="' + (qc[t] || 0) + '"> <label>' + t + '每题分</label><br><input type="number" id="ex-qs-' + t + '" value="' + (qs[t] || 0) + '"></p>';
    }
    html += '<h3>考试名单</h3><p><input type="checkbox" id="ex-all"> 全选所有学员</p>';
    for (i = 0; i < list.length; i++) {
      var checked = e && e.members && inArr(e.members, list[i].id) ? ' checked' : '';
      html += '<p><input type="checkbox" class="ex-member" value="' + list[i].id + '"' + checked + '> ' + esc(list[i].name) + '（' + esc(list[i].username) + ' · ' + esc(list[i].department) + '）</p>';
    }
    html += '<p><input type="button" value="' + (e ? '保存' : '创建') + '" class="btn" id="ex-save"> <input type="button" value="返回" class="btn-ghost btn" id="ex-back"></p></div>';
    setView(html);
    $('ex-all').onclick = function () {
      var boxes = document.getElementsByTagName('input'), k;
      for (k = 0; k < boxes.length; k++) { if (boxes[k].className === 'ex-member') { boxes[k].checked = $('ex-all').checked; } }
    };
    $('ex-back').onclick = function () { go('exams'); };
    $('ex-save').onclick = function () {
      var qcounts = {}, qscores = {}, k;
      for (k = 0; k < ZK.TYPES.length; k++) { qcounts[ZK.TYPES[k]] = parseInt($('ex-qc-' + ZK.TYPES[k]).value, 10) || 0; qscores[ZK.TYPES[k]] = parseInt($('ex-qs-' + ZK.TYPES[k]).value, 10) || 0; }
      var members = [], boxes = document.getElementsByTagName('input');
      for (k = 0; k < boxes.length; k++) { if (boxes[k].className === 'ex-member' && boxes[k].checked) { members.push(parseInt(boxes[k].value, 10)); } }
      var body = { name: trim($('ex-name').value), subject: $('ex-subject').value, duration_min: parseInt($('ex-dur').value, 10) || 60, shuffle: false, mode: $('ex-mode').value, qcounts: qcounts, qscores: qscores, start_at: '', end_at: '', members: members };
      if (!body.name) { alert('请填写考试名称'); return; }
      if (e) { api('PUT', '/api/admin/exams/' + e.id, body, function () { alert('考试已更新'); go('exams'); }, function (err) { alert(err); }); }
      else { apiPost('/api/admin/exams', body, function () { alert('考试已创建（草稿）'); go('exams'); }, function (err) { alert(err); }); }
    };
  };
  apiGet('/api/users/students', render, function () { render([]); });
}
function viewExamResultsLite(examId) {
  apiGet('/api/admin/exams/' + examId + '/results', function (d) {
    var html = '<div class="card"><h2>' + esc(d.exam.name) + ' · 成绩</h2>' +
      '<p class="muted">应考 ' + d.total_members + ' 人 · 已交卷 ' + d.submitted + ' 人 · 平均分 ' + (d.average === null ? '—' : d.average) + '</p>' +
      '<p><a class="btn btn-gold" href="/api/admin/exams/' + examId + '/results.csv">导出 CSV</a> <input type="button" value="返回考试管理" class="btn-ghost btn" id="back-exams"></p>' +
      '<table><tr><th>姓名</th><th>用户名</th><th>部门</th><th>状态</th><th>交卷时间</th><th>得分</th></tr>';
    var i, r;
    for (i = 0; i < d.list.length; i++) { r = d.list[i]; html += '<tr><td>' + esc(r.name) + '</td><td>' + esc(r.username) + '</td><td>' + esc(r.department) + '</td><td>' + esc(r.status) + '</td><td>' + esc(r.submitted_at || '') + '</td><td>' + (r.score === null ? '—' : r.score) + '</td></tr>'; }
    html += '</table></div>';
    setView(html);
    $('back-exams').onclick = function () { go('exams'); };
  }, function (e) { alert(e); });
}

/* ---- 考官：题库管理（Lite 简化版） ---- */
function viewQuestions() {
  apiGet('/api/questions?page=1&page_size=20', function (d) {
    var html = '<div class="card"><h2>题库管理</h2><p class="muted">题库共 ' + d.total + ' 题（Lite 版显示前 20 题；新增 / 编辑 / 删除请用现代版，或用本页的新增与行内删除）</p>' +
      '<p><a class="btn-ghost btn" href="/api/questions/template">下载导入模板</a> <input type="button" value="新增题目" class="btn" id="btn-new-q"></p>' +
      '<table><tr><th>题号</th><th>题干</th><th>题型</th><th>分类</th><th>答案</th><th>状态</th><th></th></tr>';
    var i, it;
    for (i = 0; i < d.items.length; i++) {
      it = d.items[i];
      html += '<tr><td>' + esc(it.no) + '</td><td>' + esc(it.stem.slice(0, 40)) + '</td><td>' + esc(it.type) + '</td><td>' + esc(it.category) + '</td><td>' + esc(it.answer) + '</td><td>' + esc(it.status) + '</td>' +
        '<td><input type="button" value="停用/启用" class="btn-ghost btn" data-st="' + it.id + '" data-cur="' + it.status + '"> <input type="button" value="删除" class="btn-danger btn" data-del="' + it.id + '"></td></tr>';
    }
    html += '</table></div>';
    setView(html);
    $('btn-new-q').onclick = function () { questionFormLite(null); };
    var btns = $('view').getElementsByTagName('input'), j;
    for (j = 0; j < btns.length; j++) {
      (function (b) {
        if (b.getAttribute('data-st')) {
          b.onclick = function () {
            var ns = b.getAttribute('data-cur') === '启用' ? '停用' : '启用';
            apiPost('/api/questions/' + b.getAttribute('data-st') + '/status', { status: ns }, function () { alert('状态已更新'); go('questions'); }, function (e) { alert(e); });
          };
        }
        if (b.getAttribute('data-del')) {
          b.onclick = function () {
            if (!confirm('确定删除这道题吗？')) { return; }
            api('DELETE', '/api/questions', { ids: [parseInt(b.getAttribute('data-del'), 10)] }, function () { alert('已删除'); go('questions'); }, function (e) { alert(e); });
          };
        }
      })(btns[j]);
    }
  }, function (e) { setView('加载失败：' + esc(e)); });
}
function questionFormLite(it) {
  var html = '<div class="card"><h2>' + (it ? '编辑题目' : '新增题目') + '</h2>' +
    '<p><label>题号（可空）</label><br><input type="text" id="qf-no" value="' + esc(it ? it.no : '') + '"></p>' +
    '<p><label>题型</label><br><select id="qf-type"><option>单选</option><option>多选</option><option>判断</option><option>填空</option><option>简答</option></select></p>' +
    '<p><label>分类</label><br><input type="text" id="qf-cat" value="' + esc(it ? it.category : '') + '"></p>' +
    '<p><label>题干 *</label><br><textarea id="qf-stem" rows="3">' + esc(it ? it.stem : '') + '</textarea></p>' +
    '<p><label>选项 A</label><br><input type="text" id="qf-a" value="' + esc(it && it.options ? it.options.A || '' : '') + '"></p>' +
    '<p><label>选项 B</label><br><input type="text" id="qf-b" value="' + esc(it && it.options ? it.options.B || '' : '') + '"></p>' +
    '<p><label>选项 C</label><br><input type="text" id="qf-c" value="' + esc(it && it.options ? it.options.C || '' : '') + '"></p>' +
    '<p><label>选项 D</label><br><input type="text" id="qf-d" value="' + esc(it && it.options ? it.options.D || '' : '') + '"></p>' +
    '<p><label>正确答案 *</label><br><input type="text" id="qf-ans" value="' + esc(it ? it.answer : '') + '"></p>' +
    '<p><label>解析</label><br><textarea id="qf-analysis" rows="2">' + esc(it ? it.analysis || '' : '') + '</textarea></p>' +
    '<p><input type="button" value="保存" class="btn" id="qf-save"> <input type="button" value="返回" class="btn-ghost btn" id="qf-back"></p></div>';
  setView(html);
  if (it) { $('qf-type').value = it.type; }
  $('qf-back').onclick = function () { go('questions'); };
  $('qf-save').onclick = function () {
    var body = { no: trim($('qf-no').value), type: $('qf-type').value, category: trim($('qf-cat').value), stem: trim($('qf-stem').value), options: {}, answer: trim($('qf-ans').value), analysis: trim($('qf-analysis').value), image: '' };
    var a = trim($('qf-a').value), b = trim($('qf-b').value), c = trim($('qf-c').value), d = trim($('qf-d').value);
    if (a) { body.options.A = a; } if (b) { body.options.B = b; } if (c) { body.options.C = c; } if (d) { body.options.D = d; }
    if (!body.stem) { alert('题干不能为空'); return; }
    if (!body.answer) { alert('答案不能为空'); return; }
    apiPost('/api/questions', body, function () { alert('题目已保存'); go('questions'); }, function (e) { alert(e); });
  };
}

/* ---- 管理员：用户 / 上报 / 统计 / 版本（Lite 简化版） ---- */
function viewUsers() {
  apiGet('/api/admin/users?page=1&page_size=20', function (d) {
    var html = '<div class="card"><h2>用户管理</h2><p class="muted">共 ' + d.total + ' 名用户（Lite 版显示前 20 名）</p>' +
      '<p><input type="button" value="新增用户" class="btn" id="btn-new-user"></p>' +
      '<table><tr><th>用户名</th><th>姓名</th><th>部门</th><th>角色</th><th>状态</th><th></th></tr>';
    var i, u;
    for (i = 0; i < d.items.length; i++) {
      u = d.items[i];
      html += '<tr><td>' + esc(u.username) + '</td><td>' + esc(u.name) + '</td><td>' + esc(u.department) + '</td><td>' + esc(u.role_name) + '</td><td>' + esc(u.status) + '</td>' +
        '<td><input type="button" value="停用/恢复" class="btn-ghost btn" data-dis="' + u.id + '" data-cur="' + u.status + '"> <input type="button" value="重置密码" class="btn-ghost btn" data-rst="' + u.id + '"> <input type="button" value="删除" class="btn-danger btn" data-del="' + u.id + '"></td></tr>';
    }
    html += '</table></div>';
    setView(html);
    $('btn-new-user').onclick = function () { userFormLite(); };
    var btns = $('view').getElementsByTagName('input'), j;
    for (j = 0; j < btns.length; j++) {
      (function (b) {
        if (b.getAttribute('data-dis')) {
          b.onclick = function () {
            var act = b.getAttribute('data-cur') === '正常' ? 'disable' : 'enable';
            apiPost('/api/admin/users/' + b.getAttribute('data-dis') + '/' + act, {}, function () { alert('已更新'); go('users'); }, function (e) { alert(e); });
          };
        }
        if (b.getAttribute('data-rst')) {
          b.onclick = function () {
            if (!confirm('将该用户密码重置为 123456 吗？')) { return; }
            apiPost('/api/admin/users/' + b.getAttribute('data-rst') + '/reset-password', { password: '123456' }, function () { alert('密码已重置为 123456'); }, function (e) { alert(e); });
          };
        }
        if (b.getAttribute('data-del')) {
          b.onclick = function () {
            if (!confirm('确定删除该用户吗？其考试记录将一并删除，且不可恢复。')) { return; }
            api('DELETE', '/api/admin/users/' + b.getAttribute('data-del'), null, function () { alert('已删除'); go('users'); }, function (e) { alert(e); });
          };
        }
      })(btns[j]);
    }
  }, function (e) { setView('加载失败：' + esc(e)); });
}
function userFormLite() {
  setView('<div class="card"><h2>新增用户</h2>' +
    '<p><label>用户名</label><br><input type="text" id="uf-user"></p>' +
    '<p><label>姓名 *</label><br><input type="text" id="uf-name"></p>' +
    '<p><label>密码（至少 6 位）</label><br><input type="password" id="uf-pass"></p>' +
    '<p><label>部门</label><br><input type="text" id="uf-dept"></p>' +
    '<p><label>角色</label><br><select id="uf-role"><option value="student">学员</option><option value="examiner">考官</option><option value="admin">管理员</option></select></p>' +
    '<p><input type="button" value="保存" class="btn" id="uf-save"> <input type="button" value="返回" class="btn-ghost btn" id="uf-back"></p></div>');
  $('uf-back').onclick = function () { go('users'); };
  $('uf-save').onclick = function () {
    var body = { username: trim($('uf-user').value), name: trim($('uf-name').value), department: trim($('uf-dept').value), role: $('uf-role').value, password: $('uf-pass').value };
    if (!body.name) { alert('姓名不能为空'); return; }
    if (!body.password || body.password.length < 6) { alert('密码至少 6 位'); return; }
    apiPost('/api/admin/users', body, function () { alert('用户信息已更新'); go('users'); }, function (e) { alert(e); });
  };
}
function viewAdminReports() {
  apiGet('/api/admin/reports', function (list) {
    var pending = [], done = [], i;
    for (i = 0; i < list.length; i++) { if (list[i].status === '待处理') { pending.push(list[i]); } else { done.push(list[i]); } }
    var html = '<h2>上报处理</h2>';
    if (!pending.length) { html += '<div class="card empty">暂无待处理的上报</div>'; }
    for (i = 0; i < pending.length; i++) { html += reportCardLite(pending[i], true); }
    if (done.length) {
      html += '<h3>已处理记录</h3>';
      for (i = 0; i < done.length; i++) { html += reportCardLite(done[i], false); }
    }
    setView(html);
    var btns = $('view').getElementsByTagName('input'), j;
    for (j = 0; j < btns.length; j++) {
      if (btns[j].getAttribute('data-act')) {
        btns[j].onclick = function () {
          var id = this.getAttribute('data-id'), act = this.getAttribute('data-act');
          apiPost('/api/admin/reports/' + id + '/handle', { action: act, reply: '' }, function () { alert('已处理'); go('reports'); }, function (e) { alert(e); });
        };
      }
    }
  }, function (e) { setView('加载失败：' + esc(e)); });
}
function reportCardLite(r, isPending) {
  var q = r.question || {};
  var html = '<div class="card"><p><b>[' + esc(r.status) + '] ' + esc(r.type) + '</b> · 上报用户 ' + esc(r.reporter ? r.reporter.name : '') + ' · ' + esc(r.created_at || '') + '</p>' +
    '<p><b>' + esc(q.no || '') + ' · ' + esc(q.type || '') + '</b></p><p>' + esc(q.stem || '') + '</p>' +
    '<p class="muted">正确答案：' + esc(q.answer || '') + (q.analysis ? ' · 解析：' + esc(q.analysis) : '') + '</p>' +
    '<p>上报内容：' + esc(r.detail || '（无补充说明）') + '</p>';
  if (isPending) {
    html += '<p><input type="button" value="标记已解决" class="btn" data-act="已解决" data-id="' + r.id + '"> <input type="button" value="驳回（无需处理）" class="btn-ghost btn" data-act="已驳回" data-id="' + r.id + '"> <input type="button" value="同时停用该题" class="btn btn-gold" data-act="停用该题" data-id="' + r.id + '"></p>';
  } else {
    html += '<p class="muted">处理于 ' + esc(r.handled_at || '') + (r.reply ? ' · 处理回复：' + esc(r.reply) : '') + '</p>';
  }
  return html + '</div>';
}
function viewStats() {
  apiGet('/api/admin/stats', function (d) {
    var html = '<div class="card"><h2>统计分析</h2>' +
      '<p>学员总数：<b>' + d.student_count + '</b>　练习总题次：<b>' + d.practice_total + '</b>　全站正确率：<b>' + (d.accuracy || 0) + '%</b>　待处理上报：<b>' + d.pending_reports + '</b></p></div>' +
      '<div class="card"><h3>学员部门分布</h3>' + tableLite(d.students_by_department, 'department', 'count', '部门', '人数') + '</div>' +
      '<div class="card"><h3>题库构成（按题型）</h3>' + tableLite(d.questions_by_type, 'type', 'count', '题型', '题数') + '</div>' +
      '<div class="card"><h3>考试成绩（最近 5 场）</h3>';
    if (d.recent_exams && d.recent_exams.length) {
      html += '<table><tr><th>考试</th><th>已考人数</th><th>平均分</th></tr>';
      var i;
      for (i = 0; i < d.recent_exams.length; i++) { html += '<tr><td>' + esc(d.recent_exams[i].name) + '</td><td>' + d.recent_exams[i].submitted + '</td><td>' + (d.recent_exams[i].average === null ? '—' : d.recent_exams[i].average) + '</td></tr>'; }
      html += '</table>';
    } else { html += '<div class="empty">暂无数据</div>'; }
    html += '</div>';
    setView(html);
  }, function (e) { setView('加载失败：' + esc(e)); });
}
function tableLite(arr, k1, k2, h1, h2) {
  if (!arr || !arr.length) { return '<div class="empty">暂无数据</div>'; }
  var html = '<table><tr><th>' + h1 + '</th><th>' + h2 + '</th></tr>', i;
  for (i = 0; i < arr.length; i++) { html += '<tr><td>' + esc(arr[i][k1]) + '</td><td>' + arr[i][k2] + '</td></tr>'; }
  return html + '</table>';
}
function viewVersions() {
  apiGet('/api/admin/versions', function (list) {
    var html = '<div class="card"><h2>客户端更新发布</h2><p class="muted">发布新版本后，各终端启动软件时自动检查并升级；同一平台一次只保留一个生效版本。</p>' +
      '<p><label>目标平台</label><br><select id="ver-platform"><option value="win7-32">win7-32</option><option value="win10-64">win10-64</option><option value="xp-32">xp-32</option></select></p>' +
      '<p><label>版本号</label><br><input type="text" id="ver-version" value="v2.2"></p>' +
      '<p><label>更新说明</label><br><textarea id="ver-note" rows="2"></textarea></p>' +
      '<p><label>客户端程序 / 安装包文件名（可选）</label><br><input type="text" id="ver-file"></p>' +
      '<p><input type="button" value="发布新版本" class="btn" id="ver-go"></p></div>' +
      '<div class="card"><h3>已发布版本</h3>';
    if (!list.length) { html += '<div class="empty">尚未发布任何版本</div>'; }
    var i, x;
    for (i = 0; i < list.length; i++) {
      x = list[i];
      html += '<p><b>' + esc(x.version) + '</b> [' + esc(x.status) + '] ' + esc(x.platform) + ' · ' + esc(x.note || '') + (x.filename ? ' · ' + esc(x.filename) : '') +
        (x.status !== '生效中' ? ' <input type="button" value="设为生效版本" class="btn" data-act="' + x.id + '">' : ' <input type="button" value="下架" class="btn-ghost btn" data-deact="' + x.id + '">') +
        ' <input type="button" value="删除记录" class="btn-danger btn" data-del="' + x.id + '"></p>';
    }
    html += '</div>';
    setView(html);
    $('ver-go').onclick = function () {
      apiPost('/api/admin/versions', { platform: $('ver-platform').value, version: trim($('ver-version').value), note: $('ver-note').value, filename: trim($('ver-file').value) }, function () { alert('新版本已发布'); go('versions'); }, function (e) { alert(e); });
    };
    var btns = $('view').getElementsByTagName('input'), j;
    for (j = 0; j < btns.length; j++) {
      (function (b) {
        if (b.getAttribute('data-act')) { b.onclick = function () { apiPost('/api/admin/versions/' + b.getAttribute('data-act') + '/activate', {}, function () { alert('已设为生效版本'); go('versions'); }, function (e) { alert(e); }); }; }
        if (b.getAttribute('data-deact')) { b.onclick = function () { apiPost('/api/admin/versions/' + b.getAttribute('data-deact') + '/deactivate', {}, function () { alert('已下架'); go('versions'); }, function (e) { alert(e); }); }; }
        if (b.getAttribute('data-del')) {
          b.onclick = function () {
            if (!confirm('确定删除这条版本记录吗？生效中的版本需先下架才能删除。')) { return; }
            api('DELETE', '/api/admin/versions/' + b.getAttribute('data-del'), null, function () { alert('已删除'); go('versions'); }, function (e) { alert(e); });
          };
        }
      })(btns[j]);
    }
  }, function (e) { setView('加载失败：' + esc(e)); });
}


/* ---- v2.0 合并：刷题宝功能并入（B 工人，Lite 版） ----
   ES3 兼容：只用 var / for 循环 / 已有工具函数，不用 forEach / map / indexOf。
   接口未就绪时显示友好空态，不白屏。字段假设见汇总（按 v07 返回形状）。 */
function apiRaw(method, path, body, ok, fail) {
  var xhr;
  if (window.XMLHttpRequest) { xhr = new XMLHttpRequest(); } else { xhr = new ActiveXObject('Microsoft.XMLHTTP'); }
  xhr.open(method, path, true);
  xhr.setRequestHeader('Content-Type', 'application/json');
  if (ZK.token) { xhr.setRequestHeader('X-Token', ZK.token); }
  xhr.onreadystatechange = function () {
    if (xhr.readyState !== 4) { return; }
    var json = null;
    try { json = JSON.parse(xhr.responseText); } catch (e) { json = null; }
    if (xhr.status === 401) { ZK.token = ''; ZK.user = null; showLogin(); showMsg('登录已过期，请重新登录'); return; }
    if (!json || !json.ok) { if (fail) { fail(json && json.error ? json.error : '请求失败'); } return; }
    if (ok) { ok(json); }
  };
  xhr.onerror = function () { if (fail) { fail('无法连接服务器，请检查服务器地址与网络'); } };
  xhr.send(body ? JSON.stringify(body) : null);
}
function v2unwrapLite(j) {
  if (!j || typeof j !== 'object') { return j; }
  if (j.data !== undefined && j.data !== null) { return j.data; }
  var out = {}, k;
  for (k in j) { if (j.hasOwnProperty(k) && k !== 'ok' && k !== 'error') { out[k] = j[k]; } }
  return out;
}
function v2getLite(path, ok, fail) {
  apiRaw('GET', path, null, function (j) { ok(v2unwrapLite(j)); }, fail);
}
function normLiteQ(q) {
  var map = { single: '单选', multi: '多选', judge: '判断', short: '简答', material: '简答', fill: '填空' };
  var c = {}, k;
  for (k in q) { if (q.hasOwnProperty(k)) { c[k] = q[k]; } }
  if (map[c.type]) { c.type = map[c.type]; }
  if (!c.type) { c.type = '单选'; }
  if (c.options && c.options.length !== undefined && typeof c.options.length === 'number') {
    var o = {}, i;
    for (i = 0; i < c.options.length; i++) { if (c.options[i] && c.options[i].label) { o[c.options[i].label] = c.options[i].content; } }
    c.options = o;
  }
  if (!c.no) { c.no = c.id ? ('Q' + c.id) : ''; }
  if (!c.image && c.assets && c.assets.length) { c.image = c.assets[0].path || c.assets[0].filename || ''; }
  return c;
}
function normLiteQs(list) {
  var out = [], i;
  for (i = 0; i < (list || []).length; i++) { out.push(normLiteQ(list[i])); }
  return out;
}
function liteEmpty(msg, sub) {
  return '<div class="empty">' + esc(msg) + (sub ? '<br>' + esc(sub) : '') + '</div>';
}

/* ---- /lite/practice：五环节 + 自适应 + 薄弱项（轻量页） ---- */
function viewLitePractice() {
  var html = '<div class="card"><h2>自适应练习 · 学习方法五环节</h2>' +
    '<p class="muted">五环节：顺序 / 随机 / 错题回顾 / 薄弱分析 / 阶段考核。自适应按掌握度动态调组卷权重与难度（薄弱占比动态到 65%；冷启动 20 题）。Lite 版无图表与动效，练习交互与现代版一致。</p>' +
    '<p><input type="button" value="顺序刷题" class="btn" data-mode="顺序"> <input type="button" value="随机刷题" class="btn" data-mode="随机"> <input type="button" value="错题回顾" class="btn" data-mode="错题"> <input type="button" value="题型练习" class="btn" data-mode="题型"></p>' +
    '<p><input type="button" value="薄弱项训练" class="btn" id="lp-weak"> <input type="button" value="阶段考核" class="btn" id="lp-exam"> <input type="button" value="自适应练习" class="btn btn-gold" id="lp-adaptive"></p></div>' +
    '<div class="card" id="lp-profile"><h3>自适应画像</h3><p class="muted">加载中…</p></div>';
  setView(html);
  var btns = $('view').getElementsByTagName('input'), i;
  for (i = 0; i < btns.length; i++) {
    if (btns[i].getAttribute('data-mode')) {
      btns[i].onclick = function () { startPractice(this.getAttribute('data-mode')); };
    }
  }
  $('lp-weak').onclick = function () { liteStartWeak(); };
  $('lp-exam').onclick = function () { go('mock'); };
  $('lp-adaptive').onclick = function () { liteStartAdaptive(); };
  v2getLite('/api/v2/adaptive', function (d) {
    var p = d.adaptive || d, i, per = p.per_knowledge || [];
    var h = '<h3>自适应画像</h3><p>累计作答：<b>' + (p.total_attempts || 0) + '</b>　待复习：<b>' + (p.due_count || 0) + '</b>　连续学习：<b>' + (p.streak_days || 0) + '</b> 天</p>';
    if (p.sample_note) { h += '<p class="muted">' + esc(p.sample_note) + '</p>'; }
    if (p.cold_start) { h += '<p><b>冷启动：</b>样本不足 20 题，先按默认比例出题。</p>'; }
    if (p.weak_knowledge && p.weak_knowledge.length) { h += '<p>薄弱知识点：<b>' + esc(p.weak_knowledge.join('、')) + '</b></p>'; }
    if (per.length) {
      h += '<table><tr><th>知识点</th><th>作答</th><th>答对</th><th>正确率</th><th>状态</th></tr>';
      for (i = 0; i < per.length; i++) {
        var acc = per[i].accuracy;
        h += '<tr><td>' + esc(per[i].knowledge) + '</td><td>' + (per[i].total || 0) + '</td><td>' + (per[i].correct || 0) + '</td><td>' + (acc <= 1 ? Math.round(acc * 1000) / 10 : acc) + '%</td><td>' + esc(per[i].status || '') + '</td></tr>';
      }
      h += '</table>';
    }
    $('lp-profile').innerHTML = h;
  }, function (e) { $('lp-profile').innerHTML = '<h3>自适应画像</h3>' + liteEmpty('自适应画像暂不可用', e); });
}
function liteStartAdaptive() {
  v2getLite('/api/v2/practice/adaptive', function (d) {
    var qs = normLiteQs(d.questions || []);
    if (!qs.length) { alert('自适应暂无题目（题库为空或接口未返回题目）'); return; }
    ZK.practice = { mode: '自适应', questions: qs, idx: 0, correct: 0, wrong: 0, result: null, sel: null, input: '' };
    renderPractice();
  }, function (e) { alert(e); });
}
function liteStartWeak() {
  v2getLite('/api/v2/weak', function (d) {
    var qs = normLiteQs(d.questions || []);
    if (!qs.length) { alert('暂无薄弱项题目（先多练几题，满 20 题后开始个性化判断）'); return; }
    ZK.practice = { mode: '薄弱项', questions: qs, idx: 0, correct: 0, wrong: 0, result: null, sel: null, input: '' };
    renderPractice();
  }, function (e) { alert(e); });
}

/* ---- /lite/report：我的报告（轻量页，表格呈现，无 SVG 动效） ---- */
function viewLiteReport() {
  var html = '<div class="card"><h2>我的报告</h2><p class="muted">Lite 版降级说明：图表降级为纯文本表格呈现，无 SVG、无数字滚动、无动效；数据与现代版一致。</p></div>' +
    '<div class="card" id="lr-stats"><h3>练习统计</h3><p class="muted">加载中…</p></div>' +
    '<div class="card" id="lr-essay"><h3>简答 / 材料题批阅结果</h3><p class="muted">与选择题分开列示；≥60% 满分算对。加载中…</p></div>';
  setView(html);
  viewPracticeStats($('lr-stats'));
  v2getLite('/api/v2/essay/mine', function (d) {
    var items = d.submissions || d.items || d.list || [], i, it;
    var h = '<h3>简答 / 材料题批阅结果</h3><p class="muted">与选择题分开列示；≥60% 满分算对。</p>';
    if (!items.length) { h += liteEmpty('暂无简答 / 材料题批阅记录'); }
    else {
      h += '<table><tr><th>题干</th><th>得分</th><th>满分</th><th>状态</th><th>批阅人</th><th>批阅意见</th></tr>';
      for (i = 0; i < items.length; i++) {
        it = items[i];
        var max = parseFloat(it.max_score) || 10;
        var graded = it.status === 'graded' && it.score !== null && it.score !== undefined;
        var passed = graded && parseFloat(it.score) >= 0.6 * max;
        h += '<tr><td>' + esc(it.stem || ('题目 #' + (it.question_id || ''))) + '</td><td>' + (graded ? it.score : '—') + '</td><td>' + max + '</td><td>' + (graded ? (passed ? '已批阅 · 算对' : '已批阅 · 算错') : '待批阅') + '</td><td>' + esc(it.reviewer || '') + '</td><td>' + esc(it.comment || '') + '</td></tr>';
      }
      h += '</table>';
    }
    $('lr-essay').innerHTML = h;
  }, function (e) { $('lr-essay').innerHTML = '<h3>简答 / 材料题批阅结果</h3>' + liteEmpty('批阅记录暂不可用', e); });
}

/* ---- /lite/plans：学习计划（轻量页，文字进度条，无动效） ---- */
function viewLitePlans() {
  var isAdmin = ZK.user.role === 'admin';
  var html = '<div class="card"><h2>' + (isAdmin ? '学习计划（全部）' : '我的学习计划') + '</h2><p class="muted">Lite 版降级说明：进度用文字 + 静态色块条呈现，无动效；进度按去重题数算（同一题重复做只算 1 道）。</p></div><div id="lpl-list"><div class="card">加载中…</div></div>';
  setView(html);
  if (isAdmin) {
    v2getLite('/api/v2/plans', function (d) {
      var list = d.plans || [], i, p;
      var h = '';
      if (!list.length) { h = liteEmpty('暂无学习计划'); }
      for (i = 0; i < list.length; i++) {
        p = list[i];
        h += '<div class="card"><b>' + esc(p.title) + '</b><p class="muted">' + esc(p.team || '') + ' · 目标 ' + (p.target_count || 0) + ' 题' + (p.due_date ? ' · 截止 ' + esc(p.due_date) : '') + ' · 已指派 ' + (p.assigned || 0) + ' 人 · 已完成 ' + (p.done_count || 0) + ' 人 · 平均进度 ' + (p.avg_pct || 0) + '%</p>' +
          '<div class="bar-track"><div class="bar-fill" style="width:' + (p.avg_pct || 0) + '%"></div></div></div>';
      }
      $('lpl-list').innerHTML = h;
    }, function (e) { $('lpl-list').innerHTML = '<div class="card">' + liteEmpty('学习计划暂不可用', e) + '</div>'; });
    return;
  }
  v2getLite('/api/v2/plans/me', function (d) {
    var list = d.plans || [], i, p;
    var h = '';
    if (!list.length) { h = liteEmpty('暂无学习计划，请等待考官 / 管理员下发'); }
    for (i = 0; i < list.length; i++) {
      p = list[i];
      var pct = p.pct || 0;
      h += '<div class="card"><b>' + esc(p.title) + '</b>' + (p.overdue ? ' <b style="color:#DC2626">已逾期</b>' : '') +
        '<p class="muted">' + (p.knowledge ? '知识点：' + esc(p.knowledge) + ' · ' : '') + '目标 ' + (p.target || 0) + ' 题 · 已做 ' + (p.done || 0) + ' 题' + (p.due_date ? ' · 截止 ' + esc(p.due_date) : '') + (p.days_left !== null && p.days_left !== undefined ? ' · 剩余 ' + p.days_left + ' 天' : '') + '</p>' +
        '<div class="bar-track"><div class="bar-fill" style="width:' + pct + '%"></div></div><p>进度 ' + pct + '%</p></div>';
    }
    $('lpl-list').innerHTML = h;
  }, function (e) { $('lpl-list').innerHTML = '<div class="card">' + liteEmpty('学习计划暂不可用', e) + '</div>'; });
}

/* ---- 空格键推进 ---- */
document.onkeydown = function (e) {
  e = e || window.event;
  if (e.keyCode !== 32) { return; }
  var tag = (e.target || e.srcElement).tagName;
  if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') { return; }
  if (ZK.practice) {
    if (e.preventDefault) { e.preventDefault(); }
    if (ZK.practice.result) { nextPractice(); } else { submitPractice(false); }
    return;
  }
  if (ZK.mock) {
    if (e.preventDefault) { e.preventDefault(); }
    if (ZK.mock.idx + 1 < ZK.mock.questions.length) { ZK.mock.idx++; renderMock(); }
    return;
  }
  if (ZK.exam) {
    if (e.preventDefault) { e.preventDefault(); }
    if (ZK.exam.idx + 1 < ZK.exam.questions.length) { ZK.exam.idx++; renderExam(); }
  }
};

/* ---- 启动 ---- */
$('login-form').onsubmit = function () { doLogin(); return false; };
$('go-register').onclick = function () { showRegister(); return false; };
$('btn-logout').onclick = function () {
  apiPost('/api/auth/logout', {}, function () {}, function () {});
  ZK.token = ''; ZK.user = null; location.reload();
  return false;
};
showLogin();
