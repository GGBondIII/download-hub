# -*- coding: utf-8 -*-
"""常熟站智考通 v2.2 — 导入任务:Excel/Word/PDF 解析 + 校验 + 审核发布 + 回滚。

解析器照抄刷题宝 v0.7 server.py 385–660 行(parse_xlsx/parse_docx,仅把
f-string 报错换成 .format);validate_row/normalize_type 改成 v1 中文题型
(单选/多选/判断/填空/简答;材料题并入简答)。
流程照抄 v07 do_import:逐行校验 -> 草稿入库(状态 停用) -> 图文配对分流 ->
review_queue 待审核;审核通过后 bank 发布才启用。
Python 3.4 兼容语法。
"""
import hashlib
import io
import json
import os
import re
import zipfile
import xml.etree.ElementTree as ET

import db
import questions as qmod

# ---------------- 导入解析（标准库 zipfile + xml） ----------------
NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "xdr": "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing",
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"}
def _col_to_num(col):
    n = 0
    for ch in col:
        n = n * 26 + (ord(ch) - 64)
    return n
def _parse_cell_ref(ref):
    m = re.match(r"([A-Z]+)(\d+)", ref or "")
    return (_col_to_num(m.group(1)), int(m.group(2))) if m else (0, 0)
def parse_xlsx(data):
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
    except Exception as e:
        return [], {}, "不是有效的 xlsx 文件：{0}".format(e)
    names = z.namelist()
    shared = []
    if "xl/sharedStrings.xml" in names:
        try:
            root = ET.fromstring(z.read("xl/sharedStrings.xml"))
            for si in root:
                shared.append("".join(t.text or "" for t in si.iter("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t")))
        except Exception:
            shared = []
    sheet_name = "xl/worksheets/sheet1.xml"
    for n in names:
        if n.startswith("xl/worksheets/sheet") and n.endswith(".xml"):
            sheet_name = n
            break
    try:
        root = ET.fromstring(z.read(sheet_name))
    except Exception as e:
        return [], {}, "读取工作表失败：{0}".format(e)
    m_ns = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
    rows_raw = {}
    for row_el in root.iter(m_ns + "row"):
        r_attr = row_el.get("r")
        if not r_attr:
            continue
        rno = int(r_attr)
        cells = {}
        for c_el in row_el.findall(m_ns + "c"):
            ref = c_el.get("r") or ""
            col, rnum = _parse_cell_ref(ref)
            t = c_el.get("t")
            v_el = c_el.find(m_ns + "v")
            is_el = c_el.find(m_ns + "is")
            val = ""
            if t == "s" and v_el is not None and v_el.text is not None:
                try:
                    val = shared[int(v_el.text)]
                except Exception:
                    val = ""
            elif is_el is not None:
                val = "".join(x.text or "" for x in is_el.iter(m_ns + "t"))
            elif v_el is not None and v_el.text is not None:
                val = v_el.text
            cells[col] = str(val).strip()
        rows_raw[rno] = cells
    if not rows_raw:
        return [], {}, "工作表为空"
    header_row = None
    header_map = {}
    for rno in sorted(rows_raw):
        for col, v in rows_raw[rno].items():
            if "题干" in v or "题目" in v:
                header_row = rno
                for c2, v2 in rows_raw[rno].items():
                    header_map[c2] = v2
                break
        if header_row:
            break
    if header_row is None:
        return [], {}, "未找到表头行（需包含“题干”列）。请用提供的标准模板。"
    col_for = {}
    for col, name in header_map.items():
        n = name.replace(" ", "")
        if "图片" in n:
            col_for["image_note"] = col
        elif n in ("题干", "题目", "题干内容"):
            col_for["stem"] = col
        elif "题型" in n:
            col_for["type"] = col
        elif n in ("选项A", "A"):
            col_for["A"] = col
        elif n in ("选项B", "B"):
            col_for["B"] = col
        elif n in ("选项C", "C"):
            col_for["C"] = col
        elif n in ("选项D", "D"):
            col_for["D"] = col
        elif n in ("选项E", "E"):
            col_for["E"] = col
        elif "答案" in n:
            col_for["answer"] = col
        elif "解析" in n:
            col_for["explanation"] = col
        elif "科目" in n:
            col_for["subject"] = col
        elif "知识点" in n:
            col_for["knowledge"] = col
        elif "难度" in n:
            col_for["difficulty"] = col
        elif "评分要点" in n:
            col_for["rubric"] = col
        elif "满分" in n:
            col_for["max_score"] = col
        elif "父题" in n:
            col_for["parent_row"] = col
        elif "来源" in n:
            col_for["source"] = col
        elif "图片" in n:
            col_for["image_note"] = col
    if "stem" not in col_for:
        return [], {}, "表头缺少题干列"
    rows = []
    for rno in sorted(rows_raw):
        if rno <= header_row:
            continue
        cells = rows_raw[rno]
        if all(not v for v in cells.values()):
            continue
        d = {"row_no": rno}
        for k, col in col_for.items():
            d[k] = cells.get(col, "")
        for lab in "ABCDE":
            d[lab] = cells.get(col_for.get(lab, -1), "") if lab in col_for else ""
        rows.append(d)
    images_by_row = {}
    try:
        drawing_names = [n for n in names if n.startswith("xl/drawings/drawing") and n.endswith(".xml")]
        for dn in drawing_names:
            rels_name = dn.replace("xl/drawings/", "xl/drawings/_rels/") + ".rels"
            rel_map = {}
            if rels_name in names:
                rroot = ET.fromstring(z.read(rels_name))
                for rel in rroot:
                    rel_map[rel.get("Id")] = rel.get("Target", "")
            droot = ET.fromstring(z.read(dn))
            for anchor in list(droot):
                from_el = anchor.find("xdr:from", NS)
                if from_el is None:
                    continue
                row_el = from_el.find("xdr:row", NS)
                if row_el is None or row_el.text is None:
                    continue
                anchor_row = int(row_el.text) + 1
                blip = anchor.find(".//a:blip", NS)
                if blip is None:
                    continue
                rid = blip.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed")
                target = rel_map.get(rid, "")
                if not target:
                    continue
                media_name = "xl/media/" + target.split("/")[-1]
                if media_name not in names:
                    continue
                blob = z.read(media_name)
                ext = media_name.split(".")[-1].lower()
                mime = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "gif": "image/gif", "bmp": "image/bmp"}.get(ext, "image/png")
                images_by_row.setdefault(anchor_row, []).append({"filename": target.split("/")[-1], "bytes": blob, "mime": mime, "anchor_row": anchor_row})
    except Exception:
        pass
    return rows, images_by_row, ""
def parse_docx(data):
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
    except Exception as e:
        return [], "不是有效的 docx 文件：{0}".format(e)
    names = z.namelist()
    if "word/document.xml" not in names:
        return [], "docx 缺少 word/document.xml"
    rel_map = {}
    if "word/_rels/document.xml.rels" in names:
        rroot = ET.fromstring(z.read("word/_rels/document.xml.rels"))
        for rel in rroot:
            rel_map[rel.get("Id")] = rel.get("Target", "")
    w_ns = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    r_ns = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
    a_ns = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
    root = ET.fromstring(z.read("word/document.xml"))
    paras = []
    for pidx, p in enumerate(root.iter(w_ns + "p")):
        text = "".join(t.text or "" for t in p.iter(w_ns + "t"))
        imgs = []
        for blip in p.iter(a_ns + "blip"):
            rid = blip.get(r_ns + "embed")
            target = rel_map.get(rid, "")
            if not target:
                continue
            media_name = target if target.startswith("word/") else "word/" + target.lstrip("/")
            if media_name not in names:
                media_name = "word/media/" + target.split("/")[-1]
            if media_name not in names:
                continue
            blob = z.read(media_name)
            ext = media_name.split(".")[-1].lower()
            mime = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "gif": "image/gif"}.get(ext, "image/png")
            imgs.append({"filename": target.split("/")[-1], "bytes": blob, "mime": mime})
        if text.strip() or imgs:
            paras.append((text.strip(), imgs, pidx))
    q_start = re.compile(r"^(?:第)?(\d+)[\.、．）\)\s]+(.+)$")
    opt_re = re.compile(r"^([A-E])[\.、．）\)\s]+(.+)$")
    ans_re = re.compile(r"^(?:【?答案】?|答案)[:：\s]*(.+)$")
    exp_re = re.compile(r"^(?:【?解析】?|解析)[:：\s]*(.+)$")
    ref_re = re.compile(r"^(?:【?参考答案】?|参考答案)[:：\s]*(.+)$")
    rubric_re = re.compile(r"^(?:【?评分要点】?|评分要点)[:：\s]*(.+)$")
    short_re = re.compile(r"^(?:【?简答题】?|【?材料题】?|简答题|材料题)[:：\s]*(.*)$")
    questions = []
    orphans = []
    cur = None
    cur_start_para = None
    def flush():
        nonlocal cur
        if cur and cur.get("stem"):
            questions.append(cur)
        cur = None
    for text, imgs, pidx in paras:
        m = q_start.match(text)
        if m and len(text) > 3:
            flush()
            cur_start_para = pidx
            cur = {"stem": m.group(2).strip(), "type": "single", "options": {}, "answer": "", "explanation": "", "subject": "", "knowledge": "", "difficulty": "3", "rubric": "", "max_score": 10, "images": [], "row_no": len(questions) + 1}
            sm = short_re.match(cur["stem"])
            if sm:
                cur["stem"] = sm.group(1).strip() or cur["stem"]
                cur["type"] = "material" if "材料" in text[:8] else "short"
            for im in imgs:
                im2 = dict(im); im2["dist"] = 0
                cur["images"].append(im2)
            continue
        if cur is None:
            for im in imgs:
                im2 = dict(im); im2["dist"] = None
                orphans.append(im2)
            continue
        if imgs:
            for im in imgs:
                im2 = dict(im); im2["dist"] = max(0, pidx - (cur_start_para or pidx))
                cur["images"].append(im2)
        rm = ref_re.match(text)
        if rm:
            cur["answer"] = rm.group(1).strip()
            if cur["type"] in ("single", "multi", "judge"):
                cur["type"] = "short"
            continue
        rb = rubric_re.match(text)
        if rb:
            cur["rubric"] = rb.group(1).strip()
            continue
        am = ans_re.match(text)
        if am:
            cur["answer"] = am.group(1).strip()
            continue
        em = exp_re.match(text)
        if em:
            cur["explanation"] = em.group(1).strip()
            continue
        om = opt_re.match(text)
        if om:
            cur["options"][om.group(1)] = om.group(2).strip()
            continue
        if re.search(r"[A-D][\.、]", text) and len(cur["options"]) < 2 and "A" not in cur["options"]:
            parts = re.split(r"(?=[A-E][\.、．])", text)
            for part in parts:
                mm = opt_re.match(part.strip())
                if mm:
                    cur["options"][mm.group(1)] = mm.group(2).strip()
            if cur["options"]:
                continue
        cur["stem"] = (cur["stem"] + " " + text).strip() if cur["stem"] else text
    flush()
    for q in questions:
        if q["type"] in ("short", "material"):
            q["options_list"] = []
            continue
        ans = (q["answer"] or "").strip().upper()
        opts = q["options"]
        if set(opts.keys()) <= {"A", "B"} and set(v for v in opts.values()) <= {"对", "错"}:
            q["type"] = "judge"
        elif len([c for c in ans if c.isalpha()]) >= 2:
            q["type"] = "multi"
        else:
            q["type"] = "single"
        q["options_list"] = [opts.get(lab, "") for lab in sorted(opts.keys())]
    return questions, "", orphans

def normalize_type(raw):
    """v07 英文/中文题型 -> v1 中文题型。材料题并入简答(v1 无材料题型)。"""
    t = (raw or '').strip()
    if t in ('单选', '单选题', 'single', '1'):
        return '单选'
    if t in ('多选', '多选题', 'multi', '2'):
        return '多选'
    if t in ('判断', '判断题', 'judge', '3'):
        return '判断'
    if t in ('填空', '填空题', 'fill', 'blank'):
        return '填空'
    if t in ('简答', '简答题', 'short', '4'):
        return '简答'
    if t in ('材料', '材料题', 'material', '5'):
        return '简答'
    if not t:
        return '单选'
    return None


def validate_row(d):
    """校验一行解析结果,返回 (cleaned_dict, error)。cleaned 用 v1 中文题型,
    options 为内容列表,subject 为 category 的来源字段。"""
    stem = (d.get('stem') or '').strip()
    if not stem:
        return None, "题干为空"
    t = normalize_type(d.get('type', ''))
    if t is None:
        return None, "题型不识别:{0}".format(d.get('type'))
    if t in ('简答', '填空'):
        ref = str(d.get('answer') or '').strip()
        if t == '简答' and not ref:
            return None, "简答题缺参考答案"
        if t == '填空' and not ref:
            return None, "填空题缺答案"
        try:
            ms = float(str(d.get('max_score') or 10))
        except Exception:
            ms = 10
        if ms <= 0:
            ms = 10
        try:
            diff = int(str(d.get('difficulty') or '3').strip())
        except Exception:
            diff = 3
        if diff < 1 or diff > 5:
            diff = 3
        knowledge = []
        for part in re.split(r'[、，,；;／/]', str(d.get('knowledge') or '')):
            part = part.strip()
            if part:
                knowledge.append(part)
        return {'type': t, 'stem': stem, 'options': [], 'answer': ref,
                'explanation': str(d.get('explanation') or '').strip(),
                'rubric': str(d.get('rubric') or '').strip(), 'max_score': ms,
                'parent_row': d.get('parent_row'),
                'subject': str(d.get('subject') or '未分类').strip() or '未分类',
                'knowledge': knowledge, 'difficulty': diff,
                'source': str(d.get('source') or '导入').strip()}, ''
    if isinstance(d.get('options_list'), list):
        opts = [str(x).strip() for x in d['options_list']]
    else:
        raw_opts = [str(d.get(lab, '') or '').strip() for lab in 'ABCDE']
        last = -1
        for i, o in enumerate(raw_opts):
            if o:
                last = i
        if last < 0:
            return None, "选项为空"
        opts = raw_opts[:last + 1]
        if t in ('单选', '多选') and any(not o for o in opts):
            return None, "选项中间有空缺"
    if t == '判断':
        if not opts:
            opts = ['对', '错']
        if len(opts) < 2:
            return None, "判断题至少需要 2 个选项(对/错)"
    else:
        if len(opts) < 2:
            return None, "选项数不足(仅 {0} 个)".format(len(opts))
        if len(opts) > 5:
            return None, "选项数超过 5 个"
    ans_raw = str(d.get('answer') or '').strip().upper().replace('，', ',').replace(' ', '')
    if not ans_raw:
        return None, "缺答案"
    if t == '判断':
        mapping = {'A': '对', 'B': '错'}
        ans = mapping.get(ans_raw, ans_raw)
        if ans not in ('对', '错'):
            return None, "判断题答案越界:{0}(应为 对/错)".format(d.get('answer'))
    elif t == '多选':
        letters = [c for c in ans_raw if c.isalpha()]
        if len(letters) < 2:
            return None, "多选题答案至少 2 个选项"
        if any((ord(c) - 65) >= len(opts) for c in letters):
            return None, "多选题答案越界:{0}(选项仅到 {1})".format(
                d.get('answer'), chr(64 + len(opts)))
        ans = ''.join(sorted(set(letters)))
    else:
        if len(ans_raw) != 1 or not ans_raw.isalpha():
            return None, "单选题答案应为单个字母:{0}".format(d.get('answer'))
        if (ord(ans_raw) - 65) >= len(opts):
            return None, "单选题答案越界:{0}(选项仅到 {1})".format(
                ans_raw, chr(64 + len(opts)))
        ans = ans_raw
    try:
        diff = int(str(d.get('difficulty') or '3').strip())
    except Exception:
        diff = 3
    if diff < 1 or diff > 5:
        diff = 3
    knowledge = []
    for part in re.split(r'[、，,；;／/]', str(d.get('knowledge') or '')):
        part = part.strip()
        if part:
            knowledge.append(part)
    return {'type': t, 'stem': stem, 'options': opts, 'answer': ans,
            'explanation': str(d.get('explanation') or '').strip(),
            'rubric': str(d.get('rubric') or '').strip(), 'max_score': 10,
            'parent_row': d.get('parent_row'),
            'subject': str(d.get('subject') or '未分类').strip() or '未分类',
            'knowledge': knowledge, 'difficulty': diff,
            'source': str(d.get('source') or '导入').strip()}, ''


def insert_cleaned_question(conn, cleaned, source, username):
    """把校验通过的题写入 v1 questions 表(状态 停用=草稿,待审核发布),
    选项同时写 JSON 与 question_options,知识点写 question_knowledge。返回 qid。"""
    import adaptive
    opts = dict([(chr(65 + j), c) for j, c in enumerate(cleaned['options'])])
    category = cleaned['subject']
    cur = conn.execute(
        "INSERT INTO questions(no, type, category, stem, options, answer, analysis,"
        " image, status, created_at, difficulty, source, version_id, rubric,"
        " max_score, parent_id)"
        " VALUES(?, ?, ?, ?, ?, ?, ?, '', '停用', datetime('now', 'localtime'),"
        " ?, ?, NULL, ?, ?, NULL)",
        (qmod.next_no(), cleaned['type'], category, cleaned['stem'],
         json.dumps(opts, ensure_ascii=False), cleaned['answer'],
         cleaned['explanation'], cleaned['difficulty'], source,
         cleaned.get('rubric', ''), cleaned.get('max_score', 10)))
    qid = cur.lastrowid
    for j, opt in enumerate(cleaned['options']):
        conn.execute(
            "INSERT INTO question_options(question_id, label, content)"
            " VALUES(?, ?, ?)", (qid, chr(65 + j), opt))
    kn = cleaned['knowledge'] or ([category] if category else [])
    adaptive.set_knowledge(conn, qid, kn, category)
    return qid


def _upload_dir():
    return os.path.join(os.path.dirname(db.DB_PATH or ''), 'uploads')


def do_import(blob, filename, file_type, username):
    """导入主流程(Excel/Word/PDF):解析 -> 逐行校验 -> 草稿入库 -> 配对分流 ->
    review_queue 待审核。返回 (result_dict, error)。"""
    import import_pdf
    import pairing as pairing_mod
    conn = db.get_conn()
    with db.DB_LOCK:
        cur = conn.execute(
            "INSERT INTO import_jobs(filename, file_type, total_rows, ok_rows,"
            " bad_rows, status, created_by, created_at)"
            " VALUES(?, ?, 0, 0, 0, 'parsed', ?, datetime('now', 'localtime'))",
            (filename, file_type, username))
        job_id = cur.lastrowid
        conn.commit()
    parsed = []
    parsed_orphans = []
    err = ''
    if file_type == 'excel':
        rows, images_by_row, err = parse_xlsx(blob)
        for d in rows:
            parsed.append((d.get('row_no'), d,
                           list(images_by_row.get(d.get('row_no'), []))))
        for arow, imgs in list(images_by_row.items()):
            if any(p[0] == arow for p in parsed):
                continue
            nxt = [p for p in parsed if p[0] > arow]
            if nxt:
                nxt[0][2].extend(imgs)
            elif parsed:
                parsed[-1][2].extend(imgs)
    elif file_type == 'pdf':
        questions, pinfo, err = import_pdf.parse_pdf(blob)
        if err:
            with db.DB_LOCK:
                conn.execute("UPDATE import_jobs SET status='failed' WHERE id=?",
                             (job_id,))
                conn.commit()
            return {'ok': False, 'error': err, 'job_id': job_id,
                    'pdf_info': pinfo}, err
        for i, q in enumerate(questions):
            d = {'row_no': i + 1, 'stem': q['stem'], 'type': q['type'],
                 'answer': q['answer'], 'explanation': q['explanation'],
                 'subject': q['subject'], 'knowledge': q['knowledge'],
                 'difficulty': q['difficulty'], 'rubric': q.get('rubric', ''),
                 'max_score': q.get('max_score', 10),
                 'options_list': q.get('options_list', [])}
            parsed.append((i + 1, d, q.get('images', [])))
    else:
        questions, err, orphans = parse_docx(blob)
        for i, q in enumerate(questions):
            d = {'row_no': i + 1, 'stem': q['stem'], 'type': q['type'],
                 'answer': q['answer'], 'explanation': q['explanation'],
                 'subject': q['subject'], 'knowledge': q['knowledge'],
                 'difficulty': q['difficulty'], 'rubric': q.get('rubric', ''),
                 'max_score': q.get('max_score', 10),
                 'options_list': q.get('options_list', [])}
            parsed.append((i + 1, d, q.get('images', [])))
        for im in orphans:
            parsed_orphans.append(im)
    if err:
        with db.DB_LOCK:
            conn.execute("UPDATE import_jobs SET status='failed' WHERE id=?",
                         (job_id,))
            conn.commit()
        return {'ok': False, 'error': err, 'job_id': job_id}, err
    ok_n = 0
    bad_n = 0
    bad_list = []
    row_qids = {}
    pending_parents = []
    pair_counts = {'auto': 0, 'review': 0, 'manual': 0}
    pair_items = []
    with db.DB_LOCK:
        for row_no, d, imgs in parsed:
            cleaned, verr = validate_row(d)
            if verr:
                bad_n += 1
                bad_list.append({'row_no': row_no, 'error': verr})
                conn.execute(
                    "INSERT INTO import_items(job_id, row_no, raw_json, error, status)"
                    " VALUES(?, ?, ?, ?, 'bad')",
                    (job_id, row_no, json.dumps(d, ensure_ascii=False), verr))
                conn.execute(
                    "INSERT INTO review_queue(job_id, question_id, row_no, reason, status)"
                    " VALUES(?, NULL, ?, ?, 'needs_fix')",
                    (job_id, row_no, verr))
                continue
            ok_n += 1
            qid = insert_cleaned_question(
                conn, cleaned, "导入:{0}".format(filename), username)
            row_qids[row_no] = qid
            if cleaned.get('parent_row'):
                try:
                    pending_parents.append((qid, int(cleaned['parent_row'])))
                except Exception:
                    pass
            for img in imgs:
                aid = pairing_mod.save_asset(conn, qid, img['bytes'],
                                             img['filename'], img['mime'])
                if 'dist' in img:
                    dist = img.get('dist')
                else:
                    dist = abs(int(img.get('anchor_row', row_no)) - int(row_no))
                conf = pairing_mod.pairing_confidence(dist)
                st = pairing_mod.pairing_status(conf)
                pair_counts[st] += 1
                anchor_txt = "锚点行{0}".format(img.get('anchor_row')) if img.get('anchor_row') else "锚点段落距题干{0}段".format(dist)
                conn.execute(
                    "INSERT INTO image_pairings(job_id, asset_id, question_id, filename,"
                    " confidence, status, reason, created_at)"
                    " VALUES(?, ?, ?, ?, ?, ?, ?, datetime('now', 'localtime'))",
                    (job_id, aid, qid, img['filename'], conf, st,
                     "{0},置信度 {1:.2f}({2})".format(
                         anchor_txt, conf,
                         '自动通过' if st == 'auto' else ('需复核' if st == 'review' else '需人工指定'))))
                pair_items.append({'filename': img['filename'],
                                   'question_id': qid, 'confidence': conf,
                                   'status': st})
            conn.execute(
                "INSERT INTO import_items(job_id, row_no, raw_json, error, status)"
                " VALUES(?, ?, ?, '', 'ok')",
                (job_id, row_no, json.dumps(cleaned, ensure_ascii=False)))
            conn.execute(
                "INSERT INTO review_queue(job_id, question_id, row_no, reason, status)"
                " VALUES(?, ?, ?, '待审核', 'pending')",
                (job_id, qid, row_no))
        for qid, prow in pending_parents:
            if prow in row_qids:
                conn.execute("UPDATE questions SET parent_id=? WHERE id=?",
                             (row_qids[prow], qid))
        for im in parsed_orphans:
            try:
                h = hashlib.sha256(im['bytes']).hexdigest()[:16]
                ext = (im['filename'].split('.')[-1].lower()
                       if '.' in im['filename'] else 'png')
                if ext not in ('png', 'jpg', 'jpeg', 'gif', 'bmp'):
                    ext = 'png'
                pname = "pending_{0}_{1}.{2}".format(job_id, h, ext)
                udir = _upload_dir()
                try:
                    os.makedirs(udir)
                except OSError:
                    pass
                with open(os.path.join(udir, pname), 'wb') as f:
                    f.write(im['bytes'])
                pair_counts['manual'] += 1
                conn.execute(
                    "INSERT INTO image_pairings(job_id, asset_id, question_id, filename,"
                    " confidence, status, reason, pending_path, created_at)"
                    " VALUES(?, NULL, NULL, ?, 0.40, 'manual',"
                    " '图片所在段落无对应题号,需人工指定题目', ?,"
                    " datetime('now', 'localtime'))",
                    (job_id, im['filename'], pname))
                pair_items.append({'filename': im['filename'],
                                   'question_id': None, 'confidence': 0.40,
                                   'status': 'manual'})
            except Exception:
                pass
        conn.execute(
            "UPDATE import_jobs SET total_rows=?, ok_rows=?, bad_rows=?,"
            " status='parsed', pairing_auto=?, pairing_review=?, pairing_manual=?,"
            " pairing_report_json=? WHERE id=?",
            (len(parsed), ok_n, bad_n, pair_counts['auto'],
             pair_counts['review'], pair_counts['manual'],
             json.dumps({'auto': pair_counts['auto'],
                         'review': pair_counts['review'],
                         'manual': pair_counts['manual'],
                         'items': pair_items[:200]}, ensure_ascii=False),
             job_id))
        conn.commit()
    db.audit(username, 'import',
             "{0} 解析 {1} 行,通过 {2},待修 {3};配对自动 {4} / 复核 {5} / 人工 {6}".format(
                 filename, len(parsed), ok_n, bad_n, pair_counts['auto'],
                 pair_counts['review'], pair_counts['manual']))
    return {'ok': True, 'job_id': job_id, 'total': len(parsed), 'ok': ok_n,
            'bad': bad_n, 'bad_list': bad_list, 'pairing': pair_counts}, ""


def list_jobs():
    conn = db.get_conn()
    with db.DB_LOCK:
        jobs = [db.row_to_dict(r) for r in conn.execute(
            "SELECT * FROM import_jobs ORDER BY id DESC LIMIT 20").fetchall()]
        queue = [db.row_to_dict(r) for r in conn.execute(
            "SELECT * FROM review_queue ORDER BY id DESC LIMIT 100").fetchall()]
    return {'jobs': jobs, 'review_queue': queue}


def job_detail(job_id):
    conn = db.get_conn()
    with db.DB_LOCK:
        job = conn.execute("SELECT * FROM import_jobs WHERE id=?",
                           (job_id,)).fetchone()
        if job is None:
            return None, "导入任务不存在"
        items = [db.row_to_dict(r) for r in conn.execute(
            "SELECT * FROM import_items WHERE job_id=? ORDER BY row_no",
            (job_id,)).fetchall()]
    return {'job': db.row_to_dict(job), 'items': items}, ""


def approve_job(job_id, username=''):
    conn = db.get_conn()
    with db.DB_LOCK:
        job = conn.execute("SELECT * FROM import_jobs WHERE id=?",
                           (job_id,)).fetchone()
        if job is None:
            return None, "导入任务不存在"
        conn.execute(
            "UPDATE review_queue SET status='approved', reviewer=?,"
            " reviewed_at=datetime('now', 'localtime')"
            " WHERE job_id=? AND status='pending'", (username, job_id))
        conn.commit()
    db.audit(username, 'import_approve', "导入任务 {0} 审核通过".format(job_id))
    return {'approved': True}, ""


def current_version_id(conn):
    r = conn.execute(
        "SELECT id FROM bank_versions WHERE is_current=1 ORDER BY id DESC"
        " LIMIT 1").fetchone()
    return r[0] if r else None


def list_versions():
    conn = db.get_conn()
    with db.DB_LOCK:
        rows = conn.execute(
            "SELECT * FROM bank_versions ORDER BY id DESC").fetchall()
    return [db.row_to_dict(r) for r in rows]


def publish_bank(note, username=''):
    """发布新版本:已审核通过的题目进新版本并启用(状态 停用->启用)。"""
    conn = db.get_conn()
    with db.DB_LOCK:
        approved = [r[0] for r in conn.execute(
            "SELECT DISTINCT question_id FROM review_queue"
            " WHERE status='approved' AND question_id IS NOT NULL").fetchall()]
        if not approved:
            approved = [r[0] for r in conn.execute(
                "SELECT id FROM questions WHERE status='停用'").fetchall()]
        if not approved:
            return None, "没有可发布的草稿题(请先导入并审核通过)"
        n_ver = conn.execute("SELECT COUNT(*) FROM bank_versions").fetchone()[0]
        ver_no = "v2.2.{0}".format(n_ver)
        while conn.execute(
                "SELECT id FROM bank_versions WHERE version_no=?",
                (ver_no,)).fetchone():
            n_ver += 1
            ver_no = "v2.2.{0}".format(n_ver)
        conn.execute("UPDATE bank_versions SET is_current=0")
        cur = conn.execute(
            "INSERT INTO bank_versions(version_no, note, question_count, is_current,"
            " created_by, created_at) VALUES(?, ?, ?, 1, ?,"
            " datetime('now', 'localtime'))",
            (ver_no, note or "导入发布", len(approved), username))
        vid = cur.lastrowid
        for qid in approved:
            conn.execute(
                "UPDATE questions SET status='启用', version_id=? WHERE id=?",
                (vid, qid))
            conn.execute(
                "INSERT OR IGNORE INTO bank_version_items(version_id, question_id)"
                " VALUES(?, ?)", (vid, qid))
        ph = ','.join('?' * len(approved))
        conn.execute(
            "UPDATE review_queue SET status='published' WHERE status='approved'"
            " AND question_id IN ({0})".format(ph), approved)
        conn.commit()
    db.audit(username, 'bank_publish',
             "发布 {0},{1} 题".format(ver_no, len(approved)))
    return {'version': ver_no, 'count': len(approved)}, ""


def rollback_bank(version_id, username=''):
    conn = db.get_conn()
    with db.DB_LOCK:
        row = conn.execute("SELECT * FROM bank_versions WHERE id=?",
                           (version_id,)).fetchone()
        if row is None:
            return None, "版本不存在"
        conn.execute("UPDATE bank_versions SET is_current=0")
        conn.execute("UPDATE bank_versions SET is_current=1 WHERE id=?",
                     (version_id,))
        conn.commit()
    db.audit(username, 'bank_rollback', "回滚到 {0}".format(row['version_no']))
    return {'version': row['version_no']}, ""
