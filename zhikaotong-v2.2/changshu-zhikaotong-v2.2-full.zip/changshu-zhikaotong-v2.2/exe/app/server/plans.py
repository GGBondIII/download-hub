# -*- coding: utf-8 -*-
"""常熟站智考通 v2.2 — 学习计划下发:study_plans + tasks、去重进度。

照抄刷题宝 v0.7 server.py 317–335、1470–1498、2247 行的逻辑。
修复(合并方案§五-2):plan_progress 改为 COUNT(DISTINCT question_id),
同一题重复做只算 1 道;任务进度同理。进度来源取 attempts 与
practice_records 两处并集(按 question_id 去重),简答只算已批阅的。
Python 3.4 兼容语法。
"""
import json
from datetime import datetime

import db
import auth


def plan_progress(conn, plan, user_id):
    """学习计划进度:自计划创建起,该用户在目标知识点(为空=全部)上已作答的
    去重题数。同一题重复做只算 1 道。"""
    target = plan['target_count'] or 0
    created = plan['created_at'] or '2000-01-01'
    kn = plan['knowledge'] or ''
    done_ids = set()
    rows = conn.execute(
        "SELECT DISTINCT question_id FROM attempts WHERE user_id=?"
        " AND mode IN ('practice', 'exam') AND is_correct IS NOT NULL"
        " AND answered_at>=?", (user_id, created)).fetchall()
    done_ids.update([r[0] for r in rows])
    rows = conn.execute(
        "SELECT DISTINCT question_id FROM practice_records WHERE user_id=?"
        " AND answered_at>=?", (user_id, created)).fetchall()
    done_ids.update([r[0] for r in rows])
    if kn:
        keep = set()
        for qid in done_ids:
            r = conn.execute("SELECT category FROM questions WHERE id=?",
                             (qid,)).fetchone()
            if r and r[0] == kn:
                keep.add(qid)
        done_ids = keep
    done = len(done_ids)
    pct = round(done / target * 100) if target else 0
    due = plan['due_date'] or ''
    overdue = bool(due and due < datetime.now().strftime("%Y-%m-%d") and pct < 100)
    days_left = None
    if due:
        try:
            days_left = (datetime.strptime(due, "%Y-%m-%d").date()
                         - datetime.now().date()).days
        except Exception:
            days_left = None
    return {'done': done, 'target': target, 'pct': min(100, pct),
            'overdue': overdue, 'days_left': days_left,
            'daily_count': plan['daily_count'] or 0}


def create_plan(data, created_by_username, created_by_id=None):
    title = (data.get('title') or '').strip()
    if not title:
        return None, "计划要有名称"
    try:
        target_count = int(data.get('target_count') or 0)
    except (TypeError, ValueError):
        target_count = 0
    if target_count <= 0:
        return None, "目标题量要是大于 0 的整数"
    try:
        daily_count = int(data.get('daily_count') or 0)
    except (TypeError, ValueError):
        daily_count = 0
    due_date = (data.get('due_date') or '').strip()
    if due_date:
        try:
            datetime.strptime(due_date, "%Y-%m-%d")
        except Exception:
            return None, "截止日格式应为 YYYY-MM-DD"
    scope = data.get('scope') or 'team'
    if scope not in ('team', 'personal'):
        return None, "范围只能是 team(部门)或 personal(个人)"
    team = (data.get('team') or '').strip()
    target_uid = data.get('user_id')
    conn = db.get_conn()
    if scope == 'personal':
        try:
            target_uid = int(target_uid)
        except (TypeError, ValueError):
            return None, "个人计划要指定用户 ID"
        members = conn.execute("SELECT id, department FROM users WHERE id=?",
                               (target_uid,)).fetchall()
        if not members:
            return None, "指定用户不存在"
        team = members[0]['department'] or ''
    else:
        if not team:
            u = auth.get_user_by_id(created_by_id) if created_by_id else None
            team = u['department'] if u else ''
        members = conn.execute("SELECT id FROM users WHERE department=?",
                               (team,)).fetchall()
        if not members:
            return None, "该部门下没有用户"
    with db.DB_LOCK:
        cur = conn.execute(
            "INSERT INTO study_plans(title, team, target_count, due_date, created_by,"
            " created_at, knowledge, daily_count, scope, target_user_id)"
            " VALUES(?, ?, ?, ?, ?, datetime('now', 'localtime'), ?, ?, ?, ?)",
            (title, team, target_count, due_date, created_by_username,
             (data.get('knowledge') or '').strip(), daily_count, scope,
             target_uid if scope == 'personal' else None))
        pid = cur.lastrowid
        for mrow in members:
            conn.execute(
                "INSERT INTO tasks(plan_id, user_id, title, status, created_at, due_date)"
                " VALUES(?, ?, ?, 'pending', datetime('now', 'localtime'), ?)",
                (pid, mrow['id'], title, due_date))
        conn.commit()
    db.audit(created_by_username, 'plan_create',
             "学习计划 {0}《{1}》下发给 {2} 人".format(pid, title, len(members)))
    return {'plan_id': pid, 'assigned': len(members)}, ""


def list_plans():
    conn = db.get_conn()
    out = []
    with db.DB_LOCK:
        plans = conn.execute("SELECT * FROM study_plans ORDER BY id DESC").fetchall()
        for pl in plans:
            uids = [r[0] for r in conn.execute(
                "SELECT user_id FROM tasks WHERE plan_id=?", (pl['id'],)).fetchall()]
            pcts = [plan_progress(conn, pl, uid)['pct'] for uid in uids]
            out.append({'id': pl['id'], 'title': pl['title'], 'team': pl['team'],
                        'knowledge': pl['knowledge'],
                        'target_count': pl['target_count'],
                        'daily_count': pl['daily_count'],
                        'due_date': pl['due_date'], 'scope': pl['scope'],
                        'created_by': pl['created_by'],
                        'created_at': pl['created_at'],
                        'assigned': len(uids),
                        'done_count': sum(1 for p in pcts if p >= 100),
                        'avg_pct': round(sum(pcts) / len(pcts)) if pcts else 0})
    return out


def my_plans(user_id):
    conn = db.get_conn()
    out = []
    with db.DB_LOCK:
        plans = conn.execute(
            "SELECT sp.* FROM study_plans sp JOIN tasks t ON t.plan_id=sp.id"
            " WHERE t.user_id=? ORDER BY sp.due_date", (user_id,)).fetchall()
        for pl in plans:
            p = plan_progress(conn, pl, user_id)
            if p['pct'] >= 100:
                conn.execute(
                    "UPDATE tasks SET status='done' WHERE plan_id=? AND user_id=?",
                    (pl['id'], user_id))
            out.append({'id': pl['id'], 'title': pl['title'],
                        'knowledge': pl['knowledge'],
                        'due_date': pl['due_date'], 'done': p['done'],
                        'target': p['target'], 'pct': p['pct'],
                        'overdue': p['overdue'], 'days_left': p['days_left'],
                        'daily_count': p['daily_count']})
        conn.commit()
    return out
