# -*- coding: utf-8 -*-
"""常熟站智考通 v2.2 — 正式考试:创建/编辑/发布/结束/删除、固定试卷、名单、
成绩列表与 CSV 导出、阅卷回看、考生端开考/答题/交卷/迟交。

试卷模式:fixed 全员同一份卷(固定试卷,开考后不能重新生成);
random 每人开考时随机抽题(抽一次后锁定在该考生的 attempt.paper 里)。
交卷后服务端统一判分;填空自动判分,简答交卷后自评计分。
Python 3.4 兼容语法。
"""
import csv
import io
import json
import time

import auth
import db
import questions as qmod

DEFAULT_QSCORES = {"单选": 5, "多选": 10, "判断": 5, "填空": 5, "简答": 10}


def exam_to_dict(row, with_members=False):
    d = db.row_to_dict(row)
    if d is None:
        return None
    for k in ('qcounts', 'qscores'):
        try:
            d[k] = json.loads(d.get(k) or '{}')
        except ValueError:
            d[k] = {}
    try:
        d['fixed_paper'] = json.loads(d.get('fixed_paper') or '') if d.get('fixed_paper') else []
    except ValueError:
        d['fixed_paper'] = []
    if with_members:
        conn = db.get_conn()
        with db.DB_LOCK:
            rows = conn.execute("SELECT user_id FROM exam_members WHERE exam_id=?",
                                (d['id'],)).fetchall()
        d['members'] = [r[0] for r in rows]
    return d


def grade_paper(question_ids, answers, qscores):
    """统一判分。answers: {qid_str: {'a': 作答, 's': 自评 0/1/None}}。
    返回 (total_score, full_score, results, pending_ids)。
    results: [{question_id, type, user_answer, correct_answer, correct(None=待自评),
               score, full_score, analysis, options}]。"""
    total = 0.0
    full = 0.0
    results = []
    pending = []
    for qid in question_ids:
        row = qmod.get_question(qid)
        if row is None:
            continue
        q = qmod.question_to_dict(row)
        fs = float((qscores or {}).get(q['type'], DEFAULT_QSCORES.get(q['type'], 0)) or 0)
        full += fs
        ent = (answers or {}).get(str(qid)) or {}
        if isinstance(ent, dict):
            ua = ent.get('a', '')
            self_c = ent.get('s')
        else:
            ua = ent
            self_c = None
        correct, auto = qmod.grade_answer(q['type'], ua, q['answer'],
                                          self_correct=self_c)
        if correct is None:
            pending.append(qid)
            got = 0.0
        elif correct:
            got = fs
        else:
            got = 0.0
        total += got
        results.append({
            'question_id': qid, 'no': q.get('no'), 'type': q['type'],
            'stem': q['stem'], 'options': q.get('options') or {},
            'image': q.get('image') or '',
            'user_answer': ua, 'correct_answer': q['answer'],
            'correct': correct, 'score': got, 'full_score': fs,
            'analysis': q.get('analysis') or '',
        })
    return total, full, results, pending


def _recompute_attempt_score(attempt_id):
    conn = db.get_conn()
    with db.DB_LOCK:
        row = conn.execute("SELECT * FROM exam_attempts WHERE id=?", (attempt_id,)).fetchone()
    if row is None:
        return None
    paper = json.loads(row['paper'] or '[]')
    answers = json.loads(row['answers'] or '{}')
    exam = conn.execute("SELECT * FROM exams WHERE id=?", (row['exam_id'],)).fetchone()
    qscores = json.loads(exam['qscores'] or '{}') if exam else {}
    total, full, _r, _p = grade_paper(paper, answers, qscores)
    with db.DB_LOCK:
        conn.execute("UPDATE exam_attempts SET score=? WHERE id=?", (total, attempt_id))
        conn.commit()
    return total


def create_exam(data, created_by):
    name = (data.get('name') or '').strip()
    if not name:
        return None, "考试名称不能为空"
    duration = int(data.get('duration_min') or 60)
    if duration <= 0:
        return None, "时长必须大于 0 分钟"
    qcounts = data.get('qcounts') or {}
    qscores = data.get('qscores') or {}
    mode = data.get('mode') or 'fixed'
    if mode not in ('fixed', 'random'):
        mode = 'fixed'
    conn = db.get_conn()
    with db.DB_LOCK:
        cur = conn.execute(
            "INSERT INTO exams(name, subject, duration_min, shuffle, mode, qcounts, qscores,"
            " start_at, end_at, status, fixed_paper, created_by, created_at)"
            " VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, '草稿', '', ?, datetime('now', 'localtime'))",
            (name, (data.get('subject') or '').strip(), duration,
             1 if data.get('shuffle') else 0, mode,
             json.dumps(qcounts, ensure_ascii=False),
             json.dumps(qscores, ensure_ascii=False),
             data.get('start_at') or '', data.get('end_at') or '', created_by))
        exam_id = cur.lastrowid
        for uid in (data.get('members') or []):
            conn.execute("INSERT OR IGNORE INTO exam_members(exam_id, user_id) VALUES(?, ?)",
                         (exam_id, uid))
        conn.commit()
        row = conn.execute("SELECT * FROM exams WHERE id=?", (exam_id,)).fetchone()
    return exam_to_dict(row, with_members=True), ""


def update_exam(exam_id, data):
    conn = db.get_conn()
    with db.DB_LOCK:
        row = conn.execute("SELECT * FROM exams WHERE id=?", (exam_id,)).fetchone()
    if row is None:
        return None, "考试不存在"
    if row['status'] == '已结束':
        return None, "已结束的考试不能再编辑"
    d = exam_to_dict(row)
    for k in ('name', 'subject', 'duration_min', 'shuffle', 'mode', 'qcounts',
              'qscores', 'start_at', 'end_at'):
        if k in data:
            d[k] = data[k]
    if not (d.get('name') or '').strip():
        return None, "考试名称不能为空"
    with db.DB_LOCK:
        conn.execute(
            "UPDATE exams SET name=?, subject=?, duration_min=?, shuffle=?, mode=?,"
            " qcounts=?, qscores=?, start_at=?, end_at=? WHERE id=?",
            (d['name'], d.get('subject') or '', int(d.get('duration_min') or 60),
             1 if d.get('shuffle') else 0, d.get('mode') or 'fixed',
             json.dumps(d.get('qcounts') or {}, ensure_ascii=False),
             json.dumps(d.get('qscores') or {}, ensure_ascii=False),
             d.get('start_at') or '', d.get('end_at') or '', exam_id))
        if 'members' in data:
            conn.execute("DELETE FROM exam_members WHERE exam_id=?", (exam_id,))
            for uid in (data.get('members') or []):
                conn.execute("INSERT OR IGNORE INTO exam_members(exam_id, user_id) VALUES(?, ?)",
                             (exam_id, uid))
        conn.commit()
        row = conn.execute("SELECT * FROM exams WHERE id=?", (exam_id,)).fetchone()
    return exam_to_dict(row, with_members=True), ""


def set_exam_status(exam_id, status):
    if status not in ('草稿', '已发布', '已结束'):
        return False, "状态不合法"
    conn = db.get_conn()
    with db.DB_LOCK:
        cur = conn.execute("UPDATE exams SET status=? WHERE id=?", (status, exam_id))
        conn.commit()
    if cur.rowcount == 0:
        return False, "考试不存在"
    return True, ""


def delete_exam(exam_id):
    conn = db.get_conn()
    with db.DB_LOCK:
        row = conn.execute("SELECT * FROM exams WHERE id=?", (exam_id,)).fetchone()
        if row is None:
            return None, "考试不存在"
        submitted = conn.execute(
            "SELECT COUNT(*) FROM exam_attempts WHERE exam_id=? AND status IN ('已交卷', '迟交')",
            (exam_id,)).fetchone()[0]
        ongoing = conn.execute(
            "SELECT COUNT(*) FROM exam_attempts WHERE exam_id=? AND status='进行中'",
            (exam_id,)).fetchone()[0]
        conn.execute("DELETE FROM exam_attempts WHERE exam_id=?", (exam_id,))
        conn.execute("DELETE FROM exam_members WHERE exam_id=?", (exam_id,))
        conn.execute("DELETE FROM exams WHERE id=?", (exam_id,))
        conn.commit()
    return {'submitted': submitted, 'ongoing': ongoing}, ""


def generate_fixed_paper(exam_id):
    """按题型数量抽一次题并锁定。已生成过(或已有考生开考)则拒绝重新生成。"""
    conn = db.get_conn()
    with db.DB_LOCK:
        row = conn.execute("SELECT * FROM exams WHERE id=?", (exam_id,)).fetchone()
    if row is None:
        return None, "考试不存在"
    if row['fixed_paper']:
        return None, "固定试卷已生成,开考后不能再重新生成"
    started = conn.execute("SELECT COUNT(*) FROM exam_attempts WHERE exam_id=?",
                           (exam_id,)).fetchone()[0]
    if started:
        return None, "已有考生开考,不能再生成固定试卷"
    qcounts = json.loads(row['qcounts'] or '{}')
    qids = qmod.sample_questions(qcounts)
    with db.DB_LOCK:
        conn.execute("UPDATE exams SET fixed_paper=? WHERE id=?",
                     (json.dumps(qids), exam_id))
        conn.commit()
    return qids, ""


def list_exams(status='', for_user_id=None):
    conn = db.get_conn()
    with db.DB_LOCK:
        if for_user_id is not None:
            rows = conn.execute(
                "SELECT e.* FROM exams e JOIN exam_members m ON m.exam_id=e.id"
                " WHERE m.user_id=? ORDER BY e.id DESC", (for_user_id,)).fetchall()
        elif status:
            rows = conn.execute("SELECT * FROM exams WHERE status=? ORDER BY id DESC",
                                (status,)).fetchall()
        else:
            rows = conn.execute("SELECT * FROM exams ORDER BY id DESC").fetchall()
    return [exam_to_dict(r, with_members=True) for r in rows]


def exam_results(exam_id):
    conn = db.get_conn()
    with db.DB_LOCK:
        exam = conn.execute("SELECT * FROM exams WHERE id=?", (exam_id,)).fetchone()
        if exam is None:
            return None, "考试不存在"
        members = conn.execute(
            "SELECT u.id, u.username, u.name, u.department FROM exam_members m"
            " JOIN users u ON u.id=m.user_id WHERE m.exam_id=? ORDER BY u.department, u.id",
            (exam_id,)).fetchall()
        attempts = conn.execute(
            "SELECT * FROM exam_attempts WHERE exam_id=?", (exam_id,)).fetchall()
    att_by_user = {}
    for a in attempts:
        att_by_user[a['user_id']] = a
    scores = [a['score'] for a in attempts
              if a['status'] in ('已交卷', '迟交') and a['score'] is not None]
    summary = {
        'exam': exam_to_dict(exam, with_members=True),
        'total_members': len(members),
        'submitted': len(scores),
        'average': round(sum(scores) / len(scores), 1) if scores else 0,
    }
    lst = []
    for m in members:
        a = att_by_user.get(m['id'])
        lst.append({
            'user_id': m['id'], 'username': m['username'], 'name': m['name'],
            'department': m['department'],
            'status': a['status'] if a else '未开始',
            'submitted_at': a['submitted_at'] if a else '',
            'score': a['score'] if a else None,
        })
    summary['list'] = lst
    return summary, ""


def results_csv(exam_id):
    summary, err = exam_results(exam_id)
    if err:
        return None, err
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(['姓名', '用户名', '部门', '状态', '交卷时间', '得分'])
    for item in summary['list']:
        w.writerow([item['name'], item['username'], item['department'],
                    item['status'], item['submitted_at'],
                    '' if item['score'] is None else item['score']])
    return buf.getvalue(), ""


# ---------------- 考生端 ----------------

def _paper_for_attempt(exam, attempt_paper):
    if exam['mode'] == 'fixed':
        return json.loads(exam['fixed_paper'] or '[]')
    return json.loads(attempt_paper or '[]')


def start_exam(user_id, exam_id):
    conn = db.get_conn()
    with db.DB_LOCK:
        exam = conn.execute("SELECT * FROM exams WHERE id=?", (exam_id,)).fetchone()
        if exam is None:
            return None, "考试不存在"
        if exam['status'] != '已发布':
            return None, "考试尚未发布"
        mem = conn.execute("SELECT 1 FROM exam_members WHERE exam_id=? AND user_id=?",
                           (exam_id, user_id)).fetchone()
        if not mem:
            return None, "您不在本次考试名单内"
        att = conn.execute(
            "SELECT * FROM exam_attempts WHERE exam_id=? AND user_id=?",
            (exam_id, user_id)).fetchone()
        if att is not None:
            if att['status'] in ('已交卷', '迟交'):
                return None, "您已交卷,不能再进入"
            paper = _paper_for_attempt(exam, att['paper'])
            return {'attempt_id': att['id'], 'exam': exam_to_dict(exam),
                    'paper': paper, 'answers': json.loads(att['answers'] or '{}'),
                    'started_at': att['started_at'], 'resumed': True}, ""
        if exam['mode'] == 'fixed':
            paper = json.loads(exam['fixed_paper'] or '[]')
            if not paper:
                return None, "固定试卷尚未生成,请联系考官"
        else:
            qcounts = json.loads(exam['qcounts'] or '{}')
            paper = qmod.sample_questions(qcounts)
            if not paper:
                return None, "题库中没有符合要求的题目"
            if exam['shuffle']:
                import random
                random.shuffle(paper)
        cur = conn.execute(
            "INSERT INTO exam_attempts(exam_id, user_id, answers, score, status, started_at, submitted_at, paper)"
            " VALUES(?, ?, '{}', NULL, '进行中', datetime('now', 'localtime'), '', ?)",
            (exam_id, user_id, json.dumps(paper)))
        conn.commit()
        att_id = cur.lastrowid
    return {'attempt_id': att_id, 'exam': exam_to_dict(exam),
            'paper': paper, 'answers': {},
            'started_at': time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),
            'resumed': False}, ""


def save_exam_answer(user_id, exam_id, question_id, answer):
    conn = db.get_conn()
    with db.DB_LOCK:
        att = conn.execute(
            "SELECT * FROM exam_attempts WHERE exam_id=? AND user_id=?",
            (exam_id, user_id)).fetchone()
        if att is None:
            return False, "请先开始考试"
        if att['status'] in ('已交卷', '迟交'):
            return False, "已交卷,不能再修改"
        answers = json.loads(att['answers'] or '{}')
        ent = answers.get(str(question_id)) or {}
        if not isinstance(ent, dict):
            ent = {'a': ent, 's': None}
        ent['a'] = answer or ''
        answers[str(question_id)] = ent
        conn.execute("UPDATE exam_attempts SET answers=? WHERE id=?",
                     (json.dumps(answers, ensure_ascii=False), att['id']))
        conn.commit()
    return True, ""


def submit_exam(user_id, exam_id, late=False):
    conn = db.get_conn()
    with db.DB_LOCK:
        att = conn.execute(
            "SELECT * FROM exam_attempts WHERE exam_id=? AND user_id=?",
            (exam_id, user_id)).fetchone()
        if att is None:
            return None, "请先开始考试"
        if att['status'] in ('已交卷', '迟交'):
            return None, "已交卷,不能重复提交"
        exam = conn.execute("SELECT * FROM exams WHERE id=?", (exam_id,)).fetchone()
        paper = _paper_for_attempt(exam, att['paper'])
        answers = json.loads(att['answers'] or '{}')
        qscores = json.loads(exam['qscores'] or '{}')
        total, full, results, pending = grade_paper(paper, answers, qscores)
        status = '迟交' if late else '已交卷'
        conn.execute(
            "UPDATE exam_attempts SET answers=?, score=?, status=?, submitted_at=datetime('now', 'localtime')"
            " WHERE id=?",
            (json.dumps(answers, ensure_ascii=False), total, status, att['id']))
        conn.commit()
        # v2:顺带写 attempts 表 + FSRS 调度;简答进人工批阅队列(不自动判分)
        import adaptive as adaptive_mod
        import essay as essay_mod
        for r in results:
            if r['type'] == '简答' and r['correct'] is None:
                ent = answers.get(str(r['question_id'])) or {}
                ua = ent.get('a', '') if isinstance(ent, dict) else ent
                essay_mod.enqueue_from_exam(user_id, r['question_id'], ua,
                                            att['id'])
            elif r['correct'] is not None:
                ent = answers.get(str(r['question_id'])) or {}
                ua = ent.get('a', '') if isinstance(ent, dict) else ent
                adaptive_mod.record_attempt(user_id, r['question_id'], 'exam',
                                            ua, r['correct'])
    answered = len([k for k, v in answers.items()
                    if (v.get('a') if isinstance(v, dict) else v)])
    return {'attempt_id': att['id'], 'score': total, 'full_score': full,
            'status': status, 'answered': answered, 'total_questions': len(paper),
            'pending_self_grade': pending, 'results': results}, ""


def exam_result_for_user(user_id, exam_id):
    conn = db.get_conn()
    with db.DB_LOCK:
        att = conn.execute(
            "SELECT * FROM exam_attempts WHERE exam_id=? AND user_id=?",
            (exam_id, user_id)).fetchone()
        if att is None:
            return None, "暂无考试记录"
        exam = conn.execute("SELECT * FROM exams WHERE id=?", (exam_id,)).fetchone()
        paper = _paper_for_attempt(exam, att['paper'])
        answers = json.loads(att['answers'] or '{}')
        qscores = json.loads(exam['qscores'] or '{}')
        total, full, results, pending = grade_paper(paper, answers, qscores)
    return {'attempt_id': att['id'], 'exam': exam_to_dict(exam),
            'status': att['status'], 'score': att['score'],
            'full_score': full, 'submitted_at': att['submitted_at'],
            'pending_self_grade': pending, 'results': results}, ""


def self_grade_exam(user_id, exam_id, question_id, correct):
    """正式考试简答自评:我答对了/我答错了,自评后计入总分。"""
    conn = db.get_conn()
    with db.DB_LOCK:
        att = conn.execute(
            "SELECT * FROM exam_attempts WHERE exam_id=? AND user_id=?",
            (exam_id, user_id)).fetchone()
        if att is None:
            return False, "暂无考试记录"
        if att['status'] not in ('已交卷', '迟交'):
            return False, "请先交卷再自评"
        row = qmod.get_question(question_id)
        if row is None or row['type'] != '简答':
            return False, "只有简答题需要自评"
        answers = json.loads(att['answers'] or '{}')
        ent = answers.get(str(question_id)) or {}
        if not isinstance(ent, dict):
            ent = {'a': ent, 's': None}
        ent['s'] = 1 if correct else 0
        answers[str(question_id)] = ent
        conn.execute("UPDATE exam_attempts SET answers=? WHERE id=?",
                     (json.dumps(answers, ensure_ascii=False), att['id']))
        conn.commit()
    _recompute_attempt_score(att['id'])
    return True, ""
