# -*- coding: utf-8 -*-
"""常熟站智考通 v2.2 — 组卷模板:增删改查、按模板生成试卷、按模板开考、打印成绩单。

照抄刷题宝 v0.7 server.py 1498–1516、2577 行与 sample_by_template 的逻辑。
修复(合并方案§五-3):按模板生成试卷时用 rules_json 里全部题型的配比
(含简答、填空)调 questions.sample_questions,不只取客观题。
Python 3.4 兼容语法。
"""
import json
import random

import db
import auth
import exams as exam_mod
import questions as qmod

DEFAULT_QSCORES = {"单选": 5, "多选": 10, "判断": 5, "填空": 5, "简答": 10}


def list_templates():
    conn = db.get_conn()
    with db.DB_LOCK:
        rows = conn.execute("SELECT * FROM paper_templates ORDER BY id DESC").fetchall()
    out = []
    for r in rows:
        d = db.row_to_dict(r)
        try:
            d['rules'] = json.loads(d.get('rules_json') or '{}')
        except ValueError:
            d['rules'] = {}
        out.append(d)
    return out


def get_template(tid):
    conn = db.get_conn()
    with db.DB_LOCK:
        row = conn.execute("SELECT * FROM paper_templates WHERE id=?", (tid,)).fetchone()
    if row is None:
        return None
    d = db.row_to_dict(row)
    try:
        d['rules'] = json.loads(d.get('rules_json') or '{}')
    except ValueError:
        d['rules'] = {}
    return d


def create_template(title, subject='', total_count=10, rules=None, created_by=''):
    title = (title or '').strip()
    if not title:
        return None, "模板要有标题"
    if rules is None:
        rules = {}
    if isinstance(rules, str):
        try:
            rules = json.loads(rules)
        except ValueError:
            return None, "配比规则不是有效 JSON"
    conn = db.get_conn()
    with db.DB_LOCK:
        cur = conn.execute(
            "INSERT INTO paper_templates(title, subject, total_count, rules_json,"
            " created_by, created_at) VALUES(?, ?, ?, ?, ?, datetime('now', 'localtime'))",
            (title, subject or '', int(total_count or 10),
             json.dumps(rules, ensure_ascii=False), created_by or ''))
        tid = cur.lastrowid
        conn.commit()
    db.audit(created_by, 'template_create', "组卷模板 {0} {1}".format(tid, title))
    return {'template_id': tid}, ""


def delete_template(tid):
    conn = db.get_conn()
    with db.DB_LOCK:
        cur = conn.execute("DELETE FROM paper_templates WHERE id=?", (tid,))
        conn.commit()
    if cur.rowcount == 0:
        return False, "模板不存在"
    return True, ""


def sample_by_template(conn, rules, total_count):
    """按模板配比抽题。rules 可含:
    type_counts: {题型: 数量}(全部五种题型,含简答/填空)——优先;
    knowledge_weights: {知识点: 权重};difficulty_dist: {难度: 权重}。
    疑似错题排除;不足时用其余启用题补足。"""
    import quality as quality_mod
    sus = quality_mod.suspect_qids(conn)
    rules = rules or {}
    tc = rules.get('type_counts') or {}
    picked = []
    seen = set()
    if tc:
        # 全部题型配比(含简答、填空):直接调 sample_questions
        qcounts = dict([(k, int(v or 0)) for k, v in tc.items()
                        if k in qmod.Q_TYPES and int(v or 0) > 0])
        ids = qmod.sample_questions(qcounts)
        picked = [i for i in ids if i not in sus]
        seen = set(picked)
    kw = rules.get('knowledge_weights') or {}
    dd = rules.get('difficulty_dist') or {}
    if kw or dd:
        rows = conn.execute(
            "SELECT id FROM questions WHERE status='启用' ORDER BY id").fetchall()
        pool_all = [r[0] for r in rows if r[0] not in sus and r[0] not in seen]
        if kw:
            tot_w = sum(int(v) for v in kw.values()) or 1
            for kn, w in kw.items():
                n = max(0, int(round(total_count * int(w) / tot_w)))
                sub = [qid for qid in pool_all
                       if _question_category(conn, qid) == kn]
                random.shuffle(sub)
                for qid in sub[:n]:
                    picked.append(qid)
                    seen.add(qid)
        if dd:
            tot_w = sum(int(v) for v in dd.values()) or 1
            for dstr, w in dd.items():
                n = max(0, int(round(total_count * int(w) / tot_w)))
                sub = [qid for qid in pool_all
                       if _question_difficulty(conn, qid) == int(dstr)]
                random.shuffle(sub)
                for qid in sub[:n]:
                    picked.append(qid)
                    seen.add(qid)
    rest = [r[0] for r in conn.execute(
        "SELECT id FROM questions WHERE status='启用' ORDER BY id").fetchall()
        if r[0] not in sus and r[0] not in seen]
    random.shuffle(rest)
    picked += rest[:max(0, total_count - len(picked))]
    return picked[:total_count]


def _question_category(conn, qid):
    r = conn.execute("SELECT category FROM questions WHERE id=?", (qid,)).fetchone()
    return r[0] if r else ''


def _question_difficulty(conn, qid):
    r = conn.execute("SELECT difficulty FROM questions WHERE id=?", (qid,)).fetchone()
    return r[0] if r and r[0] is not None else 3


def start_exam_from_template(user_id, template_id, duration_min=60, members=None):
    """按模板开考:新建一场正式考试(固定试卷、已发布、template_id 回填),
    试卷按模板全部题型配比生成。members 为 None 时:学员本人只给自己;
    考官/管理员默认给全部在用学员。返回 (exam_dict, error)。"""
    conn = db.get_conn()
    with db.DB_LOCK:
        trow = conn.execute("SELECT * FROM paper_templates WHERE id=?",
                            (template_id,)).fetchone()
    if trow is None:
        return None, "组卷模板不存在"
    try:
        rules = json.loads(trow['rules_json'] or '{}')
    except ValueError:
        rules = {}
    total_count = int(trow['total_count'] or 10)
    tc = rules.get('type_counts') or {}
    qcounts = dict([(k, int(v or 0)) for k, v in tc.items()
                    if k in qmod.Q_TYPES and int(v or 0) > 0])
    if not qcounts:
        qcounts = {'单选': total_count}
    qids = sample_by_template(conn, rules, total_count)
    if not qids:
        return None, "模板抽题为空,请检查配比"
    user = auth.get_user_by_id(user_id)
    role = user['role'] if user else 'student'
    if members is None:
        if role in ('admin', 'examiner'):
            members = [r[0] for r in conn.execute(
                "SELECT id FROM users WHERE role='student' AND status='正常'").fetchall()]
        else:
            members = [user_id]
    with db.DB_LOCK:
        cur = conn.execute(
            "INSERT INTO exams(name, subject, duration_min, shuffle, mode, qcounts,"
            " qscores, start_at, end_at, status, fixed_paper, created_by, created_at,"
            " template_id)"
            " VALUES(?, ?, ?, 0, 'fixed', ?, ?, '', '', '已发布', ?, ?,"
            " datetime('now', 'localtime'), ?)",
            (trow['title'], trow['subject'] or '',
             int(duration_min or 60),
             json.dumps(qcounts, ensure_ascii=False),
             json.dumps(DEFAULT_QSCORES, ensure_ascii=False),
             json.dumps(qids), user_id, template_id))
        exam_id = cur.lastrowid
        for uid in members:
            conn.execute("INSERT OR IGNORE INTO exam_members(exam_id, user_id)"
                         " VALUES(?, ?)", (exam_id, uid))
        conn.commit()
        row = conn.execute("SELECT * FROM exams WHERE id=?", (exam_id,)).fetchone()
    db.audit(user['username'] if user else '', 'template_start',
             "模板 {0} 开考,考试 {1},{2} 题".format(template_id, exam_id, len(qids)))
    return exam_mod.exam_to_dict(row, with_members=True), ""


def exam_print_html(exam_id, focus_user_id=None):
    """打印成绩单 HTML:选择题与简答题分开列示(合并方案§五-3)。
    focus_user_id 给出时附该考生的逐题明细;否则只列全员成绩表。"""
    summary, err = exam_mod.exam_results(exam_id)
    if err:
        return None, err
    exam = summary['exam']
    rows = ""
    for i, item in enumerate(summary['list']):
        score = '' if item['score'] is None else item['score']
        rows += ("<tr><td>{0}</td><td>{1}</td><td>{2}</td><td>{3}</td>"
                 "<td>{4}</td><td>{5}</td></tr>").format(
                     i + 1, item['name'], item['department'], item['status'],
                     item['submitted_at'] or '', score)
    detail_html = ""
    if focus_user_id:
        res, err2 = exam_mod.exam_result_for_user(focus_user_id, exam_id)
        if not err2:
            obj_rows = ""
            ess_rows = ""
            for j, r in enumerate(res['results']):
                ua = r['user_answer'] or '未答'
                if r['type'] == '简答':
                    mark = '待自评/待批阅' if r['correct'] is None else (
                        '对' if r['correct'] else '错')
                    ess_rows += ("<tr><td>{0}</td><td>{1}</td><td>{2}</td>"
                                 "<td>{3}</td><td>{4}</td></tr>").format(
                                     j + 1, r['stem'], ua, r['correct_answer'], mark)
                else:
                    mark = '对' if r['correct'] else '错'
                    obj_rows += ("<tr><td>{0}</td><td>{1}</td><td>{2}</td>"
                                 "<td>{3}</td><td>{4}</td></tr>").format(
                                     j + 1, r['stem'], ua, r['correct_answer'], mark)
            detail_html = ("<h2>逐题明细(选择题)</h2><table><tr><th>#</th><th>题干</th>"
                           "<th>你的答案</th><th>正确答案</th><th>对错</th></tr>{0}</table>"
                           "<h2>逐题明细(简答题,另行人工批阅)</h2><table><tr><th>#</th>"
                           "<th>题干</th><th>你的答案</th><th>参考答案</th><th>结果</th></tr>"
                           "{1}</table>").format(obj_rows, ess_rows)
    html = ("<!DOCTYPE html><html><head><meta charset='utf-8'><title>成绩单</title>"
            "<style>body{{font-family:sans-serif;font-size:15px;line-height:1.6}}"
            "table{{border-collapse:collapse;width:100%}}td,th{{border:1px solid #999;"
            "padding:8px;text-align:left}}h1{{font-size:22px}}</style></head><body>"
            "<h1>阶段考核成绩单</h1><p>考试:{0} · 应考 {1} 人 · 已交卷 {2} 人 · "
            "平均分 {3}</p>"
            "<table><tr><th>#</th><th>姓名</th><th>部门</th><th>状态</th>"
            "<th>交卷时间</th><th>得分</th></tr>{4}</table>{5}"
            "<p>打印:浏览器菜单 → 打印。本页仅供打印/存档,成绩以系统记录为准。"
            "简答题由教官人工批阅,与选择题分开列示。</p></body></html>").format(
                exam['name'], summary['total_members'], summary['submitted'],
                summary['average'], rows, detail_html)
    return html, ""
