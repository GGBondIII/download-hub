# -*- coding: utf-8 -*-
"""常熟站智考通 v2.2 — 共享服务器核心入口。

Python 标准库 + SQLite,零依赖、零 CDN。exe 与网页版共用同一套服务器代码。
监听 0.0.0.0:8766(环境变量 ZHIKAOTONG_PORT 可改)。
路由:/ 与 /lite 与 /static/* 与 /showcase.html(静态文件服务,页面由后续
网页版代理提供,此处为占位页)、/api/*(JSON API)、/api/v2/*(v2 新增功能)。
会话用 Cookie token(zk_token),也接受 X-Token / Authorization: Bearer。
首次启动自动建库并播种(见 seed.py)。
全部 Python 3.4 兼容语法:无 f-string、无 3.5+ 语法与库。
"""
import base64
import json
import mimetypes
import os
import re
import sys
import threading
from socketserver import ThreadingMixIn
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs, unquote

import db
import auth
import seed
import questions as qmod
import practice as practice_mod
import mock as mock_mod
import exams as exam_mod
import reports as report_mod
import admin as admin_mod
import import_xlsx
import import_docx
# v2.0 新增服务器模块(合并方案§四)
import adaptive as adaptive_mod
import quality as quality_mod
import templates as templates_mod
import plans as plans_mod
import essay as essay_mod
import federation as fed_mod
import backup as backup_mod
import ai_variants as ai_mod
import import_pdf
import pairing as pairing_mod
import dashboard as dashboard_mod
import import_jobs as import_jobs_mod

if getattr(sys, "frozen", False):
    BASE = os.path.dirname(os.path.abspath(sys.executable))
    SRC_BASE = getattr(sys, "_MEIPASS", BASE)
else:
    BASE = os.path.dirname(os.path.abspath(__file__))
    SRC_BASE = BASE
DATA_DIR = os.environ.get("ZHIKAOTONG_DATA_DIR") or os.path.join(BASE, "data")
ASSETS_DIR = os.path.join(DATA_DIR, "assets")
STATIC_DIR = os.path.join(SRC_BASE, "static")
DB_PATH = os.path.join(DATA_DIR, "zhikaotong.db")
PORT = int(os.environ.get("ZHIKAOTONG_PORT", "8766"))
HOST = os.environ.get("ZHIKAOTONG_HOST", "0.0.0.0")
VERSION = "v2.2"
APP_NAME = "常熟站智考通"
MAX_BODY = 20 * 1024 * 1024

db.configure(DB_PATH)


def _parse_cookies(header):
    out = {}
    if not header:
        return out
    for part in header.split(';'):
        if '=' in part:
            k, v = part.split('=', 1)
            out[k.strip()] = v.strip()
    return out


class Handler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'

    # ---------- 通用工具 ----------
    def log_message(self, fmt, *args):
        sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))

    def send_json(self, obj, status=200, set_cookie=None):
        body = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        if set_cookie:
            self.send_header('Set-Cookie', set_cookie)
        self.end_headers()
        self.wfile.write(body)

    def send_text(self, body, status=200, ctype='text/plain; charset=utf-8'):
        if isinstance(body, str):
            body = body.encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def send_file(self, path, ctype=None):
        try:
            with open(path, 'rb') as f:
                data = f.read()
        except OSError:
            self.send_text('Not Found', status=404)
            return
        if ctype is None:
            ctype = mimetypes.guess_type(path)[0] or 'application/octet-stream'
        self.send_response(200)
        self.send_header('Content-Type', ctype)
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def read_json_body(self):
        length = int(self.headers.get('Content-Length') or 0)
        if length <= 0:
            return {}
        if length > MAX_BODY:
            return None
        raw = self.rfile.read(length)
        if not raw:
            return {}
        try:
            return json.loads(raw.decode('utf-8'))
        except (ValueError, UnicodeDecodeError):
            return None

    def current_user(self):
        token = None
        cookies = _parse_cookies(self.headers.get('Cookie'))
        token = cookies.get('zk_token')
        if not token:
            token = self.headers.get('X-Token')
        if not token:
            authz = self.headers.get('Authorization') or ''
            if authz.startswith('Bearer '):
                token = authz[7:]
        if not token:
            return None
        row = auth.verify_token(token)
        if row is None:
            return None
        return auth.public_user(row)

    def need_login(self):
        user = self.current_user()
        if user is None:
            self.send_json({'ok': False, 'error': '请先登录'}, status=401)
            return None
        return user

    def need_role(self, roles):
        user = self.need_login()
        if user is None:
            return None
        if user['role'] not in roles:
            self.send_json({'ok': False, 'error': '没有权限'}, status=403)
            return None
        return user

    def ok(self, data=None, **kw):
        out = {'ok': True}
        if data is not None:
            out['data'] = data
        out.update(kw)
        return out

    def err(self, msg, status=400):
        self.send_json({'ok': False, 'error': msg}, status=status)

    # ---------- 静态 ----------
    def serve_static(self, path):
        if path == '/' or path == '/index.html':
            return self.send_file(os.path.join(STATIC_DIR, 'index.html'),
                                  'text/html; charset=utf-8')
        if path == '/lite':
            return self.send_file(os.path.join(STATIC_DIR, 'lite.html'),
                                  'text/html; charset=utf-8')
        if path == '/showcase.html':
            return self.send_file(os.path.join(STATIC_DIR, 'showcase.html'),
                                  'text/html; charset=utf-8')
        if path.startswith('/static/'):
            name = unquote(path[len('/static/'):])
            safe = os.path.normpath(name).replace('\\', '/')
            if safe.startswith('..') or safe.startswith('/'):
                return self.send_text('Not Found', status=404)
            return self.send_file(os.path.join(STATIC_DIR, safe))
        if path.startswith('/assets/'):
            name = unquote(path[len('/assets/'):])
            safe = os.path.normpath(name).replace('\\', '/')
            if safe.startswith('..') or safe.startswith('/'):
                return self.send_text('Not Found', status=404)
            return self.send_file(os.path.join(ASSETS_DIR, safe))
        return self.send_text('Not Found', status=404)

    # ---------- GET ----------
    def do_GET(self):
        try:
            self._do_GET()
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            self.log_message("GET error: %r", e)
            try:
                self.send_json({'ok': False, 'error': '服务器内部错误: {0}'.format(e)},
                               status=500)
            except Exception:
                pass

    def _do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        qs = parse_qs(parsed.query)
        q = {}
        for k, v in qs.items():
            q[k] = v[0] if v else ''
        if not path.startswith('/api/'):
            return self.serve_static(path)
        # ---- 公开 ----
        if path == '/api/version':
            platform = q.get('platform', '')
            v = admin_mod.latest_version(platform) if platform else None
            return self.send_json(self.ok({'current_version': VERSION,
                                           'app_name': APP_NAME,
                                           'latest': v}))
        if path == '/api/questions/template':
            user = self.need_role(('admin', 'examiner'))
            if user is None:
                return
            tpl = os.path.join(SRC_BASE, 'question-import-template.xlsx')
            if not os.path.exists(tpl):
                return self.err('模板文件不存在')
            return self.send_file(tpl, 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        # ---- 联邦目录:只认联邦令牌,不认登录态(对方服务器没有本站 Cookie) ----
        # 注意:此接口与 /api/v2/federation/package 同为机对机接口,不包 data 信封,
        # 返回 {"ok": true, "catalog": ...}(与 v07 格式一致,拉取方直接读 catalog)。
        if path == '/api/v2/federation/catalog':
            import hmac
            if not hmac.compare_digest(q.get('token', ''), fed_mod.fed_token()):
                return self.err('联邦令牌不正确', status=401)
            return self.send_json({'ok': True, 'catalog': fed_mod.catalog_data()})
        # ---- 需登录 ----
        user = self.need_login()
        if user is None:
            return
        if path.startswith('/api/v2/'):
            return self._v2_get(path, q, user)
        uid = user['id']
        if path == '/api/me':
            return self.send_json(self.ok(user))
        if path == '/api/home/stats':
            stats = practice_mod.get_stats(uid)
            cur_mock = mock_mod.current_mock(uid)
            return self.send_json(self.ok({
                'user': user, 'practice': stats,
                'ongoing_mock': cur_mock,
                'invite_code': db.get_setting('invite_code', 'CS2026'),
                'app_version': VERSION}))
        if path == '/api/questions/categories':
            return self.send_json(self.ok(qmod.list_categories()))
        if path == '/api/questions':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            total, items = qmod.list_questions(
                keyword=q.get('q', ''), qtype=q.get('type', ''),
                category=q.get('category', ''), status=q.get('status', ''),
                page=int(q.get('page') or 1), page_size=int(q.get('page_size') or 20))
            return self.send_json(self.ok({'total': total, 'items': items,
                                           'page': int(q.get('page') or 1),
                                           'page_size': int(q.get('page_size') or 20)}))
        m = re.match(r'^/api/questions/(\d+)$', path)
        if m:
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            row = qmod.get_question(int(m.group(1)))
            if row is None:
                return self.err('题目不存在', status=404)
            return self.send_json(self.ok(qmod.question_to_dict(row)))
        if path == '/api/practice/list':
            ids = practice_mod.build_list(
                uid, q.get('mode', '顺序'), category=q.get('category', ''),
                qtype=q.get('type', ''), count=int(q.get('count') or 0),
                seed=int(q.get('seed') or 0))
            return self.send_json(self.ok({
                'mode': q.get('mode', '顺序'), 'total': len(ids),
                'questions': practice_mod.get_questions_for_list(ids)}))
        if path == '/api/practice/stats':
            return self.send_json(self.ok(practice_mod.get_stats(uid)))
        if path == '/api/wrongbook':
            return self.send_json(self.ok(practice_mod.wrong_book_list(uid)))
        if path == '/api/reports/mine':
            return self.send_json(self.ok(report_mod.my_reports(uid)))
        if path == '/api/mock/current':
            cur = mock_mod.current_mock(uid)
            if cur is None:
                return self.send_json(self.ok(None))
            cur['question_detail'] = practice_mod.get_questions_for_list(cur['questions'])
            return self.send_json(self.ok(cur))
        if path == '/api/mock/history':
            return self.send_json(self.ok(mock_mod.mock_history(uid)))
        m = re.match(r'^/api/mock/(\d+)$', path)
        if m:
            att, err = mock_mod.get_mock(int(m.group(1)), uid)
            if err:
                return self.err(err, status=404)
            att['question_detail'] = practice_mod.get_questions_for_list(att['questions'])
            return self.send_json(self.ok(att))
        m = re.match(r'^/api/mock/(\d+)/detail$', path)
        if m:
            detail, err = mock_mod.mock_detail(uid, int(m.group(1)))
            if err:
                return self.err(err, status=404)
            return self.send_json(self.ok(detail))
        if path == '/api/exams/mine':
            exams = exam_mod.list_exams(for_user_id=uid)
            out = []
            for e in exams:
                item = dict(e)
                att = None
                conn = db.get_conn()
                with db.DB_LOCK:
                    row = conn.execute(
                        "SELECT * FROM exam_attempts WHERE exam_id=? AND user_id=?",
                        (e['id'], uid)).fetchone()
                if row is not None:
                    att = {'status': row['status'], 'score': row['score'],
                           'submitted_at': row['submitted_at']}
                item['attempt'] = att
                out.append(item)
            return self.send_json(self.ok(out))
        m = re.match(r'^/api/exams/(\d+)/paper$', path)
        if m:
            exam_id = int(m.group(1))
            conn = db.get_conn()
            with db.DB_LOCK:
                att = conn.execute(
                    "SELECT * FROM exam_attempts WHERE exam_id=? AND user_id=?",
                    (exam_id, uid)).fetchone()
                exam = conn.execute("SELECT * FROM exams WHERE id=?", (exam_id,)).fetchone()
            if exam is None:
                return self.err('考试不存在', status=404)
            if att is None:
                return self.err('请先开始考试')
            paper = exam_mod._paper_for_attempt(exam, att['paper'])
            return self.send_json(self.ok({
                'paper': paper,
                'questions': practice_mod.get_questions_for_list(paper),
                'answers': json.loads(att['answers'] or '{}'),
                'attempt_status': att['status']}))
        m = re.match(r'^/api/exams/(\d+)/result$', path)
        if m:
            res, err = exam_mod.exam_result_for_user(uid, int(m.group(1)))
            if err:
                return self.err(err, status=404)
            return self.send_json(self.ok(res))
        # ---- 考官 ----
        if path == '/api/admin/exams':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            return self.send_json(self.ok(exam_mod.list_exams(status=q.get('status', ''))))
        m = re.match(r'^/api/admin/exams/(\d+)/fixed-paper$', path)
        if m:
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            conn = db.get_conn()
            with db.DB_LOCK:
                exam = conn.execute("SELECT * FROM exams WHERE id=?",
                                    (int(m.group(1)),)).fetchone()
            if exam is None:
                return self.err('考试不存在', status=404)
            paper = json.loads(exam['fixed_paper'] or '[]') if exam['fixed_paper'] else []
            return self.send_json(self.ok({
                'paper': paper,
                'questions': practice_mod.get_questions_for_list(paper)}))
        m = re.match(r'^/api/admin/exams/(\d+)/results$', path)
        if m:
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            res, err = exam_mod.exam_results(int(m.group(1)))
            if err:
                return self.err(err, status=404)
            return self.send_json(self.ok(res))
        m = re.match(r'^/api/admin/exams/(\d+)/results\.csv$', path)
        if m:
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            text, err = exam_mod.results_csv(int(m.group(1)))
            if err:
                return self.err(err, status=404)
            return self.send_text('\ufeff' + text, ctype='text/csv; charset=utf-8')
        m = re.match(r'^/api/admin/exams/(\d+)/review/(\d+)$', path)
        if m:
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            res, err = exam_mod.exam_result_for_user(int(m.group(2)), int(m.group(1)))
            if err:
                return self.err(err, status=404)
            return self.send_json(self.ok(res))
        # ---- 考官/管理员共用:考试名单 ----
        if path == '/api/users/students':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            return self.send_json(self.ok(admin_mod.list_students()))
        # ---- 管理员 ----
        if path == '/api/admin/users':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            total, items, depts = admin_mod.list_users(
                keyword=q.get('q', ''), department=q.get('department', ''),
                role=q.get('role', ''), page=int(q.get('page') or 1),
                page_size=int(q.get('page_size') or 20))
            return self.send_json(self.ok({'total': total, 'items': items,
                                           'departments': depts}))
        if path == '/api/admin/stats':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            return self.send_json(self.ok(admin_mod.get_stats()))
        if path == '/api/admin/reports':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            return self.send_json(self.ok(report_mod.list_reports(status=q.get('status', ''))))
        if path == '/api/admin/versions':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            return self.send_json(self.ok(admin_mod.list_versions()))
        if path == '/api/settings/invite-code':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            return self.send_json(self.ok({'invite_code': db.get_setting('invite_code', 'CS2026')}))
        return self.err('接口不存在', status=404)

    # ---------- v2 新增 API(GET,合并方案§六) ----------
    # 响应信封与 v1 一致:{"ok": true, "data": ...} / {"ok": false, "error": ...}。
    # 角色:学员=任意登录用户;考官=admin/examiner;管理员=仅 admin(按§六)。
    def _v2_get(self, path, q, user):
        uid = user['id']
        conn = db.get_conn()
        if path == '/api/v2/adaptive':
            prof = adaptive_mod.adaptive_profile(conn, uid)
            return self.send_json(self.ok(prof))
        if path == '/api/v2/practice/adaptive':
            total = int(q.get('count') or 10)
            picked, prof = adaptive_mod.adaptive_pick(conn, uid, total)
            return self.send_json(self.ok({
                'total': total, 'ratio': prof['ratio'],
                'weak_knowledge': prof['weak_knowledge'],
                'mastered_knowledge': prof['mastered_knowledge'],
                'sample_note': prof['sample_note'],
                'cold_start': prof['cold_start'],
                'per_knowledge': prof['per_knowledge'],
                'due_count': prof['due_count'],
                'questions': picked}))
        if path == '/api/v2/weak':
            total = int(q.get('count') or 10)
            picked, prof = adaptive_mod.adaptive_pick(conn, uid, total)
            return self.send_json(self.ok({
                'total': total, 'ratio': prof['ratio'],
                'weak_knowledge': prof['weak_knowledge'],
                'mastered_knowledge': prof['mastered_knowledge'],
                'sample_note': prof['sample_note'],
                'cold_start': prof['cold_start'],
                'per_knowledge': prof['per_knowledge'],
                'due_count': prof['due_count'],
                'questions': picked}))
        if path == '/api/v2/practice/modes':
            return self.send_json(self.ok(adaptive_mod.practice_modes(uid)))
        if path == '/api/v2/quality':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            return self.send_json(self.ok({'quality': quality_mod.quality_list()}))
        if path == '/api/v2/templates':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            return self.send_json(self.ok({'templates': templates_mod.list_templates()}))
        m = re.match(r'^/api/v2/templates/(\d+)$', path)
        if m:
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            t = templates_mod.get_template(int(m.group(1)))
            if t is None:
                return self.err('模板不存在', status=404)
            return self.send_json(self.ok(t))
        m = re.match(r'^/api/v2/exams/(\d+)/print$', path)
        if m:
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            focus = None
            if q.get('user_id'):
                try:
                    focus = int(q['user_id'])
                except ValueError:
                    focus = None
            html, err = templates_mod.exam_print_html(int(m.group(1)), focus)
            if err:
                return self.err(err, status=404)
            return self.send_text(html, ctype='text/html; charset=utf-8')
        if path == '/api/v2/essay/queue':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            return self.send_json(self.ok({'queue': essay_mod.essay_queue()}))
        if path == '/api/v2/essay/mine':
            return self.send_json(self.ok({'submissions': essay_mod.my_essays(uid)}))
        if path == '/api/v2/plans':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            return self.send_json(self.ok({'plans': plans_mod.list_plans()}))
        if path == '/api/v2/plans/me':
            return self.send_json(self.ok({'plans': plans_mod.my_plans(uid)}))
        if path == '/api/v2/import/jobs':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            return self.send_json(self.ok(import_jobs_mod.list_jobs()))
        m = re.match(r'^/api/v2/import/jobs/(\d+)/pairings$', path)
        if m:
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            res, err = pairing_mod.list_pairings(int(m.group(1)))
            if err:
                return self.err(err, status=404)
            return self.send_json(self.ok(res))
        m = re.match(r'^/api/v2/import/jobs/(\d+)$', path)
        if m:
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            res, err = import_jobs_mod.job_detail(int(m.group(1)))
            if err:
                return self.err(err, status=404)
            return self.send_json(self.ok(res))
        if path == '/api/v2/bank/versions':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            return self.send_json(self.ok({'versions': import_jobs_mod.list_versions()}))
        if path == '/api/v2/dashboard/overview':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            return self.send_json(self.ok(dashboard_mod.admin_overview()))
        if path == '/api/v2/dashboard/teams':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            ov = dashboard_mod.admin_overview()
            return self.send_json(self.ok({'teams': ov['teams'],
                                           'heatmap': ov['heatmap']}))
        m = re.match(r'^/api/v2/dashboard/user/(\d+)$', path)
        if m:
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            return self.send_json(self.ok(dashboard_mod.report_for(int(m.group(1)))))
        if path == '/api/v2/dashboard/charts':
            scope = q.get('scope', '')
            if user['role'] == 'admin' and scope == 'all':
                return self.send_json(self.ok(
                    dashboard_mod.charts_data(None, scope='all')))
            return self.send_json(self.ok(
                dashboard_mod.charts_data(uid, scope='me')))
        if path == '/api/v2/federation/hosts':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            return self.send_json(self.ok({'hosts': fed_mod.list_hosts()}))
        if path == '/api/v2/federation/token':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            return self.send_json(self.ok({'token': fed_mod.fed_token(),
                                           'lan_url': 'http://{0}:{1}'.format(
                                               fed_mod.lan_ip(), PORT)}))
        if path == '/api/v2/backup/status':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            return self.send_json(self.ok(backup_mod.backup_status_summary()))
        if path == '/api/v2/backup/list':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            return self.send_json(self.ok({'backups': backup_mod.list_backups()}))
        m = re.match(r'^/api/v2/backup/download/(.+)$', path)
        if m:
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            fname = os.path.basename(unquote(m.group(1)))
            if not fname.endswith('.zip') or '/' in fname:
                return self.err('备份文件名不正确')
            fpath = os.path.join(os.path.dirname(db.DB_PATH), 'backups', fname)
            if not os.path.isfile(fpath):
                return self.err('备份文件不存在', status=404)
            with open(fpath, 'rb') as f:
                data = f.read()
            self.send_response(200)
            self.send_header('Content-Type', 'application/zip')
            self.send_header('Content-Disposition',
                             'attachment; filename="{0}"'.format(fname))
            self.send_header('Content-Length', str(len(data)))
            self.end_headers()
            self.wfile.write(data)
            return
        if path == '/api/v2/ai/variants':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            return self.send_json(self.ok({'variants': ai_mod.list_variants()}))
        m = re.match(r'^/api/v2/ai/tips/(\d+)$', path)
        if m:
            res = ai_mod.ai_tip_for(conn, int(m.group(1)))
            if not res.get('ok'):
                return self.err(res.get('error', '题目不存在'), status=404)
            return self.send_json(self.ok(res))
        return self.err('接口不存在', status=404)

    # ---------- POST/PUT/DELETE ----------
    def do_POST(self):
        try:
            self._do_POST()
        except (BrokenPipeError, ConnectionResetError):
            pass
        except Exception as e:
            self.log_message("POST error: %r", e)
            try:
                self.send_json({'ok': False, 'error': '服务器内部错误: {0}'.format(e)},
                               status=500)
            except Exception:
                pass

    def do_PUT(self):
        self.do_POST()

    def do_DELETE(self):
        self.do_POST()

    def _do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path
        method = self.command
        # ---- 公开:登录/注册 ----
        if path == '/api/auth/login' and method == 'POST':
            body = self.read_json_body()
            if body is None:
                return self.err('请求体不是合法 JSON')
            ok, token_or_msg, user = auth.login(body.get('username'), body.get('password'))
            if not ok:
                return self.err(token_or_msg, status=401)
            cookie = 'zk_token={0}; Path=/; HttpOnly'.format(token_or_msg)
            return self.send_json(self.ok({'token': token_or_msg, 'user': user}),
                                  set_cookie=cookie)
        if path == '/api/auth/register' and method == 'POST':
            body = self.read_json_body()
            if body is None:
                return self.err('请求体不是合法 JSON')
            ok, msg, user = auth.register(body.get('name'), body.get('department'),
                                          body.get('username'), body.get('password'),
                                          body.get('invite_code'))
            if not ok:
                return self.err(msg)
            return self.send_json(self.ok({'message': msg, 'user': user}))
        if path == '/api/auth/logout' and method == 'POST':
            cookies = _parse_cookies(self.headers.get('Cookie'))
            if cookies.get('zk_token'):
                auth.revoke_token(cookies['zk_token'])
            return self.send_json(self.ok({'message': '已退出登录'}),
                                  set_cookie='zk_token=; Path=/; Max-Age=0')
        # ---- 联邦拉包:只认联邦令牌,不认登录态(对方服务器没有本站 Cookie) ----
        # 注意:此接口不包 data 信封,返回 {"ok": true, "package": ..., "sha256": ...},
        # 拉取方直接对 package 做 SHA-256 校验(与 v07 格式一致)。
        if path == '/api/v2/federation/package' and method == 'POST':
            import hmac
            qs = parse_qs(parsed.query)
            tok = qs.get('token', [''])[0]
            if not hmac.compare_digest(tok, fed_mod.fed_token()):
                return self.err('联邦令牌不正确', status=401)
            pbody = self.read_json_body()
            if pbody is None:
                return self.err('请求体不是合法 JSON')
            pkg, sha = fed_mod.build_package(pbody if isinstance(pbody, dict) else {})
            return self.send_json({'ok': True, 'package': pkg, 'sha256': sha})
        # ---- 其余需登录 ----
        user = self.need_login()
        if user is None:
            return
        uid = user['id']
        body = self.read_json_body()
        if body is None:
            return self.err('请求体不是合法 JSON')
        if not isinstance(body, dict):
            body = {}
        if path.startswith('/api/v2/'):
            return self._v2_post(path, method, user, body)
        if path == '/api/auth/change-password' and method == 'POST':
            ok, msg = auth.change_password(uid, body.get('old_password'),
                                           body.get('new_password'),
                                           body.get('confirm_password'))
            if not ok:
                return self.err(msg)
            return self.send_json(self.ok({'message': msg}))
        # ---- 练习 ----
        if path == '/api/practice/answer' and method == 'POST':
            res, err = practice_mod.answer_question(
                uid, int(body.get('question_id') or 0), body.get('mode') or '顺序',
                body.get('user_answer') or '',
                self_correct=body.get('self_correct'))
            if err:
                return self.err(err, status=404)
            return self.send_json(self.ok(res))
        if path == '/api/wrongbook/remove' and method == 'POST':
            ok = practice_mod.wrong_book_remove(uid, int(body.get('question_id') or 0))
            return self.send_json(self.ok({'removed': ok}))
        # ---- 上报 ----
        if path == '/api/reports' and method == 'POST':
            res, err = report_mod.submit_report(uid, int(body.get('question_id') or 0),
                                                body.get('type') or '',
                                                body.get('detail') or '')
            if err:
                return self.err(err)
            return self.send_json(self.ok(res))
        # ---- 模拟考试 ----
        if path == '/api/mock' and method == 'POST':
            res, err = mock_mod.create_mock(uid, body)
            if err:
                return self.err(err)
            res['question_detail'] = practice_mod.get_questions_for_list(res['questions'])
            return self.send_json(self.ok(res))
        m = re.match(r'^/api/mock/(\d+)/answer$', path)
        if m and method == 'POST':
            ok, err = mock_mod.save_mock_answer(uid, int(m.group(1)),
                                                int(body.get('question_id') or 0),
                                                body.get('answer') or '')
            if not ok:
                return self.err(err)
            return self.send_json(self.ok({'saved': True}))
        m = re.match(r'^/api/mock/(\d+)/submit$', path)
        if m and method == 'POST':
            res, err = mock_mod.submit_mock(uid, int(m.group(1)))
            if err:
                return self.err(err)
            return self.send_json(self.ok(res))
        m = re.match(r'^/api/mock/(\d+)/selfgrade$', path)
        if m and method == 'POST':
            ok, err = mock_mod.self_grade_mock(uid, int(m.group(1)),
                                              int(body.get('question_id') or 0),
                                              bool(body.get('correct')))
            if not ok:
                return self.err(err)
            return self.send_json(self.ok({'graded': True}))
        # ---- 正式考试(考生端) ----
        m = re.match(r'^/api/exams/(\d+)/start$', path)
        if m and method == 'POST':
            res, err = exam_mod.start_exam(uid, int(m.group(1)))
            if err:
                return self.err(err)
            res['question_detail'] = practice_mod.get_questions_for_list(res['paper'])
            return self.send_json(self.ok(res))
        m = re.match(r'^/api/exams/(\d+)/answer$', path)
        if m and method == 'POST':
            ok, err = exam_mod.save_exam_answer(uid, int(m.group(1)),
                                                int(body.get('question_id') or 0),
                                                body.get('answer') or '')
            if not ok:
                return self.err(err)
            return self.send_json(self.ok({'saved': True}))
        m = re.match(r'^/api/exams/(\d+)/submit$', path)
        if m and method == 'POST':
            res, err = exam_mod.submit_exam(uid, int(m.group(1)),
                                            late=bool(body.get('late')))
            if err:
                return self.err(err)
            return self.send_json(self.ok(res))
        m = re.match(r'^/api/exams/(\d+)/selfgrade$', path)
        if m and method == 'POST':
            ok, err = exam_mod.self_grade_exam(uid, int(m.group(1)),
                                               int(body.get('question_id') or 0),
                                               bool(body.get('correct')))
            if not ok:
                return self.err(err)
            return self.send_json(self.ok({'graded': True}))
        # ---- 考官:题库 ----
        if path == '/api/questions' and method == 'POST':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            q, err = qmod.create_question(body)
            if err:
                return self.err(err)
            return self.send_json(self.ok(q))
        if path == '/api/questions/import' and method == 'POST':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            return self._import_questions(body)
        m = re.match(r'^/api/questions/(\d+)$', path)
        if m and method == 'PUT':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            q, err = qmod.update_question(int(m.group(1)), body)
            if err:
                return self.err(err)
            return self.send_json(self.ok(q))
        if path == '/api/questions' and method == 'DELETE':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            n = qmod.delete_questions([int(i) for i in (body.get('ids') or [])])
            return self.send_json(self.ok({'deleted': n}))
        m = re.match(r'^/api/questions/(\d+)/status$', path)
        if m and method == 'POST':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            ok, err = qmod.set_question_status(int(m.group(1)), body.get('status') or '')
            if not ok:
                return self.err(err)
            return self.send_json(self.ok({'status': body.get('status')}))
        # ---- 考官:考试管理 ----
        if path == '/api/admin/exams' and method == 'POST':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            e, err = exam_mod.create_exam(body, uid)
            if err:
                return self.err(err)
            return self.send_json(self.ok(e))
        m = re.match(r'^/api/admin/exams/(\d+)$', path)
        if m and method == 'PUT':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            e, err = exam_mod.update_exam(int(m.group(1)), body)
            if err:
                return self.err(err)
            return self.send_json(self.ok(e))
        if m and method == 'DELETE':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            res, err = exam_mod.delete_exam(int(m.group(1)))
            if err:
                return self.err(err, status=404)
            return self.send_json(self.ok(res))
        m = re.match(r'^/api/admin/exams/(\d+)/(publish|end)$', path)
        if m and method == 'POST':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            status = '已发布' if m.group(2) == 'publish' else '已结束'
            ok, err = exam_mod.set_exam_status(int(m.group(1)), status)
            if not ok:
                return self.err(err)
            return self.send_json(self.ok({'status': status}))
        m = re.match(r'^/api/admin/exams/(\d+)/fixed-paper$', path)
        if m and method == 'POST':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            qids, err = exam_mod.generate_fixed_paper(int(m.group(1)))
            if err:
                return self.err(err)
            return self.send_json(self.ok({
                'paper': qids,
                'questions': practice_mod.get_questions_for_list(qids),
                'message': '已生成固定试卷,所有考生将使用这份相同的试卷'}))
        # ---- 管理员:用户 ----
        if path == '/api/admin/users' and method == 'POST':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            u, err = admin_mod.create_user(body)
            if err:
                return self.err(err)
            return self.send_json(self.ok(u))
        if path == '/api/admin/users/import' and method == 'POST':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            return self._import_users(body)
        m = re.match(r'^/api/admin/users/(\d+)$', path)
        if m and method == 'PUT':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            u, err = admin_mod.update_user(int(m.group(1)), body)
            if err:
                return self.err(err)
            return self.send_json(self.ok(u))
        if m and method == 'DELETE':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            n = admin_mod.delete_users([int(m.group(1))], uid)
            return self.send_json(self.ok({'deleted': n}))
        m = re.match(r'^/api/admin/users/(\d+)/(disable|enable|reset-password)$', path)
        if m and method == 'POST':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            action = m.group(2)
            if action == 'reset-password':
                ok, err = admin_mod.reset_password(int(m.group(1)),
                                                  body.get('password') or '123456')
            else:
                ok, err = admin_mod.set_user_status(int(m.group(1)),
                                                    '停用' if action == 'disable' else '正常')
            if not ok:
                return self.err(err)
            return self.send_json(self.ok({'action': action}))
        if path == '/api/admin/users/batch' and method == 'POST':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            action = body.get('action') or ''
            ids = [int(i) for i in (body.get('ids') or [])]
            if action in ('disable', 'enable'):
                n = 0
                for i in ids:
                    ok, _e = admin_mod.set_user_status(i, '停用' if action == 'disable' else '正常')
                    if ok:
                        n += 1
                return self.send_json(self.ok({'updated': n}))
            if action == 'delete':
                n = admin_mod.delete_users(ids, uid)
                return self.send_json(self.ok({'deleted': n}))
            return self.err('批量动作不合法')
        # ---- 管理员:上报处理 ----
        m = re.match(r'^/api/admin/reports/(\d+)/handle$', path)
        if m and method == 'POST':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            ok, err = report_mod.handle_report(int(m.group(1)),
                                               body.get('action') or '',
                                               body.get('reply') or '')
            if not ok:
                return self.err(err)
            return self.send_json(self.ok({'handled': True}))
        # ---- 管理员:版本 ----
        if path == '/api/admin/versions' and method == 'POST':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            v, err = admin_mod.create_version(body)
            if err:
                return self.err(err)
            return self.send_json(self.ok(v))
        m = re.match(r'^/api/admin/versions/(\d+)/(activate|deactivate)$', path)
        if m and method == 'POST':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            ok, err = admin_mod.set_version_status(
                int(m.group(1)), '生效中' if m.group(2) == 'activate' else '已下架')
            if not ok:
                return self.err(err)
            return self.send_json(self.ok({'status': '生效中' if m.group(2) == 'activate' else '已下架'}))
        m = re.match(r'^/api/admin/versions/(\d+)$', path)
        if m and method == 'DELETE':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            ok, err = admin_mod.delete_version(int(m.group(1)))
            if not ok:
                return self.err(err)
            return self.send_json(self.ok({'deleted': True}))
        # ---- 管理员:邀请码 ----
        if path == '/api/settings/invite-code' and method == 'POST':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            code = (body.get('invite_code') or '').strip()
            if not code:
                return self.err('邀请码不能为空')
            db.set_setting('invite_code', code)
            return self.send_json(self.ok({'invite_code': code}))
        return self.err('接口不存在', status=404)

    # ---------- v2 新增 API(POST/PUT/DELETE,合并方案§六) ----------
    def _v2_post(self, path, method, user, body):
        uid = user['id']
        if path == '/api/v2/quality/refresh' and method == 'POST':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            items = quality_mod.refresh_all()
            return self.send_json(self.ok({'refreshed': len(items)}))
        m = re.match(r'^/api/v2/questions/(\d+)/status$', path)
        if m and method == 'POST':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            ok, err = quality_mod.set_question_status(int(m.group(1)),
                                                      body.get('status') or '')
            if not ok:
                return self.err(err)
            return self.send_json(self.ok({'status': body.get('status')}))
        if path == '/api/v2/templates' and method == 'POST':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            rules = body.get('rules')
            if rules is None and body.get('rules_json'):
                try:
                    rules = json.loads(body.get('rules_json'))
                except ValueError:
                    return self.err('配比规则不是有效 JSON')
            res, err = templates_mod.create_template(
                body.get('title'), body.get('subject') or '',
                body.get('total_count') or 10, rules or {},
                created_by=user['username'])
            if err:
                return self.err(err)
            return self.send_json(self.ok(res))
        m = re.match(r'^/api/v2/templates/(\d+)$', path)
        if m and method == 'DELETE':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            ok, err = templates_mod.delete_template(int(m.group(1)))
            if not ok:
                return self.err(err, status=404)
            return self.send_json(self.ok({'deleted': True}))
        m = re.match(r'^/api/v2/templates/(\d+)/start$', path)
        if m and method == 'POST':
            exam, err = templates_mod.start_exam_from_template(
                uid, int(m.group(1)),
                duration_min=int(body.get('duration_min') or 60),
                members=body.get('members'))
            if err:
                return self.err(err, status=404 if '不存在' in err else 400)
            qids = exam.get('fixed_paper') or []
            return self.send_json(self.ok({
                'exam': exam, 'paper': qids,
                'questions': practice_mod.get_questions_for_list(qids)}))
        if path == '/api/v2/essay/submit' and method == 'POST':
            res, err = essay_mod.submit_essay(
                uid, int(body.get('question_id') or 0), body.get('answer') or '')
            if err:
                return self.err(err, status=404 if '不存在' in err else 400)
            return self.send_json(self.ok(res))
        if path == '/api/v2/essay/review' and method == 'POST':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            res, err = essay_mod.review_essay(
                int(body.get('review_id') or 0), body.get('score'),
                body.get('comment') or '', reviewer_username=user['username'])
            if err:
                return self.err(err, status=404 if '不存在' in err else 400)
            return self.send_json(self.ok(res))
        if path == '/api/v2/plans' and method == 'POST':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            res, err = plans_mod.create_plan(body, user['username'],
                                             created_by_id=uid)
            if err:
                return self.err(err)
            return self.send_json(self.ok(res))
        m = re.match(r'^/api/v2/import/jobs/(\d+)/approve$', path)
        if m and method == 'POST':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            res, err = import_jobs_mod.approve_job(int(m.group(1)),
                                                   username=user['username'])
            if err:
                return self.err(err, status=404)
            return self.send_json(self.ok(res))
        m = re.match(r'^/api/v2/import/pairings/(\d+)/confirm$', path)
        if m and method == 'POST':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            target = body.get('question_id')
            res, err = pairing_mod.confirm_pairing(
                int(m.group(1)),
                int(target) if target else None,
                username=user['username'])
            if err:
                return self.err(err, status=404 if '不存在' in err else 400)
            return self.send_json(self.ok(res))
        m = re.match(r'^/api/v2/import/pairings/(\d+)/reject$', path)
        if m and method == 'POST':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            res, err = pairing_mod.reject_pairing(int(m.group(1)),
                                                  username=user['username'])
            if err:
                return self.err(err, status=404)
            return self.send_json(self.ok(res))
        if path == '/api/v2/import/pdf' and method == 'POST':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            try:
                data = base64.b64decode(body.get('content_b64') or '')
            except Exception:
                return self.err('文件内容不是合法 base64')
            res, err = import_jobs_mod.do_import(
                data, body.get('filename') or 'import.pdf', 'pdf',
                user['username'])
            if err:
                return self.send_json({'ok': False, 'error': err,
                                       'data': res}, status=400)
            return self.send_json(self.ok(res))
        if path == '/api/v2/bank/publish' and method == 'POST':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            res, err = import_jobs_mod.publish_bank(body.get('note') or '',
                                                    username=user['username'])
            if err:
                return self.err(err)
            return self.send_json(self.ok(res))
        if path == '/api/v2/bank/rollback' and method == 'POST':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            res, err = import_jobs_mod.rollback_bank(
                int(body.get('version_id') or 0), username=user['username'])
            if err:
                return self.err(err, status=404)
            return self.send_json(self.ok(res))
        if path == '/api/v2/federation/hosts' and method == 'POST':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            res, err = fed_mod.register_host(
                body.get('name'), body.get('host'), body.get('port'),
                body.get('token'))
            if err:
                return self.err(err)
            return self.send_json(self.ok(res))
        m = re.match(r'^/api/v2/federation/hosts/(\d+)/test$', path)
        if m and method == 'POST':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            res, err = fed_mod.test_host(int(m.group(1)))
            if err:
                return self.err(err)
            return self.send_json(self.ok(res))
        m = re.match(r'^/api/v2/federation/hosts/(\d+)/delete$', path)
        if m and method == 'POST':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            ok, err = fed_mod.delete_host(int(m.group(1)))
            if not ok:
                return self.err(err, status=404)
            return self.send_json(self.ok({'deleted': True}))
        if path == '/api/v2/federation/pull' and method == 'POST':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            res, err = fed_mod.pull_from_host(int(body.get('host_id') or 0),
                                              body, user['username'])
            if err:
                return self.err(err)
            return self.send_json(self.ok(res))
        if path == '/api/v2/federation/token' and method == 'POST':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            if body.get('rotate'):
                tok = fed_mod.rotate_token()
            else:
                tok = fed_mod.fed_token()
            return self.send_json(self.ok({'token': tok,
                                           'lan_url': 'http://{0}:{1}'.format(
                                               fed_mod.lan_ip(), PORT)}))
        if path == '/api/v2/backup/create' and method == 'POST':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            note = (body.get('note') or '手动备份').strip() or '手动备份'
            try:
                res = backup_mod.make_backup(note, user['username'])
            except Exception as e:
                return self.err('备份失败:{0}'.format(e), status=500)
            backup_mod.prune_backups()
            db.audit(user['username'], 'backup_create',
                     "备份 {0}({1} 字节)".format(res['filename'],
                                                res['size_bytes']))
            return self.send_json(self.ok(res))
        if path == '/api/v2/backup/restore' and method == 'POST':
            if user['role'] != 'admin':
                return self.err('没有权限', status=403)
            res = backup_mod.restore_backup_file(body.get('filename') or '',
                                                 user['username'])
            if not res.get('ok'):
                return self.err(res.get('error', '恢复失败'))
            return self.send_json(self.ok(res))
        if path == '/api/v2/ai/variants' and method == 'POST':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            try:
                qid = int(body.get('question_id') or 0)
                count = min(max(int(body.get('count') or 2), 1), 3)
            except (TypeError, ValueError):
                return self.err('题目 ID 或数量不正确')
            res, err = ai_mod.generate_variants(qid, count,
                                                created_by=user['username'])
            if err:
                return self.err(err, status=404 if '不存在' in err else 400)
            return self.send_json(self.ok(res))
        m = re.match(r'^/api/v2/ai/variants/(\d+)/approve$', path)
        if m and method == 'POST':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            res, err = ai_mod.approve_variant(int(m.group(1)),
                                              username=user['username'])
            if err:
                return self.err(err, status=404 if '不存在' in err else 400)
            return self.send_json(self.ok(res))
        m = re.match(r'^/api/v2/ai/variants/(\d+)/reject$', path)
        if m and method == 'POST':
            if user['role'] not in ('admin', 'examiner'):
                return self.err('没有权限', status=403)
            res, err = ai_mod.reject_variant(int(m.group(1)),
                                             username=user['username'])
            if err:
                return self.err(err, status=404 if '不存在' in err else 400)
            return self.send_json(self.ok(res))
        return self.err('接口不存在', status=404)

    def _import_questions(self, body):
        filename = (body.get('filename') or '').lower()
        try:
            data = base64.b64decode(body.get('content_b64') or '')
        except Exception:
            return self.err('文件内容不是合法 base64')
        if filename.endswith('.xlsx'):
            ok_list, bad_list = import_xlsx.parse_question_xlsx(data, ASSETS_DIR)
        elif filename.endswith('.docx'):
            ok_list, bad_list = import_docx.parse_docx_bytes(data, ASSETS_DIR)
        else:
            return self.err('只支持 .xlsx / .docx')
        inserted = 0
        for q in ok_list:
            _q, err = qmod.create_question(q)
            if err:
                bad_list.append({'row': 0, 'error': err})
            else:
                inserted += 1
        return self.send_json(self.ok({
            'ok_count': inserted, 'bad_count': len(bad_list),
            'errors': bad_list,
            'message': '导入完成:成功 {0} 条,失败 {1} 条'.format(inserted, len(bad_list))}))

    def _import_users(self, body):
        filename = (body.get('filename') or '').lower()
        try:
            data = base64.b64decode(body.get('content_b64') or '')
        except Exception:
            return self.err('文件内容不是合法 base64')
        if not filename.endswith('.xlsx'):
            return self.err('用户批量导入只支持 .xlsx')
        ok_list, bad_list = import_xlsx.parse_user_xlsx(data)
        inserted = 0
        for u in ok_list:
            _u, err = admin_mod.create_user(u)
            if err:
                bad_list.append({'row': 0, 'error': u['username'] + ': ' + err})
            else:
                inserted += 1
        return self.send_json(self.ok({
            'ok_count': inserted, 'bad_count': len(bad_list),
            'errors': bad_list,
            'message': '导入完成:成功 {0} 条,失败 {1} 条'.format(inserted, len(bad_list))}))


class ThreadingServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def main():
    os.makedirs(DATA_DIR, exist_ok=True)
    os.makedirs(ASSETS_DIR, exist_ok=True)
    db.init_db()
    seed.seed_all()
    backup_mod.start_auto_backup_thread()
    server = ThreadingServer((HOST, PORT), Handler)
    print("{0} {1} listening on http://{2}:{3}/".format(APP_NAME, VERSION, HOST, PORT))
    print("data: {0}".format(DB_PATH))
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    server.server_close()


if __name__ == '__main__':
    main()
