# 常熟站智考通 v2.0 — 验收记录（D：统合、打包与文档）

> 合并方向：智考通 v1.0 为底，刷题宝功能并入，合成一个程序，名字仍叫「常熟站智考通」，版本 v2.0。
> mvp-v07 与 mvp-zhikaotong-v1 原样保留，未动。
> 本文件只记 D 负责的统合、打包、回归与冒烟；A/B/C 各自的模块自测见其自测记录
> （A：`_build/server-selftest.py`，91/91；B：`node --check`；C：`exe/app/selftest.py`）。

## 一、自测清单与验证结果

### 1. 对齐修复（A 核对清单发现的 B/C 与服务端不一致，D 已逐项改掉并实测）

| # | 问题 | 改了哪里 | 验证结果 |
| --- | --- | --- | --- |
| 1 | 组卷模板 rules 须用中文题型键 `type_counts`。B 发 `rules:{counts}`（中文键但错键名），C 发英文键 `rules`（single/multi/judge/fill/short），都会被服务端静默忽略、抽题回退为随机补题 | `web/static/app.js`：新建模板改发 `rules:{type_counts: counts}` + `rules_json` 同形；列表渲染改读 `rules.type_counts \|\| rules.counts \|\| rules`（兼容旧模板）。`exe/app/views_examiner.py`：`_template_dialog.save()` 改发 `{"type_counts": {中文: n}}`；列表渲染新增 `template_type_counts()`（读 `type_counts`，兼容扁平中文键 / 扁平英文键旧模板）；更新头部契约注释 | 新建模板（B 体）200，`template_id` 1；按模板开考，试卷含全部 5 种题型（单选/多选/判断/填空/简答各 1 道）；学员交卷后简答进批阅队列 1 道；打分 6/10 满分算对 |
| 2 | 题目停用/恢复只收中文值 `{status: '启用'/'停用'}`，英文值报 400。B 的质量页与 C 的质量页都发 `disabled`/`published` | `web/static/app.js` viewQuality：`'disabled'`→`'停用'`，`'published'`→`'启用'`，注释更新。`exe/app/views_examiner.py`：停用/恢复按钮改传 `"停用"`/`"启用"`，提示文案映射同步改 | 停用后题状态变 `停用`，恢复后变 `启用`；英文值 `disabled` 实测报 400「状态只能是 启用/停用」 |
| 3 | 联邦 catalog/package 不包 data 信封。B/C 的读取本身已是顶层键（B：`d.catalog` 经 v2unwrap 去 ok 后读顶层；C：`_unwrap(data, "catalog")` 读顶层；服务端拉取 `federation.py` 直接读 `res['package']`），**读取形状无需改**；但真正的问题是两处调目录接口都不带联邦令牌，必 401 | `web/static/app.js` viewFederation：目录按钮先取已加载的本机令牌，调 `/api/v2/federation/catalog?token=…`；连通测试提示改为显示对方题库数（`d.catalog.question_count`）。`exe/app/api_client.py`：`v2_fed_catalog(host_id)` 改走 `POST hosts/<id>/test`，由服务端用登记的令牌代取对方目录、返回顶层 catalog；`exe/app/views_admin.py` `_fed_test` 提示同步改 | 带令牌调目录 200，返回 `{"ok": true, "catalog": {...}}`（无 data 键），题数 23（20 种子 + PDF 导入 2 + 变式发布 1）；不带令牌 401；对端连通测试返回对方目录；拉取新题 1 道，重复拉取去重为 0 |
| 4 | 成绩单打印返回 HTML 不是 JSON。C 已正确（`download()` 取原始 bytes，另存 .html 打印）；**B 完全没有打印入口** | `web/static/app.js` viewExamResults：新增「打印成绩单」按钮；用 `api()` 的非 JSON 分支（返回 `{raw: Response}`）取 HTML 文本，在新窗口打开打印 | 打印接口 200，`Content-Type: text/html; charset=utf-8`，HTML 含简答分区、与选择题分开列示 |
| 5 | 角色边界：dashboard / federation / backup 仅 admin，考官调会 403 | 核查通过，无需改：B 考官导航无仪表盘/联邦/备份入口，考官视图的 403 由 `v2errHtml` 友好展示；C 考官导航同样无三入口，403 由 `banner` 展示。回归补了显式断言 | 考官调 `/api/v2/dashboard/overview`、`/api/v2/federation/hosts`、`/api/v2/backup/status` 均为 403；客户端自测 v2_api_calls：学员调 3 个学员接口成功、10 个考官/管理员接口 403 |
| 6 | 其余按 A 的核对清单核对 | 核查通过，无需改：自适应画像 data 就是画像 dict 本身（B：`profile.adaptive \|\| profile`；C：`_unwrap` 兜底返回画像；lite：`d.adaptive \|\| d`）；备份 create/restore 的 data 里嵌 `ok`（B 读 `d.filename` 正常；C 读 `data.get('filename')` 正常）；PDF 导入是 JSON `{filename, content_b64}`（B、C 均已是 JSON）；简答批阅 POST `{review_id, score, comment}`，≥60% 满分算对（B、C 均已是该体）；计划 scope 为 `team`/`personal`，done 是去重题数（B、C 均已是该值）；仪表盘 charts 的 accuracy 一律 0–1 小数（B：`pctNum` 与 `chartsHtml` 按 0–1 处理；C：`acc <= 1` 时 ×100）；AI 变式 kinds 为 `{shuffle, wording, numeric}`（B 读 `variant_ids`；C 读 `variant_ids`） | 回归逐项调通：自适应画像/出题、五环节、薄弱项、质量列表/重算、计划下发与去重、PDF 导入正向 2 题与非 PDF 拒绝、版本发布、仪表盘五图、备份一键/列表/恢复、AI 变式生成 kinds `['shuffle', 'wording']` 并审核通过、AI 提示 |

### 2. 统合检查

- `web/*.py` 与 `exe/app/server/`：逐文件 cmp 完全一致（除 `web/` 专属的 `README.md`、`data/`、`start.bat`、`start.sh` 外）；`web/static/*` 已同步进 `exe/app/server/static/`（v1 时 exe 内嵌服务器只剩 3 个占位页，v2 起 exe 与网页版 served 同一套界面）。
- 版本号全站统一 v2.0：`settings.app_version` = v2.0、`server.py VERSION` = v2.0、登录页（`app.js` 的 `VERSION`、lite 页脚、`theme.py` 的 `VERSION`/`TITLE`）、设置页（`${VERSION}`）、`product-intro.md`、`showcase.html`、两处 `branding.json`、启动器源码头注释、客户端版本发布默认值。例外（有意保留）：`API-CONTRACT.md` 仍是 v1 的 61 端点契约原文（合并方案 §一：v1 契约保持不变；v2 新增端点见 MERGE-PLAN.md §六）；`_build/` 里的 v1 旧 README 含「连云港」历史表述（不进包，见下）。
- 全树 grep：交付物（`web/`、`exe/`、`rebrand-tool/`、`product-intro.md`、`showcase.html`、两 zip）无「连云港」、无原版服务器地址 `50.19.166`。仅有的两处命中是 `check_py34.py` 自身的扫描模式字面量（它要靠写出该地址来扫描别人，v1 同样做法；连续的「连云港」三字在任何交付文件里都不出现）。`MERGE-PLAN.md` 的自查句已改写，不再含该词。`_build/` 的 v1 旧 README 有两处历史表述（「全部『连云港边检站』已改成『常熟站』」），是 v1 工作备注，不进包。
- 全部 .py（`web/`、`exe/app/`、`rebrand-tool/`，共 69 个）`ast.parse(feature_version=(3,4))` 全过，无真 f-string；`node --check` 过 `app.js`、`lite.js` 与 showcase 内联 JS。
- 改名小工具：`rebrand-tool/branding.json` 名字仍是常熟站智考通、版本已改 v2.0；`/tmp` 副本实测：
  - exe 包扫描 49 个文件（全名 90 处、站名 9 处），web 包 37 个文件（全名 73 处、站名 9 处）；12 个新增 v2 服务器模块与 3 个新客户端视图全部在扫描范围内；
  - 改名（常熟站→测试站）后无残留，启动器 exe 改名为测试站智考通.exe，两处 `branding.json` 同步更新、version 保持 v2.0；
  - 再改一次（测试站→南京站）正常，读当前名字、不写死；
  - 恢复用最近一次备份：52 个文件，0 缺失 0 错误，新旧 exe 不会同时存在（注：若中间又改过一次名、却用旧备份恢复，需用最近一次备份或手动删多余 exe）；
  - 实测发现并已修一个覆盖缺口：`SCAN_EXTS` 原来没有 `.sh`，`web/start.sh` 改名后会残留旧名；已在两处 `rebrand.py`（`rebrand-tool/` 与 `exe/` 根目录）补上 `.sh`，重测后 start.sh 正确改名。GBK 的 `start.bat` 改名正常。

### 3. 打包

- 启动器：沿用 `_build/launcher/launcher.c`，`i686-w64-mingw32-gcc -O2 -mwindows -municode` 重新编译；`file` 确认 `PE32 executable (GUI) Intel 80386, for MS Windows`；md5 `f67ce7733d233eae58487fd75374f50f`；`exe/python34` 沿用 v1 运行时（含 Pillow 5.4.1）；`exe/data/` 保持为空（仅 `.gitkeep`，首次启动自动建库）。
- 两 zip（全部英文文件名，`unzip -t` 全过，无 `__pycache__` / `.pyc` / 测试数据库）：
  - `changshu-zhikaotong-v2.0-exe.zip`（10,782,234 字节，1,681 个文件，exe/ 整包）
  - `changshu-zhikaotong-v2.0-web.zip`（206,412 字节，45 个文件，web/ 整包）
- `.bat` 一律 GBK + CRLF，无 `chcp 65001`（`web/start.bat` 已验证；其余 `.bat` 是 python34 自带运行时文件，未动）。

### 4. 整体回归（干净副本，端口 18766 主 + 18767 对端；脚本与完整日志见 `_build/d-regress.py`、`_build/d-regress.log`）

**HTTP 回归 81/81 通过**（`REGRESS DONE 81/81`，exit 0）：

- v1 回归：三角色登录、版本号 v2.0、学员首页统计、练习（出题/答对/答错+智能分析/错题本）、模拟考（组卷/交卷/历史）、正式考试（列表/开始/交卷）、考官建考试、题库共 20 题、用户管理、统计分析、上报处理、客户端更新发布、设置邀请码 CS2026。
- v2 新功能（按 MERGE-PLAN.md §六逐项，模板开考含简答实测）：adaptive 画像/出题 10 道、weak、modes 五环节、AI 提示、质量列表/重算、题目停用/恢复、模板新建（`type_counts` 中文键）/列表/开考（试卷含 5 种题型各 1 道）/学员交卷（得分 25.0）/简答进批阅队列/打分 6/10 算对/我的批阅结果、成绩单打印 HTML、学习计划下发与去重（见下）、导入任务列表、PDF 文字型导入 2 题与非 PDF 拒绝、题库版本列表/发布 v2.0.1、AI 变式生成 kinds `['shuffle','wording']` 并审核通过、仪表盘总览/部门对比/五图、联邦令牌/目录/登记/连通测试/拉取 1 道/重复拉取去重 0/删除主机、备份状态/一键/列表/恢复（恢复后登录仍可用）、考官调管理员接口 403×3。
- 冒烟（干净副本）：根页、`/lite`、showcase 均 200（另验 `/static/app.js`、`/static/lite.js`、`/static/style.css` 均 200）；三角色登录成功；首次启动自动建库播种 20 道题、4 个用户、`app_version` v2.0。
- 冒烟（从 zip 解压的干净副本，端口 18768）：根页、`/lite`、showcase、三个 static 文件均 200；三角色登录成功；播种 20 题、4 用户、v2.0。

**客户端自测 21/21 通过**（`exe/app/selftest.py`，Linux + Xvfb，系统 Python 3.12 + tkinter，连 18766 回归服务器）：
登录三角色、学员首页四模块、练习答题判分、模拟考建卷交卷、考官建考试、管理员用户列表与统计、v2 学员视图（自适应/五环节/薄弱/仪表盘/计划/批阅）、v2 考官视图（模板/导入/质量/批阅/AI 变式）、v2 管理员视图（仪表盘/计划/联邦/备份）、v2 API 调用（学员 3 个接口成功、10 个考官/管理员接口 403）。
注：自测原 `v2_api_calls` 步的期望是旧的（写于 v2 服务端未落地时，期望全部 404）；现服务端已落地，D 已把该步期望改成正确断言（3 个学员接口成功 + 10 个越权接口 403），重跑 21/21。

**A 的服务器自测**：`_build/server-selftest.py` 91/91（D 改动后重跑仍 91/91）。

### 5. 三个旧问题修复的证据（A 的对照数，D 回归复核）

1. **部门横向对比精确汇总**：A 自测 `dashboard(修复1)`：执勤三队总作答精确=**11**、答对数精确=**7**、正确率 0.636。D 回归复核：`/api/v2/dashboard/teams` 返回的每队 `correct <= total_attempts`、`avg_accuracy` 在 0–1 内（回归库：执勤一队总作答 22、答对 5、正确率 0.227，均为精确汇总值）。
2. **学习计划进度去重题数**：A 自测 `plans(修复2)`：同题重复做只算 1 道，去重 done=**3**（目标 5、进度 60%）。D 回归复核：建计划后答 3 道新题 + 重复 1 道，`plans/me` 的 done=**3**、pct=60。**同秒边界已修**（见§四-1）：`plan_progress()` 改为 `answered_at>=created_at`，建计划后同一秒内答 2 道题，`plans/me` 立即 done=**2**；服务器自测仍 91/91。
3. **模板开考含简答题**：A 自测 `templates(修复3)`：模板抽题含全部 5 种题型，固定试卷含简答，交卷后简答进批阅队列 1 道，成绩单 HTML 分开列示。D 回归复核：模板试卷 5 种题型各 1 道；学员交卷得分 25.0；简答进批阅队列 1 道；打分 6/10 算对；成绩单 HTML 选择题与简答题分开列示。

## 二、交付物清单与文件位置

`~/workspace/常熟边检站刷题宝/mvp-zhikaotong-v2/` 下：

| 交付物 | 位置 |
| --- | --- |
| exe 便携包 | `exe/`（启动器 `changshu-zhikaotong.exe`、python34、app/、data/、改名工具、README.txt） |
| exe zip | `changshu-zhikaotong-v2.0-exe.zip` |
| 网页版 | `web/`（服务器核心 + static + start.bat/sh + README/API-CONTRACT/README-import + 导入模板） |
| 网页版 zip | `changshu-zhikaotong-v2.0-web.zip` |
| 产品介绍 | `product-intro.md` |
| 可交互介绍页 | `showcase.html`（与 `web/static/showcase.html` 同一份，也已同步进 `exe/app/server/static/showcase.html`） |
| 验收记录 | `acceptance-v2.0.md`（本文件） |
| 改名小工具 | `rebrand-tool/`（源码目录）；exe 包内另有一份 `rebrand-tool.exe` / `rebrand.py` / `branding.json` |
| 合并方案 | `MERGE-PLAN.md` |
| 回归脚本与日志 | `_build/d-regress.py`、`_build/d-regress.log`（D 的整体回归，81/81） |

## 三、已知限制（诚实边界）

- **32 位 exe 未在真实 XP / Win7 / Win10 机上双击验证过**：启动器只做了交叉编译 + `file` 确认 PE32 32 位；GUI 未在真实 Windows 上点按过；客户端界面只在 Linux + Xvfb 下跑过自测；Python 3.4.4 运行时上的实际表现仅做了 3.4 语法静态检查。
- **真实局域网多机与 150 并发压测未做**：只做了逻辑自测、小规模冒烟与双机联邦拉取（127.0.0.1 上的两个实例）；真实局域网多机访问与 150 并发需在真实环境核实。
- **浏览器实测未做**：B 的 `app.js` 只做了 `node --check` 与 HTTP 层回归（按 B 发的请求体逐项调通），现代版在 Chrome / Edge 中的实际交互、动效手感、深色模式切换、空格键推进未实测；Lite 版在真实 IE8 / XP 机上的渲染未实测。
- **题图**：tkinter 原生只解 GIF / PPM；Pillow `_imaging.pyd` 在真实 XP 上的实际加载与题图显示未验证。
- **客户端更新检查只查版本记录**，不下载程序体；启动器不含图标与版本信息，不管应用死活。

## 四、发现的问题（需 A 或 B/C 跟进，D 未改逻辑）

### 1. 学习计划同秒边界：同一秒内的作答不计入进度（已修）

- 现象（修前）：建计划后**同一秒内**答 2 道新题，`plans/me` 的 done=**0**；睡 2 秒后再答 1 道新题，done=**1**（只有后来那道计入，同一秒那 2 道永久不计）。
- 原因：`web/plans.py` 的 `plan_progress()` 用 `answered_at > created_at`（严格大于，秒级时间戳）。建计划与作答发生在同一秒时条件为假。
- 修复（统合收尾时修掉）：两处查询（`attempts` 与 `practice_records`）一律改为 `answered_at>=created_at`；`exe/app/server/plans.py` 已同步；自测 `plans(修复2)` 的建计划前加 1.2 秒等待（保证计划的 created_at 秒数严格晚于此前所有作答）。验证：建计划后同一秒内答 2 道题，`plans/me` 立即 done=**2**；服务器自测仍 91/91；两 zip 已重打（plans.py 修复版在内）。

### 2. 已修的 C 自测期望过期（D 已修测试代码，未动产品逻辑）

- `exe/app/selftest.py` 的 `v2_api_calls` 步写于 v2 服务端未落地时，期望 13 个调用全部 404；现服务端已落地，该步会把成功的学员接口判为 `unexpected-ok`（首次跑 20/21）。D 已把期望改成正确断言（3 个学员接口成功 + 10 个越权接口 403），重跑 21/21。

### 3. 回归中发现的脚本侧问题（均已在回归脚本里修正，不是产品问题）

- `/api/me` 只返回用户 dict，邀请码在 `/api/home/stats` 里；
- `v2_template_start` 的客户端封装返回 exam 本身（`_unwrap` 取 `exam` 键），不是 `{exam, questions}`；
- 联邦目录题数在回归中途从 20 涨到 23（PDF 导入 +2、变式发布 +1），属正常；
- 联邦主机登记返回 `{"host_id": 1}`；
- 对端联邦令牌须用对端管理员账号取（考官取会 403）。
