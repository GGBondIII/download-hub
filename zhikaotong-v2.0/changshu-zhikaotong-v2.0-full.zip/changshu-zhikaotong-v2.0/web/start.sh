#!/bin/sh
# 常熟站智考通 v2.0 网页版启动脚本
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null 2>&1 && ! command -v python >/dev/null 2>&1; then
  echo "未找到 Python，请先安装 Python 3.4 或以上版本，或直接使用 exe 版。"
  exit 1
fi
PY=$(command -v python3 || command -v python)
echo "正在启动常熟站智考通，端口 8766 ..."
echo "启动后用浏览器打开 http://127.0.0.1:8766/"
exec "$PY" server.py
