# -*- coding: utf-8 -*-
"""常熟站智考通 v2.0 -- 配色与 ttk 样式(藏青金主题)。

Python 3.4 兼容语法,仅用标准库 tkinter/ttk。
配色取自原版 palette.py 精确值。
"""
import tkinter.font as tkFont
from tkinter.ttk import Style

NAVY = "#24425F"
NAVY_DARK = "#1A3149"
NAVY_DEEP = "#13222F"
GOLD = "#D9A55C"
GOLD_DARK = "#B9894A"
GOLD_LIGHT = "#F6E8D2"
BG = "#F4F6F9"
CARD = "#FFFFFF"
PRIMARY_LIGHT = "#E9EEF5"
GREEN = "#16A34A"
RED = "#DC2626"
AMBER = "#F59E0B"
TEXT = "#1F2937"
TEXT_MUTED = "#6B7280"
BORDER = "#D9DEE6"

APP_NAME = "常熟站智考通"
VERSION = "v2.0"
TITLE = "常熟站智考通 v2.0"

FONT_CANDIDATES = ["微软雅黑", "黑体", "SimHei", "Microsoft YaHei", "Arial"]
_font_family = None


def pick_font_family(root):
    """按系统实际字体族修正:优先微软雅黑/黑体,不存在时回退。"""
    global _font_family
    if _font_family:
        return _font_family
    try:
        avail = tkFont.families(root)
    except Exception:
        avail = []
    for cand in FONT_CANDIDATES:
        if cand in avail:
            _font_family = cand
            return _font_family
    _font_family = "TkDefaultFont"
    return _font_family


def sizes(large=False):
    """字号两档:标准 / 特大。"""
    if large:
        return {"title": 22, "h1": 18, "h2": 16, "body": 15,
                "small": 13, "stem": 17, "option": 16, "pill": 13}
    return {"title": 18, "h1": 15, "h2": 13, "body": 12,
            "small": 10, "stem": 14, "option": 13, "pill": 11}


def font(root, size, bold=False, large=False):
    fam = pick_font_family(root)
    if fam == "TkDefaultFont":
        return ("TkDefaultFont", size, "bold" if bold else "normal")
    return (fam, size, "bold" if bold else "normal")


def setup_style(root):
    """clam 主题打底,按藏青金配色调 ttk.Style。"""
    st = Style(root)
    try:
        st.theme_use("clam")
    except Exception:
        pass
    st.configure("TFrame", background=BG)
    st.configure("Card.TFrame", background=CARD)
    st.configure("Nav.TFrame", background=NAVY)
    st.configure("TLabel", background=BG, foreground=TEXT)
    st.configure("Card.TLabel", background=CARD, foreground=TEXT)
    st.configure("Nav.TLabel", background=NAVY, foreground="#FFFFFF")
    st.configure("Muted.TLabel", background=BG, foreground=TEXT_MUTED)
    st.configure("CardMuted.TLabel", background=CARD, foreground=TEXT_MUTED)
    st.configure("TButton", padding=8, font=font(root, 12))
    st.configure("Navy.TButton", background=NAVY, foreground="#FFFFFF",
                 borderwidth=0, padding=10)
    st.map("Navy.TButton", background=[("active", NAVY_DARK),
                                       ("pressed", NAVY_DEEP)])
    st.configure("Gold.TButton", background=GOLD, foreground="#FFFFFF",
                 borderwidth=0, padding=10)
    st.map("Gold.TButton", background=[("active", GOLD_DARK),
                                      ("pressed", GOLD_DARK)])
    st.configure("Ghost.TButton", background=CARD, foreground=NAVY,
                 borderwidth=1, padding=8)
    st.configure("Nav.TButton", background=NAVY_DARK, foreground="#FFFFFF",
                 borderwidth=0, padding=10)
    st.map("Nav.TButton", background=[("active", NAVY_DEEP),
                                      ("pressed", NAVY_DEEP)])
    st.configure("Danger.TButton", background=RED, foreground="#FFFFFF",
                 borderwidth=0, padding=8)
    st.configure("TEntry", padding=6)
    st.configure("TCombobox", padding=5)
    st.configure("Treeview", background=CARD, fieldbackground=CARD,
                 foreground=TEXT, rowheight=28)
    st.configure("Treeview.Heading", background=PRIMARY_LIGHT,
                 foreground=NAVY)
    st.configure("TNotebook", background=BG)
    st.configure("TNotebook.Tab", padding=(12, 6))
    st.configure("TCheckbutton", background=BG)
    st.configure("Card.TCheckbutton", background=CARD)
    st.configure("TScale", background=BG)
    return st
