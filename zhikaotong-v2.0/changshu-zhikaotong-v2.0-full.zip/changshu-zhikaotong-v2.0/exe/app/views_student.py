# -*- coding: utf-8 -*-
"""常熟站智考通 v2.0 -- 学员端:首页、日常练习、错题本、练习统计、上报。

Python 3.4 兼容语法,仅标准库。
"""
import random

from tkinter import Frame, Label, StringVar
from tkinter.ttk import Button, Combobox, Entry, Treeview

from theme import (NAVY, GOLD, GOLD_LIGHT, BG, CARD, TEXT, TEXT_MUTED,
                   BORDER, PRIMARY_LIGHT, GREEN, RED, font, sizes)
from widgets import (clear, banner, stat_card, bar_chart, QuestionPanel,
                     confirm_dialog)
from api_client import ApiError

MODES = ["顺序", "随机", "错题", "题型"]
MODE_DESC = {"顺序": "按题号顺序刷完题库,断点续刷",
             "随机": "全量随机抽题,顺序打乱",
             "错题": "只刷错题本,做对自动移出",
             "题型": "选定题型后刷完该题型全部题目"}
TYPES = ["单选", "多选", "判断", "填空", "简答"]


def build_home(app, parent):
    """学员首页:问候、部门、统计、四模块卡片、导航、我的上报入口。"""
    clear(parent)
    app.page = "home_student"
    app.set_space_handler(None)
    try:
        data = app.api.get("/api/home/stats")
    except ApiError as e:
        banner(parent, e.message, "error")
        return parent
    user = (data or {}).get("user") or app.user or {}
    stats = (data or {}).get("practice") or {}
    ongoing = (data or {}).get("ongoing_mock")
    app.ui["home_stats"] = stats
    head = Frame(parent, bg=BG)
    head.pack(fill="x", padx=16, pady=(14, 4))
    Label(head, text="你好,{0}".format(user.get("name", "")),
          bg=BG, fg=NAVY, font=font(head, 20, bold=True)).pack(side="left")
    Label(head, text=user.get("department", ""), bg=PRIMARY_LIGHT, fg=NAVY,
          font=font(head, 12), padx=8, pady=2).pack(side="left", padx=10)
    Label(head, text="常熟站智考通", bg=BG, fg=TEXT_MUTED,
          font=font(head, 12)).pack(side="right")
    if ongoing:
        bar = banner(parent, "有一场进行中的模拟考试,继续作答", "warn")
        bar.bind("<Button-1>", lambda e: app.goto("mock_resume",
                                                  attempt_id=ongoing.get("id")))
        bar.configure(cursor="hand2")
    row = Frame(parent, bg=BG)
    row.pack(fill="x", padx=16, pady=8)
    total = stats.get("total", 0)
    correct = stats.get("correct", 0)
    acc = stats.get("accuracy", 0)
    wrong = stats.get("wrong_count", 0)
    for title, val in (("已练习题", str(total)), ("答对题数", str(correct)),
                       ("正确率", "{0}%".format(acc)),
                       ("错题数", str(wrong))):
        c = stat_card(row, title, val)
        c.pack(side="left", fill="x", expand=True, padx=6)
    Label(parent, text="日常练习", bg=BG, fg=NAVY,
          font=font(parent, 15, bold=True)).pack(anchor="w", padx=16,
                                                  pady=(8, 4))
    grid = Frame(parent, bg=BG)
    grid.pack(fill="x", padx=16)
    app.ui["home_modules"] = {}
    for i, mode in enumerate(MODES):
        card = Frame(grid, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1, cursor="hand2")
        card.grid(row=0, column=i, padx=6, pady=6, sticky="nsew")
        grid.columnconfigure(i, weight=1)
        dot = Label(card, text=mode[0], bg=NAVY, fg="#FFFFFF",
                    font=font(card, 20, bold=True), width=2, height=1)
        dot.pack(pady=(14, 4))
        Label(card, text={"顺序": "顺序刷题", "随机": "随机刷题",
                          "错题": "错题刷题", "题型": "题型练习"}[mode],
              bg=CARD, fg=NAVY, font=font(card, 14, bold=True)).pack()
        Label(card, text=MODE_DESC[mode], bg=CARD, fg=TEXT_MUTED,
              font=font(card, 11), wraplength=180, justify="left"
              ).pack(padx=10, pady=(4, 14))
        cmd = lambda m=mode: app.goto("practice", mode=m)
        for w in (card, dot):
            w.bind("<Button-1>", lambda e, c=cmd: c())
        app.ui["home_modules"][mode] = cmd
    nav = Frame(parent, bg=BG)
    nav.pack(fill="x", padx=16, pady=10)
    for text, page in (("日常练习", "practice"), ("模拟考试", "mock"),
                       ("正式考试", "exam"), ("系统设置", "settings")):
        Button(nav, text=text, style="Navy.TButton",
               command=lambda p=page: app.goto(p)).pack(side="left", padx=6)
    Button(nav, text="我的上报", style="Gold.TButton",
           command=lambda: app.goto("my_reports")).pack(side="left", padx=6)
    Button(nav, text="练习统计", style="Ghost.TButton",
           command=lambda: app.goto("practice_stats")).pack(side="left", padx=6)
    Button(nav, text="错题本", style="Ghost.TButton",
           command=lambda: app.goto("wrongbook")).pack(side="left", padx=6)
    Button(nav, text="自适应练习", style="Navy.TButton",
           command=lambda: app.goto("adaptive")).pack(side="left", padx=6)
    Button(nav, text="五环节", style="Navy.TButton",
           command=lambda: app.goto("modes")).pack(side="left", padx=6)
    Button(nav, text="薄弱训练", style="Gold.TButton",
           command=lambda: app.goto("weak")).pack(side="left", padx=6)
    Button(nav, text="我的仪表盘", style="Gold.TButton",
           command=lambda: app.goto("my_dashboard")).pack(side="left", padx=6)
    Button(nav, text="我的计划", style="Ghost.TButton",
           command=lambda: app.goto("my_plans")).pack(side="left", padx=6)
    Button(nav, text="简答批阅结果", style="Ghost.TButton",
           command=lambda: app.goto("my_essay")).pack(side="left", padx=6)
    return parent


# ---------------- 练习 ----------------

class PracticeSession(object):
    def __init__(self, app, parent, mode, category="", qtype="", count=0,
                 seed=None):
        self.app = app
        self.parent = parent
        self.mode = mode
        self.category = category
        self.qtype = qtype
        self.count = count
        self.seed = seed if seed is not None else random.randint(1, 999999)
        self.questions = []
        self.idx = 0
        self.correct_n = 0
        self.wrong_n = 0
        self.panel = None
        self._load()

    def _load(self):
        app = self.app
        params = {"mode": self.mode, "count": self.count}
        if self.category:
            params["category"] = self.category
        if self.qtype:
            params["type"] = self.qtype
        if self.mode in ("随机", "题型"):
            params["seed"] = self.seed
        try:
            data = app.api.get("/api/practice/list", params=params)
        except ApiError as e:
            banner(self.parent, e.message, "error")
            return
        self.questions = (data or {}).get("questions") or []
        # 断点续刷:同一模式记住上次下标
        key = "breakpoint_" + self.mode
        saved = app.config.get(key, 0)
        if isinstance(saved, int) and 0 <= saved < len(self.questions):
            self.idx = saved
        self._render()

    def _render(self):
        clear(self.parent)
        app = self.app
        app.page = "practice_run"
        head = Frame(self.parent, bg=BG)
        head.pack(fill="x", padx=12, pady=(10, 0))
        Label(head, text="{0}刷题".format(self.mode), bg=BG, fg=NAVY,
              font=font(head, 16, bold=True)).pack(side="left")
        Label(head, text="共 {0} 题".format(len(self.questions)), bg=BG,
              fg=TEXT_MUTED, font=font(head, 12)).pack(side="left", padx=10)
        Button(head, text="结束练习", style="Gold.TButton",
               command=self._finish).pack(side="right", padx=4)
        Button(head, text="返回", style="Ghost.TButton",
               command=lambda: app.goto("practice")).pack(side="right")
        if not self.questions:
            banner(self.parent, "暂无题目,请先让考官导入题库", "warn")
            return
        self.body = Frame(self.parent, bg=BG)
        self.body.pack(fill="both", expand=True)
        self._show_question()
        nav = Frame(self.parent, bg=BG)
        nav.pack(fill="x", padx=12, pady=8)
        Button(nav, text="上一题", style="Ghost.TButton",
               command=self._prev).pack(side="left", padx=4)
        Button(nav, text="下一题", style="Navy.TButton",
               command=self._next).pack(side="left", padx=4)
        Label(nav, text="跳转到题号:", bg=BG, fg=TEXT_MUTED,
              font=font(nav, 12)).pack(side="left", padx=(16, 2))
        self.jump_var = StringVar()
        Entry(nav, textvariable=self.jump_var, width=6,
              font=font(nav, 12)).pack(side="left")
        Button(nav, text="跳转", style="Ghost.TButton",
               command=self._jump).pack(side="left", padx=4)
        app.set_space_handler(self._space)

    def _show_question(self):
        clear(self.body)
        q = self.questions[self.idx]
        app = self.app

        def on_submit(ans, panel):
            payload = {"question_id": q.get("id"), "mode": self.mode,
                       "user_answer": ans}
            if q.get("type") == "简答":
                # 简答:先提交文本,由面板下方自评按钮判分
                payload["self_correct"] = None
            try:
                res = app.api.post("/api/practice/answer", payload)
            except ApiError as e:
                banner(self.body, e.message, "error")
                return {"correct": None}
            if res.get("correct") is True:
                self.correct_n += 1
            elif res.get("correct") is False:
                self.wrong_n += 1
            if q.get("type") == "简答":
                self._self_grade_bar(q, res)
            return res

        self.panel = QuestionPanel(app, self.body, q, self.idx,
                                   len(self.questions), on_submit=on_submit,
                                   shuffle=bool(app.prefs.get("shuffle_options")))
        app.ui["practice_panel"] = self.panel
        app.ui["practice_session"] = self

    def _self_grade_bar(self, q, res):
        row = Frame(self.panel.frame, bg=CARD)
        row.pack(fill="x", padx=14, pady=6)
        Label(row, text="对照参考答案自评:", bg=CARD, fg=NAVY,
              font=font(row, 12, bold=True)).pack(side="left")
        Label(row, text="参考答案:{0}".format(res.get("correct_answer", "")),
              bg=CARD, fg=TEXT, font=font(row, 12), wraplength=500,
              justify="left").pack(side="left", padx=8)

        def grade(ok):
            try:
                r2 = self.app.api.post("/api/practice/answer",
                                       {"question_id": q.get("id"),
                                        "mode": self.mode,
                                        "user_answer": self.panel.current_answer(),
                                        "self_correct": bool(ok)})
            except ApiError as e:
                banner(self.parent, e.message, "error")
                return
            if r2.get("correct") is True:
                self.correct_n += 1
            elif r2.get("correct") is False:
                self.wrong_n += 1
            for w in row.winfo_children():
                w.configure(state="disabled") if hasattr(w, "configure") else None
            banner(self.parent, "自评已记录:{0}".format(
                "我做对了" if ok else "我做错了"), "ok")

        Button(row, text="我做对了", style="Navy.TButton",
               command=lambda: grade(True)).pack(side="left", padx=4)
        Button(row, text="我做错了", style="Ghost.TButton",
               command=lambda: grade(False)).pack(side="left", padx=4)

    def _save_breakpoint(self):
        self.app.config["breakpoint_" + self.mode] = self.idx
        self.app.save_config()

    def _space(self):
        if not self.panel:
            return
        if not self.panel.submitted:
            self.panel.submit()
        else:
            self._next()

    def _prev(self):
        if self.idx > 0:
            self.idx -= 1
            self._save_breakpoint()
            self._show_question()

    def _next(self):
        if self.idx + 1 < len(self.questions):
            self.idx += 1
            self._save_breakpoint()
            self._show_question()
        else:
            self._finish()

    def _jump(self):
        try:
            n = int(self.jump_var.get())
        except Exception:
            return
        if 1 <= n <= len(self.questions):
            self.idx = n - 1
            self._save_breakpoint()
            self._show_question()

    def _finish(self):
        self.app.config["breakpoint_" + self.mode] = 0
        self.app.save_config()
        self.app.set_space_handler(None)
        clear(self.parent)
        Label(self.parent, text="练习完成", bg=BG, fg=NAVY,
              font=font(self.parent, 18, bold=True)).pack(pady=(30, 6))
        Label(self.parent, text="答对 {0} 题,答错 {1} 题".format(
            self.correct_n, self.wrong_n), bg=BG, fg=TEXT,
            font=font(self.parent, 14)).pack(pady=4)
        Label(self.parent, text="答错的题目已自动加入错题本,"
              "可在错题本中复习并查看智能分析", bg=BG, fg=TEXT_MUTED,
              font=font(self.parent, 12)).pack(pady=4)
        row = Frame(self.parent, bg=BG)
        row.pack(pady=16)
        Button(row, text="再练一组", style="Navy.TButton",
               command=lambda: self.app.goto("practice", mode=self.mode)
               ).pack(side="left", padx=6)
        Button(row, text="去错题本", style="Gold.TButton",
               command=lambda: self.app.goto("wrongbook")).pack(side="left",
                                                                padx=6)
        Button(row, text="返回首页", style="Ghost.TButton",
               command=lambda: self.app.goto("home")).pack(side="left", padx=6)


def build_practice(app, parent, mode="顺序"):
    """练习模式选择页。"""
    clear(parent)
    app.page = "practice"
    app.set_space_handler(None)
    Label(parent, text="日常练习", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    try:
        cats = app.api.get("/api/questions/categories")
    except ApiError:
        cats = []
    form = Frame(parent, bg=CARD, highlightbackground=BORDER,
                 highlightthickness=1)
    form.pack(fill="x", padx=16, pady=6)
    mode_var = StringVar(value=mode)
    Label(form, text="模式", bg=CARD, fg=TEXT,
          font=font(form, 12, bold=True)).pack(anchor="w", padx=14, pady=(10, 2))
    mrow = Frame(form, bg=CARD)
    mrow.pack(anchor="w", padx=14)
    for m in MODES:
        Button(mrow, text=m, style="Navy.TButton" if m == mode else "Ghost.TButton",
               command=lambda mm=m: build_practice(app, parent, mode=mm)
               ).pack(side="left", padx=4)
    cat_var = StringVar(value="全部分类")
    Label(form, text="分类", bg=CARD, fg=TEXT,
          font=font(form, 12, bold=True)).pack(anchor="w", padx=14, pady=(8, 2))
    Combobox(form, textvariable=cat_var,
             values=["全部分类"] + list(cats or []), width=20,
             state="readonly").pack(anchor="w", padx=14)
    type_var = StringVar(value="单选")
    Label(form, text="题型(题型练习用)", bg=CARD, fg=TEXT,
          font=font(form, 12, bold=True)).pack(anchor="w", padx=14, pady=(8, 2))
    Combobox(form, textvariable=type_var, values=TYPES, width=20,
             state="readonly").pack(anchor="w", padx=14)
    count_var = StringVar(value="20")
    Label(form, text="题数(可下拉也可直接输入自定义数量;题型练习不选题数)",
          bg=CARD, fg=TEXT, font=font(form, 12, bold=True)
          ).pack(anchor="w", padx=14, pady=(8, 2))
    Combobox(form, textvariable=count_var,
             values=["10", "20", "30", "50", "全部"], width=20
             ).pack(anchor="w", padx=14)

    def start():
        cat = "" if cat_var.get() in ("全部分类", "") else cat_var.get()
        try:
            count = 0 if count_var.get() == "全部" else int(count_var.get())
        except Exception:
            count = 20
        PracticeSession(app, parent, mode_var.get(), category=cat,
                        qtype=type_var.get(), count=count)

    Button(form, text="开始练习", style="Navy.TButton",
           command=start).pack(anchor="w", padx=14, pady=14)
    app.ui["practice_start"] = start
    app.ui["practice_mode_var"] = mode_var
    app.ui["practice_count_var"] = count_var
    # 断点续刷提示
    key = "breakpoint_" + mode
    saved = app.config.get(key, 0)
    if isinstance(saved, int) and saved > 0:
        banner(parent, "上次刷到第 {0} 题,可继续作答(开始后自动续刷)".format(saved + 1),
               "info")
    row = Frame(parent, bg=BG)
    row.pack(fill="x", padx=16, pady=8)
    Button(row, text="错题本", style="Gold.TButton",
           command=lambda: app.goto("wrongbook")).pack(side="left", padx=6)
    Button(row, text="练习统计", style="Ghost.TButton",
           command=lambda: app.goto("practice_stats")).pack(side="left", padx=6)
    Button(row, text="上报题目问题", style="Ghost.TButton",
           command=lambda: app.goto("my_reports")).pack(side="left", padx=6)
    return parent


def build_wrongbook(app, parent):
    clear(parent)
    app.page = "wrongbook"
    Label(parent, text="错题本", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    try:
        items = app.api.get("/api/wrongbook")
    except ApiError as e:
        banner(parent, e.message, "error")
        return parent
    app.ui["wrongbook_items"] = items
    if not items:
        Label(parent, text="暂无错题,继续加油", bg=BG, fg=GREEN,
              font=font(parent, 14)).pack(pady=30)
        return parent
    row = Frame(parent, bg=BG)
    row.pack(fill="x", padx=16, pady=4)
    Button(row, text="重做全部错题", style="Navy.TButton",
           command=lambda: app.goto("practice", mode="错题")).pack(side="left")
    for q in items:
        card = Frame(parent, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1)
        card.pack(fill="x", padx=16, pady=6)
        head = Frame(card, bg=CARD)
        head.pack(fill="x", padx=12, pady=(8, 2))
        Label(head, text="{0} {1}".format(q.get("no", ""), q.get("type", "")),
              bg=CARD, fg=NAVY, font=font(head, 13, bold=True)).pack(side="left")
        Label(head, text="正确答案:{0}".format(q.get("answer", "")),
              bg=CARD, fg=GREEN, font=font(head, 12, bold=True)
              ).pack(side="left", padx=10)
        Button(head, text="移除", style="Ghost.TButton",
               command=lambda qid=q.get("id"): _remove_wrong(app, parent, qid)
               ).pack(side="right")
        Label(card, text=q.get("stem", ""), bg=CARD, fg=TEXT,
              font=font(card, 13), wraplength=860, justify="left",
              anchor="w").pack(fill="x", padx=12, pady=2)
        if q.get("analysis"):
            Label(card, text="解析:{0}".format(q.get("analysis")), bg=CARD,
                  fg=TEXT, font=font(card, 12), wraplength=860,
                  justify="left", anchor="w").pack(fill="x", padx=12, pady=2)
        sat = q.get("smart_analysis_text") or ""
        if sat:
            Label(card, text=sat, bg=GOLD_LIGHT, fg=TEXT,
                  font=font(card, 12), wraplength=860, justify="left",
                  anchor="w").pack(fill="x", padx=12, pady=(2, 8))
    return parent


def _remove_wrong(app, parent, qid):
    try:
        app.api.post("/api/wrongbook/remove", {"question_id": qid})
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    build_wrongbook(app, parent)


def build_practice_stats(app, parent):
    clear(parent)
    app.page = "practice_stats"
    Label(parent, text="练习统计", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    try:
        stats = app.api.get("/api/practice/stats")
    except ApiError as e:
        banner(parent, e.message, "error")
        return parent
    row = Frame(parent, bg=BG)
    row.pack(fill="x", padx=16, pady=6)
    for title, val in (("做题总数", str(stats.get("total", 0))),
                       ("答对题数", str(stats.get("correct", 0))),
                       ("正确率", "{0}%".format(stats.get("accuracy", 0))),
                       ("错题数", str(stats.get("wrong_count", 0)))):
        stat_card(row, title, val).pack(side="left", fill="x", expand=True,
                                         padx=6)
    by_type = stats.get("by_type") or []
    items = [(d.get("type", ""), d.get("total", 0)) for d in by_type]
    bar_chart(parent, items, "各题型做题数").pack(fill="x", padx=16, pady=8)
    trend = stats.get("trend") or []
    titems = [(d.get("date", "")[5:], d.get("total", 0)) for d in trend]
    bar_chart(parent, titems, "近期练习趋势(近 14 天)").pack(fill="x",
                                                             padx=16, pady=8)
    return parent


def build_my_reports(app, parent):
    clear(parent)
    app.page = "my_reports"
    Label(parent, text="我的上报", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    try:
        items = app.api.get("/api/reports/mine")
    except ApiError as e:
        banner(parent, e.message, "error")
        return parent
    # 上报入口:选一道题上报(用题号)
    form = Frame(parent, bg=CARD, highlightbackground=BORDER,
                 highlightthickness=1)
    form.pack(fill="x", padx=16, pady=6)
    Label(form, text="上报题目问题", bg=CARD, fg=NAVY,
          font=font(form, 13, bold=True)).pack(anchor="w", padx=14, pady=(8, 2))
    qid_var = StringVar()
    type_var = StringVar(value="题干有歧义")
    detail_var = StringVar()
    Label(form, text="题目 ID(题号数字,如 1)", bg=CARD, fg=TEXT,
          font=font(form, 12)).pack(anchor="w", padx=14)
    Entry(form, textvariable=qid_var, width=12,
          font=font(form, 12)).pack(anchor="w", padx=14)
    Label(form, text="问题类型", bg=CARD, fg=TEXT,
          font=font(form, 12)).pack(anchor="w", padx=14, pady=(6, 0))
    Combobox(form, textvariable=type_var,
             values=["题干有歧义", "答案有误", "解析有误", "其他问题"],
             width=20, state="readonly").pack(anchor="w", padx=14)
    Label(form, text="补充说明(选填)", bg=CARD, fg=TEXT,
          font=font(form, 12)).pack(anchor="w", padx=14, pady=(6, 0))
    Entry(form, textvariable=detail_var, width=50,
          font=font(form, 12)).pack(anchor="w", padx=14)
    msg = Label(form, text="", bg=CARD, fg="#16A34A", font=font(form, 12))
    msg.pack(anchor="w", padx=14, pady=4)

    def submit_report():
        try:
            qid = int(qid_var.get())
        except Exception:
            msg.configure(text="请填写正确的题目 ID", fg="#DC2626")
            return
        try:
            app.api.post("/api/reports",
                         {"question_id": qid, "type": type_var.get(),
                          "detail": detail_var.get()})
        except ApiError as e:
            msg.configure(text=e.message, fg="#DC2626")
            return
        msg.configure(text="提交成功", fg="#16A34A")
        app.root.after(800, lambda: build_my_reports(app, parent))

    Button(form, text="提交上报", style="Navy.TButton",
           command=submit_report).pack(anchor="w", padx=14, pady=10)
    if not items:
        Label(parent, text="暂无上报记录", bg=BG, fg=TEXT_MUTED,
              font=font(parent, 12)).pack(pady=12)
        return parent
    for r in items:
        card = Frame(parent, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1)
        card.pack(fill="x", padx=16, pady=6)
        q = r.get("question") or {}
        Label(card, text="{0} {1}  {2}".format(q.get("no", ""),
              r.get("type", ""), r.get("status", "")), bg=CARD, fg=NAVY,
              font=font(card, 13, bold=True), anchor="w"
              ).pack(fill="x", padx=12, pady=(8, 2))
        Label(card, text=q.get("stem", ""), bg=CARD, fg=TEXT,
              font=font(card, 12), wraplength=860, justify="left",
              anchor="w").pack(fill="x", padx=12)
        if r.get("detail"):
            Label(card, text="补充说明:{0}".format(r.get("detail")), bg=CARD,
                  fg=TEXT_MUTED, font=font(card, 12), anchor="w",
                  wraplength=860, justify="left").pack(fill="x", padx=12)
        if r.get("reply"):
            Label(card, text="管理员回复:{0}".format(r.get("reply")),
                  bg=CARD, fg=NAVY, font=font(card, 12), anchor="w",
                  wraplength=860, justify="left").pack(fill="x", padx=12,
                                                        pady=(0, 8))
    return parent


# ---------------- v2:自适应 / 五环节 / 薄弱 / 仪表盘 ----------------
# v2 接口返回的题目可能是 v07 形状(type 为 single/multi/judge/
# short/material,options 为 [{label, content}] 列表),也可能是
# v1 形状(type 为中文,options 为 {A: ...} dict);统一归一化成
# v1 QuestionPanel 能用的形状再作答。作答仍走 v1 的
# /api/practice/answer(见 MERGE-PLAN.md §六末尾说明)。

V2_TYPE_MAP = {"single": "单选", "multi": "多选", "judge": "判断",
               "fill": "填空", "short": "简答", "material": "简答"}


def normalize_v2_question(q):
    """把 v07/v2 形状的题目归一化成 v1 形状(不改原 dict)。"""
    q = dict(q or {})
    q["type"] = V2_TYPE_MAP.get(q.get("type"), q.get("type", "单选"))
    opts = q.get("options")
    if isinstance(opts, list):
        out = {}
        for i, o in enumerate(opts):
            if isinstance(o, dict):
                out[o.get("label") or chr(65 + i)] = o.get("content", "")
            else:
                out[chr(65 + i)] = o
        q["options"] = out
    if not q.get("category"):
        kn = q.get("knowledge") or []
        if isinstance(kn, list) and kn:
            q["category"] = kn[0]
        elif q.get("subject"):
            q["category"] = q.get("subject")
    if not q.get("no"):
        q["no"] = "题 {0}".format(q.get("id", ""))
    assets = q.get("assets") or []
    if assets and not q.get("image"):
        first = assets[0]
        if isinstance(first, dict):
            q["image"] = first.get("filename", "")
        else:
            q["image"] = first
    return q


class V2PracticeSession(PracticeSession):
    """用已取回的题单直接开练(自适应 / 薄弱训练),不走
    /api/practice/list。判分与断点逻辑沿用 PracticeSession。"""

    def __init__(self, app, parent, mode, questions):
        self.app = app
        self.parent = parent
        self.mode = mode
        self.category = ""
        self.qtype = ""
        self.count = len(questions or [])
        self.seed = random.randint(1, 999999)
        self.questions = [normalize_v2_question(q)
                          for q in (questions or [])]
        self.idx = 0
        self.correct_n = 0
        self.wrong_n = 0
        self.panel = None
        self._render()

    def _load(self):
        return


def _v2_start_session(app, parent, mode, questions):
    if not questions:
        banner(parent, "暂无题目,请先练习几道题或让考官导入题库", "warn")
        return
    V2PracticeSession(app, parent, mode, questions)


def build_adaptive(app, parent):
    """自适应练习:画像 + 出题比例 + 开始按钮。"""
    clear(parent)
    app.page = "adaptive"
    app.set_space_handler(None)
    Label(parent, text="自适应练习", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    try:
        prof = app.api.v2_adaptive()
    except ApiError as e:
        banner(parent, e.message, "error")
        app.ui["v2_adaptive"] = {}
        return parent
    prof = prof or {}
    app.ui["v2_adaptive"] = prof
    row = Frame(parent, bg=BG)
    row.pack(fill="x", padx=16, pady=6)
    ratio = prof.get("ratio") or {}
    for title, val in (("累计作答", str(prof.get("total_attempts", 0))),
                       ("连续学习", "{0} 天".format(prof.get("streak_days", 0))),
                       ("待复习", "{0} 题".format(prof.get("due_count", 0))),
                       ("薄弱占比", "{0}%".format(ratio.get("weak_pct", "")))):
        stat_card(row, title, val).pack(side="left", fill="x", expand=True,
                                         padx=6)
    if prof.get("cold_start"):
        banner(parent, "冷启动:样本不足 20 题,先按默认比例出题,"
               "满 20 题后开始个性化", "info")
    if prof.get("sample_note"):
        Label(parent, text=prof.get("sample_note"), bg=BG, fg=TEXT,
              font=font(parent, 12), wraplength=860, justify="left",
              anchor="w").pack(fill="x", padx=16, pady=4)
    weak = prof.get("weak_knowledge") or []
    if weak:
        Label(parent, text="薄弱知识点:{0}".format("、".join(weak)), bg=BG,
              fg=RED, font=font(parent, 13, bold=True), anchor="w"
              ).pack(fill="x", padx=16, pady=4)
    per = prof.get("per_knowledge") or []
    if per:
        items = [(d.get("knowledge", ""), d.get("accuracy", 0))
                 for d in per]
        from widgets import radar_chart
        radar_chart(parent, items, "各知识点掌握度(雷达)").pack(
            fill="x", padx=16, pady=8)
        for d in per:
            Label(parent, text="{0}:共 {1} 题,正确率 {2}%,目标难度 {3}".format(
                d.get("knowledge", ""), d.get("total", 0),
                int(round((d.get("accuracy", 0) or 0) * 100)),
                d.get("target_difficulty", "")), bg=BG, fg=TEXT,
                font=font(parent, 12), anchor="w").pack(fill="x", padx=16)
    row2 = Frame(parent, bg=BG)
    row2.pack(fill="x", padx=16, pady=12)
    count_var = StringVar(value="20")
    Label(row2, text="题数", bg=BG, fg=TEXT,
          font=font(row2, 12)).pack(side="left")
    Combobox(row2, textvariable=count_var,
             values=["10", "20", "30"], width=6).pack(side="left", padx=6)

    def start():
        try:
            count = int(count_var.get() or 20)
        except Exception:
            count = 20
        try:
            qs = app.api.v2_adaptive_questions(count=count)
        except ApiError as e:
            banner(parent, e.message, "error")
            return
        if isinstance(qs, dict):
            qs = qs.get("questions") or []
        _v2_start_session(app, parent, "自适应", qs)

    Button(row2, text="开始自适应练习", style="Navy.TButton",
           command=start).pack(side="left", padx=6)
    app.ui["v2_adaptive_start"] = start
    app.ui["v2_adaptive_count"] = count_var
    Button(row2, text="薄弱项训练", style="Gold.TButton",
           command=lambda: app.goto("weak")).pack(side="left", padx=6)
    Button(row2, text="我的仪表盘", style="Ghost.TButton",
           command=lambda: app.goto("my_dashboard")).pack(side="left", padx=6)
    return parent


MODES_V2 = [("顺序", "顺序刷题", "按题号顺序刷完题库,断点续刷"),
            ("随机", "随机刷题", "全量随机抽题,顺序打乱"),
            ("错题回顾", "错题回顾", "只刷错题本,做对自动移出"),
            ("薄弱分析", "薄弱分析", "按薄弱知识点出题,重点突破"),
            ("阶段考核", "阶段考核", "模拟考试 / 正式考试入口")]


def build_modes(app, parent):
    """学习方法五环节入口。接口有数据就用接口的,没有就用内置五项。"""
    clear(parent)
    app.page = "modes"
    app.set_space_handler(None)
    Label(parent, text="学习方法五环节", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    modes = None
    try:
        raw = app.api.v2_practice_modes()
        if isinstance(raw, dict):
            modes = raw.get("modes") or raw.get("items")
        elif isinstance(raw, list):
            modes = raw
    except ApiError:
        modes = None
    app.ui["v2_modes"] = modes
    entries = []
    if modes:
        for m in modes:
            if isinstance(m, dict):
                entries.append((m.get("key") or m.get("name") or "",
                                m.get("title") or m.get("name") or "",
                                m.get("desc") or m.get("description") or ""))
            else:
                entries.append((m, m, ""))
    if not entries:
        entries = list(MODES_V2)
    app.ui["v2_mode_entries"] = entries
    for key, title, desc in entries:
        card = Frame(parent, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1)
        card.pack(fill="x", padx=16, pady=6)
        Label(card, text=title, bg=CARD, fg=NAVY,
              font=font(card, 14, bold=True), anchor="w").pack(
                  fill="x", padx=12, pady=(8, 2))
        Label(card, text=desc, bg=CARD, fg=TEXT_MUTED,
              font=font(card, 12), anchor="w", wraplength=860,
              justify="left").pack(fill="x", padx=12, pady=(0, 8))

        def go(k=key):
            if k in ("顺序", "sequential", "order"):
                app.goto("practice", mode="顺序")
            elif k in ("随机", "random"):
                app.goto("practice", mode="随机")
            elif k in ("错题回顾", "错题", "wrong", "review"):
                app.goto("practice", mode="错题")
            elif k in ("薄弱分析", "薄弱", "weak"):
                app.goto("weak")
            elif k in ("阶段考核", "考核", "exam", "mock"):
                app.goto("mock")
            else:
                app.goto("practice", mode="顺序")

        Button(card, text="进入", style="Navy.TButton",
               command=go).pack(anchor="w", padx=12, pady=(0, 10))
        app.ui["v2_mode_go_" + key] = go
    return parent


def build_weak(app, parent):
    """薄弱项训练:薄弱知识点 + 薄弱题单。"""
    clear(parent)
    app.page = "weak"
    app.set_space_handler(None)
    Label(parent, text="薄弱项训练", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    try:
        qs = app.api.v2_weak(count=10)
    except ApiError as e:
        banner(parent, e.message, "error")
        app.ui["v2_weak"] = []
        return parent
    if isinstance(qs, dict):
        prof = qs
        qs = qs.get("questions") or []
    else:
        prof = {}
    app.ui["v2_weak"] = qs
    weak = prof.get("weak_knowledge") or []
    if weak:
        Label(parent, text="薄弱知识点:{0}".format("、".join(weak)), bg=BG,
              fg=RED, font=font(parent, 13, bold=True), anchor="w"
              ).pack(fill="x", padx=16, pady=4)
    if not qs:
        Label(parent, text="暂无薄弱题:先做 20 道练习,系统才能判断薄弱项",
              bg=BG, fg=TEXT_MUTED, font=font(parent, 13)).pack(pady=20)
        return parent
    Label(parent, text="共 {0} 道薄弱题".format(len(qs)), bg=BG, fg=TEXT,
          font=font(parent, 13)).pack(anchor="w", padx=16, pady=4)
    for q in qs:
        nq = normalize_v2_question(q)
        card = Frame(parent, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1)
        card.pack(fill="x", padx=16, pady=4)
        Label(card, text="{0} [{1}] {2}".format(nq.get("no", ""),
              nq.get("type", ""), nq.get("stem", "")), bg=CARD, fg=TEXT,
              font=font(card, 12), wraplength=860, justify="left",
              anchor="w").pack(fill="x", padx=12, pady=8)
    row = Frame(parent, bg=BG)
    row.pack(fill="x", padx=16, pady=10)
    Button(row, text="开始薄弱训练", style="Navy.TButton",
           command=lambda: _v2_start_session(app, parent, "薄弱", qs)
           ).pack(side="left", padx=6)
    app.ui["v2_weak_start"] = lambda: _v2_start_session(app, parent,
                                                        "薄弱", qs)
    Button(row, text="自适应练习", style="Ghost.TButton",
           command=lambda: app.goto("adaptive")).pack(side="left", padx=6)
    return parent


def build_my_dashboard(app, parent):
    """我的仪表盘:雷达 + 趋势 + 环形(简版,Canvas 自绘)。"""
    clear(parent)
    app.page = "my_dashboard"
    app.set_space_handler(None)
    Label(parent, text="我的仪表盘", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    data = None
    try:
        data = app.api.v2_dashboard_charts()
    except ApiError:
        data = None
    if not data:
        try:
            uid = (app.user or {}).get("id")
            if uid:
                data = app.api.v2_dashboard_user(uid)
        except ApiError:
            data = None
    app.ui["my_dashboard"] = data or {}
    if not data:
        banner(parent, "仪表盘接口暂不可用(v2 服务端未就绪),"
               "先看练习统计", "warn")
        Button(parent, text="去练习统计", style="Navy.TButton",
               command=lambda: app.goto("practice_stats")).pack(
                   anchor="w", padx=16, pady=8)
        return parent
    rep = data
    if isinstance(data, dict):
        rep = data.get("report") or data.get("charts") or data
    if not isinstance(rep, dict):
        rep = {}
    total = rep.get("total", 0)
    correct = rep.get("correct", 0)
    acc = rep.get("accuracy", 0)
    if acc and acc <= 1:
        acc = int(round(acc * 100))
    row = Frame(parent, bg=BG)
    row.pack(fill="x", padx=16, pady=6)
    for title, val in (("累计作答", str(total)),
                       ("答对题数", str(correct)),
                       ("正确率", "{0}%".format(acc)),
                       ("连续学习", "{0} 天".format(rep.get("streak_days", 0))),
                       ("待复习", "{0} 题".format(rep.get("due_count", 0))),
                       ("错题数", str(rep.get("wrong_count", 0)))):
        stat_card(row, title, val).pack(side="left", fill="x", expand=True,
                                         padx=6)
    from widgets import radar_chart, donut_chart, trend_chart
    by_kn = rep.get("by_knowledge") or []
    if not by_kn:
        per = ((rep.get("adaptive") or {}).get("per_knowledge") or [])
        by_kn = per
    if by_kn:
        radar_chart(parent, [(d.get("knowledge", ""),
                              d.get("accuracy", 0)) for d in by_kn],
                    "各知识点掌握度(雷达)").pack(fill="x", padx=16, pady=8)
    trend = rep.get("trend") or []
    if trend:
        trend = list(reversed(trend)) if len(trend) > 1 and trend[0].get(
            "date", "") > trend[-1].get("date", "") else trend
        trend_chart(parent, [(d.get("date", "")[5:],
                              d.get("total", 0)) for d in trend],
                    "近期练习趋势(近 14 天)").pack(fill="x", padx=16, pady=8)
    wrong = rep.get("wrong_count", 0)
    donut_chart(parent, [("答对", correct, GREEN), ("答错", total - correct,
                              RED), ("错题本未掌握", wrong, "#F59E0B")],
                "作答构成(环形)").pack(fill="x", padx=16, pady=8)
    essay = rep.get("essay") or {}
    if essay:
        Label(parent, text="简答题:共 {0} 道,已批 {1} 道,待批 {2} 道,"
              "得分 {3}/{4}".format(essay.get("total", 0),
              essay.get("graded", 0), essay.get("pending", 0),
              essay.get("score", 0), essay.get("max_score", 0)), bg=BG,
              fg=TEXT, font=font(parent, 12), anchor="w").pack(
                  fill="x", padx=16, pady=4)
    if rep.get("advice"):
        Label(parent, text=rep.get("advice"), bg=GOLD_LIGHT, fg=NAVY,
              font=font(parent, 12), wraplength=860, justify="left",
              anchor="w").pack(fill="x", padx=16, pady=8)
    Button(parent, text="看简答批阅结果", style="Ghost.TButton",
           command=lambda: app.goto("my_essay")).pack(anchor="w", padx=16,
                                                      pady=4)
    return parent


def build_my_plans(app, parent):
    """我的学习计划:去重进度 + 逾期预警。"""
    clear(parent)
    app.page = "my_plans"
    app.set_space_handler(None)
    Label(parent, text="我的学习计划", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    try:
        plans = app.api.v2_plans_me()
    except ApiError as e:
        banner(parent, e.message, "error")
        app.ui["my_plans"] = []
        return parent
    if isinstance(plans, dict):
        plans = plans.get("plans") or []
    app.ui["my_plans"] = plans or []
    if not plans:
        Label(parent, text="暂无学习计划", bg=BG, fg=TEXT_MUTED,
              font=font(parent, 14)).pack(pady=30)
        return parent
    for p in plans:
        card = Frame(parent, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1)
        card.pack(fill="x", padx=16, pady=6)
        title = "{0}  进度 {1}/{2}({3}%)".format(p.get("title", ""),
                p.get("done", 0), p.get("target", 0), p.get("pct", 0))
        Label(card, text=title, bg=CARD, fg=NAVY,
              font=font(card, 13, bold=True), anchor="w").pack(
                  fill="x", padx=12, pady=(8, 2))
        detail = "知识点:{0}  每日目标:{1} 题  截止:{2}".format(
            p.get("knowledge", "") or "全部", p.get("daily_count", 0),
            p.get("due_date", "") or "无")
        if p.get("overdue"):
            detail += "  已逾期,请抓紧补练"
        Label(card, text=detail, bg=CARD,
              fg=RED if p.get("overdue") else TEXT_MUTED,
              font=font(card, 12), anchor="w", wraplength=860,
              justify="left").pack(fill="x", padx=12, pady=(0, 8))
    return parent


def build_my_essay(app, parent):
    """我的简答批阅结果:与选择题分开列示。"""
    clear(parent)
    app.page = "my_essay"
    app.set_space_handler(None)
    Label(parent, text="我的简答批阅结果", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    try:
        subs = app.api.v2_essay_mine()
    except ApiError as e:
        banner(parent, e.message, "error")
        app.ui["my_essay"] = []
        return parent
    if isinstance(subs, dict):
        subs = subs.get("submissions") or []
    app.ui["my_essay"] = subs or []
    if not subs:
        Label(parent, text="暂无简答批阅记录", bg=BG, fg=TEXT_MUTED,
              font=font(parent, 14)).pack(pady=30)
        return parent
    for s in subs:
        card = Frame(parent, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1)
        card.pack(fill="x", padx=16, pady=6)
        status = s.get("status", "")
        score = s.get("score")
        max_score = s.get("max_score", 10)
        head = "得分 {0}/{1}".format(score, max_score) if score is not None \
            else "待批阅"
        Label(card, text="{0}  {1}".format(s.get("stem", "")[:40], head),
              bg=CARD, fg=NAVY, font=font(card, 13, bold=True), anchor="w",
              wraplength=860, justify="left").pack(fill="x", padx=12,
                                                    pady=(8, 2))
        Label(card, text="状态:{0}  批阅人:{1}".format(status,
              s.get("reviewer", "") or "待批"), bg=CARD, fg=TEXT_MUTED,
              font=font(card, 12), anchor="w").pack(fill="x", padx=12)
        if s.get("comment"):
            Label(card, text="批阅意见:{0}".format(s.get("comment")),
                  bg=CARD, fg=TEXT, font=font(card, 12), anchor="w",
                  wraplength=860, justify="left").pack(fill="x", padx=12,
                                                        pady=(0, 8))
    return parent
