# -*- coding: utf-8 -*-
"""常熟站智考通 v2.0 — 题库业务:增删改查、搜索分页、启用停用、判分公用函数。

判分规则(规格书§四-3):单选/判断选中后提交,不选按答错;多选全对才得分;
填空留空按答错;简答对照参考答案自评(我做对了/我做错了)。
Python 3.4 兼容语法。
"""
import json
import re

import db

Q_TYPES = ('单选', '多选', '判断', '填空', '简答')
TYPE_ALIASES = {
    'single': '单选', 'multi': '多选', 'judge': '判断', 'fill': '填空', 'short': '简答',
    'choice': '单选', 'multiple': '多选', 'truefalse': '判断',
}
JUDGE_TRUE = ('A', '对', '正确', '√', 'TRUE', 'True', 'true', '1')
JUDGE_FALSE = ('B', '错', '错误', '×', 'FALSE', 'False', 'false', '0')


def normalize_type(raw):
    t = (raw or '').strip()
    if t in Q_TYPES:
        return t
    return TYPE_ALIASES.get(t.lower(), '')


def question_to_dict(row, include_answer=True):
    d = db.row_to_dict(row)
    if d is None:
        return None
    try:
        d['options'] = json.loads(d.get('options') or '{}')
    except ValueError:
        d['options'] = {}
    if not include_answer:
        d.pop('answer', None)
        d.pop('analysis', None)
    return d


def get_question(qid):
    conn = db.get_conn()
    with db.DB_LOCK:
        row = conn.execute("SELECT * FROM questions WHERE id=?", (qid,)).fetchone()
    return row


def normalize_judge(ans):
    a = (ans or '').strip()
    if a in JUDGE_TRUE:
        return '对'
    if a in JUDGE_FALSE:
        return '错'
    return a


def letters_of(ans):
    return sorted(set([c.upper() for c in (ans or '') if c.upper() in 'ABCDE']))


def grade_answer(qtype, user_answer, correct, self_correct=None):
    """返回 (is_correct, auto_graded)。
    简答不自动判分:自评 self_correct 为 True/False 时按自评计分,
    否则 is_correct 为 None(待自评)。
    """
    ua = (user_answer or '').strip()
    ca = (correct or '').strip()
    if qtype == '单选':
        return (ua.upper() == ca.upper(), True)
    if qtype == '多选':
        return (letters_of(ua) == letters_of(ca), True)
    if qtype == '判断':
        return (normalize_judge(ua) == normalize_judge(ca), True)
    if qtype == '填空':
        if self_correct is not None:
            # 交卷后自评可覆盖自动判分(表述不一致时以自评为准)
            return (bool(self_correct), False)
        if not ua:
            return (False, True)
        norm = lambda s: re.sub(r'\s+', '', s)
        alts = [norm(a) for a in ca.replace('；', '|').replace(';', '|').split('|')]
        return (norm(ua) in alts, True)
    # 简答
    if self_correct is None:
        return (None, False)
    return (bool(self_correct), False)


def list_questions(keyword='', qtype='', category='', status='', page=1, page_size=20):
    conn = db.get_conn()
    conds = []
    params = []
    if keyword:
        conds.append("(stem LIKE ? OR no LIKE ? OR category LIKE ?)")
        kw = '%' + keyword + '%'
        params += [kw, kw, kw]
    if qtype:
        conds.append("type=?")
        params.append(qtype)
    if category:
        conds.append("category=?")
        params.append(category)
    if status:
        conds.append("status=?")
        params.append(status)
    where = ('WHERE ' + ' AND '.join(conds)) if conds else ''
    with db.DB_LOCK:
        total = conn.execute("SELECT COUNT(*) FROM questions " + where, params).fetchone()[0]
        rows = conn.execute(
            "SELECT * FROM questions " + where + " ORDER BY no, id LIMIT ? OFFSET ?",
            params + [page_size, (page - 1) * page_size]).fetchall()
    return total, [question_to_dict(r) for r in rows]


def list_categories():
    conn = db.get_conn()
    with db.DB_LOCK:
        rows = conn.execute(
            "SELECT DISTINCT category FROM questions WHERE category<>'' ORDER BY category").fetchall()
    return [r[0] for r in rows]


def next_no():
    conn = db.get_conn()
    with db.DB_LOCK:
        rows = conn.execute("SELECT no FROM questions").fetchall()
    nums = []
    for r in rows:
        m = re.match(r'ZK(\d+)$', r[0] or '')
        if m:
            nums.append(int(m.group(1)))
    return "ZK{0:03d}".format((max(nums) if nums else 0) + 1)


def validate_question(q):
    """校验一道题 dict,返回错误信息(空串为通过)。字段:no/type/category/stem/options/answer/analysis。"""
    qtype = normalize_type(q.get('type'))
    if not qtype:
        return "题型不识别(应为 单选/多选/判断/填空/简答)"
    stem = (q.get('stem') or '').strip()
    if not stem:
        return "题干为空"
    opts = q.get('options') or {}
    answer = (q.get('answer') or '').strip()
    if not answer:
        return "答案为空"
    if qtype in ('单选', '多选', '判断'):
        filled = [k for k in sorted(opts.keys()) if (opts.get(k) or '').strip()]
        if qtype == '判断':
            if normalize_judge(answer) not in ('对', '错'):
                return "判断题答案应为 对/错"
        elif qtype == '单选':
            if len(filled) < 2:
                return "单选题至少填 2 个选项"
            if len(answer) != 1 or answer.upper() not in filled:
                return "单选题答案应为单个选项字母,且须在选项范围内"
        else:
            if len(filled) < 2:
                return "多选题至少填 2 个选项"
            if not letters_of(answer) or [c for c in letters_of(answer) if c not in filled]:
                return "多选题答案字母须在选项范围内"
    return ""


def create_question(data, created_no=None):
    qtype = normalize_type(data.get('type'))
    err = validate_question(data)
    if err:
        return None, err
    conn = db.get_conn()
    with db.DB_LOCK:
        no = (data.get('no') or '').strip() or created_no or next_no()
        cur = conn.execute(
            "INSERT INTO questions(no, type, category, stem, options, answer, analysis, image, status, created_at)"
            " VALUES(?, ?, ?, ?, ?, ?, ?, ?, '启用', datetime('now', 'localtime'))",
            (no, qtype, (data.get('category') or '').strip(),
             (data.get('stem') or '').strip(),
             json.dumps(data.get('options') or {}, ensure_ascii=False),
             (data.get('answer') or '').strip(),
             data.get('analysis') or '', data.get('image') or ''))
        conn.commit()
        row = conn.execute("SELECT * FROM questions WHERE id=?", (cur.lastrowid,)).fetchone()
    return question_to_dict(row), ""


def update_question(qid, data):
    row = get_question(qid)
    if row is None:
        return None, "题目不存在"
    merged = question_to_dict(row)
    for k in ('no', 'type', 'category', 'stem', 'options', 'answer', 'analysis', 'image', 'status'):
        if k in data:
            merged[k] = data[k]
    err = validate_question(merged)
    if err:
        return None, err
    conn = db.get_conn()
    with db.DB_LOCK:
        conn.execute(
            "UPDATE questions SET no=?, type=?, category=?, stem=?, options=?, answer=?, analysis=?, image=?, status=? WHERE id=?",
            ((merged.get('no') or '').strip(), normalize_type(merged.get('type')),
             (merged.get('category') or '').strip(), (merged.get('stem') or '').strip(),
             json.dumps(merged.get('options') or {}, ensure_ascii=False),
             (merged.get('answer') or '').strip(), merged.get('analysis') or '',
             merged.get('image') or '', merged.get('status') or '启用', qid))
        conn.commit()
        row = conn.execute("SELECT * FROM questions WHERE id=?", (qid,)).fetchone()
    return question_to_dict(row), ""


def delete_questions(ids):
    conn = db.get_conn()
    with db.DB_LOCK:
        n = 0
        for qid in ids:
            cur = conn.execute("DELETE FROM questions WHERE id=?", (qid,))
            n += cur.rowcount
        conn.commit()
    return n


def set_question_status(qid, status):
    if status not in ('启用', '停用'):
        return False, "状态只能是 启用/停用"
    conn = db.get_conn()
    with db.DB_LOCK:
        cur = conn.execute("UPDATE questions SET status=? WHERE id=?", (status, qid))
        conn.commit()
    if cur.rowcount == 0:
        return False, "题目不存在"
    return True, ""


def sample_questions(qcounts, category='', exclude_ids=None, seed=None):
    """按各题型数量从启用题库随机抽题,返回 question id 列表(按题型分组顺序)。
    抽不到足量时返回实际抽到的数量。"""
    import random
    rng = random.Random(seed)
    conn = db.get_conn()
    out = []
    with db.DB_LOCK:
        for qtype in Q_TYPES:
            n = int((qcounts or {}).get(qtype) or 0)
            if n <= 0:
                continue
            sql = "SELECT id FROM questions WHERE type=? AND status='启用'"
            params = [qtype]
            if category:
                sql += " AND category=?"
                params.append(category)
            rows = conn.execute(sql, params).fetchall()
            ids = [r[0] for r in rows]
            if exclude_ids:
                ids = [i for i in ids if i not in exclude_ids]
            rng.shuffle(ids)
            out.extend(ids[:n])
    return out
