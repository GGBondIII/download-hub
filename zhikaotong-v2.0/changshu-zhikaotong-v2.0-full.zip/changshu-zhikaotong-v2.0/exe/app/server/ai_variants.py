# -*- coding: utf-8 -*-
"""常熟站智考通 v2.0 — 本地 AI 辅助出题:纯规则变式引擎,不联网、不接模型。

照抄刷题宝 v0.7 server.py 3311–3391 行的逻辑。
变式只改可替换槽位(选项顺序/题干同义词/题干数字),不改考点;变式进草稿,
须人工审核通过才能发布。Python 3.4 兼容语法。
"""
import json
import random
import re

import db
import questions as qmod

VARIANT_SYNONYMS = [("应当", "应该"), ("必须", "应"), ("旅客", "出入境旅客"),
                    ("可以", "能够"), ("不得", "不准")]
NUM_REPLACE = {1: 2, 2: 3, 3: 5, 5: 10, 7: 14, 10: 15, 15: 20, 20: 30,
               30: 45, 45: 30, 60: 90, 24: 48}


def _remap_answer(qtype, old_options, new_options, old_answer):
    """选项重排后重算答案字母。old_options/new_options 都是内容列表。"""
    pos = dict([(c, i) for i, c in enumerate(old_options)])
    if qtype == '单选':
        idx = pos.get((old_answer or '').strip(), 0)
        if old_options[idx] in new_options:
            return chr(65 + new_options.index(old_options[idx]))
        return old_answer
    if qtype == '多选':
        letters = []
        for ch in str(old_answer):
            if ch.strip() in pos:
                letters.append(chr(65 + new_options.index(old_options[pos[ch.strip()]])))
        return ''.join(sorted(letters))
    return old_answer


def make_variants(q, count):
    """按母题生成变式。q 为 questions.question_to_dict 的 dict(options 为
    {字母: 内容})。返回 [{kind, stem, options, answer, explanation, note}]。
    kind:shuffle=选项顺序变式;wording=题干表述变式;numeric=题干数字变式。"""
    out = []
    opts = q.get('options') or {}
    contents = [opts[k] for k in sorted(opts.keys())]
    correct_contents = []
    if q['type'] == '单选':
        ans = str(q.get('answer') or '').strip()
        if ans:
            correct_contents = [contents[ord(ans[0]) - 65]] if 0 <= ord(ans[0]) - 65 < len(contents) else []
    elif q['type'] == '多选':
        correct_contents = [contents[ord(ch) - 65] for ch in str(q.get('answer') or '')
                            if ch.strip() and 65 <= ord(ch) < 65 + len(contents)]
    if q['type'] in ('单选', '多选') and len(contents) >= 3:
        new_opts = contents[:]
        for _ in range(20):
            random.shuffle(new_opts)
            if new_opts != contents:
                break
        if new_opts != contents:
            out.append({'kind': 'shuffle', 'stem': q['stem'], 'options': new_opts,
                        'answer': _remap_answer(q['type'], contents, new_opts,
                                                q.get('answer') or ''),
                        'explanation': (q.get('analysis') or '')
                        + '(变式说明:仅选项顺序打乱,考点与答案内容不变。)',
                        'note': '选项顺序变式:只打乱选项顺序,答案内容不变。'})
    for old_w, new_w in VARIANT_SYNONYMS:
        if old_w in q['stem']:
            out.append({'kind': 'wording',
                        'stem': q['stem'].replace(old_w, new_w, 1),
                        'options': contents[:], 'answer': q.get('answer') or '',
                        'explanation': (q.get('analysis') or '')
                        + '(变式说明:仅题干同义词替换,考点与答案不变。)',
                        'note': '题干表述变式:仅把“{0}”换成“{1}”,答案不变。'.format(old_w, new_w)})
            break
    m = re.search(r'(\d+)', q['stem'])
    if m:
        num = int(m.group(1))
        rep_num = NUM_REPLACE.get(num)
        if (rep_num is not None and str(num) not in ''.join(correct_contents)
                and str(num) not in (q.get('analysis') or '')):
            out.append({'kind': 'numeric',
                        'stem': q['stem'].replace(str(num), str(rep_num), 1),
                        'options': contents[:], 'answer': q.get('answer') or '',
                        'explanation': (q.get('analysis') or '')
                        + '(变式说明:题干数字已替换,须人工复核数字合理性后再发布。)',
                        'note': '题干数字变式:题干数字 {0} 换成 {1},须人工复核数字合理性。'.format(
                            num, rep_num)})
    return out[:count]


def generate_variants(qid, count, created_by=''):
    """生成变式并写入草稿(状态 停用,source 变式·母题#id)。返回 (result, error)。"""
    import adaptive
    count = min(max(int(count or 2), 1), 3)
    row = qmod.get_question(qid)
    if row is None:
        return None, "母题不存在"
    q = qmod.question_to_dict(row)
    if q['type'] == '简答':
        return None, "简答题暂不支持变式(只有选择/判断/填空题可变式)"
    if q['status'] != '启用':
        return None, "只有已发布的题目才能生成变式"
    vars_ = make_variants(q, count)
    if not vars_:
        return None, "这道题没有可替换的槽位(选项少于 3 个且题干无可换表述/数字),无法生成变式"
    conn = db.get_conn()
    ids = []
    with db.DB_LOCK:
        for v in vars_:
            opts = dict([(chr(65 + j), c) for j, c in enumerate(v['options'])])
            cur = conn.execute(
                "INSERT INTO questions(no, type, category, stem, options, answer,"
                " analysis, image, status, created_at, difficulty, source,"
                " version_id, rubric, max_score, parent_id)"
                " VALUES(?, ?, ?, ?, ?, ?, ?, '', '停用',"
                " datetime('now', 'localtime'), ?, ?, NULL, ?, ?, ?)",
                (qmod.next_no(), q['type'], q.get('category') or '',
                 v['stem'], json.dumps(opts, ensure_ascii=False),
                 v['answer'], v['explanation'], q.get('difficulty') or 3,
                 "变式·母题#{0}({1})".format(qid, v['kind']),
                 q.get('rubric') or '', q.get('max_score') or 10, qid))
            vid = cur.lastrowid
            for j, opt in enumerate(v['options']):
                conn.execute(
                    "INSERT INTO question_options(question_id, label, content)"
                    " VALUES(?, ?, ?)", (vid, chr(65 + j), opt))
            adaptive.set_knowledge(conn, vid, q.get('category') and [q['category']] or [],
                                   q.get('category') or '')
            ids.append(vid)
        conn.execute(
            "INSERT INTO ai_jobs(kind, input_json, status, result_json, created_at)"
            " VALUES('variant', ?, 'done', ?, datetime('now', 'localtime'))",
            (json.dumps({'question_id': qid, 'count': count}, ensure_ascii=False),
             json.dumps({'variant_ids': ids,
                         'kinds': [v['kind'] for v in vars_],
                         'notes': [v['note'] for v in vars_]}, ensure_ascii=False)))
        conn.commit()
    db.audit(created_by, 'ai_variant',
             "母题 {0} 生成变式 {1} 道({2}),待人工审核".format(
                 qid, len(ids), ','.join(v['kind'] for v in vars_)))
    return {'variant_ids': ids, 'kinds': [v['kind'] for v in vars_],
            'notes': [v['note'] for v in vars_],
            'message': '变式已生成进草稿,须人工审核通过后才能发布'}, ""


def list_variants():
    conn = db.get_conn()
    with db.DB_LOCK:
        rows = conn.execute(
            "SELECT q.*, p.stem AS parent_stem FROM questions q"
            " LEFT JOIN questions p ON p.id=q.parent_id"
            " WHERE q.source LIKE '变式·%' ORDER BY q.id DESC LIMIT 100").fetchall()
    out = []
    for r in rows:
        d = qmod.question_to_dict(r)
        d['parent_stem'] = r['parent_stem']
        out.append(d)
    return out


def approve_variant(vid, username=''):
    conn = db.get_conn()
    with db.DB_LOCK:
        row = conn.execute(
            "SELECT * FROM questions WHERE id=? AND source LIKE '变式·%'",
            (vid,)).fetchone()
        if row is None:
            return None, "变式不存在"
        if row['status'] == '启用':
            return None, "该变式已发布过,不能重复审核"
        cur_ver = conn.execute(
            "SELECT id FROM bank_versions WHERE is_current=1 ORDER BY id DESC"
            " LIMIT 1").fetchone()
        vid_cur = cur_ver[0] if cur_ver else None
        conn.execute("UPDATE questions SET status='启用', version_id=? WHERE id=?",
                     (vid_cur, vid))
        if vid_cur:
            conn.execute(
                "INSERT OR IGNORE INTO bank_version_items(version_id, question_id)"
                " VALUES(?, ?)", (vid_cur, vid))
        conn.commit()
    db.audit(username, 'ai_variant_approve', "变式 {0} 审核通过并发布".format(vid))
    return {'approved': True}, ""


def reject_variant(vid, username=''):
    conn = db.get_conn()
    with db.DB_LOCK:
        row = conn.execute(
            "SELECT * FROM questions WHERE id=? AND source LIKE '变式·%'",
            (vid,)).fetchone()
        if row is None:
            return None, "变式不存在"
        conn.execute("UPDATE questions SET status='停用' WHERE id=?", (vid,))
        conn.commit()
    db.audit(username, 'ai_variant_reject', "变式 {0} 审核驳回".format(vid))
    return {'rejected': True}, ""


def ai_tip_for(conn, qid):
    """易错点提示:用全站作答统计算,不编数据。"""
    q = conn.execute("SELECT stem FROM questions WHERE id=?", (qid,)).fetchone()
    if not q:
        return {'ok': False, 'error': '题目不存在'}
    rows = conn.execute(
        "SELECT user_answer, is_correct FROM attempts"
        " WHERE question_id=? AND is_correct IS NOT NULL", (qid,)).fetchall()
    total = len(rows)
    correct = sum(1 for r in rows if r[1])
    acc = round(correct / total * 100) if total else None
    wrong_counts = {}
    for r in rows:
        if not r[1] and r[0]:
            wrong_counts[r[0]] = wrong_counts.get(r[0], 0) + 1
    top_wrong = max(wrong_counts.items(), key=lambda kv: kv[1]) if wrong_counts else None
    if total == 0:
        tip = "暂无作答数据,尚无易错统计:先让大家练一练,再回来查看最常见的错误选项。"
    elif acc is not None and acc < 60:
        tip = "属于易错题(全站正确率 {0}%):讲评时重点讲清为什么错选项错、正确选项为什么对;建议把本题放进薄弱项训练。".format(acc)
    elif acc is not None and acc > 90:
        tip = "掌握较好(全站正确率 {0}%):可做快速复习,不必反复练。".format(acc)
    else:
        tip = "中等难度(全站正确率 {0}%):注意区分易混选项,讲评时对照解析逐项辨析。".format(acc)
    if top_wrong:
        tip += "最常见的错误答案是“{0}”({1} 人次)。".format(top_wrong[0], top_wrong[1])
    return {'ok': True, 'question_id': qid, 'total': total, 'correct': correct,
            'accuracy': acc,
            'top_wrong': {'answer': top_wrong[0], 'count': top_wrong[1]} if top_wrong else None,
            'tip': tip}
