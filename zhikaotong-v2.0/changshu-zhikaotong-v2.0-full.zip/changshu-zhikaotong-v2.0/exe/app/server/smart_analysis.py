# -*- coding: utf-8 -*-
"""本地智能分析 —— 离线规则引擎(不依赖任何在线服务)。

原样移植自原版 v2.9.0 反编译干净版 decompiled6/smart_analysis.py:
只做 Python 3.4 语法适配(f-string 改 .format、去掉 3.7+ 的
from __future__ import annotations),并修复了反编译器留下的两处损坏
(逐级降长前缀匹配里的 t[None[:n]]、取前 4 句的 sents[None[:4]]、
_find_sentence_about 开头一句导致函数提前返回的死代码)。
规则与全部文案与原版一致。

输入题目与作答信息,输出四段结构化分析:
  1. 错因分析   :根据答案差异推断错选类型(漏选/多选/选反/答偏)
  2. 逐选项辨析 :指出正确项为何对、干扰项为何错(尽量结合解析)
  3. 答案关键点 :从解析中抽取要点句(无解析时从题干+正确答案归纳)
  4. 理解与记忆建议:按题型与题干特征(数字/流程/职责/分类)给出记忆方法

纯本地计算,内网可用。
"""
import re

_SENT_SPLIT = re.compile(u"[。；;！!？?\\n]+")
_NUM_RE = re.compile("\\d+(\\.\\d+)?")
_FLOW_WORDS = ('流程', '步骤', '顺序', '先后', '程序', '环节')
_DUTY_WORDS = ('应当', '不得', '可以', '负责', '职责', '禁止', '必须')
_CLASS_WORDS = ('分为', '包括', '种类', '类别', '以下哪', '不属于', '属于')


def _sentences(text):
    if not text:
        return []
    parts = [p.strip() for p in _SENT_SPLIT.split(text)]
    return [p for p in parts if len(p) >= 4]


def _letters(ans):
    return sorted(set([c.upper() for c in (ans or "") if c.upper() in "ABCD"]))


def _find_sentence_about(sents, opt_text):
    """在解析句中找一个与选项文本相关的句子(用于指出该选项错在哪)。

    v2.9.0:匹配从"固定取前 6 字"升级为逐级降长的前缀匹配
    (10/8/6/4 字),并在全部句子无命中时再尝试选项中的关键片段,
    命中率明显提高 —— 解析里通常会用与选项相近的措辞说明对错。
    """
    t = (opt_text or "").strip()
    if not t or not sents:
        return ""
    for n in (10, 8, 6, 4):
        if len(t) >= n:
            key = t[:n]
            for s in sents:
                if key in s:
                    return s
    for i in range(0, max(1, len(t) - 3)):
        frag = t[i:i + 4]
        for s in sents:
            if frag in s:
                return s
    return ""


def option_breakdown(qtype, correct, options=None, explanation='', user_answer=''):
    """逐选项辨析:指出正确项为何对、干扰项为何错(尽量结合解析)。

    v2.9.0:传入 user_answer 后,会专门标出「您错选的选项」,
    并优先引用解析中解释该选项为何不对的句子。
    """
    if not options or qtype not in ('单选', '多选', '判断'):
        return []
    if qtype == "多选":
        ca = _letters(correct)
    else:
        ca = [correct.strip().upper()]
    if qtype == "多选":
        ua = _letters(user_answer)
    elif (user_answer or "").strip():
        ua = [user_answer.strip().upper()]
    else:
        ua = []
    lines = []
    sents = _sentences(explanation or "")
    for letter in sorted(options.keys()):
        text = options[letter]
        t = (text or "").strip()
        hit = _find_sentence_about(sents, t)
        if letter in ca:
            note = "正确选项"
            if hit:
                note += "(解析:{0})".format(hit)
            lines.append("{0}「{1}」—— ✓ {2}".format(letter, t, note))
        else:
            picked = letter in ua
            if picked:
                note = "您错选了此项"
                if hit:
                    note += ",解析指出:{0}".format(hit)
                else:
                    alt = ""
                    if ca:
                        alt = _find_sentence_about(sents, options.get(ca[0], "") or "")
                    if not alt and sents:
                        alt = sents[0]
                    if alt:
                        note += ",对照解析:{0}".format(alt)
                    else:
                        note += ",它不是本题正确表述,请对照正确选项与解析弄清差异"
            else:
                note = "干扰项"
                if hit:
                    note += ",解析指出:{0}".format(hit)
                else:
                    note += ",与正确项易混淆,注意辨析"
            lines.append("{0}「{1}」—— ✗ {2}".format(letter, t, note))
    return lines


def wrong_reason(qtype, user_answer, correct, options=None):
    ua = (user_answer or "").strip()
    ca = (correct or "").strip()
    if not ua:
        return "本题未作答。遇到没有把握的题目,建议先排除明显错误选项, 再从剩余选项中比较选择,不要留空。"
    if qtype == "单选":
        picked = options.get(ua.upper(), "") if options else ""
        right = options.get(ca.upper(), "") if options else ""
        s = "您选择了选项 {0}".format(ua)
        if picked:
            s += "(「{0}」)".format(picked)
        s += ",正确答案是选项 {0}".format(ca)
        if right:
            s += "(「{0}」)".format(right)
        s += "。两个选项对应的知识点存在混淆,请重点辨析它们之间的差异。"
        return s
    if qtype == "多选":
        u = _letters(ua)
        c = _letters(ca)
        missed = [x for x in c if x not in u]
        extra = [x for x in u if x not in c]
        if missed and not extra:
            mtxt = ",".join(missed)
            detail = (options or {}).get(mtxt, "") if len(missed) == 1 else ""
            s = "本题属于漏选:您漏掉了选项 {0}".format(mtxt)
            if detail:
                s += "(「{0}」)".format(detail)
            s += "。多选题漏选往往是对其一要点印象不深,请对照解析补齐这一要点。"
            return s
        if extra and not missed:
            etxt = ",".join(extra)
            detail = (options or {}).get(etxt, "") if len(extra) == 1 else ""
            s = "本题属于多选:选项 {0}".format(etxt)
            if detail:
                s += "(「{0}」)".format(detail)
            s += " 并不属于正确答案。做这类题时要警惕「看起来也对」的干扰项,回归题干逐字核对条件。"
            return s
        if missed and extra:
            return "本题既有漏选又有误选:漏了 {0},多选了 {1}。说明对该知识点的要点边界还不清晰,建议把解析完整读一遍再重做。".format(",".join(missed), ",".join(extra))
        return "本题选项组合与正确答案不同,请对照正确答案逐项核对。"
    if qtype == "判断":
        mine = "正确" if ua.upper() in ('A', '正确', '对', '√') else "错误"
        real = "正确" if ca.upper() in ('A', '正确', '对', '√') else "错误"
        if mine != real:
            return "本题判断相反:您答「{0}」,实际「{1}」。判断题选反通常是被题干中的绝对化表述或细节改动迷惑,请特别留意题干中的限定词。".format(mine, real)
        return "本题判断有偏差,请对照正确答案与解析复核。"
    if qtype == "填空":
        return "您填写的「{0}」与标准答案「{1}」不一致。填空题注意答题要使用规范表述,与教材/题库用语保持一致。".format(ua, ca)
    return "自评未通过:请把您的作答与参考答案逐条对比,找出遗漏或表述不规范之处。"


def key_points(explanation, stem, correct, options=None):
    sents = _sentences(explanation or "")
    if sents:
        picked = sents[:4]
        return ["解析:" + s for s in picked]
    pts = []
    if options and correct:
        right_opt = options.get(correct.strip().upper())
        if right_opt:
            pts.append("正确选项内容:「{0}」".format(right_opt))
    kw = [w for w in _FLOW_WORDS + _DUTY_WORDS if w in (stem or "")]
    if kw:
        pts.append("题干关键限定词:{0} —— 这类词往往直接决定答案走向".format("、".join(sorted(set(kw)))))
    if pts:
        return pts
    return [
        "本题正确答案为「{0}」".format(correct),
        "题库暂未收录该题解析,可在题目上报中反馈,由管理员补充解析"]


def memory_advice(qtype, stem, correct, explanation):
    text = "{0} {1}".format(stem, explanation or "")
    has_num = bool(_NUM_RE.search(text))
    if any(w in text for w in _FLOW_WORDS):
        base = "这是一道流程/步骤类题目:建议把各环节按先后顺序串成一条链,用「首字连词法」编成口诀记忆,比死记硬背更牢固。"
    elif any(w in text for w in _CLASS_WORDS):
        base = "这是一道分类/辨析类题目:建议自制一张对比表,把易混项并排列出各自的适用条件,逐项比较记忆。"
    elif any(w in text for w in _DUTY_WORDS):
        base = "这是一道职责/规范类题目:注意题干中的「应当/不得/可以」等措辞,它们是判断对错的题眼,建议圈画标记后再做题。"
    else:
        base = "建议采用「理解→复述→自测」三步法:先读懂解析,再合上解析用自己的话复述要点,最后隔天重做本题验证。"
    if has_num:
        base += " 本题涉及数字要点,可把数字单独摘出来做「数字卡片」重点记忆。"
    base += " 系统已把本题收进错题本,隔 1 天、3 天、7 天各重做一次效果最佳。"
    return base


def analyze(qtype, stem, user_answer, correct, explanation='', options=None):
    """返回 {'wrong_reason','key_points','option_notes','advice'} 结构化分析。"""
    return {'wrong_reason': wrong_reason(qtype, user_answer, correct, options),
        'key_points': key_points(explanation, stem, correct, options),
        'option_notes': option_breakdown(qtype, correct, options, explanation, user_answer=user_answer),
        'advice': memory_advice(qtype, stem, correct, explanation)}


def format_text(a):
    lines = ["\u3010\u9519\u56e0\u5206\u6790\u3011" + a["wrong_reason"], ""]
    if a.get("option_notes"):
        lines += ["\u3010\u9010\u9009\u9879\u8fa8\u6790\u3011"]
        lines += a["option_notes"]
        lines += [""]
    lines += ["\u3010\u7b54\u6848\u5173\u952e\u70b9\u3011"]
    lines += ["· " + p for p in a["key_points"]]
    lines += ["", "\u3010\u7406\u89e3\u4e0e\u8bb0\u5fc6\u5efa\u8bae\u3011" + a["advice"]]
    return "\n".join(lines)
