# -*- coding: utf-8 -*-
"""常熟站智考通 v2.0 — 模拟考试:自选范围随机组卷、限时、答案实时保存、
断线恢复、交卷服务端统一判分、填空简答自评计分、历史成绩。

模拟考与正式考试的区别:模拟考由学员自己组卷(按题型选数量、分类、时长),
可反复考;正式考试由考官发布、统一试卷、名单制。
Python 3.4 兼容语法。
"""
import json

import db
import questions as qmod
import exams as exam_mod

DEFAULT_MOCK_SCORES = {"单选": 2, "多选": 3, "判断": 1, "填空": 2, "简答": 5}


def create_mock(user_id, config):
    counts = config.get('counts') or {}
    total_n = sum(int(v or 0) for v in counts.values())
    if total_n <= 0:
        return None, "请至少设置一种题型的数量"
    duration = int(config.get('duration_min') or 30)
    if duration <= 0:
        return None, "时长必须大于 0 分钟"
    category = config.get('category') or ''
    qids = qmod.sample_questions(counts, category=category)
    if not qids:
        return None, "题库中没有符合要求的题目"
    cfg = {'counts': counts, 'category': category, 'duration_min': duration,
           'scores': config.get('scores') or DEFAULT_MOCK_SCORES}
    conn = db.get_conn()
    with db.DB_LOCK:
        cur = conn.execute(
            "INSERT INTO mock_attempts(user_id, config, questions, answers, score, status, started_at, submitted_at)"
            " VALUES(?, ?, ?, '{}', NULL, '进行中', datetime('now', 'localtime'), '')",
            (user_id, json.dumps(cfg, ensure_ascii=False), json.dumps(qids)))
        conn.commit()
        att_id = cur.lastrowid
    return {'attempt_id': att_id, 'questions': qids, 'config': cfg,
            'started_at': _now()}, ""


def _now():
    import time
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())


def get_mock(attempt_id, user_id):
    conn = db.get_conn()
    with db.DB_LOCK:
        row = conn.execute(
            "SELECT * FROM mock_attempts WHERE id=? AND user_id=?",
            (attempt_id, user_id)).fetchone()
    if row is None:
        return None, "模拟考试不存在"
    d = db.row_to_dict(row)
    d['config'] = json.loads(d.get('config') or '{}')
    d['questions'] = json.loads(d.get('questions') or '[]')
    d['answers'] = json.loads(d.get('answers') or '{}')
    return d, ""


def current_mock(user_id):
    conn = db.get_conn()
    with db.DB_LOCK:
        row = conn.execute(
            "SELECT * FROM mock_attempts WHERE user_id=? AND status='进行中'"
            " ORDER BY id DESC LIMIT 1", (user_id,)).fetchone()
    if row is None:
        return None
    d, _e = get_mock(row['id'], user_id)
    return d


def save_mock_answer(user_id, attempt_id, question_id, answer):
    att, err = get_mock(attempt_id, user_id)
    if err:
        return False, err
    if att['status'] != '进行中':
        return False, "本次模拟考试已交卷"
    answers = att['answers']
    ent = answers.get(str(question_id)) or {}
    if not isinstance(ent, dict):
        ent = {'a': ent, 's': None}
    ent['a'] = answer or ''
    answers[str(question_id)] = ent
    conn = db.get_conn()
    with db.DB_LOCK:
        conn.execute("UPDATE mock_attempts SET answers=? WHERE id=?",
                     (json.dumps(answers, ensure_ascii=False), attempt_id))
        conn.commit()
    return True, ""


def submit_mock(user_id, attempt_id):
    att, err = get_mock(attempt_id, user_id)
    if err:
        return None, err
    if att['status'] != '进行中':
        return None, "本次模拟考试已交卷"
    qscores = att['config'].get('scores') or DEFAULT_MOCK_SCORES
    total, full, results, pending = exam_mod.grade_paper(att['questions'], att['answers'], qscores)
    conn = db.get_conn()
    with db.DB_LOCK:
        conn.execute(
            "UPDATE mock_attempts SET answers=?, score=?, status='已完成',"
            " submitted_at=datetime('now', 'localtime') WHERE id=?",
            (json.dumps(att['answers'], ensure_ascii=False), total, attempt_id))
        conn.commit()
    # v2:顺带写 attempts 表 + FSRS 调度(模拟考按练习模式记账);简答未自评的不记
    import adaptive as adaptive_mod
    for r in results:
        if r['correct'] is not None:
            ent = att['answers'].get(str(r['question_id'])) or {}
            ua = ent.get('a', '') if isinstance(ent, dict) else ent
            adaptive_mod.record_attempt(user_id, r['question_id'], 'practice',
                                        ua, r['correct'])
    correct_n = len([r for r in results if r['correct'] is True])
    obj_total = len([r for r in results if r['correct'] is not None])
    return {'attempt_id': attempt_id, 'score': total, 'full_score': full,
            'correct': correct_n, 'objective_total': obj_total,
            'accuracy': round(100.0 * correct_n / obj_total, 1) if obj_total else 0,
            'pending_self_grade': pending, 'results': results}, ""


def self_grade_mock(user_id, attempt_id, question_id, correct):
    att, err = get_mock(attempt_id, user_id)
    if err:
        return False, err
    if att['status'] != '已完成':
        return False, "请先交卷再自评"
    row = qmod.get_question(question_id)
    if row is None or row['type'] not in ('填空', '简答'):
        return False, "只有填空/简答题需要自评"
    answers = att['answers']
    ent = answers.get(str(question_id)) or {}
    if not isinstance(ent, dict):
        ent = {'a': ent, 's': None}
    ent['s'] = 1 if correct else 0
    answers[str(question_id)] = ent
    qscores = att['config'].get('scores') or DEFAULT_MOCK_SCORES
    total, _full, _r, _p = exam_mod.grade_paper(att['questions'], answers, qscores)
    conn = db.get_conn()
    with db.DB_LOCK:
        conn.execute("UPDATE mock_attempts SET answers=?, score=? WHERE id=?",
                     (json.dumps(answers, ensure_ascii=False), total, attempt_id))
        conn.commit()
    return True, ""


def mock_history(user_id, limit=20):
    conn = db.get_conn()
    with db.DB_LOCK:
        rows = conn.execute(
            "SELECT * FROM mock_attempts WHERE user_id=? ORDER BY id DESC LIMIT ?",
            (user_id, limit)).fetchall()
    out = []
    for r in rows:
        d = db.row_to_dict(r)
        cfg = json.loads(d.get('config') or '{}')
        d['config'] = cfg
        d['question_count'] = len(json.loads(d.get('questions') or '[]'))
        d.pop('questions', None)
        d.pop('answers', None)
        out.append(d)
    return out


def mock_detail(user_id, attempt_id):
    """历史试卷解析:逐题(你的答案/正确答案/解析)。"""
    att, err = get_mock(attempt_id, user_id)
    if err:
        return None, err
    if att['status'] != '已完成':
        return None, "本次模拟考试尚未交卷"
    qscores = att['config'].get('scores') or DEFAULT_MOCK_SCORES
    total, full, results, pending = exam_mod.grade_paper(att['questions'], att['answers'], qscores)
    return {'attempt_id': attempt_id, 'score': att['score'], 'full_score': full,
            'config': att['config'], 'submitted_at': att['submitted_at'],
            'pending_self_grade': pending, 'results': results}, ""
