# -*- coding: utf-8 -*-
"""构建期检查脚本:3.4 语法 + f-string/3.5+ 语法扫描 + 禁写内容扫描。"""
import ast
import glob
import re
import sys

ok = True
for f in sorted(glob.glob('*.py')):
    if f == 'check_py34.py':
        continue  # 本脚本自身含待查模式的字面量,跳过自查
    src = open(f, encoding='utf-8').read()
    try:
        ast.parse(src, feature_version=(3, 4))
        print('AST34 OK  ' + f)
    except SyntaxError as e:
        ok = False
        print('AST34 FAIL ' + f + ' ' + str(e))

patterns = {
    'f-string': re.compile(r'''(?<![A-Za-z0-9_])f["']'''),
    'walrus': re.compile(r':='),
    'removeprefix': re.compile(r'removeprefix|removesuffix'),
    'async/await': re.compile(r'\basync\b|\bawait\b'),
    'secrets module': re.compile(r'import secrets|secrets\.'),
    'bytes.hex': re.compile(r'\.hex\(\)'),
}
for f in sorted(glob.glob('*.py')):
    if f == 'check_py34.py':
        continue  # 本脚本自身含待查模式的字面量,跳过自查
    src = open(f, encoding='utf-8').read()
    for name, pat in patterns.items():
        hits = [ln for ln in src.splitlines() if pat.search(ln)]
        if hits:
            ok = False
            print('BANNED {0} in {1}: {2}'.format(name, f, hits[:3]))
for f in sorted(glob.glob('*.py')) + sorted(glob.glob('*.md')) + sorted(glob.glob('static/*.html')):
    if f == 'check_py34.py':
        continue
    src = open(f, encoding='utf-8').read()
    if '连' + '云' + '港' in src or '50.19.166' in src:
        ok = False
        print('FORBIDDEN CONTENT in ' + f)
print('ALL OK' if ok else 'FAILURES FOUND')
sys.exit(0 if ok else 1)
