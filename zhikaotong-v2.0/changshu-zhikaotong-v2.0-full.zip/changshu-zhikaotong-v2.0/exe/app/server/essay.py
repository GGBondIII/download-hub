# -*- coding: utf-8 -*-
"""常熟站智考通 v2.0 — 简答/材料题人工批阅:提交待批、队列、人工打分、我的批阅。

照抄刷题宝 v0.7 server.py 1442–1470、2151–2210 行的逻辑。
打分规则:≥60% 满分算对;批阅后回写 attempts.is_correct、掌握度、FSRS、
质量分,答错进错题本。正式考试交卷后简答进批阅队列(见 enqueue_from_exam)。
Python 3.4 兼容语法。
"""
import db
import auth
import questions as qmod


def submit_essay(user_id, question_id, answer):
    """学员提交简答作答:记 attempts(is_correct NULL) + review_scores 待批。"""
    ans = (answer or '').strip()
    if not ans:
        return None, "请先写答案再提交"
    if len(ans) > 5000:
        return None, "答案过长(最多 5000 字)"
    row = qmod.get_question(question_id)
    if row is None or row['type'] != '简答':
        return None, "题目不存在或不是简答题"
    q = qmod.question_to_dict(row)
    conn = db.get_conn()
    with db.DB_LOCK:
        cur = conn.execute(
            "INSERT INTO attempts(user_id, question_id, mode, user_answer,"
            " is_correct, version_id, answered_at)"
            " VALUES(?, ?, 'practice', ?, NULL, ?, datetime('now', 'localtime'))",
            (user_id, question_id, ans, q.get('version_id')))
        aid = cur.lastrowid
        cur2 = conn.execute(
            "INSERT INTO review_scores(question_id, user_id, score, comment, reviewer,"
            " attempt_id, status, max_score, created_at)"
            " VALUES(?, ?, NULL, '', '', ?, 'pending', ?,"
            " datetime('now', 'localtime'))",
            (question_id, user_id, aid, q.get('max_score') or 10))
        rid = cur2.lastrowid
        conn.commit()
    user = auth.get_user_by_id(user_id)
    db.audit(user['username'] if user else '', 'essay_submit',
             "简答题 {0} 已提交待批".format(question_id))
    return {'review_id': rid, 'message': '已提交,待教官人工批阅'}, ""


def enqueue_from_exam(user_id, question_id, answer, exam_session_id=None):
    """正式考试交卷后简答进批阅队列(与 submit_essay 同结构,mode='exam')。"""
    row = qmod.get_question(question_id)
    if row is None or row['type'] != '简答':
        return None
    q = qmod.question_to_dict(row)
    conn = db.get_conn()
    with db.DB_LOCK:
        cur = conn.execute(
            "INSERT INTO attempts(user_id, question_id, mode, exam_session_id,"
            " user_answer, is_correct, version_id, answered_at)"
            " VALUES(?, ?, 'exam', ?, ?, NULL, ?, datetime('now', 'localtime'))",
            (user_id, question_id, exam_session_id, answer or '', q.get('version_id')))
        aid = cur.lastrowid
        cur2 = conn.execute(
            "INSERT INTO review_scores(question_id, user_id, score, comment, reviewer,"
            " attempt_id, status, max_score, created_at)"
            " VALUES(?, ?, NULL, '', '', ?, 'pending', ?,"
            " datetime('now', 'localtime'))",
            (question_id, user_id, aid, q.get('max_score') or 10))
        conn.commit()
        return cur2.lastrowid


def essay_queue():
    conn = db.get_conn()
    with db.DB_LOCK:
        rows = conn.execute(
            "SELECT rs.*, q.stem, q.answer AS reference_answer, q.rubric,"
            " u.name AS user_name, u.department FROM review_scores rs"
            " JOIN questions q ON q.id=rs.question_id"
            " JOIN users u ON u.id=rs.user_id"
            " WHERE rs.status='pending' ORDER BY rs.created_at").fetchall()
    return [db.row_to_dict(r) for r in rows]


def my_essays(user_id):
    conn = db.get_conn()
    with db.DB_LOCK:
        rows = conn.execute(
            "SELECT rs.*, q.stem FROM review_scores rs"
            " JOIN questions q ON q.id=rs.question_id"
            " WHERE rs.user_id=? ORDER BY rs.created_at DESC LIMIT 50",
            (user_id,)).fetchall()
    return [db.row_to_dict(r) for r in rows]


def review_essay(review_id, score, comment='', reviewer_username=''):
    """人工打分。返回 (result_dict, error)。"""
    import adaptive
    import quality as quality_mod
    try:
        score = float(score)
    except (TypeError, ValueError):
        return None, "分数要是数字"
    conn = db.get_conn()
    with db.DB_LOCK:
        row = conn.execute("SELECT * FROM review_scores WHERE id=?",
                           (review_id,)).fetchone()
    if row is None:
        return None, "批阅记录不存在"
    if row['status'] == 'graded':
        return None, "该题已批阅过,不能重复批改"
    max_score = row['max_score'] or 10
    if score < 0 or score > max_score:
        return None, "分数应在 0 到 {0} 之间".format(max_score)
    q = qmod.get_question(row['question_id'])
    passed = score >= 0.6 * max_score
    with db.DB_LOCK:
        conn.execute(
            "UPDATE review_scores SET score=?, comment=?, reviewer=?,"
            " status='graded', reviewed_at=datetime('now', 'localtime') WHERE id=?",
            (score, comment or '', reviewer_username, review_id))
        if row['attempt_id']:
            conn.execute("UPDATE attempts SET is_correct=? WHERE id=?",
                         (1 if passed else 0, row['attempt_id']))
        if q is not None:
            qd = qmod.question_to_dict(q)
            kn = adaptive.knowledge_of(conn, row['question_id'],
                                       qd.get('category') or '')
            adaptive.update_mastery(conn, row['user_id'], kn, passed,
                                    qd.get('difficulty') or 3)
            adaptive.update_review_schedule(conn, row['user_id'],
                                            row['question_id'], passed)
            quality_mod.refresh_quality_for(conn, row['question_id'])
            if not passed:
                ex = conn.execute(
                    "SELECT wrong_count FROM wrong_book WHERE user_id=? AND question_id=?",
                    (row['user_id'], row['question_id'])).fetchone()
                if ex is None:
                    conn.execute(
                        "INSERT INTO wrong_book(user_id, question_id, added_at,"
                        " wrong_count, last_wrong_at, mastered)"
                        " VALUES(?, ?, datetime('now', 'localtime'), 1,"
                        " datetime('now', 'localtime'), 0)",
                        (row['user_id'], row['question_id']))
                else:
                    conn.execute(
                        "UPDATE wrong_book SET wrong_count=wrong_count+1,"
                        " last_wrong_at=datetime('now', 'localtime'), mastered=0"
                        " WHERE user_id=? AND question_id=?",
                        (row['user_id'], row['question_id']))
        conn.commit()
    db.audit(reviewer_username, 'essay_review',
             "批阅 {0} 得分 {1}/{2}".format(review_id, score, max_score))
    return {'passed': passed, 'score': score, 'max_score': max_score}, ""
