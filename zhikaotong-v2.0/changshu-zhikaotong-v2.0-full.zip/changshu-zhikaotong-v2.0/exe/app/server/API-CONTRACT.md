# 常熟站智考通 v1.0 — API 契约

> 本文档是 tkinter 客户端与网页版唯一的开发依据：后续的客户端代理与网页版代理只按这份契约开发，不读服务器代码。
> 服务器：Python 标准库 + SQLite 单文件，零依赖、零 CDN；默认监听 `0.0.0.0:8766`（环境变量 `ZHIKAOTONG_PORT` / `ZHIKAOTONG_HOST` 可改）；数据库 `data/zhikaotong.db`，首次启动自动建库并播种。
> 全部 Python 代码 Python 3.4 兼容语法。

## 0. 通用约定

- Base URL：`http://<主机IP>:8766`。exe 内嵌服务器用 `http://127.0.0.1:8766`。
- 除注明外，所有 `/api/*` 均为 JSON：请求 `Content-Type: application/json`，响应 `application/json; charset=utf-8`。
- 响应信封：成功 `{"ok": true, "data": ...}`（个别接口在 `data` 外另有顶层字段，见各条）；失败 `{"ok": false, "error": "中文原因"}`，并配 HTTP 状态码（400 参数错误 / 401 未登录 / 403 无权限 / 404 不存在 / 500 服务器内部错误）。
- 会话：登录成功后服务器同时做两件事——响应体返回 `token`，并以 `Set-Cookie: zk_token=<token>; Path=/; HttpOnly` 下发 Cookie。后续请求任选其一携带身份：
  - Cookie `zk_token`（推荐，浏览器自动带），或
  - 请求头 `X-Token: <token>`，或
  - 请求头 `Authorization: Bearer <token>`。
  token 有效期 24 小时；退出登录后失效。
- 角色：`admin` 管理员 / `examiner` 考官 / `student` 学员。下文“角色”列写 `admin` 表示仅管理员，`admin,examiner` 表示管理员或考官，`登录` 表示任意已登录用户。
- 时间格式：`YYYY-MM-DD HH:MM:SS`（本地时间）；日期字段为空字符串表示未设置。
- 题型常量：`单选` `多选` `判断` `填空` `简答`。判断题答案用 `对` / `错`；选项字母为 `A`-`E`。
- 题目对象（`question`）字段：
  `{"id": 1, "no": "ZK001", "type": "单选", "category": "证件查验", "stem": "题干", "options": {"A": "...", "B": "..."}, "answer": "B", "analysis": "解析", "image": "题图文件名或空串", "status": "启用", "created_at": "..."}`
  其中 `answer` / `analysis` 只在考官/管理员端与判分结果里返回；学员练习/考试的题单里不含这两项（`GET /api/practice/list`、`GET /api/exams/{id}/paper`、`GET /api/mock/{id}` 返回的 `question_detail` 均不含答案与解析）。
- 分数：考试按 `qscores`（各题型每题分）；模拟考默认 `{"单选": 2, "多选": 3, "判断": 1, "填空": 2, "简答": 5}`，创建时可在 `config.scores` 里覆盖。
- 判分规则：单选/判断答对 1 题得满分，答错 0 分，不选按答错；多选全对才得分；填空去空白后与标准答案精确匹配（多答案用 `|` 或 `；` 分隔，任一匹配即对），交卷后自评可覆盖；简答不自动判分，交卷后自评（我答对了/我答错了）计入总分。

## 1. 公开接口

### GET /api/version
- 角色：公开。查询客户端最新版本（登录页“发现新版本”提示条用）。
- 请求：query `platform` 可选（`win7-32` / `win10-64` / `xp-32` 等）。
- 响应 `data`：`{"current_version": "v1.0", "app_name": "常熟站智考通", "latest": null}`；`platform` 有生效版本时 `latest` 为版本对象 `{"id": 1, "platform": "win7-32", "version": "v1.0", "note": "更新说明", "filename": "", "status": "生效中", "created_at": "..."}`，无则为 `null`。

### POST /api/auth/login
- 角色：公开。
- 请求：`{"username": "minjing", "password": "123456"}`。
- 响应 `data`：`{"token": "…", "user": user}`；同时下发 `zk_token` Cookie。`user` 对象见 §2 `GET /api/me`。登录失败 401，`error` 为“用户名或密码错误”或“该账号已被停用,请联系管理员”。
- 演示账号（密码均为 `123456`，上线前必改）：`admin` 管理员（站机关）、`jiaoguan` 考官（执勤一队）、`minjing` 学员（执勤一队）、`minjing2` 学员（执勤二队）。

### POST /api/auth/register
- 角色：公开。学员自助注册，注册成功后提示“注册成功,请登录”，返回登录页。
- 请求：`{"name": "姓名", "department": "部门", "username": "用户名", "password": "至少6位", "invite_code": "邀请码"}`。姓名、部门必填；邀请码初始值 `CS2026`（管理员可在设置里更换，见 §7）。
- 响应 `data`：`{"message": "注册成功,请登录", "user": user}`。失败 400：姓名/部门/用户名为空、密码不足 6 位、邀请码不正确、用户名已被注册。

### POST /api/auth/logout
- 角色：登录。使当前 token 失效并清除 Cookie。
- 请求：无 body。响应 `data`：`{"message": "已退出登录"}`。

## 2. 账号与首页

### GET /api/me
- 角色：登录。返回当前用户。
- 响应 `data`（`user` 对象）：`{"id": 1, "username": "minjing", "name": "民警甲", "department": "执勤一队", "role": "student", "role_name": "学员", "status": "正常", "created_at": "..."}`。`role_name` 为中文角色名。

### POST /api/auth/change-password
- 角色：登录。
- 请求：`{"old_password": "当前密码", "new_password": "新密码", "confirm_password": "新密码"}`。新密码至少 6 位。
- 响应 `data`：`{"message": "密码修改成功,下次登录请使用新密码"}`。失败 400：当前密码不正确 / 两次输入不一致 / 新密码不足 6 位。

### GET /api/home/stats
- 角色：登录。学员首页数据：问候、统计、四模块入口状态。
- 响应 `data`：`{"user": user, "practice": practice_stats, "ongoing_mock": mock对象或null, "invite_code": "CS2026", "app_version": "v1.0"}`。
  `practice_stats` 同 `GET /api/practice/stats`；`ongoing_mock` 为进行中的模拟考试对象（无则为 `null`），客户端据此在顶部显示“有一场进行中的模拟考试，继续作答”。

### GET /api/questions/categories
- 角色：登录。返回全部题目分类列表（供练习“可选分类”下拉与组卷分类选择）。
- 响应 `data`：`["基础法规", "证件查验", "口岸勤务", "执勤规范"]`（按分类排序）。

## 3. 题库（考官/管理员）

### GET /api/questions
- 角色：`admin,examiner`。搜索分页列表。
- 请求 query：`q` 关键词（题干/题号/分类模糊搜）、`type` 题型、`category` 分类、`status`（`启用`/`停用`）、`page`（默认 1）、`page_size`（默认 20）。
- 响应 `data`：`{"total": 20, "page": 1, "page_size": 20, "items": [question, ...]}`（含答案与解析）。

### GET /api/questions/{id}
- 角色：`admin,examiner`。返回单个题目对象（含答案与解析）。

### POST /api/questions
- 角色：`admin,examiner`。新增题目。
- 请求：`{"no": "题号，可空，空则自动生成 ZKnnn", "type": "单选", "category": "证件查验", "stem": "题干", "options": {"A": "...", "B": "..."}, "answer": "B", "analysis": "解析", "image": "题图文件名，可空"}`。
- 校验失败 400：题干为空 / 答案为空 / 题型不识别 / 单选至少 2 个选项且答案须为单个在范围内的字母 / 多选至少 2 个选项且答案字母须在范围内 / 判断答案须为 对/错。
- 响应 `data`：新建的题目对象。

### PUT /api/questions/{id}
- 角色：`admin,examiner`。编辑题目，请求字段同新增（只传要改的字段即可，未传字段保持原值）。
- 响应 `data`：更新后的题目对象。

### DELETE /api/questions
- 角色：`admin,examiner`。批量删除。
- 请求：`{"ids": [1, 2, 3]}`。响应 `data`：`{"deleted": 3}`。

### POST /api/questions/{id}/status
- 角色：`admin,examiner`。启用 / 停用。
- 请求：`{"status": "停用"}`（只能是 `启用` / `停用`）。响应 `data`：`{"status": "停用"}`。

### GET /api/questions/template
- 角色：`admin,examiner`。下载导入模板 `question-import-template.xlsx`（二进制 xlsx 文件，非 JSON）。

### POST /api/questions/import
- 角色：`admin,examiner`。Excel / Word 导入。
- 请求：`{"filename": "xxx.xlsx", "content_b64": "文件的 base64"}`。只支持 `.xlsx` / `.docx`。
- xlsx 列：题型 | 题干 | 选项A-E | 答案 | 解析 | 科目 | 知识点 | 难度 | 来源 | 题干图片说明（详见 `README-import.md`）。图片插在行上按行挂题，存入 `data/assets/`。
- docx 段落格式：`1. 题干` 开头，`A. 选项`，`答案：B`，`解析：……`，可选 `题型：单选` / `科目：证件查验`；图片插在题干附近按顺序挂题。
- 响应 `data`：`{"ok_count": 18, "bad_count": 2, "errors": [{"row": 5, "error": "答案为空"}], "message": "导入完成:成功 18 条,失败 2 条"}`。通过的行直接进入启用题库；失败行只列原因，不整批失败。

## 4. 日常练习

### GET /api/practice/list
- 角色：登录。按模式取题单（题单不含答案与解析）。
- 请求 query：`mode`（`顺序` / `随机` / `错题` / `题型`，默认 `顺序`）、`category` 分类（可选）、`type` 题型（题型练习用）、`count` 题数（可选，0 表示全部；题型练习不选题数）、`seed` 随机种子（随机模式用同一 seed 得到同一顺序，供断点续刷）。
- 顺序：按题号全量顺序；随机：全量随机抽题（seed 固定顺序）；错题：错题本顺序；题型：选定题型后顺序或随机（传 `seed` 则随机）刷完该题型全部题目。
- 响应 `data`：`{"mode": "顺序", "total": 20, "questions": [question(不含答案), ...]}`。
- 断点续刷：客户端记住上次刷到的题号下标，下次用同一 `mode`/`seed` 取题单后从该下标继续，或从头开始。

### POST /api/practice/answer
- 角色：登录。逐题判分：提交一题答案，返回判分、正确答案、解析，答错自动入错题本并返回智能分析；做对自动移出错题本。
- 请求：`{"question_id": 1, "mode": "顺序", "user_answer": "B", "self_correct": true/false/null}`。`user_answer`：单选字母 / 多选字母串（如 `ABC`）/ 判断 `对` 或 `错`（也接受 `A`/`B`）/ 填空文本 / 简答文本。简答须传 `self_correct`（`true` 我做对了 / `false` 我做错了），不传则不判分。
- 响应 `data`：`{"question_id": 1, "correct": true/false/null, "auto_graded": true/false, "correct_answer": "B", "analysis": "解析", "in_wrong_book": false, "mode": "顺序", "smart_analysis": {...}, "smart_analysis_text": "..."}`。
  `correct` 为 `null` 表示简答未自评；`auto_graded` 为 `false` 表示本次按自评计分。
  仅当 `correct` 为 `false` 时返回 `smart_analysis`（对象）与 `smart_analysis_text`（纯文本）：
  `smart_analysis` = `{"wrong_reason": "错因分析", "key_points": ["答案关键点", ...], "option_notes": ["逐选项辨析", ...], "advice": "理解与记忆建议"}`；
  `smart_analysis_text` 为四段拼成的文本（段头：错因分析 / 逐选项辨析 / 答案关键点 / 理解与记忆建议）。

### GET /api/practice/stats
- 角色：登录。练习统计（首页统计卡与练习统计页共用）。
- 响应 `data`：`{"total": 120, "correct": 96, "accuracy": 80.0, "wrong_count": 5, "by_type": [{"type": "单选", "total": 60, "correct": 50, "accuracy": 83.3}], "trend": [{"date": "2026-11-06", "total": 20, "correct": 16}]}`。`trend` 为最近 14 天按日期升序。

### GET /api/wrongbook
- 角色：登录。错题本列表（暂无错题时返回空数组，客户端显示“暂无错题，继续加油”）。
- 响应 `data`：题目对象数组，每题另附 `smart_analysis` 与 `smart_analysis_text`（按“未作答”生成的分析，供复习查看）。

### POST /api/wrongbook/remove
- 角色：登录。从错题本移除一题。
- 请求：`{"question_id": 1}`。响应 `data`：`{"removed": true}`。

## 5. 模拟考试

### POST /api/mock
- 角色：登录。创建模拟考试：按题型选数量、分类、时长，服务端随机组卷，立即计时。
- 请求：`{"counts": {"单选": 5, "多选": 2, "判断": 3, "填空": 0, "简答": 0}, "category": "分类，可空", "duration_min": 30, "scores": {"单选": 2, ...} 可选，不传用默认分}`。至少设置一种题型的数量，否则 400“请至少设置一种题型的数量”。
- 响应 `data`：`{"attempt_id": 1, "questions": [题号id数组], "question_detail": [question(不含答案)], "config": {"counts": {...}, "category": "", "duration_min": 30, "scores": {...}}, "started_at": "..."}`。

### GET /api/mock/current
- 角色：登录。取进行中的模拟考试（无则 `data` 为 `null`）。
- 响应 `data`：模拟考试对象，含 `question_detail`（不含答案）与已保存的 `answers`。字段同 `GET /api/mock/{id}`。

### GET /api/mock/{id}
- 角色：登录。取一场模拟考试（断线恢复用：答案实时保存，重连后继续作答）。
- 响应 `data`：`{"id": 1, "user_id": 3, "config": {...}, "questions": [题号id数组], "question_detail": [...], "answers": {"1": {"a": "B", "s": null}}, "score": null, "status": "进行中", "started_at": "...", "submitted_at": ""}`。
  `answers` 以题号字符串为键，值为 `{"a": "作答", "s": 自评 1/0/null}`。

### POST /api/mock/{id}/answer
- 角色：登录。实时保存一题答案（断线重连后可继续作答）。
- 请求：`{"question_id": 1, "answer": "B"}`。响应 `data`：`{"saved": true}`。已交卷返回 400。

### POST /api/mock/{id}/submit
- 角色：登录。交卷：服务端统一判分；超时由客户端在时间到时同样调本接口交卷。
- 请求：无 body（可空对象）。响应 `data`：`{"attempt_id": 1, "score": 24, "full_score": 30, "correct": 12, "objective_total": 13, "accuracy": 92.3, "pending_self_grade": [题号id数组], "results": [result, ...]}`。
  `pending_self_grade` 为待自评的填空/简答题号（自评后计入总分）；`result` 对象见 §6 `submit` 的 results 说明。

### POST /api/mock/{id}/selfgrade
- 角色：登录。填空/简答交卷后对照参考答案自评：我答对了 / 我答错了，自评后计入总分。
- 请求：`{"question_id": 19, "correct": true}`。响应 `data`：`{"graded": true}`。未交卷或题型不是填空/简答返回 400。

### GET /api/mock/history
- 角色：登录。历史成绩（横向卡片列表；暂无记录返回空数组）。
- 响应 `data`：数组，元素 `{"id": 1, "user_id": 3, "config": {...}, "score": 24, "status": "已完成", "started_at": "...", "submitted_at": "...", "question_count": 10}`（不含题目与答案）。

### GET /api/mock/{id}/detail
- 角色：登录。历史试卷解析：逐题（你的答案 / 正确答案 / 解析）。
- 响应 `data`：`{"attempt_id": 1, "score": 24, "full_score": 30, "config": {...}, "submitted_at": "...", "pending_self_grade": [...], "results": [result, ...]}`。未交卷返回 400。

## 6. 正式考试（我的考试）

### GET /api/exams/mine
- 角色：登录。名单内学员可参加的考试列表（暂无时返回空数组，客户端显示“暂无可参加的考试，请等待考官发布”）。
- 响应 `data`：考试对象数组，每项另附 `attempt`：`{"status": "进行中"/"已交卷"/"迟交", "score": 85, "submitted_at": "..."}`，未开始为 `null`。
  考试对象：`{"id": 1, "name": "常熟站 2026 年第一季度业务考核", "subject": "基础法规", "duration_min": 60, "shuffle": 0, "mode": "fixed", "qcounts": {"单选": 8, "多选": 2, "判断": 0, "填空": 0, "简答": 0}, "qscores": {"单选": 5, "多选": 10, "判断": 5, "填空": 5, "简答": 10}, "start_at": "", "end_at": "", "status": "已发布", "fixed_paper": [题号id数组], "created_by": 1, "created_at": "...", "members": [用户id数组]}`。
  `mode`：`fixed` 全员同一份卷 / `random` 每人开考时随机抽题；`status`：`草稿` / `已发布` / `已结束`。

### POST /api/exams/{id}/start
- 角色：登录。开始考试（进入后将开始计时；已开始未交卷时为继续考试，返回已保存答案）。
- 请求：无 body。响应 `data`：`{"attempt_id": 1, "exam": 考试对象, "paper": [题号id数组], "question_detail": [question(不含答案)], "answers": {...}, "started_at": "...", "resumed": false}`。`resumed` 为 `true` 表示继续考试。
- 失败 400：考试尚未发布 / 不在名单内 / 已交卷 / 固定试卷尚未生成 / 题库中没有符合要求的题目。

### GET /api/exams/{id}/paper
- 角色：登录。取本次考试的试卷（题单不含答案）与已保存答案。须先 `start`。
- 响应 `data`：`{"paper": [...], "questions": [question(不含答案)], "answers": {...}, "attempt_status": "进行中"}`。

### POST /api/exams/{id}/answer
- 角色：登录。自动保存一题答案。
- 请求：`{"question_id": 1, "answer": "B"}`。响应 `data`：`{"saved": true}`。已交卷返回 400“已交卷,不能再修改”。

### POST /api/exams/{id}/submit
- 角色：登录。交卷：交卷后立即判分，不能再修改。时间到由客户端调本接口并传 `late: true`（系统按已保存答案自动交卷，记为迟交）。
- 请求：`{"late": false}`。响应 `data`：`{"attempt_id": 1, "score": 85, "full_score": 100, "status": "已交卷"/"迟交", "answered": 10, "total_questions": 10, "pending_self_grade": [题号id数组], "results": [result, ...]}`。
  `result` 对象：`{"question_id": 1, "no": "ZK001", "type": "单选", "stem": "题干", "options": {...}, "image": "", "user_answer": "B", "correct_answer": "B", "correct": true/false/null, "score": 5, "full_score": 5, "analysis": "解析"}`。`correct` 为 `null` 表示待自评（简答，或填空尚未自评覆盖时不出现——填空自动判分）。
  交卷后答错的客观题自动收入错题本。

### POST /api/exams/{id}/selfgrade
- 角色：登录。简答交卷后自评：我答对了 / 我答错了，自评后计入总分。
- 请求：`{"question_id": 20, "correct": true}`。响应 `data`：`{"graded": true}`。未交卷或题型不是简答返回 400。

### GET /api/exams/{id}/result
- 角色：登录。查看成绩与逐题解析（只看错题 / 查看全部由客户端在 `results` 上过滤；全部答对时 `results` 里无 `correct=false` 的题，客户端显示“全部答对，没有错题”）。
- 响应 `data`：`{"attempt_id": 1, "exam": 考试对象, "status": "已交卷", "score": 85, "full_score": 100, "submitted_at": "...", "pending_self_grade": [...], "results": [result, ...]}`。暂无记录返回 404。

## 7. 考官-考试管理

### GET /api/users/students
- 角色：`admin,examiner`。考试名单用：在用学员列表（供考官/管理员建考试时取名单；此前只有管理员能调的 `GET /api/admin/users`，考官建考试拿不到名单）。
- 请求：无 query。响应 `data`：学员对象数组（只含建考试必需的四个字段，按部门、id 排序），元素 `{"id": 3, "username": "minjing", "name": "民警甲", "department": "执勤一队"}`；停用账号不返回。学员角色调本接口返回 403。

### GET /api/admin/exams
- 角色：`admin,examiner`。考试列表。
- 请求 query：`status` 可选（`草稿` / `已发布` / `已结束`）。响应 `data`：考试对象数组（含 `members`）。

### POST /api/admin/exams
- 角色：`admin,examiner`。创建考试（默认 `草稿`）。
- 请求：`{"name": "考试名称", "subject": "考试科目（自定义 / 基础法规 / 业务技能）", "duration_min": 60, "shuffle": false, "mode": "fixed", "qcounts": {"单选": 8, "多选": 2, "判断": 0, "填空": 0, "简答": 0}, "qscores": {"单选": 5, "多选": 10, "判断": 5, "填空": 5, "简答": 10}, "start_at": "", "end_at": "", "members": [用户id数组]}`。`start_at` / `end_at` 选填；`members` 为考试名单（可传全部学员 id）。
- 响应 `data`：新建的考试对象（含 `members`）。

### PUT /api/admin/exams/{id}
- 角色：`admin,examiner`。编辑考试，请求字段同创建（只传要改的字段；传 `members` 则替换名单）。已结束的考试不能再编辑。
- 响应 `data`：更新后的考试对象。

### DELETE /api/admin/exams/{id}
- 角色：`admin,examiner`。删除考试：连同名单、试卷、成绩一起清掉，不可恢复。
- 响应 `data`：`{"submitted": 2, "ongoing": 1}`（删除前已交卷人数与正在考试人数，供客户端在确认框里提示“已有 N 人交卷 / 还有 N 人正在考试，其作答将作废”）。

### POST /api/admin/exams/{id}/publish
- 角色：`admin,examiner`。发布考试（`草稿` → `已发布`）。响应 `data`：`{"status": "已发布"}`。

### POST /api/admin/exams/{id}/end
- 角色：`admin,examiner`。结束考试（→ `已结束`）。响应 `data`：`{"status": "已结束"}`。

### POST /api/admin/exams/{id}/fixed-paper
- 角色：`admin,examiner`。生成固定试卷：按题型数量抽一次题并锁定，之后全员同一份卷，题目与顺序完全相同；开考后不能再重新生成。
- 请求：无 body。响应 `data`：`{"paper": [题号id数组], "questions": [question(含答案)], "message": "已生成固定试卷,所有考生将使用这份相同的试卷"}`。已生成过或已有考生开考返回 400。

### GET /api/admin/exams/{id}/fixed-paper
- 角色：`admin,examiner`。查看固定试卷的题目与顺序。
- 响应 `data`：`{"paper": [...], "questions": [question(含答案)]}`。未生成返回空数组。

### GET /api/admin/exams/{id}/results
- 角色：`admin,examiner`。成绩：应考人数 / 已交卷 / 平均分 + 列表。
- 响应 `data`：`{"exam": 考试对象, "total_members": 2, "submitted": 2, "average": 87.5, "list": [{"user_id": 3, "username": "minjing", "name": "民警甲", "department": "执勤一队", "status": "已交卷", "submitted_at": "...", "score": 85}]}`。`status` 为 `未开始` / `进行中` / `已交卷` / `迟交`。

### GET /api/admin/exams/{id}/results.csv
- 角色：`admin,examiner`。导出成绩 CSV（非 JSON，`text/csv; charset=utf-8`，带 BOM，Excel 直接打开不乱码）。
- 列：姓名，用户名，部门，状态，交卷时间，得分。

### GET /api/admin/exams/{id}/review/{user_id}
- 角色：`admin,examiner`。阅卷回看：逐题（学员所选 / 正确答案 / 解析）。
- 响应 `data`：同 `GET /api/exams/{id}/result` 的结构（该学员的成绩与 `results`）。

## 8. 管理员-用户管理

### GET /api/admin/users
- 角色：`admin`。用户列表。
- 请求 query：`q` 关键词（用户名/姓名）、`department` 部门、`role` 角色、`page`（默认 1）、`page_size`（默认 20）。
- 响应 `data`：`{"total": 4, "items": [user, ...], "departments": ["执勤一队", "执勤二队", "站机关"]}`。`departments` 为部门下拉选项。

### POST /api/admin/users
- 角色：`admin`。新增用户。
- 请求：`{"username": "用户名", "name": "姓名", "department": "部门", "role": "student", "password": "初始密码，至少6位"}`。
- 响应 `data`：新建的 `user` 对象。

### PUT /api/admin/users/{id}
- 角色：`admin`。编辑用户：用户名不可修改；密码留空表示不改动。
- 请求：`{"name": "姓名", "department": "部门", "role": "student", "password": "留空不改"}`。姓名不能为空；密码如传则至少 6 位。
- 响应 `data`：更新后的 `user` 对象。

### DELETE /api/admin/users/{id}
- 角色：`admin`。删除单个用户：其考试记录将一并删除，不可恢复。
- 响应 `data`：`{"deleted": 1}`。

### POST /api/admin/users/{id}/disable
- 角色：`admin`。停用所选用户。响应 `data`：`{"action": "disable"}`。

### POST /api/admin/users/{id}/enable
- 角色：`admin`。恢复停用用户。响应 `data`：`{"action": "enable"}`。

### POST /api/admin/users/{id}/reset-password
- 角色：`admin`。重置密码。
- 请求：`{"password": "新密码，不传默认 123456"}`，至少 6 位。响应 `data`：`{"action": "reset-password"}`。

### POST /api/admin/users/batch
- 角色：`admin`。批量操作。
- 请求：`{"action": "disable" / "enable" / "delete", "ids": [3, 4]}`。`delete` 会一并删除这些用户的考试记录，不可恢复，且不能删除操作者自己。
- 响应 `data`：`{"updated": 2}`（disable/enable）或 `{"deleted": 2}`（delete）。

### POST /api/admin/users/import
- 角色：`admin`。批量导入用户（只支持 .xlsx）。
- 请求：`{"filename": "users.xlsx", "content_b64": "base64"}`。列：用户名 / 姓名 / 部门 / 角色 / 密码（角色填 管理员 / 考官 / 学员，默认学员；密码留空默认 123456）。
- 响应 `data`：`{"ok_count": 5, "bad_count": 1, "errors": [{"row": 3, "error": "用户名为空"}], "message": "导入完成:成功 5 条,失败 1 条"}`。

## 9. 管理员-上报处理 / 统计分析 / 版本发布 / 设置

### POST /api/reports
- 角色：登录。学员上报题目问题。
- 请求：`{"question_id": 1, "type": "题干有歧义", "detail": "补充说明，选填"}`。`type` 只能是 `题干有歧义` / `答案有误` / `解析有误` / `其他问题`。
- 响应 `data`：`{"id": 1, "status": "待处理"}`。

### GET /api/reports/mine
- 角色：登录。我的上报列表（待处理 / 已解决 / 已驳回 + 管理员回复）。
- 响应 `data`：上报对象数组，元素 `{"id": 1, "user_id": 3, "question_id": 1, "type": "答案有误", "detail": "...", "status": "待处理", "reply": "", "created_at": "...", "handled_at": "", "question": question对象, "reporter": {"username": "...", "name": "...", "department": "..."}}`。

### GET /api/admin/reports
- 角色：`admin`。上报列表（待处理在上，按 id 升序；已处理记录按处理时间追加在下方末尾，越晚处理越往下排——客户端按 `id` 升序展示即满足此顺序）。
- 请求 query：`status` 可选（`待处理` / `已解决` / `已驳回`）。响应 `data`：上报对象数组（每项含完整题目原样 `question` 与上报人 `reporter`）。

### POST /api/admin/reports/{id}/handle
- 角色：`admin`。处理上报。
- 请求：`{"action": "已解决" / "已驳回" / "停用该题", "reply": "处理回复文本"}`。`停用该题` = 标记已解决 + 同时把该题状态置为停用。
- 响应 `data`：`{"handled": true}`。已处理过的上报返回 400。

### GET /api/admin/stats
- 角色：`admin`。统计分析卡片与图表数据（图表由客户端用纯 SVG 绘制）。
- 响应 `data`：`{"student_count": 2, "user_count": 4, "practice_total": 120, "accuracy": 80.0, "pending_reports": 1, "question_count": 20, "questions_by_type": [{"type": "单选", "count": 8}], "questions_by_category": [{"category": "证件查验", "count": 6}], "students_by_department": [{"department": "执勤一队", "count": 1}], "recent_exams": [{"exam_id": 1, "name": "...", "submitted": 2, "average": 87.5}]}`。`recent_exams` 为最近 5 场考试（人已考、均分）；暂无数据时各数组为空，客户端显示“暂无数据”。

### GET /api/admin/versions
- 角色：`admin`。已发布版本列表（按 id 倒序）。
- 响应 `data`：版本对象数组（字段见 §1 `latest`）。

### POST /api/admin/versions
- 角色：`admin`。发布新版本：目标平台、版本号、更新说明、客户端程序/安装包（可选，`filename` 只记文件名，不传文件体）。
- 请求：`{"platform": "win7-32", "version": "v1.0", "note": "更新说明", "filename": ""}`。
- 同一平台一次只保留一个生效版本：新版本生效时，同一平台旧的生效版本自动下架。
- 响应 `data`：新建的版本对象。

### POST /api/admin/versions/{id}/activate
- 角色：`admin`。设为生效版本（同平台其他生效版本自动下架）。响应 `data`：`{"status": "生效中"}`。

### POST /api/admin/versions/{id}/deactivate
- 角色：`admin`。下架版本。响应 `data`：`{"status": "已下架"}`。

### DELETE /api/admin/versions/{id}
- 角色：`admin`。删除版本记录。生效中的版本需先下架才能删除，否则 400。
- 响应 `data`：`{"deleted": true}`。

### GET /api/settings/invite-code
- 角色：`admin`。取当前学员注册邀请码。响应 `data`：`{"invite_code": "CS2026"}`。

### POST /api/settings/invite-code
- 角色：`admin`。更换学员注册邀请码（学员自助注册时需填写，可随时更换）。
- 请求：`{"invite_code": "新邀请码"}`。响应 `data`：`{"invite_code": "新邀请码"}`。

## 10. 静态页面（占位）

网页版与 exe 的页面文件由后续代理提供；服务器核心仅做静态文件服务，占位页已随包提供：

- `GET /` → `static/index.html`（现代浏览器首页占位）
- `GET /lite` → `static/lite.html`（IE8 / XP 老浏览器 Lite 版占位；降级点：无圆角/阴影/毛玻璃/动效/深色模式）
- `GET /showcase.html` → `static/showcase.html`（可交互产品介绍页占位）
- `GET /static/*` → `static/` 下的文件
- `GET /assets/*` → `data/assets/` 下的题图文件（导入时存入）

## 11. 播种数据（首次启动自动建库）

- 用户：`admin` / `jiaoguan` / `minjing` / `minjing2`，密码均为 `123456`，上线前必改。
- 题库：20 道常熟边检通用样题（单选 8、多选 4、判断 4、填空 2、简答 2），题号 `ZK001`-`ZK020`，分类：基础法规 / 证件查验 / 口岸勤务 / 执勤规范。
- 考试：已发布正式考试 1 场（“常熟站 2026 年第一季度业务考核”，固定试卷 10 道题，名单含 `minjing` / `minjing2`，时长 60 分钟）与草稿考试 1 场（“执勤规范专项测试(草稿)”）。
- 设置：`invite_code = CS2026`。

## 12. 实现备注（客户端不需要关心，但写明以免误解）

- `exam_attempts` 表除规格书§三字段外另有 `paper` 列（TEXT，JSON 题号数组）：`random` 模式下每位考生开考时抽的题只抽一次并锁定在此列；`fixed` 模式以考试的 `fixed_paper` 为准。
- `answers` 的存储格式：`{"<题号id>": {"a": "作答", "s": 1/0/null}}`，`s` 为填空/简答自评结果。
- 会话只存内存（token → 用户），服务器重启后需重新登录；SQLite 访问有全局线程锁，exe 内嵌服务器线程与 UI 线程共用安全。
- 客户端更新检查只查版本记录（`GET /api/version`），不下载程序体；更新包文件本身由部署方另行分发。
- `GET /api/users/students`（v1.0 统合时补加，第 61 个端点）：角色 `admin,examiner`，返回在用学员的 `id`/`username`/`name`/`department` 列表，供考官建考试取名单；实现为 `admin.list_students()`，只查 `role='student' AND status='正常'`。
- 数据目录可用环境变量 `ZHIKAOTONG_DATA_DIR` 覆盖（见 `db.configure()` 与 `server.py` 的 `DATA_DIR`）：有值时数据库落在该目录下，无值时保持默认的服务器目录下 `data/`。exe 版 tkinter 客户端在启动内嵌服务器前把它设为 exe 文件夹根目录下的 `data/`。
