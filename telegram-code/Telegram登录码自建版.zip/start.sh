#!/bin/sh
# 自建版 Telegram 登录码网站 v0.1 启动脚本
# 用法：
#   sh start.sh --demo        # 演示模式（不连 Telegram）
#   sh start.sh               # 真实模式（需先配好 config.py 或环境变量）
set -e
cd "$(dirname "$0")"
if [ ! -d .venv ]; then
  echo "[start] 未检测到 .venv，演示模式可直接跑；真实模式建议先建 venv 并安装依赖。"
fi
if [ -f .venv/bin/activate ]; then
  . .venv/bin/activate
fi
exec python3 app.py "$@"
