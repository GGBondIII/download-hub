"""Telegram 登录码监听器（Telethon / MTProto）

只做一件事：以你本人的身份登录 Telegram，监听官方账号 777000
发来的新消息，从中提取 5 位登录码，交给 code_store 保存。

不做的事：
- 不发任何消息、不加任何联系人、不做群发
- 不收通用短信（Gmail / TikTok 的短信不在本期范围）
- 不把会话文件、API 密钥发到任何地方

首次登录说明（必须在你自己的服务器上、由你本人操作）：
1. 先在 https://my.telegram.org 创建应用，拿到 API_ID / API_HASH
2. 把它们填进 config.py 或环境变量
3. 第一次运行会向你的号码发一次登录码 —— 那次码是短信，
   需要弟弟那部手机上读一次，念给你，你在终端输入
4. 登录成功后会生成 <session>.session 文件，这个文件 = 你的账号本身，
   只放在 /mnt/workspace（魔搭）或本项目 data/ 下，绝不分享、绝不上传
"""
from __future__ import annotations

import os
import re
import time

CODE_RE = re.compile(r"(?<!\d)(\d{5})(?!\d)")
OFFICIAL_SENDER_ID = 777000  # Telegram 官方账号


def extract_login_code(text: str) -> str | None:
    """从一段消息文本里提取 5 位登录码；没有就返回 None。"""
    if not text:
        return None
    m = CODE_RE.search(text)
    return m.group(1) if m else None


def is_login_code_message(text: str) -> bool:
    """粗筛：是否像一条登录码消息。Telegram 官方消息里常带 Login code / 登录码。"""
    if not text:
        return False
    if extract_login_code(text) is None:
        return False
    low = text.lower()
    return ("login" in low) or ("code" in low) or ("登录" in text) or ("验证码" in text)


class TelegramCodeListener:
    """封装 Telethon 客户端。Telethon 未安装时，构造即报错，由调用方降级。"""

    def __init__(self, api_id: int, api_hash: str, phone: str,
                 session_path: str, on_code):
        self.api_id = api_id
        self.api_hash = api_hash
        self.phone = phone
        self.session_path = session_path
        self.on_code = on_code  # on_code(code: str, source: str)
        self._client = None

    def start_blocking(self) -> None:
        """阻塞运行监听。只应在独立线程 / 独立进程里调用。"""
        try:
            from telethon import TelegramClient, events
        except ImportError as exc:  # pragma: no cover
            raise RuntimeError(
                "未安装 Telethon，请先 pip install -r requirements.txt"
            ) from exc

        import asyncio

        async def _main():
            client = TelegramClient(self.session_path, self.api_id, self.api_hash)
            self._client = client

            @client.on(events.NewMessage(from_users=OFFICIAL_SENDER_ID))
            async def _handler(event):
                text = event.raw_text or ""
                code = extract_login_code(text)
                if code:
                    # 只保存码和时间，不保存整条消息原文
                    self.on_code(code, "telegram-777000")
                # 不是登录码的消息直接忽略，不记录内容

            # 首次需要短信码时，Telethon 会在终端提示输入；
            # 请在你自己的服务器终端里输入，不要把码发给任何人。
            await client.start(phone=self.phone)
            print("[listener] Telegram 已登录，正在监听 777000 的登录码…", flush=True)
            await client.run_until_disconnected()

        asyncio.run(_main())

    def stop(self) -> None:  # 预留，v0.1 由进程退出负责停止
        if self._client is not None:
            try:
                self._client.disconnect()
            except Exception:
                pass


def load_credentials_from_env():
    """从环境变量读凭证；缺任何一项都返回 None（调用方进入未配置状态）。"""
    api_id = os.environ.get("TG_API_ID") or os.environ.get("API_ID")
    api_hash = os.environ.get("TG_API_HASH") or os.environ.get("API_HASH")
    phone = os.environ.get("TG_PHONE") or os.environ.get("PHONE")
    if not api_id or not api_hash or not phone:
        return None
    try:
        return int(api_id), api_hash, phone
    except ValueError:
        return None
