# 自建版 Telegram 登录码网站 v0.1

私人自建的 Telegram 登录码接收页：自己搭的监听，只收你一个账号的登录码，5 分钟过期。用来替代之前那个会掉线的第三方同步页。

## 这是什么，解决什么

- 问题：原来那个第三方 Telegram 登录接码页经常掉线，显示“接码设备已掉线”，码到了也看不到；而且会话在别人手里。
- 做法：用 Telethon（Telegram 官方 MTProto 协议的 Python 客户端）以你本人的身份登录，监听官方账号 777000 发来的登录码，存最新一条，5 分钟过期自动清除，通过你自己的带令牌网页显示出来。
- 范围（本期）：只收 Telegram 登录码。**不收 Gmail、TikTok 的短信**，那是下一期。

## 快速开始（演示模式，不连 Telegram）

```bash
cd Telegram登录码自建版
python3 app.py --demo
# 打开 http://127.0.0.1:8766/
# 令牌在 data/access_token.txt（首次运行自动生成），粘贴进页面，点“刷新验证码”
# 点“演示：模拟一条新码”可以看一次完整的收码流程
```

演示模式不装任何依赖，不连 Telegram，没有真实码，只用来看版式和流程。

## 真实模式（在你自己的服务器上操作）

1. 在 https://my.telegram.org 创建应用，拿到 `API_ID`（数字）和 `API_HASH`。
2. 复制配置：
   ```bash
   cp config.example.py config.py
   # 按里面的注释填 API_ID / API_HASH / PHONE
   pip install -r requirements.txt
   ```
   也可以用环境变量：`TG_API_ID`、`TG_API_HASH`、`TG_PHONE`、`ACCESS_TOKEN`。
3. 启动：
   ```bash
   python3 app.py
   # 或 sh start.sh
   ```
4. 首次登录：终端会提示输入登录码。那次码是短信，**需要弟弟那部手机上读一次、念给你**，你在终端输入。登录成功后生成 `data/tg_session.session`，之后不用再输短信码（除非会话失效、Telegram 要求重新验证）。
5. 查码：打开 `http://<服务器IP>:8766/?token=<ACCESS_TOKEN>`，或在页面里粘贴令牌。没有正确令牌查码会返回 401，什么都不给。

## 魔搭 ModelScope Notebook 部署

> 保活在另一个旁聊里做，本文件夹只管“把网站做起来”。Notebook 的限制要先知道：

- 只把文件夹放在 `/mnt/workspace`，只有这里重启后还在；别的地方关机就清。
- 在 Notebook 里：
  ```bash
  cd /mnt/workspace/Telegram登录码自建版
  pip install -r requirements.txt
  cp config.example.py config.py   # 填好你自己的凭证
  python3 app.py --host 0.0.0.0 --port 8766
  ```
- 会话文件在 `data/tg_session.session`，也在 `/mnt/workspace` 下，重启后还在；但 Notebook 单次最长 **10 小时**、空闲超 **1 小时**自动关，关了服务就停了，得重开。**所以放魔搭上做不到真正 24 小时稳定**，这是平台上限，不是代码问题。
- 对外访问：Notebook 的端口怎么对外暴露，按你那边保活方案里的做法来，本项目不另开新口子；不要把带令牌的链接公开。

## 安全警告（必读）

- `data/tg_session.session` = 你的 Telegram 账号本身。丢了、发给别人、上传到公开地方，就等于账号被拿走。只放服务器本地。
- `data/access_token.txt` = 这页的钥匙。别把带 `?token=…` 的链接发给任何人、别截图带令牌。
- 码 5 分钟过期，别截图发群、别念给陌生人。
- 新 IP / 新设备登录，Telegram 可能还要短信二次验证，这是正常的；如果频繁换 IP 登录，可能被限流或要求重新验证。
- 日志不记码本身；`data/latest_code.json` 只存最新一条，过期自动删。

## 接口（供自查）

| 接口 | 权限 | 说明 |
|---|---|---|
| `GET /` | 公开（只给页面，不给码） | 主页面 |
| `GET /api/health` | 公开 | 只返回模式/监听状态，不含码 |
| `GET /api/status?token=…` | 需令牌 | 有没有可用码、还剩几秒 |
| `GET /api/code?token=…` | 需令牌 | 返回最新一条未过期的码；无码 404，无令牌 401 |
| `POST /api/demo/new-code?token=…` | 仅演示模式 + 需令牌 | 模拟一条新码 |

## 文件清单

- `app.py` — 网页服务 + 码存储 + 令牌校验 + 过期清理
- `simple.html` — 精简版主页面（默认打开的 `/`），一屏只做查码：大字码、倒计时、令牌、刷新/复制
- `index.html` — 完整版主页面（`/full.html`），含导航、Hero、特性、部署与安全说明
- `telethon_listener.py` — Telethon 监听 777000、提取 5 位码
- `showcase.html` — 可交互流程演示
- `config.example.py` / `.env.example` — 占位符配置，不含真实凭证
- `requirements.txt` / `start.sh` / `.gitignore`
- `产品介绍.md` — 产品介绍说明

## 不做什么 / 未验证

- 不做通用短信收件箱；Gmail / TikTok 短信不在本期。
- 不抄旧第三方站的代码；它的前端是服务端渲染的报错页，没有可见的 JS / API 可抄。
- 未验证：真实 Telegram 登录（需要你自己的 API 凭证 + 一次短信码，在你自己的服务器上做，我不登录、不发码）；魔搭上的长期在线（受 10 小时 / 1 小时上限）；Telegram 对新服务器 IP 的风控表现。
