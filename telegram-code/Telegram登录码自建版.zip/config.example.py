# 配置示例 —— 复制为 config.py 后再填你自己的值
# 注意：config.py 里是真实凭证，绝不要发给别人、不要上传到公开仓库。
# 本文件只放占位符，不要在这里填真实值。

# 在 https://my.telegram.org 创建应用后拿到的数字 ID，例如 12345678
API_ID = 0  # 填你的数字 API_ID，不要加引号

# 同一页面拿到的 hash，例如 "0123456789abcdef0123456789abcdef"
API_HASH = "PASTE_YOUR_API_HASH_HERE"

# 你的 Telegram 账号绑定的号码，国际格式，例如 "+57XXXXXXXXX"
# 这里只留格式示例，不要填真实号码；界面只显示掩码 +57 ••• ••• 103
PHONE = "+57XXXXXXXXX"

# 可选：覆盖自动生成的访问令牌。留空就用首次运行时自动生成的令牌。
# ACCESS_TOKEN = "PASTE_A_RANDOM_TOKEN_HERE"
