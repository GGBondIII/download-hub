#!/usr/bin/env python3
"""自建版 Telegram 登录码网站 v0.1

运行方式：
    python3 app.py --demo                 # 演示模式：不连 Telegram，模拟收码
    python3 app.py                         # 真实模式：需 config.py / 环境变量
    python3 app.py --port 8766 --host 127.0.0.1

安全规则（硬性）：
- 查码必须带 ?token=<ACCESS_TOKEN>，不对就 401，什么都不给
- 只保存最新一条码，5 分钟过期后自动清除，不留历史
- 日志只记“有人查码 / 有新码到达”，不记码本身
- 会话文件、ACCESS_TOKEN、API 密钥只留在服务器本地，绝不放进代码仓库
"""
from __future__ import annotations

import argparse
import json
import os
import random
import secrets
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
CODE_FILE = DATA_DIR / "latest_code.json"
TOKEN_FILE = DATA_DIR / "access_token.txt"
CODE_TTL_SECONDS = 300  # 5 分钟
MASKED_PHONE = "+57 ••• ••• 103"  # 仅做界面提示的掩码，不含完整号码

DEMO = False
LISTENER_STATE = "demo"  # demo | offline | online | unconfigured


# ---------- 存储：只存最新一条码 ----------
def save_code(code: str, source: str = "telegram-777000") -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    now = int(time.time())
    payload = {"code": code, "received_at": now, "expires_at": now + CODE_TTL_SECONDS,
               "source": source}
    tmp = CODE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload), encoding="utf-8")
    tmp.replace(CODE_FILE)
    print("[store] 收到一条新登录码（内容不记日志）", flush=True)


def load_code() -> dict | None:
    """返回未过期的最新码；过期或无码时清除并返回 None。"""
    if not CODE_FILE.exists():
        return None
    try:
        data = json.loads(CODE_FILE.read_text(encoding="utf-8"))
    except Exception:
        return None
    if int(time.time()) >= int(data.get("expires_at", 0)):
        try:
            CODE_FILE.unlink()
        except FileNotFoundError:
            pass
        return None
    return data


def clear_code() -> None:
    try:
        CODE_FILE.unlink()
    except FileNotFoundError:
        pass


# ---------- 访问令牌 ----------
def get_or_create_token() -> str:
    env = os.environ.get("ACCESS_TOKEN")
    if env:
        return env
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if TOKEN_FILE.exists():
        token = TOKEN_FILE.read_text(encoding="utf-8").strip()
        if token:
            return token
    token = secrets.token_urlsafe(32)
    TOKEN_FILE.write_text(token, encoding="utf-8")
    try:
        os.chmod(TOKEN_FILE, 0o600)
    except OSError:
        pass
    print("[auth] 已生成新的 ACCESS_TOKEN，见 data/access_token.txt（请勿分享）", flush=True)
    return token


ACCESS_TOKEN = get_or_create_token()


def token_ok(handler: BaseHTTPRequestHandler) -> bool:
    q = parse_qs(urlparse(handler.path).query)
    supplied = (q.get("token") or [""])[0]
    if not supplied:
        supplied = handler.headers.get("X-Access-Token", "")
    return bool(supplied) and secrets.compare_digest(supplied, ACCESS_TOKEN)


# ---------- 真实监听（可选，失败不影响网页） ----------
def start_listener_if_configured() -> None:
    global LISTENER_STATE
    if DEMO:
        LISTENER_STATE = "demo"
        return
    # 配置来源：config.py 优先，其次环境变量
    api_id = api_hash = phone = None
    try:
        sys.path.insert(0, str(BASE_DIR))
        import config  # type: ignore  # noqa: E402
        api_id = getattr(config, "API_ID", None)
        api_hash = getattr(config, "API_HASH", None)
        phone = getattr(config, "PHONE", None)
    except Exception:
        pass
    if not api_id or not api_hash or not phone:
        from telethon_listener import load_credentials_from_env
        creds = load_credentials_from_env()
        if creds:
            api_id, api_hash, phone = creds
    if not api_id or not api_hash or not phone:
        LISTENER_STATE = "unconfigured"
        print("[listener] 未配置 API_ID / API_HASH / PHONE，监听未启动（网页仍可打开）", flush=True)
        return
    try:
        from telethon_listener import TelegramCodeListener
    except ImportError:
        LISTENER_STATE = "unconfigured"
        print("[listener] 未安装 Telethon，监听未启动", flush=True)
        return
    session_path = str(DATA_DIR / "tg_session")
    try:
        api_id_int = int(api_id)
    except ValueError:
        LISTENER_STATE = "unconfigured"
        print("[listener] API_ID 不是数字，监听未启动", flush=True)
        return

    def _run():
        global LISTENER_STATE
        listener = TelegramCodeListener(api_id_int, str(api_hash), str(phone),
                                        session_path, on_code=lambda c, s: save_code(c, s))
        try:
            LISTENER_STATE = "online"
            listener.start_blocking()
        except Exception as exc:  # 断线、被踢、风控等都只记状态，不让网页挂掉
            LISTENER_STATE = "offline"
            print(f"[listener] 监听停止：{type(exc).__name__}（网页仍可打开，见产品介绍排查）", flush=True)

    threading.Thread(target=_run, daemon=True).start()
    LISTENER_STATE = "online"


# ---------- HTTP 服务 ----------
class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):  # 只记路径，不记 token 和码
        path = urlparse(self.path).path
        sys.stderr.write(f"{self.address_string()} {self.command} {path}\n")

    def _json(self, status: int, obj: dict) -> None:
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _file(self, path: Path, ctype: str) -> None:
        body = path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path in ("/", "/simple.html"):
            self._file(BASE_DIR / "simple.html", "text/html; charset=utf-8")
            return
        if path in ("/index.html", "/full.html"):
            self._file(BASE_DIR / "index.html", "text/html; charset=utf-8")
            return
        if path == "/showcase.html":
            self._file(BASE_DIR / "showcase.html", "text/html; charset=utf-8")
            return
        if path == "/api/health":
            self._json(200, {"ok": True, "mode": "demo" if DEMO else "real",
                             "listener": LISTENER_STATE, "masked_phone": MASKED_PHONE})
            return
        if path in ("/api/status", "/api/code"):
            if not token_ok(self):
                self._json(401, {"ok": False, "error": "unauthorized",
                                 "hint": "请在链接后加 ?token=你的 ACCESS_TOKEN"})
                return
            data = load_code()
            now = int(time.time())
            if path == "/api/status":
                self._json(200, {
                    "ok": True, "listener": LISTENER_STATE, "masked_phone": MASKED_PHONE,
                    "has_code": bool(data),
                    "received_at": data["received_at"] if data else None,
                    "expires_in": max(0, data["expires_at"] - now) if data else 0,
                })
                return
            # /api/code
            if not data:
                self._json(404, {"ok": False, "error": "no_code",
                                 "hint": "当前没有未过期的登录码"})
                return
            self._json(200, {
                "ok": True, "code": data["code"],
                "received_at": data["received_at"],
                "expires_in": max(0, data["expires_at"] - now),
                "masked_phone": MASKED_PHONE,
            })
            return
        self._json(404, {"ok": False, "error": "not_found"})

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/demo/new-code":
            if not DEMO:
                self._json(403, {"ok": False, "error": "demo_only"})
                return
            if not token_ok(self):
                self._json(401, {"ok": False, "error": "unauthorized"})
                return
            code = f"{random.randint(0, 99999):05d}"
            save_code(code, source="demo")
            self._json(200, {"ok": True, "received_at": int(time.time()),
                             "expires_in": CODE_TTL_SECONDS})
            return
        self._json(404, {"ok": False, "error": "not_found"})


def main() -> None:
    global DEMO
    ap = argparse.ArgumentParser(description="自建版 Telegram 登录码网站 v0.1")
    ap.add_argument("--demo", action="store_true", help="演示模式：不连 Telegram")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8766)
    args = ap.parse_args()
    DEMO = args.demo
    DATA_DIR.mkdir(parents=True, exist_ok=True)

    if DEMO:
        print("[demo] 演示模式：不连接 Telegram，验证码为模拟生成", flush=True)
        if load_code() is None:
            save_code(f"{random.randint(0, 99999):05d}", source="demo")
    else:
        start_listener_if_configured()

    print(f"[web] 打开 http://{args.host}:{args.port}/  （查码需加 ?token=…，令牌见 data/access_token.txt）", flush=True)
    print(f"[web] 监听状态：{LISTENER_STATE}，掩码号码：{MASKED_PHONE}", flush=True)
    ThreadingHTTPServer((args.host, args.port), Handler).serve_forever()


if __name__ == "__main__":
    main()
