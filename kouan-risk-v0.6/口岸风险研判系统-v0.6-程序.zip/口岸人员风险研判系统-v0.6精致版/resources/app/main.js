const { app, BrowserWindow } = require('electron');
const path = require('path');
function createWindow() {
  const win = new BrowserWindow({
    width: 1320, height: 900, minWidth: 1080, minHeight: 700,
    title: '口岸人员风险研判系统 v0.6',
    backgroundColor: '#0c1428',
    show: false,
    webPreferences: { nodeIntegration: false, contextIsolation: true }
  });
  win.once('ready-to-show', () => win.show());
  win.setMenuBarVisibility(false);
  win.loadFile(path.join(__dirname, 'index.html'));
}
app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
