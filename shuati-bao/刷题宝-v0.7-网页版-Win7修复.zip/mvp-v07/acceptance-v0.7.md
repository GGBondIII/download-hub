# 刷题宝 v0.7 验收记录（Win7 兼容修复版）

版本：v0.7。相对 v0.6 只改兼容性，功能不变。v0.6 原样保留在 `mvp-v06/`，可回滚。

## 改了什么

1. 新增 Win7 专用 exe `dist/刷题宝-Win7.exe`（Python 3.8.10 + PyInstaller 5.13.2 打包，6.3 MB，md5 `b7b020252a09b9b842111bdbb2cea598`）；保留通用版 `dist/刷题宝.exe`（Python 3.12 + PyInstaller 6.22.3，Win10/11 用）。
2. 压缩包全部改成英文文件名（`import-templates/`、`product-intro.md`、`acceptance-v0.x.md`、`design-checklist-HIG.md`、`exe-guide.md`、`shuatibao.spec` 等），打包脚本 `build-v07-zip.py` 强制校验非 ASCII 文件名。
3. `start.bat`、`build_exe.bat` 改 GBK 编码、去 `chcp 65001`；没装 Python 时指引用户改用 exe。
4. `server.py` 版本号 v0.7；`README.md`、`product-intro.md`、`exe-guide.md` 按正确口径重写；新增 `audit-win7-compat-v0.7.md`（审核报告）。

## 验收（本机模拟，非真实 Windows）

### Win7 专用 exe（wine 下，我亲自复验）

- 文件：PE32+ x86-64 控制台程序，内嵌 `python38.dll`（字符串表确认），OS 版本 5.2（无高于 Win7 的版本下限），md5 与子代理汇报一致。
- 运行：`SHUATI_PORT=18772`、`SHUATI_AUTOBACKUP=0`，pty 下启动，不卡死（v0.6 的 Python 3.12 版在同一环境下会卡在启动后拉不起服务）。
- 根页 200、Lite 200、showcase 200；民警 `minjing/123456` 登录成功（民警甲，执勤一队）；首次启动自动建库，`data/shuati.db` 有 20 道种子题，`assets/backups/uploads` 目录齐全。
- 运行时版本号：子代理用 exe 自身数据库里的联邦令牌调 `/api/federation/catalog`，返回 `version: v0.7`，题量 20。
- 注意：打包用的是官方 Python 3.8.10 embeddable zip（非图形安装程序，因本机无 wine32、装不上官方安装器 stub），内嵌的仍是官方 3.8.10 的 `python38.dll`，Win7 兼容性不变；wine 下需要 `LC_ALL=zh_CN.UTF-8` 才能解包中文名文件（v0.7 打包数据已全是英文名，这一步在真实中文 Win7 上是正常情况）。

### 网页版（干净副本冒烟，我亲自验）

- 从新 zip 解压出的干净副本跑 `server.py`：根页 200、Lite 200、showcase 200、民警登录成功、首次启动自动建库。
- 新 zip：25 个条目，全部 ASCII 文件名，`unzip -t` 无错；按 GBK 解码模拟不再有非法字节序列。

### server.py 与 Python 3.8

- `ast.parse(feature_version=(3,8))` 通过；无 3.9+ 语法与标准库用法（无 `match/case`、`X | Y` 注解、`removeprefix`、`zoneinfo`、`datetime.UTC`）。

## 仍需真实环境验证（不要当作已验证）

- Win7 专用 exe 在真实 Win7 SP1 64 位机上双击（本机只在 wine 下验过）。
- 通用版 exe 在真实 Win10/11 机上双击（v0.6 通用版已在真实 Win7 机上试过、装不上；Win10/11 未试过）。
- 真实局域网多机访问、联邦共享两台真机、150 并发实机压测、真实 XP 机开 Lite 页。
- 若用户的 Win7 是 32 位：两个 exe 都是 64 位，都不能用，需另打 32 位版。

## 沿用 caveat（v0.6 未变）

- 后台部门横向对比柱状图的答对数是推算值（总作答×平均正确率，误差≤1 道），非精确汇总。
- 学习计划进度按作答题次算，同一题重复做会重复计。
- 组卷模板开考不含简答题，只有通用卷勾选才含。
- 个别未预期异常仍会直接断连，未做全仓统一兜底。
