# 验收记录 v0.5（P1 四项，2026-11-06）

v0.5 由 v0.4 完整复制后改动，v0.4 原样保留可回滚。技术仍为 Python 3 标准库 + SQLite 单文件，零依赖零 CDN，离线可用。版本号已改为 v0.5（README、start.bat、start.sh、server.py 启动打印、产品介绍、showcase）。

## 怎么做（每项）

### 1）图文错位自动修复
- `server.py`：`pairing_confidence(dist)` 档位——0 行 0.97 / 1 行 0.85 / 2 行 0.72 / 3 行 0.62 / ≥4 行 0.45 / 无锚点 0.40；`pairing_status`：≥0.90 自动过，≥0.70 复核，否则人工。新表 `image_pairings`（job_id、asset_id、question_id、filename、confidence、status、reason、pending_path）；`import_jobs` 新增 `pairing_report_json`、`pairing_auto/review/manual` 列（`_add_col` 兼容旧库）。
- Excel 浮动图按锚定行、嵌入图按单元格；Word 解包抽图按段落锚点；锚点行在所有题行之后的图片改挂最后一题（原先会被静默丢掉）；无题号的孤图进人工队列，待指派文件存 `data/uploads/pending_<job>_<hash>.<ext>`；父题映射（`parent_row`→`parent_id`）二遍解析。
- 新接口：`GET /api/import/jobs/<jid>/pairings`（配对清单 + 报告 + 题干 + 图片路径）、`POST /api/import/pairings/<pid>/confirm`（确认当前指派、或换题、或给孤图指定题目）、`POST /api/import/pairings/<pid>/reject`（删图片资产/待指派文件）。
- 前端：导入页新增“图文配对复核”区（配对报告数字 + 题干、图片、置信度徽章、换题输入、确认/驳回按钮）；上传完成后提示里追加配对报告。
- 不谎称 100% 自动：文案统一写“低置信度要人复核”。

### 2）PDF 文字型导入
- `server.py`：纯标准库解析，无 PyMuPDF——`_pdf_objects`、`_pdf_stream_bytes`（Flate 解压）、`_pdf_cmap_from_stream`（只在 beginbfchar/bfrange 段内解析）、`_pdf_font_cmaps`（按页面 Resources 的 /Font 字典每字体一套映射；Resources 间接引用跟进）、`_pdf_decode_text`（UTF-16BE、1 字节、2 字节编码、cp1252 回退）、`_pdf_text_items`（跟 Tf 当前字体、Tm/Td、Tj/TJ；BT 重置坐标）、`_pdf_lines`（同页 y 差 ≤4pt 成行）、`_pdf_cut_questions`（与 docx 同套题号/选项/答案/解析/参考答案/评分要点正则，含行内连写选项拆分）。
- 图片：DCTDecode 的 JPEG 直接取；Flate 的 8 位 DeviceRGB/DeviceGray 原始数据用 `_pdf_raw_to_png` 手写 PNG（含 PNG 预测器 ≥10 的反滤波，支持 None/Sub/Up/Average/Paeth）；其他类型计入 `images_skipped`。图片按 y 坐标挂最近题干，换算 dist 档（<20pt=0，<60=1，<150=2，<300=3，否则 4）。
- 分类：无页面→unreadable；文字 <20 字且有图→scanned；文字 <20 或可读率 <0.5→unreadable；每页 <30 字且有图→scanned。扫描型上传时 400 拒绝，报错含“扫描型”与“OCR”，不硬做假识别。
- 路由：`POST /api/import/pdf`（multipart，限 .pdf、20MB），复用 `do_import` 与现有审核/发布/回滚流程。前端导入页新增 PDF 上传入口。

### 3）简答/材料题批阅
- `server.py`：`questions.rubric`、`questions.max_score`（默认 10）；`review_scores` 补列 `attempt_id/status/max_score/reviewed_at`（`_add_col`）。
- `validate_row` 支持 short/material；`normalize_type` 新增简答（4）、材料（5）；Excel 表头新增评分要点/满分/父题列；`parse_docx` 支持简答/材料题识别（`/`、参考答案、评分要点行）。
- 守卫：简答/材料题走 `/api/attempts` 返回 400“请用文字提交，待教官人工批阅，不自动判分”；`pick_questions` 的 `mode == "essay"` 返回简答/材料题（不含参考答案/评分要点），其他模式排除 short/material；`adaptive_pick`、`sample_by_template`、考核开考非模板分支的题库查询均加 `AND type NOT IN ('short','material')`。
- 新接口：`GET /api/essay/questions`、`GET /api/essay/queue`（教官/管理员，含参考答案与评分要点）、`GET /api/essay/mine`、`POST /api/essay/submit`（写 attempts，`is_correct` 为 NULL；写 `review_scores`，status pending）、`POST /api/essay/review`（打分 0~max_score、评语；得分 ≥60% 满分算对；调 `update_mastery`/`update_review_schedule`/`refresh_quality_for`；不及格进错题本；已批过的 400 拒绝重复批改）、`POST /api/questions/short`（教官/管理员直接建简答/材料题，简答须有参考答案，发布状态）。
- 考核：开考默认不含简答题；勾选“包含简答题”（`include_essay`）后简答进卷，草稿可保存文字答案；交卷时简答/材料题不自动判分，attempt 的 `is_correct` 置 NULL 并建待批 `review_scores`，不计入自动得分，响应加 `essay_pending`；打印成绩单对 `is_correct is None` 显示“待批阅”而非“错”。
- 报告：`report_for` 的 total/correct 查询加 `AND is_correct IS NOT NULL`（排除待批简答），并加 `essay` 统计段（总数/已批/待批/得分/满分），与选择题分开列示。
- 前端：导航新增“简答”Tab（简答题作答 textarea + 我的提交）；后台新增“简答批阅队列”（参考答案、评分要点、打分、评语）；报告页新增简答得分卡片与简答/计划段落。

### 4）学习计划下发
- 复用已有 `study_plans`/`tasks` 表（`_add_col` 补 `knowledge/daily_count/scope/target_user_id` 与 `tasks.due_date`），未另起一套。
- `server.py`：`plan_progress(conn, plan, user_id)`——自计划创建起，该用户在目标知识点（为空=全部）上已作答的题数（已批阅的简答也算，未批阅的不算；按题次计，同一题重复做重复计）；返回 done/target/pct/overdue/days_left/daily_count。
- 新接口：`POST /api/plans`（建计划并按部门/个人生成 tasks；校验名称、目标题量>0、截止日格式、范围、个人须指定用户）、`GET /api/plans`（教官/管理员，全量进度：下发人数/完成人数/平均进度）、`GET /api/plans/me`（本人计划 + 进度；达标时 tasks 置 done）。
- `admin_overview` 加 `plans_active`/`plans_overdue`；到期未完成进预警（总览卡片 + 预警区一行）；`report_for` 加本人计划摘要（最多 5 个）。
- 前端：后台新增“学习计划下发”（建计划表单 + 计划列表）；报告页新增学习计划卡片；Lite 版新增 `/lite/plans` 文字版计划列表，首页加入口。

## 怎么验（每项自测结果）

测试脚本在 `/tmp`（不进交付物），干净副本拷到 `/tmp/v05-t*`，清空 `data/`，用 `SHUATI_PORT` 换端口启动，测完停服务删副本。

| 项 | 脚本 | 结果 |
|---|---|---|
| 1 图文错位 | `/tmp/test_item1.py` | 20/20 通过。夹具：`excel-mixed.xlsx`（自动 1 + 复核 1，置信度 0.97/0.85）、`excel-far.xlsx`（自动 1 + 人工 1，0.45）、`word-far-image.docx`（3 道题含 1 道简答，图片距题干 11 段→0.45 人工；审核+发布后简答题进题库）。修过的 bug：`do_import` 的 INSERT 占位符少一个（13 values for 14 columns）；配对 confirm/reject 的路径下标错（id 在第 4 段）。 |
| 2 PDF 导入 | `/tmp/test_item2.py` | 14/14 通过。夹具：`pdf-source.pdf`（LibreOffice 由 Word 转的真实中文 PDF，3 道题全对：单选×2 含答案解析、简答含参考答案与评分要点；图片 480×200 PNG 有效，挂 Q2，置信度 0.72 复核；审核+发布后进题库）、`pdf-scanned.pdf`（PIL 纯图 PDF，400 拒绝，报错含“扫描型”与“OCR”）、非 PDF 文件上传 400 拒绝。修过的 bug：Tm 分组号错（e=第 7 组、f=第 8 组；Td 是第 9/10 组）、ToUnicode 跟引用取 CMap 流对象、BT 未重置导致 Td 位移累加、Resources/XObject 间接引用未跟进、可读率计算把 CJK 重复计入 isalnum。 |
| 3 简答批阅 | `/tmp/test_item3.py` | 19/19 通过。建简答题→提交文字答案→待批队列可见→打分 4/5 通过→报告简答分 4/5 与选择题分开列示、待批不计入总正确率；重复批改 400 拒绝；超满分 400 拒绝；打分 3/10 未通过进错题本；选择题提交走旧接口不受影响；自由练习不含简答题。 |
| 4 学习计划 | `/tmp/test_item4.py` | 17/17 通过。部门计划下发 2 人、个人逾期计划下发 1 人；目标 0、坏日期、无用户、民警建计划均被拒绝；做 1 道目标知识点题后进度 1/1（100%）、全知识点计划 1/3（33%）；报告含计划摘要；总览 `plans_overdue`=1；Lite `/lite/plans` 200 含计划与“已逾期”。 |
| 整体回归 | `/tmp/test_v05.py` | 75/75 通过。覆盖：根页/Lite/showcase/静态文件 200、四角色登录、20 道种子题、练习四模式、答对/答错/错题重练、薄弱组卷、自适应画像、考核开考/草稿/交卷/打印、报告五图数据/stats/CSV、队报告权限、后台总览/质量/模板、Excel+PDF 导入→审核→发布→能练、简答全流程、含简答考核（`essay_pending`≥1、成绩单“待批阅”、进批阅队列）、计划进度与逾期预警、Lite 计划页、前端静态检查（新 Tab/新函数/showcase 四段 P1 演示、无外部 CDN 引用）。 |

回归中抓到的 3 个真 bug（已修，均重测通过）：
1. 配对接口 JOIN 写成 `assets` 表，实际表名是 `question_assets`——请求直接断连（无响应）。修后配对清单正常返回图片路径。
2. 含简答的考核交卷时 INSERT 占位符少一个（8 列 7 值）——请求直接断连。修后交卷正常，`essay_pending` 正确。
3. 打印成绩单用 `bool(is_correct)` 包了一层，`None` 变 `False`，简答行显示“错”而非“待批阅”。修后保留 `None`，显示“待批阅”，正确答案列显示“待人工批阅”。

## 没做到 / 待回看（不编造）

- 计划进度按“作答题次”算：同一题重复做会重复计（目标题量按题次计）；时间戳是秒级精度，建计划当秒内的作答不计入进度（用严格 `>` 比较，保守选择：不把建计划前同一秒的旧作答算进去）；实际使用中计划建好几天后再做题，不受影响。
- 部门横向对比柱状图的答对数仍是推算值（总作答×平均正确率，误差 ≤1 道），v0.4 遗留，非本次引入。
- 浏览器实测动效手感与减弱动效切换未做；真实脱敏样张（Excel/Word 各一份）、真实局域网多机、真实 XP 机、150 并发压测（主代理后台模拟）、XP 原生 EXE 均未验证。
- Word 导入里不匹配任何模式的段落会并入上一题题干（v0.2 旧行为，非新 bug）。
- 考核用组卷模板开考时不含简答题（模板抽题只走选择题）；只有“通用卷”勾选“包含简答题”才能把简答放进考核。
- 异常处理边界：个别接口的未预期异常会直接断连（无 JSON 错误体），本次只修了回归中实际触发的两处；全仓统一的异常兜底未做。

## 文件改动清单

- `server.py`：P1 四项后端（配对、PDF 解析、简答批阅、学习计划、考核含简答选项、报告 essay/plans 段、总览 plans 键、Lite `/lite/plans`）；版本号 v0.5。
- `static/index.html`：简答 Tab、PDF 上传入口、图文配对复核区、批阅队列、学习计划下发区、考核“包含简答题”勾选。
- `static/app.js`：v0.5 段（showTab 覆盖、renderQuestions 简答渲染、submitEssay、loadEssayQuestions/Mine/Queue、gradeEssay、createPlan、loadPlansAdmin、loadPairings/confirmPairing/rejectPairing）；报告与后台加 P1 卡片；上传提示加配对报告；考核草稿保存支持 textarea；交卷结果显示待批简答数。
- `static/style.css`：未动。
- `产品介绍.md`：v0.5、P1 四项、流程 7/8、没做到清单更新。
- `showcase.html`：v0.5、导航新增 9–12 节（图文配对、PDF 导入、简答批阅、学习计划，全部可点演示）、导入节与底部未做清单更新。
- `设计检查表-HIG.md`：新增 J 节（J1–J10）。
- `README.md`：v0.5、P1 四项说明。
- `start.bat`、`start.sh`：v0.5。
- 本文件：新增。
