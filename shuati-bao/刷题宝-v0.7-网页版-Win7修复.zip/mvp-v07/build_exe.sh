#!/bin/bash
# 刷题宝 exe 打包（Linux 验证版）
# 在 Linux 上打包等价的冻结程序：验证打包流程与冻结后运行是否正常。
# 注意：Linux 上打出来的是 Linux 程序，不是 Windows exe；
# Windows exe 请在 Windows 主机上双击 build_exe.bat 打包。
set -e
cd "$(dirname "$0")"
python3 -m PyInstaller --noconfirm --clean --onefile --name 刷题宝 \
  --add-data "static:static" \
  --add-data "showcase.html:." \
  --add-data "import-templates:import-templates" \
  server.py
echo "完成：dist/刷题宝（Linux 程序，仅供验证打包流程，不是 Windows exe）"
