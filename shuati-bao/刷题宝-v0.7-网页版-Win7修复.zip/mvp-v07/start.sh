#!/bin/bash
# 常熟边检站刷题宝 MVP v0.6 一键启动（Linux / macOS）
cd "$(dirname "$0")"
if ! command -v python3 >/dev/null 2>&1; then
  echo "[错误] 本机没有 python3，请先安装 Python 3.8 以上。"
  exit 1
fi
echo "本机访问：http://127.0.0.1:8765/"
echo "局域网访问：请看下面启动后打印的“局域网访问”地址。"
echo "演示账号：admin / jiaoguan / minjing / minjing2，密码都是 123456"
echo "按 Ctrl+C 可停止服务。数据库在 data/shuati.db。"
exec python3 -u server.py
