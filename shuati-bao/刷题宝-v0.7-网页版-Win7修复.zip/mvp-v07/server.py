#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""常熟边检站刷题宝 MVP v0.7（Win7 兼容修复版）：Python 3 标准库 only + SQLite，不联网、不下载、不依赖 pip 包。
P0：个性化自适应（Elo+FSRS简化）/ 学习方法五环节 / 后台可视化 / 题库质量闭环 / 组卷模板。
P1（v0.5）：图文错位自动修复（三层置信度+复核页）/ PDF 文字型导入（纯标准库解析，扫描型明确拒识）/
简答·材料题人工批阅（不做自动批改）/ 学习计划下发。脱敏不做（局域网内自家题库）。
P2（v0.6）：跨主机题库联邦共享（登记+令牌+SHA-256包+草稿审核发布）/ 运维备份自动化（一键+每日自动+恢复前再备一份）/
本地 AI 辅助出题（纯本地规则变式引擎，不联网、不接外部模型、不装大模型，变式须人工审核才能发布）。
水印/脱敏已按用户决定砍掉（局域网内自家题库、自己管理，无涉密风险）。
v0.7：Win7 兼容修复——Win7 专用 exe（Python 3.8 + PyInstaller 5.13.2）、压缩包全英文文件名（Win7 自带解压可用）、start.bat/build_exe.bat 改 GBK 编码并去掉 chcp 65001；功能与 v0.6 完全相同。"""
import base64, csv, hashlib, hmac, io, json, os, random, re, secrets, shutil, sqlite3, sys, threading, time, zipfile, zlib
from datetime import datetime, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs, unquote
import urllib.request, urllib.error
import xml.etree.ElementTree as ET
# 打包成 exe（PyInstaller --onefile）时：程序文件在临时目录解包，数据（data/）放在 exe 所在目录；
# 静态页面（static/、showcase.html）从解包目录读。未打包时两者都在源码目录。
if getattr(sys, "frozen", False):
	BASE = os.path.dirname(os.path.abspath(sys.executable))
	STATIC_BASE = getattr(sys, "_MEIPASS", BASE)
else:
	BASE = os.path.dirname(os.path.abspath(__file__))
	STATIC_BASE = BASE
DATA_DIR = os.path.join(BASE, "data")
ASSETS_DIR = os.path.join(DATA_DIR, "assets")
UPLOAD_DIR = os.path.join(DATA_DIR, "uploads")
BACKUP_DIR = os.path.join(DATA_DIR, "backups")
DB_PATH = os.path.join(DATA_DIR, "shuati.db")
PORT = int(os.environ.get("SHUATI_PORT", "8765"))
HOST = os.environ.get("SHUATI_HOST", "0.0.0.0")
VERSION = "v0.7"
AUTO_BACKUP_KEEP = 7
FED_TIMEOUT = 10
DB_LOCK = threading.RLock()
SESSIONS = {}
os.makedirs(ASSETS_DIR, exist_ok=True)
os.makedirs(UPLOAD_DIR, exist_ok=True)
os.makedirs(BACKUP_DIR, exist_ok=True)
SEED_QUESTIONS = [
	{"type":"single","stem":"执勤中发现旅客所持证件疑似伪造，第一步最恰当的做法是？","options":["直接放行，避免耽误时间","先稳住旅客，按程序核查并报告带班领导","当场没收证件并让旅客离开","自行判断真伪后放行"],"answer":"B","explanation":"疑似伪造证件应按程序核查、报告，不可凭个人判断放行或没收了事。","subject":"证件查验与真伪鉴别","knowledge":["证件核查程序"],"difficulty":2},
	{"type":"single","stem":"边防检查执勤人员在查验时，应当做到以下哪一点？","options":["只查证件，不核对持证人","证件、人、行程信息相互核对","只看证件有效期","旅客自述即可，不必核查"],"answer":"B","explanation":"人证对照是基本要求，证件、持证人、行程信息要相互核对。","subject":"证件查验与真伪鉴别","knowledge":["人证对照"],"difficulty":1},
	{"type":"single","stem":"旅客出境时，边检执勤的常规顺序一般是？","options":["先放行再查验","查验、核对无误后放行","只登记不查验","由旅客自行决定顺序"],"answer":"B","explanation":"先查验核对，无误后再放行，这是常规执勤顺序。","subject":"口岸查控与勤务规范","knowledge":["查验流程"],"difficulty":1},
	{"type":"multi","stem":"下列哪些属于口岸查控中需要重点留意的情形？（多选）","options":["证件信息与持证人明显不符","旅客行程、事由含糊不清","证件有涂改、破损痕迹","旅客主动配合、证件齐全"],"answer":"ABC","explanation":"A、B、C 都是需要重点留意的异常情形；D 为正常情形。","subject":"口岸查控与勤务规范","knowledge":["异常情形识别"],"difficulty":3},
	{"type":"judge","stem":"执勤中遇到旅客对查验有疑问，执勤人员应当耐心解释、按规定处理。","options":["对","错"],"answer":"对","explanation":"文明执勤、耐心解释是执勤规范的要求。","subject":"执勤执法规范与程序","knowledge":["文明执勤"],"difficulty":1},
	{"type":"single","stem":"下图为某类证件的版式示意图（样图），查验时最应关注的要素是？","options":["证件颜色是否好看","版式、照片、个人信息是否一致且无涂改","证件大小是否标准","证件是否崭新"],"answer":"B","explanation":"版式、照片与个人信息一致性、无涂改，是查验的核心要素。本题配图为示意图。","subject":"证件查验与真伪鉴别","knowledge":["证件版式查验"],"difficulty":2,"has_image":True},
	{"type":"single","stem":"出入境管理的基本原则之一是？","options":["只管理出境，不管入境","维护国家主权、安全和社会秩序，保障合法权益","只针对外国人","不设任何查验程序"],"answer":"B","explanation":"出入境管理兼顾国家安全与合法权益保护，出入境都要管理。","subject":"出入境边防检查法律法规","knowledge":["出入境管理法总则"],"difficulty":2},
	{"type":"multi","stem":"执勤记录应当做到哪些？（多选）","options":["记录真实、完整","及时归档保存","可随意涂改、无需核对","按规定留存备查"],"answer":"ABD","explanation":"执勤记录要真实完整、及时归档、按规定留存，不可随意涂改。","subject":"执勤执法规范与程序","knowledge":["执勤记录"],"difficulty":2},
	{"type":"single","stem":"发现口岸现场出现旅客大量滞留时，执勤人员首先应？","options":["继续按原节奏查验，不作处理","立即报告，配合增开通道、疏导秩序","让旅客自行离开现场","关闭所有通道"],"answer":"B","explanation":"大客流滞留要立即报告、配合疏导增援，不能放任不管。","subject":"口岸查控与勤务规范","knowledge":["大客流处置"],"difficulty":3},
	{"type":"judge","stem":"边检执勤人员可以在执勤中随意向无关人员透露旅客信息。","options":["对","错"],"answer":"错","explanation":"旅客信息要保密，不得随意向无关人员透露。","subject":"执勤执法规范与程序","knowledge":["信息保密"],"difficulty":1},
	{"type":"single","stem":"查验中发现旅客为未成年人单独出行，执勤人员应当？","options":["直接放行","按程序核查监护、行程等情况，必要时报告","不予理会","让其自行联系他人后离开"],"answer":"B","explanation":"未成年人单独出行要按程序核查，必要时报告处理。","subject":"口岸查控与勤务规范","knowledge":["特殊旅客处置"],"difficulty":3},
	{"type":"multi","stem":"证件真伪鉴别常用的方法包括？（多选）","options":["观察版式、印刷与防伪特征","核对照片与持证人","借助查验设备辅助核查","仅凭手感判断"],"answer":"ABC","explanation":"版式观察、人证核对、设备辅助是常用方法；仅凭手感不可靠。","subject":"证件查验与真伪鉴别","knowledge":["真伪鉴别方法"],"difficulty":2},
	{"type":"single","stem":"执勤交接班时，应当交接清楚的内容不包括？","options":["在查旅客、待办事项","设备、证件、物品情况","个人私事","值班记录与注意事项"],"answer":"C","explanation":"交接班要交清工作事项，个人私事不在交接范围内。","subject":"口岸查控与勤务规范","knowledge":["交接班"],"difficulty":1},
	{"type":"single","stem":"下图为口岸通道示意图（样图），执勤人员维持秩序时最应注意的是？","options":["只管自己通道，不管现场秩序","引导分流、保持通道畅通、留意异常","让旅客随意插队","关闭引导标识"],"answer":"B","explanation":"引导分流、保持畅通、留意异常，是现场秩序维护的基本要求。本题配图为示意图。","subject":"口岸查控与勤务规范","knowledge":["现场秩序"],"difficulty":2,"has_image":True},
	{"type":"judge","stem":"阶段考核的成绩应当与日常练习成绩分开归档，练习错题不直接计入考核。","options":["对","错"],"answer":"对","explanation":"本系统练习与考核分开，练习是练手，考核单独归档。","subject":"执勤执法规范与程序","knowledge":["练考分离"],"difficulty":1},
	{"type":"single","stem":"执勤中遇到突发事件（如旅客突发疾病），第一步是？","options":["继续查验，不予理会","立即报告并配合救助、维持秩序","先拍照发朋友圈","让旅客自行处理"],"answer":"B","explanation":"突发事件先报告、配合救助、维持秩序。","subject":"应急处突与安全防护","knowledge":["突发事件处置"],"difficulty":2},
	{"type":"multi","stem":"应急处突中，执勤人员应当做到？（多选）","options":["服从指挥、协同配合","保持冷静、按预案处置","擅自离岗、自行其是","及时报告现场情况"],"answer":"ABD","explanation":"服从指挥、按预案处置、及时报告是基本要求；擅自离岗不可。","subject":"应急处突与安全防护","knowledge":["应急协同"],"difficulty":3},
	{"type":"single","stem":"关于执勤用语，以下说法正确的是？","options":["可以使用随意、粗俗的语言","应当文明规范、清晰简洁","越严厉越好","不需要解释，直接命令"],"answer":"B","explanation":"执勤用语要文明规范、清晰简洁，必要时耐心解释。","subject":"执勤执法规范与程序","knowledge":["文明用语"],"difficulty":1},
	{"type":"single","stem":"旅客携带的证件过期，执勤人员应当？","options":["直接放行","按规定告知并作相应处理，不放行过期证件","自行帮旅客延期","不予理会"],"answer":"B","explanation":"证件过期不能作为有效证件放行，要按规定告知处理。","subject":"证件查验与真伪鉴别","knowledge":["证件有效期"],"difficulty":2},
	{"type":"judge","stem":"口岸执勤中，执勤人员发现可疑人员或物品，应当按规定报告并配合处置，不得擅自放行。","options":["对","错"],"answer":"对","explanation":"可疑情形要报告、配合处置，不能擅自放行。","subject":"应急处突与安全防护","knowledge":["可疑情形处置"],"difficulty":2},
]
DEMO_USERS = [
	("admin","管理员","admin","全站","123456"),
	("jiaoguan","教官","instructor","执勤一队","123456"),
	("minjing","民警甲","officer","执勤一队","123456"),
	("minjing2","民警乙","officer","执勤二队","123456"),
]
def now_iso():
	return datetime.now().strftime("%Y-%m-%d %H:%M:%S")
def hash_pw(pw, salt=None):
	salt = salt or secrets.token_hex(8)
	h = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 100000).hex()
	return f"{salt}${h}"
def check_pw(pw, stored):
	try:
		salt, h = stored.split("$", 1)
		return hmac.compare_digest(hashlib.pbkdf2_hmac("sha256", pw.encode(), salt.encode(), 100000).hex(), h)
	except Exception:
		return False
def get_db():
	conn = sqlite3.connect(DB_PATH, check_same_thread=False)
	conn.row_factory = sqlite3.Row
	conn.execute("PRAGMA journal_mode=WAL")
	conn.execute("PRAGMA foreign_keys=ON")
	return conn
def init_db():
	conn = get_db()
	with DB_LOCK:
		c = conn.cursor()
		c.executescript("""
		CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, display_name TEXT, role TEXT NOT NULL, team TEXT, password_hash TEXT NOT NULL, created_at TEXT);
		CREATE TABLE IF NOT EXISTS knowledge_nodes(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT UNIQUE NOT NULL, parent_id INTEGER, subject TEXT);
		CREATE TABLE IF NOT EXISTS questions(id INTEGER PRIMARY KEY AUTOINCREMENT, type TEXT NOT NULL, stem TEXT NOT NULL, answer TEXT NOT NULL, explanation TEXT DEFAULT '', subject TEXT DEFAULT '', difficulty INTEGER DEFAULT 3, source TEXT DEFAULT '系统样题', status TEXT DEFAULT 'published', version_id INTEGER, created_by TEXT, created_at TEXT);
		CREATE TABLE IF NOT EXISTS question_options(id INTEGER PRIMARY KEY AUTOINCREMENT, question_id INTEGER NOT NULL, label TEXT NOT NULL, content TEXT NOT NULL, asset_id INTEGER);
		CREATE TABLE IF NOT EXISTS question_assets(id INTEGER PRIMARY KEY AUTOINCREMENT, question_id INTEGER, option_label TEXT, filename TEXT NOT NULL, mime TEXT, path TEXT NOT NULL, created_at TEXT);
		CREATE TABLE IF NOT EXISTS question_knowledge(id INTEGER PRIMARY KEY AUTOINCREMENT, question_id INTEGER NOT NULL, knowledge_id INTEGER NOT NULL, UNIQUE(question_id, knowledge_id));
		CREATE TABLE IF NOT EXISTS bank_versions(id INTEGER PRIMARY KEY AUTOINCREMENT, version_no TEXT UNIQUE NOT NULL, note TEXT, question_count INTEGER DEFAULT 0, is_current INTEGER DEFAULT 0, created_by TEXT, created_at TEXT);
		CREATE TABLE IF NOT EXISTS bank_version_items(id INTEGER PRIMARY KEY AUTOINCREMENT, version_id INTEGER NOT NULL, question_id INTEGER NOT NULL, UNIQUE(version_id, question_id));
		CREATE TABLE IF NOT EXISTS import_jobs(id INTEGER PRIMARY KEY AUTOINCREMENT, filename TEXT, file_type TEXT, total_rows INTEGER DEFAULT 0, ok_rows INTEGER DEFAULT 0, bad_rows INTEGER DEFAULT 0, status TEXT DEFAULT 'parsed', created_by TEXT, created_at TEXT);
		CREATE TABLE IF NOT EXISTS import_items(id INTEGER PRIMARY KEY AUTOINCREMENT, job_id INTEGER NOT NULL, row_no INTEGER, raw_json TEXT, error TEXT, status TEXT DEFAULT 'pending');
		CREATE TABLE IF NOT EXISTS review_queue(id INTEGER PRIMARY KEY AUTOINCREMENT, job_id INTEGER, question_id INTEGER, row_no INTEGER, reason TEXT, status TEXT DEFAULT 'pending', reviewer TEXT, reviewed_at TEXT);
		CREATE TABLE IF NOT EXISTS papers(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, subject TEXT, question_count INTEGER, minutes INTEGER, created_by TEXT, created_at TEXT);
		CREATE TABLE IF NOT EXISTS paper_items(id INTEGER PRIMARY KEY AUTOINCREMENT, paper_id INTEGER NOT NULL, question_id INTEGER NOT NULL, sort_order INTEGER);
		CREATE TABLE IF NOT EXISTS exam_sessions(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, paper_id INTEGER, title TEXT, question_ids_json TEXT, started_at TEXT, ends_at TEXT, submitted_at TEXT, score REAL, total INTEGER, status TEXT DEFAULT 'ongoing');
		CREATE TABLE IF NOT EXISTS attempts(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, question_id INTEGER NOT NULL, mode TEXT DEFAULT 'practice', exam_session_id INTEGER, user_answer TEXT, is_correct INTEGER, version_id INTEGER, answered_at TEXT);
		CREATE TABLE IF NOT EXISTS attempt_answers(id INTEGER PRIMARY KEY AUTOINCREMENT, attempt_id INTEGER, question_id INTEGER, user_answer TEXT, is_correct INTEGER);
		CREATE TABLE IF NOT EXISTS wrong_book(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, question_id INTEGER NOT NULL, wrong_count INTEGER DEFAULT 1, last_wrong_at TEXT, mastered INTEGER DEFAULT 0, UNIQUE(user_id, question_id));
		CREATE TABLE IF NOT EXISTS review_schedule(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, question_id INTEGER NOT NULL, next_review TEXT, interval_days INTEGER DEFAULT 1);
		CREATE TABLE IF NOT EXISTS mastery_states(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, knowledge TEXT NOT NULL, total INTEGER DEFAULT 0, correct INTEGER DEFAULT 0, elo INTEGER DEFAULT 1500, updated_at TEXT, UNIQUE(user_id, knowledge));
		CREATE TABLE IF NOT EXISTS audit_logs(id INTEGER PRIMARY KEY AUTOINCREMENT, user TEXT, action TEXT, detail TEXT, created_at TEXT);
		CREATE TABLE IF NOT EXISTS backups_meta(id INTEGER PRIMARY KEY AUTOINCREMENT, filename TEXT, note TEXT, created_at TEXT);
		CREATE TABLE IF NOT EXISTS quality_scores(question_id INTEGER PRIMARY KEY, total INTEGER DEFAULT 0, correct INTEGER DEFAULT 0, accuracy REAL DEFAULT 0, flag TEXT DEFAULT 'normal', updated_at TEXT);
		CREATE TABLE IF NOT EXISTS paper_templates(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, subject TEXT DEFAULT '', total_count INTEGER DEFAULT 10, rules_json TEXT DEFAULT '{}', created_by TEXT, created_at TEXT);
		CREATE TABLE IF NOT EXISTS exam_appeals(id INTEGER PRIMARY KEY AUTOINCREMENT, session_id INTEGER, user_id INTEGER, question_id INTEGER, reason TEXT DEFAULT '', status TEXT DEFAULT 'pending', created_at TEXT);
		CREATE TABLE IF NOT EXISTS study_plans(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, team TEXT DEFAULT '', target_count INTEGER DEFAULT 0, due_date TEXT, created_by TEXT, created_at TEXT);
		CREATE TABLE IF NOT EXISTS tasks(id INTEGER PRIMARY KEY AUTOINCREMENT, plan_id INTEGER, user_id INTEGER, title TEXT, status TEXT DEFAULT 'pending', created_at TEXT);
		CREATE TABLE IF NOT EXISTS peer_hosts(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT, host TEXT, port INTEGER DEFAULT 8765, token TEXT DEFAULT '', status TEXT DEFAULT 'disabled', created_at TEXT);
		CREATE TABLE IF NOT EXISTS ai_jobs(id INTEGER PRIMARY KEY AUTOINCREMENT, kind TEXT, input_json TEXT DEFAULT '{}', status TEXT DEFAULT 'pending', result_json TEXT DEFAULT '', created_at TEXT);
		CREATE TABLE IF NOT EXISTS review_scores(id INTEGER PRIMARY KEY AUTOINCREMENT, question_id INTEGER, user_id INTEGER, score REAL, comment TEXT DEFAULT '', reviewer TEXT, created_at TEXT);
		CREATE TABLE IF NOT EXISTS team_memberships(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, team TEXT NOT NULL, from_at TEXT, to_at TEXT, is_current INTEGER DEFAULT 1);
		CREATE TABLE IF NOT EXISTS image_pairings(id INTEGER PRIMARY KEY AUTOINCREMENT, job_id INTEGER NOT NULL, asset_id INTEGER, question_id INTEGER, filename TEXT DEFAULT '', confidence REAL DEFAULT 0, status TEXT DEFAULT 'review', reason TEXT DEFAULT '', pending_path TEXT DEFAULT '', created_at TEXT);
		CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY, value TEXT);
		CREATE TABLE IF NOT EXISTS federation_packages(id INTEGER PRIMARY KEY AUTOINCREMENT, host_id INTEGER, direction TEXT DEFAULT 'in', filename TEXT DEFAULT '', sha256 TEXT DEFAULT '', question_count INTEGER DEFAULT 0, status TEXT DEFAULT 'ok', created_by TEXT, created_at TEXT);
		""")
		def _add_col(table, col, ddl):
			try:
				c.execute(f"ALTER TABLE {table} ADD COLUMN {col} {ddl}")
			except Exception:
				pass
		_add_col("questions", "law_version", "TEXT DEFAULT ''")
		_add_col("questions", "classification", "TEXT DEFAULT ''")
		_add_col("questions", "parent_id", "INTEGER")
		_add_col("mastery_states", "recent_total", "INTEGER DEFAULT 0")
		_add_col("mastery_states", "recent_correct", "INTEGER DEFAULT 0")
		_add_col("mastery_states", "last_attempt_at", "TEXT")
		_add_col("mastery_states", "streak_correct", "INTEGER DEFAULT 0")
		_add_col("mastery_states", "streak_wrong", "INTEGER DEFAULT 0")
		_add_col("mastery_states", "target_difficulty", "INTEGER DEFAULT 3")
		_add_col("papers", "rules_json", "TEXT DEFAULT ''")
		_add_col("papers", "template_id", "INTEGER")
		_add_col("users", "active", "INTEGER DEFAULT 1")
		_add_col("questions", "rubric", "TEXT DEFAULT ''")
		_add_col("questions", "max_score", "REAL DEFAULT 10")
		_add_col("review_scores", "attempt_id", "INTEGER")
		_add_col("review_scores", "status", "TEXT DEFAULT 'pending'")
		_add_col("review_scores", "max_score", "REAL DEFAULT 10")
		_add_col("review_scores", "reviewed_at", "TEXT")
		_add_col("study_plans", "knowledge", "TEXT DEFAULT ''")
		_add_col("study_plans", "daily_count", "INTEGER DEFAULT 0")
		_add_col("study_plans", "scope", "TEXT DEFAULT 'team'")
		_add_col("study_plans", "target_user_id", "INTEGER")
		_add_col("tasks", "due_date", "TEXT")
		_add_col("peer_hosts", "last_seen", "TEXT DEFAULT ''")
		_add_col("peer_hosts", "last_error", "TEXT DEFAULT ''")
		_add_col("peer_hosts", "last_count", "INTEGER DEFAULT 0")
		_add_col("backups_meta", "size_bytes", "INTEGER DEFAULT 0")
		_add_col("backups_meta", "status", "TEXT DEFAULT 'ok'")
		_add_col("import_jobs", "pairing_report_json", "TEXT DEFAULT ''")
		_add_col("import_jobs", "pairing_auto", "INTEGER DEFAULT 0")
		_add_col("import_jobs", "pairing_review", "INTEGER DEFAULT 0")
		_add_col("import_jobs", "pairing_manual", "INTEGER DEFAULT 0")
		for _u, _d, _r, _t, _pw in DEMO_USERS:
			_uid = c.execute("SELECT id FROM users WHERE username=?", (_u,)).fetchone()
			if _uid and not c.execute("SELECT id FROM team_memberships WHERE user_id=? AND is_current=1", (_uid["id"],)).fetchone():
				c.execute("INSERT INTO team_memberships(user_id,team,from_at,is_current) VALUES(?,?,?,1)", (_uid["id"], _t, now_iso()))
		for username, display, role, team, pw in DEMO_USERS:
			row = c.execute("SELECT id FROM users WHERE username=?", (username,)).fetchone()
			if not row:
				c.execute("INSERT INTO users(username,display_name,role,team,password_hash,created_at) VALUES(?,?,?,?,?,?)", (username, display, role, team, hash_pw(pw), now_iso()))
		cnt = c.execute("SELECT COUNT(*) n FROM questions").fetchone()["n"]
		if cnt == 0:
			c.execute("INSERT INTO bank_versions(version_no,note,question_count,is_current,created_by,created_at) VALUES(?,?,?,?,?,?)", ("v1.0.0", "初始样题版本（20道通用脱敏演示题）", len(SEED_QUESTIONS), 1, "admin", now_iso()))
			vid = c.execute("SELECT id FROM bank_versions WHERE version_no='v1.0.0'").fetchone()["id"]
			for q in SEED_QUESTIONS:
				c.execute("INSERT INTO questions(type,stem,answer,explanation,subject,difficulty,source,status,version_id,created_by,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)", (q["type"], q["stem"], q["answer"], q["explanation"], q["subject"], q["difficulty"], "系统样题", "published", vid, "admin", now_iso()))
				qid = c.lastrowid
				for i, opt in enumerate(q["options"]):
					c.execute("INSERT INTO question_options(question_id,label,content) VALUES(?,?,?)", (qid, chr(65+i), opt))
				for kn in q["knowledge"]:
					c.execute("INSERT OR IGNORE INTO knowledge_nodes(name,subject) VALUES(?,?)", (kn, q["subject"]))
					kid = c.execute("SELECT id FROM knowledge_nodes WHERE name=?", (kn,)).fetchone()["id"]
					c.execute("INSERT OR IGNORE INTO question_knowledge(question_id,knowledge_id) VALUES(?,?)", (qid, kid))
				c.execute("INSERT INTO bank_version_items(version_id,question_id) VALUES(?,?)", (vid, qid))
			c.execute("INSERT INTO papers(title,subject,question_count,minutes,created_by,created_at) VALUES(?,?,?,?,?,?)", ("阶段考核·通用卷", "全部科目", 20, 30, "admin", now_iso()))
			pid = c.lastrowid
			for i, row in enumerate(c.execute("SELECT id FROM questions ORDER BY id").fetchall()):
				c.execute("INSERT INTO paper_items(paper_id,question_id,sort_order) VALUES(?,?,?)", (pid, row["id"], i))
		conn.commit()
		conn.close()
def audit(user, action, detail=""):
	try:
		conn = get_db()
		with DB_LOCK:
			conn.execute("INSERT INTO audit_logs(user,action,detail,created_at) VALUES(?,?,?,?)", (user, action, detail, now_iso()))
			conn.commit()
			conn.close()
	except Exception:
		pass
def qdict(row):
	return dict(row) if row else None
def get_question_full(conn, qid):
	q = conn.execute("SELECT * FROM questions WHERE id=?", (qid,)).fetchone()
	if not q:
		return None
	d = qdict(q)
	d["options"] = [qdict(r) for r in conn.execute("SELECT * FROM question_options WHERE question_id=? ORDER BY label", (qid,)).fetchall()]
	d["assets"] = [qdict(r) for r in conn.execute("SELECT * FROM question_assets WHERE question_id=?", (qid,)).fetchall()]
	d["knowledge"] = [r["name"] for r in conn.execute("SELECT kn.name FROM knowledge_nodes kn JOIN question_knowledge qk ON qk.knowledge_id=kn.id WHERE qk.question_id=?", (qid,)).fetchall()]
	return d
FSRS_STEPS = [1, 3, 7, 14, 30]
def update_mastery(conn, user_id, knowledge_list, is_correct, difficulty):
	for kn in knowledge_list or ["未分类"]:
		row = conn.execute("SELECT * FROM mastery_states WHERE user_id=? AND knowledge=?", (user_id, kn)).fetchone()
		if not row:
			conn.execute("INSERT INTO mastery_states(user_id,knowledge,total,correct,elo,updated_at) VALUES(?,?,?,?,?,?)", (user_id, kn, 0, 0, 1500, now_iso()))
			row = conn.execute("SELECT * FROM mastery_states WHERE user_id=? AND knowledge=?", (user_id, kn)).fetchone()
		b = 1200 + int(difficulty or 3) * 100
		elo = row["elo"]
		expected = 1.0 / (1.0 + 10 ** ((b - elo) / 400.0))
		actual = 1.0 if is_correct else 0.0
		new_elo = int(round(elo + 32 * (actual - expected)))
		sc = (row["streak_correct"] or 0) + 1 if is_correct else 0
		sw = 0 if is_correct else (row["streak_wrong"] or 0) + 1
		td = 3 + (1 if sc >= 3 else 0) - (1 if sw >= 3 else 0)
		td = max(1, min(5, td))
		conn.execute("UPDATE mastery_states SET total=total+1, correct=correct+?, elo=?, updated_at=?, recent_total=COALESCE(recent_total,0)+1, recent_correct=COALESCE(recent_correct,0)+?, last_attempt_at=?, streak_correct=?, streak_wrong=?, target_difficulty=? WHERE id=?", (1 if is_correct else 0, new_elo, now_iso(), 1 if is_correct else 0, now_iso(), sc, sw, td, row["id"]))
def update_review_schedule(conn, user_id, qid, is_correct):
	row = conn.execute("SELECT * FROM review_schedule WHERE user_id=? AND question_id=?", (user_id, qid)).fetchone()
	cur = row["interval_days"] if row else 1
	if is_correct:
		nxt = FSRS_STEPS[min(FSRS_STEPS.index(cur) + 1, len(FSRS_STEPS) - 1)] if cur in FSRS_STEPS else 3
	else:
		nxt = 1
	next_date = (datetime.now() + timedelta(days=nxt)).strftime("%Y-%m-%d")
	if row:
		conn.execute("UPDATE review_schedule SET next_review=?, interval_days=? WHERE id=?", (next_date, nxt, row["id"]))
	else:
		conn.execute("INSERT INTO review_schedule(user_id,question_id,next_review,interval_days) VALUES(?,?,?,?)", (user_id, qid, next_date, nxt))
def refresh_quality_for(conn, qid):
	r = conn.execute("SELECT COUNT(*) n, COALESCE(SUM(is_correct),0) c FROM attempts WHERE question_id=? AND mode IN ('practice','exam')", (qid,)).fetchone()
	total, correct = r["n"], r["c"]
	acc = round(correct / total, 3) if total else 0
	flag = "normal"
	if total >= 5 and acc < 0.20:
		flag = "suspect_low"
	elif total >= 5 and acc > 0.95:
		flag = "suspect_high"
	conn.execute("INSERT INTO quality_scores(question_id,total,correct,accuracy,flag,updated_at) VALUES(?,?,?,?,?,?) ON CONFLICT(question_id) DO UPDATE SET total=excluded.total, correct=excluded.correct, accuracy=excluded.accuracy, flag=excluded.flag, updated_at=excluded.updated_at", (qid, total, correct, acc, flag, now_iso()))
	return {"question_id": qid, "total": total, "correct": correct, "accuracy": acc, "flag": flag}
def suspect_qids(conn):
	return {r["question_id"] for r in conn.execute("SELECT question_id FROM quality_scores WHERE flag!='normal'").fetchall()}
def streak_days(conn, user_id):
	dates = {r["d"] for r in conn.execute("SELECT DISTINCT substr(answered_at,1,10) d FROM attempts WHERE user_id=?", (user_id,)).fetchall()}
	today = datetime.now().date()
	streak = 0
	d = today
	if d.strftime("%Y-%m-%d") not in dates:
		d = d - timedelta(days=1)
	while d.strftime("%Y-%m-%d") in dates:
		streak += 1
		d = d - timedelta(days=1)
	return streak
def adaptive_profile(conn, user_id):
	total = conn.execute("SELECT COUNT(*) n FROM attempts WHERE user_id=? AND mode IN ('practice','exam')", (user_id,)).fetchone()["n"]
	rows = conn.execute("""SELECT kn.name k, COUNT(*) t, COALESCE(SUM(a.is_correct),0) c, COALESCE(MAX(m.elo),1500) elo, COALESCE(MAX(m.target_difficulty),3) td
		FROM attempts a JOIN question_knowledge qk ON qk.question_id=a.question_id
		JOIN knowledge_nodes kn ON kn.id=qk.knowledge_id
		LEFT JOIN mastery_states m ON m.user_id=a.user_id AND m.knowledge=kn.name
		WHERE a.user_id=? AND a.mode IN ('practice','exam') GROUP BY kn.name""", (user_id,)).fetchall()
	per = []
	for r in rows:
		acc = round(r["c"] / r["t"], 3) if r["t"] else 0
		status = "insufficient" if r["t"] < 5 else ("weak" if acc < 0.60 else ("mastered" if acc > 0.85 and r["t"] >= 10 else "normal"))
		per.append({"knowledge": r["k"], "total": r["t"], "correct": r["c"], "accuracy": acc, "elo": r["elo"], "target_difficulty": r["td"], "status": status})
	weak = [x["knowledge"] for x in per if x["status"] == "weak"]
	mastered = [x["knowledge"] for x in per if x["status"] == "mastered"]
	due = conn.execute("SELECT COUNT(*) n FROM review_schedule WHERE user_id=? AND date(next_review)<=date('now')", (user_id,)).fetchone()["n"]
	cold = total < 20
	if cold:
		ratio = {"weak_pct": 50, "review_pct": 30, "new_pct": 20}
		note = f"样本不足（已答 {total} 题，不足 20 题）：先按默认比例 50/30/20 出题，满 20 题后开始个性化。"
	elif weak:
		ratio = {"weak_pct": 65, "review_pct": 15, "new_pct": 20}
		note = "薄弱类占比已自动提到 65%（最近≥5题且正确率<60%），已掌握类降到 10% 以下，新题保持 20%。"
	else:
		ratio = {"weak_pct": 30, "review_pct": 30, "new_pct": 40}
		note = "暂无明显薄弱类（正确率均≥60% 或样本不足），多给新题保持进度。"
	return {"total_attempts": total, "cold_start": cold, "per_knowledge": per, "weak_knowledge": weak, "mastered_knowledge": mastered, "ratio": ratio, "sample_note": note, "due_count": due, "streak_days": streak_days(conn, user_id)}
def adaptive_pick(conn, user, total):
	prof = adaptive_profile(conn, user["user_id"])
	sus = suspect_qids(conn)
	all_q = [get_question_full(conn, r["id"]) for r in conn.execute("SELECT id FROM questions WHERE status='published' AND type NOT IN ('short','material') ORDER BY id").fetchall()]
	all_q = [q for q in all_q if q["id"] not in sus]
	def pub(q):
		return {"id": q["id"], "type": q["type"], "stem": q["stem"], "subject": q["subject"], "difficulty": q["difficulty"], "knowledge": q["knowledge"], "assets": q["assets"], "options": [{"label": o["label"], "content": o["content"]} for o in q["options"]]}
	target = {x["knowledge"]: x["target_difficulty"] for x in prof["per_knowledge"]}
	def diff_key(q):
		tds = [target.get(k, 3) for k in q["knowledge"]] or [3]
		return min(abs(q["difficulty"] - t) for t in tds)
	weak_q = sorted([q for q in all_q if any(k in q["knowledge"] for k in prof["weak_knowledge"])], key=diff_key)
	due_ids = [r["question_id"] for r in conn.execute("SELECT question_id FROM review_schedule WHERE user_id=? AND date(next_review)<=date('now') ORDER BY next_review", (user["user_id"],)).fetchall()]
	wrong_ids = [r["question_id"] for r in conn.execute("SELECT question_id FROM wrong_book WHERE user_id=? AND mastered=0", (user["user_id"],)).fetchall()]
	# 复习池是用户自己错过的题（含疑似题也不排除，见 pick_questions 同款说明）
	review_all = [get_question_full(conn, qid) for qid in set(due_ids + wrong_ids) if conn.execute("SELECT status FROM questions WHERE id=?", (qid,)).fetchone()[0] == "published"]
	review_q = [q for q in review_all if q["id"] in due_ids or q["id"] in wrong_ids]
	done_ids = [r["question_id"] for r in conn.execute("SELECT DISTINCT question_id FROM attempts WHERE user_id=?", (user["user_id"],)).fetchall()]
	new_q = [q for q in all_q if q["id"] not in done_ids]
	random.shuffle(weak_q); random.shuffle(review_q); random.shuffle(new_q)
	r = prof["ratio"]
	n_w = total * r["weak_pct"] // 100; n_r = total * r["review_pct"] // 100; n_n = total - n_w - n_r
	picked = weak_q[:n_w] + review_q[:n_r] + new_q[:n_n]
	seen = {q["id"] for q in picked}
	rest = [q for q in all_q if q["id"] not in seen]
	random.shuffle(rest)
	picked += rest[:max(0, total - len(picked))]
	return [pub(q) for q in picked[:total]], prof
def plan_progress(conn, plan, user_id):
	"""学习计划进度：自计划创建起，该用户在目标知识点（为空=全部）上已作答的题数（已批阅的简答也算，未批阅的不算）。"""
	target = plan["target_count"] or 0
	created = plan["created_at"] or "2000-01-01"
	kn = plan["knowledge"] or ""
	if kn:
		done = conn.execute("SELECT COUNT(*) n FROM attempts a JOIN question_knowledge qk ON qk.question_id=a.question_id JOIN knowledge_nodes kn ON kn.id=qk.knowledge_id WHERE a.user_id=? AND a.mode IN ('practice','exam') AND a.is_correct IS NOT NULL AND a.answered_at>? AND kn.name=?", (user_id, created, kn)).fetchone()["n"]
	else:
		done = conn.execute("SELECT COUNT(*) n FROM attempts WHERE user_id=? AND mode IN ('practice','exam') AND is_correct IS NOT NULL AND answered_at>?", (user_id, created)).fetchone()["n"]
	pct = round(done / target * 100) if target else 0
	due = plan["due_date"] or ""
	overdue = bool(due and due < datetime.now().strftime("%Y-%m-%d") and pct < 100)
	days_left = None
	if due:
		try:
			days_left = (datetime.strptime(due, "%Y-%m-%d").date() - datetime.now().date()).days
		except Exception:
			days_left = None
	return {"done": done, "target": target, "pct": min(100, pct), "overdue": overdue, "days_left": days_left, "daily_count": plan["daily_count"] or 0}
def check_answer(qtype, correct, user_answer):
	if user_answer is None:
		return False
	ua = str(user_answer).strip().upper().replace("，", ",").replace(" ", "")
	ca = str(correct).strip().upper()
	if qtype == "judge":
		mapping = {"A": "对", "B": "错"}
		ua = mapping.get(ua, ua)
		return ua == ca
	if qtype == "multi":
		return "".join(sorted([c for c in ua if c.isalpha()])) == "".join(sorted([c for c in ca if c.isalpha()]))
	return ua == ca
def pairing_confidence(dist):
	"""图文配对置信度：锚点与目标题相距 dist 行/段。0行=0.97，1行=0.85，2行=0.72，3行=0.62，>=4行=0.45；无锚点=0.40。"""
	if dist is None:
		return 0.40
	if dist <= 0:
		return 0.97
	if dist == 1:
		return 0.85
	if dist == 2:
		return 0.72
	if dist == 3:
		return 0.62
	return 0.45
def pairing_status(conf):
	if conf >= 0.90:
		return "auto"
	if conf >= 0.70:
		return "review"
	return "manual"
def current_version_id(conn):
	r = conn.execute("SELECT id FROM bank_versions WHERE is_current=1 ORDER BY id DESC LIMIT 1").fetchone()
	return r["id"] if r else None
# ---------------- 导入解析（标准库 zipfile + xml） ----------------
NS = {"m": "http://schemas.openxmlformats.org/spreadsheetml/2006/main",
    "r": "http://schemas.openxmlformats.org/officeDocument/2006/relationships",
    "xdr": "http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing",
    "a": "http://schemas.openxmlformats.org/drawingml/2006/main",
    "w": "http://schemas.openxmlformats.org/wordprocessingml/2006/main",
    "wp": "http://schemas.openxmlformats.org/drawingml/2006/wordprocessingDrawing"}
def _col_to_num(col):
    n = 0
    for ch in col:
        n = n * 26 + (ord(ch) - 64)
    return n
def _parse_cell_ref(ref):
    m = re.match(r"([A-Z]+)(\d+)", ref or "")
    return (_col_to_num(m.group(1)), int(m.group(2))) if m else (0, 0)
def parse_xlsx(data):
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
    except Exception as e:
        return [], {}, f"不是有效的 xlsx 文件：{e}"
    names = z.namelist()
    shared = []
    if "xl/sharedStrings.xml" in names:
        try:
            root = ET.fromstring(z.read("xl/sharedStrings.xml"))
            for si in root:
                shared.append("".join(t.text or "" for t in si.iter("{http://schemas.openxmlformats.org/spreadsheetml/2006/main}t")))
        except Exception:
            shared = []
    sheet_name = "xl/worksheets/sheet1.xml"
    for n in names:
        if n.startswith("xl/worksheets/sheet") and n.endswith(".xml"):
            sheet_name = n
            break
    try:
        root = ET.fromstring(z.read(sheet_name))
    except Exception as e:
        return [], {}, f"读取工作表失败：{e}"
    m_ns = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
    rows_raw = {}
    for row_el in root.iter(m_ns + "row"):
        r_attr = row_el.get("r")
        if not r_attr:
            continue
        rno = int(r_attr)
        cells = {}
        for c_el in row_el.findall(m_ns + "c"):
            ref = c_el.get("r") or ""
            col, rnum = _parse_cell_ref(ref)
            t = c_el.get("t")
            v_el = c_el.find(m_ns + "v")
            is_el = c_el.find(m_ns + "is")
            val = ""
            if t == "s" and v_el is not None and v_el.text is not None:
                try:
                    val = shared[int(v_el.text)]
                except Exception:
                    val = ""
            elif is_el is not None:
                val = "".join(x.text or "" for x in is_el.iter(m_ns + "t"))
            elif v_el is not None and v_el.text is not None:
                val = v_el.text
            cells[col] = str(val).strip()
        rows_raw[rno] = cells
    if not rows_raw:
        return [], {}, "工作表为空"
    header_row = None
    header_map = {}
    for rno in sorted(rows_raw):
        for col, v in rows_raw[rno].items():
            if "题干" in v or "题目" in v:
                header_row = rno
                for c2, v2 in rows_raw[rno].items():
                    header_map[c2] = v2
                break
        if header_row:
            break
    if header_row is None:
        return [], {}, "未找到表头行（需包含“题干”列）。请用提供的标准模板。"
    col_for = {}
    for col, name in header_map.items():
        n = name.replace(" ", "")
        if "图片" in n:
            col_for["image_note"] = col
        elif n in ("题干", "题目", "题干内容"):
            col_for["stem"] = col
        elif "题型" in n:
            col_for["type"] = col
        elif n in ("选项A", "A"):
            col_for["A"] = col
        elif n in ("选项B", "B"):
            col_for["B"] = col
        elif n in ("选项C", "C"):
            col_for["C"] = col
        elif n in ("选项D", "D"):
            col_for["D"] = col
        elif n in ("选项E", "E"):
            col_for["E"] = col
        elif "答案" in n:
            col_for["answer"] = col
        elif "解析" in n:
            col_for["explanation"] = col
        elif "科目" in n:
            col_for["subject"] = col
        elif "知识点" in n:
            col_for["knowledge"] = col
        elif "难度" in n:
            col_for["difficulty"] = col
        elif "评分要点" in n:
            col_for["rubric"] = col
        elif "满分" in n:
            col_for["max_score"] = col
        elif "父题" in n:
            col_for["parent_row"] = col
        elif "来源" in n:
            col_for["source"] = col
        elif "图片" in n:
            col_for["image_note"] = col
    if "stem" not in col_for:
        return [], {}, "表头缺少题干列"
    rows = []
    for rno in sorted(rows_raw):
        if rno <= header_row:
            continue
        cells = rows_raw[rno]
        if all(not v for v in cells.values()):
            continue
        d = {"row_no": rno}
        for k, col in col_for.items():
            d[k] = cells.get(col, "")
        for lab in "ABCDE":
            d[lab] = cells.get(col_for.get(lab, -1), "") if lab in col_for else ""
        rows.append(d)
    images_by_row = {}
    try:
        drawing_names = [n for n in names if n.startswith("xl/drawings/drawing") and n.endswith(".xml")]
        for dn in drawing_names:
            rels_name = dn.replace("xl/drawings/", "xl/drawings/_rels/") + ".rels"
            rel_map = {}
            if rels_name in names:
                rroot = ET.fromstring(z.read(rels_name))
                for rel in rroot:
                    rel_map[rel.get("Id")] = rel.get("Target", "")
            droot = ET.fromstring(z.read(dn))
            for anchor in list(droot):
                from_el = anchor.find("xdr:from", NS)
                if from_el is None:
                    continue
                row_el = from_el.find("xdr:row", NS)
                if row_el is None or row_el.text is None:
                    continue
                anchor_row = int(row_el.text) + 1
                blip = anchor.find(".//a:blip", NS)
                if blip is None:
                    continue
                rid = blip.get("{http://schemas.openxmlformats.org/officeDocument/2006/relationships}embed")
                target = rel_map.get(rid, "")
                if not target:
                    continue
                media_name = "xl/media/" + target.split("/")[-1]
                if media_name not in names:
                    continue
                blob = z.read(media_name)
                ext = media_name.split(".")[-1].lower()
                mime = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "gif": "image/gif", "bmp": "image/bmp"}.get(ext, "image/png")
                images_by_row.setdefault(anchor_row, []).append({"filename": target.split("/")[-1], "bytes": blob, "mime": mime, "anchor_row": anchor_row})
    except Exception:
        pass
    return rows, images_by_row, ""
def parse_docx(data):
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
    except Exception as e:
        return [], f"不是有效的 docx 文件：{e}"
    names = z.namelist()
    if "word/document.xml" not in names:
        return [], "docx 缺少 word/document.xml"
    rel_map = {}
    if "word/_rels/document.xml.rels" in names:
        rroot = ET.fromstring(z.read("word/_rels/document.xml.rels"))
        for rel in rroot:
            rel_map[rel.get("Id")] = rel.get("Target", "")
    w_ns = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
    r_ns = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
    a_ns = "{http://schemas.openxmlformats.org/drawingml/2006/main}"
    root = ET.fromstring(z.read("word/document.xml"))
    paras = []
    for pidx, p in enumerate(root.iter(w_ns + "p")):
        text = "".join(t.text or "" for t in p.iter(w_ns + "t"))
        imgs = []
        for blip in p.iter(a_ns + "blip"):
            rid = blip.get(r_ns + "embed")
            target = rel_map.get(rid, "")
            if not target:
                continue
            media_name = target if target.startswith("word/") else "word/" + target.lstrip("/")
            if media_name not in names:
                media_name = "word/media/" + target.split("/")[-1]
            if media_name not in names:
                continue
            blob = z.read(media_name)
            ext = media_name.split(".")[-1].lower()
            mime = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "gif": "image/gif"}.get(ext, "image/png")
            imgs.append({"filename": target.split("/")[-1], "bytes": blob, "mime": mime})
        if text.strip() or imgs:
            paras.append((text.strip(), imgs, pidx))
    q_start = re.compile(r"^(?:第)?(\d+)[\.、．）\)\s]+(.+)$")
    opt_re = re.compile(r"^([A-E])[\.、．）\)\s]+(.+)$")
    ans_re = re.compile(r"^(?:【?答案】?|答案)[:：\s]*(.+)$")
    exp_re = re.compile(r"^(?:【?解析】?|解析)[:：\s]*(.+)$")
    ref_re = re.compile(r"^(?:【?参考答案】?|参考答案)[:：\s]*(.+)$")
    rubric_re = re.compile(r"^(?:【?评分要点】?|评分要点)[:：\s]*(.+)$")
    short_re = re.compile(r"^(?:【?简答题】?|【?材料题】?|简答题|材料题)[:：\s]*(.*)$")
    questions = []
    orphans = []
    cur = None
    cur_start_para = None
    def flush():
        nonlocal cur
        if cur and cur.get("stem"):
            questions.append(cur)
        cur = None
    for text, imgs, pidx in paras:
        m = q_start.match(text)
        if m and len(text) > 3:
            flush()
            cur_start_para = pidx
            cur = {"stem": m.group(2).strip(), "type": "single", "options": {}, "answer": "", "explanation": "", "subject": "", "knowledge": "", "difficulty": "3", "rubric": "", "max_score": 10, "images": [], "row_no": len(questions) + 1}
            sm = short_re.match(cur["stem"])
            if sm:
                cur["stem"] = sm.group(1).strip() or cur["stem"]
                cur["type"] = "material" if "材料" in text[:8] else "short"
            for im in imgs:
                im2 = dict(im); im2["dist"] = 0
                cur["images"].append(im2)
            continue
        if cur is None:
            for im in imgs:
                im2 = dict(im); im2["dist"] = None
                orphans.append(im2)
            continue
        if imgs:
            for im in imgs:
                im2 = dict(im); im2["dist"] = max(0, pidx - (cur_start_para or pidx))
                cur["images"].append(im2)
        rm = ref_re.match(text)
        if rm:
            cur["answer"] = rm.group(1).strip()
            if cur["type"] in ("single", "multi", "judge"):
                cur["type"] = "short"
            continue
        rb = rubric_re.match(text)
        if rb:
            cur["rubric"] = rb.group(1).strip()
            continue
        am = ans_re.match(text)
        if am:
            cur["answer"] = am.group(1).strip()
            continue
        em = exp_re.match(text)
        if em:
            cur["explanation"] = em.group(1).strip()
            continue
        om = opt_re.match(text)
        if om:
            cur["options"][om.group(1)] = om.group(2).strip()
            continue
        if re.search(r"[A-D][\.、]", text) and len(cur["options"]) < 2 and "A" not in cur["options"]:
            parts = re.split(r"(?=[A-E][\.、．])", text)
            for part in parts:
                mm = opt_re.match(part.strip())
                if mm:
                    cur["options"][mm.group(1)] = mm.group(2).strip()
            if cur["options"]:
                continue
        cur["stem"] = (cur["stem"] + " " + text).strip() if cur["stem"] else text
    flush()
    for q in questions:
        if q["type"] in ("short", "material"):
            q["options_list"] = []
            continue
        ans = (q["answer"] or "").strip().upper()
        opts = q["options"]
        if set(opts.keys()) <= {"A", "B"} and set(v for v in opts.values()) <= {"对", "错"}:
            q["type"] = "judge"
        elif len([c for c in ans if c.isalpha()]) >= 2:
            q["type"] = "multi"
        else:
            q["type"] = "single"
        q["options_list"] = [opts.get(lab, "") for lab in sorted(opts.keys())]
    return questions, "", orphans
def normalize_type(raw):
    t = (raw or "").strip()
    if t in ("单选", "单选题", "single", "1"):
        return "single"
    if t in ("多选", "多选题", "multi", "2"):
        return "multi"
    if t in ("判断", "判断题", "judge", "3"):
        return "judge"
    if t in ("简答", "简答题", "short", "4"):
        return "short"
    if t in ("材料", "材料题", "material", "5"):
        return "material"
    if not t:
        return "single"
    return None
def validate_row(d):
    stem = (d.get("stem") or "").strip()
    if not stem:
        return None, "题干为空"
    t = normalize_type(d.get("type", ""))
    if t is None:
        return None, f"题型不识别：{d.get('type')}"
    _t0 = normalize_type(d.get("type", ""))
    if _t0 in ("short", "material"):
        stem = (d.get("stem") or "").strip()
        ref = str(d.get("answer") or "").strip()
        if _t0 == "short" and not ref:
            return None, "简答题缺参考答案"
        try:
            ms = float(str(d.get("max_score") or 10))
        except Exception:
            ms = 10
        if ms <= 0:
            ms = 10
        try:
            diff = int(str(d.get("difficulty") or "3").strip())
        except Exception:
            diff = 3
        if diff < 1 or diff > 5:
            diff = 3
        knowledge = []
        for part in re.split(r"[、，,；;／/]", str(d.get("knowledge") or "")):
            part = part.strip()
            if part:
                knowledge.append(part)
        return {"type": _t0, "stem": stem, "options": [], "answer": ref,
            "explanation": str(d.get("explanation") or "").strip(),
            "rubric": str(d.get("rubric") or "").strip(), "max_score": ms,
            "parent_row": d.get("parent_row"),
            "subject": str(d.get("subject") or "未分类").strip() or "未分类",
            "knowledge": knowledge, "difficulty": diff,
            "source": str(d.get("source") or "导入").strip()}, ""
    if isinstance(d.get("options_list"), list):
        opts = [str(x).strip() for x in d["options_list"]]
    else:
        raw_opts = [str(d.get(lab, "") or "").strip() for lab in "ABCDE"]
        last = -1
        for i, o in enumerate(raw_opts):
            if o:
                last = i
        if last < 0:
            return None, "选项为空"
        opts = raw_opts[:last + 1]
        if t in ("single", "multi") and any(not o for o in opts):
            return None, "选项中间有空缺"
    if t == "judge":
        if not opts:
            opts = ["对", "错"]
        if len(opts) < 2:
            return None, "判断题至少需要 2 个选项（对/错）"
    else:
        if len(opts) < 2:
            return None, f"选项数不足（仅 {len(opts)} 个）"
        if len(opts) > 5:
            return None, "选项数超过 5 个"
    ans_raw = str(d.get("answer") or "").strip().upper().replace("，", ",").replace(" ", "")
    if not ans_raw:
        return None, "缺答案"
    if t == "judge":
        mapping = {"A": "对", "B": "错"}
        ans = mapping.get(ans_raw, ans_raw)
        if ans not in ("对", "错"):
            return None, f"判断题答案越界：{d.get('answer')}（应为 对/错）"
    elif t == "multi":
        letters = [c for c in ans_raw if c.isalpha()]
        if len(letters) < 2:
            return None, "多选题答案至少 2 个选项"
        if any((ord(c) - 65) >= len(opts) for c in letters):
            return None, f"多选题答案越界：{d.get('answer')}（选项仅到 {chr(64 + len(opts))}）"
        ans = "".join(sorted(set(letters)))
    else:
        if len(ans_raw) != 1 or not ans_raw.isalpha():
            return None, f"单选题答案应为单个字母：{d.get('answer')}"
        if (ord(ans_raw) - 65) >= len(opts):
            return None, f"单选题答案越界：{ans_raw}（选项仅到 {chr(64 + len(opts))}）"
        ans = ans_raw
    try:
        diff = int(str(d.get("difficulty") or "3").strip())
    except Exception:
        diff = 3
    if diff < 1 or diff > 5:
        diff = 3
    knowledge = []
    for part in re.split(r"[、，,；;／/]", str(d.get("knowledge") or "")):
        part = part.strip()
        if part:
            knowledge.append(part)
    return {"type": t, "stem": stem, "options": opts, "answer": ans,
        "explanation": str(d.get("explanation") or "").strip(),
        "rubric": str(d.get("rubric") or "").strip(), "max_score": 10,
        "parent_row": d.get("parent_row"),
        "subject": str(d.get("subject") or "未分类").strip() or "未分类",
        "knowledge": knowledge, "difficulty": diff,
        "source": str(d.get("source") or "导入").strip()}, ""
def save_asset(conn, question_id, blob, filename, mime, option_label=None):
    h = hashlib.sha256(blob).hexdigest()[:16]
    ext = (filename.split(".")[-1].lower() if "." in filename else "png")
    if ext not in ("png", "jpg", "jpeg", "gif", "bmp"):
        ext = "png"
    fname = f"{h}.{ext}"
    path = os.path.join(ASSETS_DIR, fname)
    if not os.path.exists(path):
        with open(path, "wb") as f:
            f.write(blob)
    cur = conn.execute("INSERT INTO question_assets(question_id,option_label,filename,mime,path,created_at) VALUES(?,?,?,?,?,?)", (question_id, option_label, filename, mime, fname, now_iso()))
    return cur.lastrowid

# ---------------- PDF 文字型导入（纯标准库，无 PyMuPDF） ----------------
# 只做文字型 PDF：抽文字块 + 图片 + 坐标切题。扫描型（无文字层）不硬做假识别，
# 直接返回明确错误。中文能否读出取决于 PDF 是否内嵌 ToUnicode（Word/WPS 导出
# 的 PDF 一般都有）；无 ToUnicode 的 CID 字体会判为“无法提取有效文字”，同样拒识。
def _pdf_stream_bytes(obj):
	"""取一个 PDF 对象里的 stream 原始字节；FlateDecode 则解压，其余原样返回。"""
	m = re.search(rb"stream\r?\n", obj)
	if not m:
		return b""
	raw = obj[m.end():]
	end = raw.rfind(b"endstream")
	if end >= 0:
		raw = raw[:end]
	if b"FlateDecode" in obj[:m.start()]:
		try:
			return zlib.decompress(raw.strip(b"\r\n"))
		except Exception:
			try:
				return zlib.decompressobj().decompress(raw.strip(b"\r\n"))
			except Exception:
				return b""
	return raw
def _pdf_objects(data):
	objs = {}
	for m in re.finditer(rb"(\d+)\s+\d+\s+obj\b(.*?)endobj", data, re.S):
		try:
			objs[int(m.group(1))] = m.group(2)
		except Exception:
			pass
	return objs
def _pdf_cmap_from_stream(stream):
	"""解析一段 ToUnicode CMap 流（只在 beginbfchar / beginbfrange 段内匹配，避免串段误读），返回 {编码: 字符}。"""
	cmap = {}
	if not stream:
		return cmap
	for sec in re.findall(rb"beginbfchar(.*?)endbfchar", stream, re.S):
		for m in re.finditer(rb"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>", sec):
			try:
				code = int(m.group(1), 16)
				ch = bytes.fromhex(m.group(2).decode()).decode("utf-16-be", "ignore")
				if ch:
					cmap[code] = ch
			except Exception:
				pass
	for sec in re.findall(rb"beginbfrange(.*?)endbfrange", stream, re.S):
		for m in re.finditer(rb"<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>\s*<([0-9A-Fa-f]+)>", sec):
			try:
				lo, hi = int(m.group(1), 16), int(m.group(2), 16)
				base = bytes.fromhex(m.group(3).decode()).decode("utf-16-be", "ignore")
				if not base or hi - lo > 500:
					continue
				for i in range(hi - lo + 1):
					cmap[lo + i] = chr(ord(base) + i)
			except Exception:
				pass
	return cmap
def _pdf_resources_body(objs, page_body):
	"""页面对象里的 /Resources 常是间接引用（/Resources 57 0 R），跟引用取真正的资源字典。"""
	rm = re.search(rb"/Resources\s+(\d+)\s+\d+\s+R", page_body)
	if rm and int(rm.group(1)) in objs:
		return objs[int(rm.group(1))]
	return page_body
def _pdf_font_cmaps(objs, page_body):
	"""按页面 Resources 的 /Font 字典，给每个字体名建自己的 ToUnicode 映射（不同字体编码会冲突，不能全局合并）。"""
	font_cmaps = {}
	res = _pdf_resources_body(objs, page_body)
	fontdict = None
	m = re.search(rb"/Font\s*<<([^>]*)>>", res, re.S)
	if m:
		fontdict = m.group(1)
	else:
		m2 = re.search(rb"/Font\s+(\d+)\s+\d+\s+R", res)
		if m2 and int(m2.group(1)) in objs:
			fontdict = objs[int(m2.group(1))]
	if fontdict is None:
		return font_cmaps
	for name, ref in re.findall(rb"/(\w+)\s+(\d+)\s+\d+\s+R", fontdict):
		fobj = objs.get(int(ref), b"")
		tm = re.search(rb"/ToUnicode\s+(\d+)\s+\d+\s+R", fobj)
		if tm and int(tm.group(1)) in objs:
			font_cmaps[name.decode("latin-1", "ignore")] = _pdf_cmap_from_stream(_pdf_stream_bytes(objs[int(tm.group(1))]))
	return font_cmaps
def _pdf_unescape_literal(bs):
	out = bytearray()
	i = 0
	while i < len(bs):
		c = bs[i]
		if c == 0x5C and i + 1 < len(bs):
			n = bs[i + 1]
			if n in b"nrtbf":
				out.append({ord("n"): 10, ord("r"): 13, ord("t"): 9, ord("b"): 8, ord("f"): 12}[n])
				i += 2
			elif 48 <= n <= 55:
				j = i + 1
				oct_digits = b""
				while j < len(bs) and len(oct_digits) < 3 and 48 <= bs[j] <= 55:
					oct_digits += bytes([bs[j]])
					j += 1
				out.append(int(oct_digits, 8) & 0xFF)
				i = j
			else:
				out.append(n)
				i += 2
		else:
			out.append(c)
			i += 1
	return bytes(out)
def _pdf_decode_text(bs, cmap):
	if bs[:2] == b"\xfe\xff":
		try:
			return bs[2:].decode("utf-16-be")
		except Exception:
			pass
	if cmap and bs:
		# 1 字节编码（LibreOffice 子集字体常用）：逐字节查表
		if max(cmap) < 256:
			chars, mapped = [], 0
			for b in bs:
				ch = cmap.get(b)
				if ch:
					mapped += 1
					chars.append(ch)
			if mapped / max(1, len(bs)) >= 0.5:
				return "".join(chars)
		# 2 字节编码
		if len(bs) >= 2:
			chars, mapped, total = [], 0, 0
			for i in range(0, len(bs) - 1, 2):
				code = (bs[i] << 8) | bs[i + 1]
				total += 1
				ch = cmap.get(code)
				if ch:
					mapped += 1
					chars.append(ch)
			if total and mapped / total >= 0.5:
				return "".join(chars)
	try:
		return bs.decode("cp1252")
	except Exception:
		return bs.decode("latin-1", "ignore")
def _pdf_text_items(stream, font_cmaps):
	"""从一个 content stream 里抽文字：返回 [(x, y, 文本)]。跟 Tf（当前字体决定用哪套 ToUnicode）、Tm/Td/TJ/Tj。
	正则分组：1=十六进制 Tj，2=TJ 数组，3-8=Tm 六个数（e=7，f=8），9-10=Td，11=Tf 字体名。"""
	items = []
	x, y = 0.0, 0.0
	cmap = {}
	pat = re.compile(rb"\((?:\\.|[^()\\])*\)\s*Tj|<([0-9A-Fa-f\s]+)>\s*Tj|\[((?:[^\]])*)\]\s*TJ|(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s+Tm|(-?[\d.]+)\s+(-?[\d.]+)\s+TD?|/(F\w+)\s+[\d.]+\s+Tf|T\*|\bBT\b")
	for m in pat.finditer(stream):
		whole = m.group(0)
		if whole == b"BT":
			x, y = 0.0, 0.0
		elif m.group(11):
			cmap = font_cmaps.get(m.group(11).decode("latin-1", "ignore"), {})
		elif whole.endswith(b"Tm"):
			try:
				x, y = float(m.group(7)), float(m.group(8))
			except Exception:
				pass
		elif whole.endswith(b"Tj") and not whole.startswith(b"["):
			if whole.startswith(b"("):
				raw = whole[1:whole.rfind(b")")]
				txt = _pdf_decode_text(_pdf_unescape_literal(raw), cmap)
			else:
				try:
					raw = bytes.fromhex(m.group(1).decode())
				except Exception:
					raw = b""
				txt = _pdf_decode_text(raw, cmap)
			if txt.strip():
				items.append((x, y, txt))
		elif whole.endswith(b"TJ"):
			inner = m.group(2) or b""
			parts = []
			for sm in re.finditer(rb"\((?:\\.|[^()\\])*\)|<([0-9A-Fa-f\s]+)>", inner):
				if sm.group(0).startswith(b"("):
					raw = sm.group(0)[1:-1]
					parts.append(_pdf_decode_text(_pdf_unescape_literal(raw), cmap))
				else:
					try:
						parts.append(_pdf_decode_text(bytes.fromhex(sm.group(1).decode()), cmap))
					except Exception:
						pass
			txt = "".join(parts)
			if txt.strip():
				items.append((x, y, txt))
		elif whole == b"T*":
			y -= 14.0
		elif re.search(rb"TD?$", whole):
			try:
				x += float(m.group(9))
				y += float(m.group(10))
			except Exception:
				pass
	return items
def _pdf_lines(items):
	"""把 (x,y,文本) 按页内行分组：同页 y 相差 <=4pt 算一行，按 x 排序拼行。"""
	lines = []
	for (x, y, txt) in sorted(items, key=lambda t: (-t[1], t[0])):
		placed = False
		for ln in lines:
			if abs(ln["y"] - y) <= 4:
				ln["parts"].append((x, txt))
				placed = True
				break
		if not placed:
			lines.append({"y": y, "parts": [(x, txt)]})
	out = []
	for ln in sorted(lines, key=lambda l: -l["y"]):
		parts = sorted(ln["parts"], key=lambda p: p[0])
		text = "".join(p[1] for p in parts)
		# 选项之间常无空格：行内 "A.xxxB.yyy" 靠切题正则处理；这里只做轻度拼接
		out.append({"y": ln["y"], "text": text.strip()})
	return [l for l in out if l["text"]]
def _pdf_cut_questions(lines):
	"""按题号/选项/答案/解析/参考答案/评分要点把行切成题（与 docx 同一套正则）。"""
	q_start = re.compile(r"^(?:第)?(\d+)[\.、．）\)\s]+(.+)$")
	opt_re = re.compile(r"^([A-E])[\.、．）\)\s]+(.+)$")
	ans_re = re.compile(r"^(?:【?答案】?|答案)[:：\s]*(.+)$")
	exp_re = re.compile(r"^(?:【?解析】?|解析)[:：\s]*(.+)$")
	ref_re = re.compile(r"^(?:【?参考答案】?|参考答案)[:：\s]*(.+)$")
	rubric_re = re.compile(r"^(?:【?评分要点】?|评分要点)[:：\s]*(.+)$")
	questions, cur = [], None
	def flush():
		nonlocal cur
		if cur and cur.get("stem"):
			questions.append(cur)
		cur = None
	for ln in lines:
		text, y = ln["text"], ln["y"]
		m = q_start.match(text)
		if m and len(text) > 3:
			flush()
			cur = {"stem": m.group(2).strip(), "type": "single", "options": {}, "answer": "", "explanation": "", "subject": "", "knowledge": "", "difficulty": "3", "rubric": "", "max_score": 10, "images": [], "row_no": len(questions) + 1, "_y": y}
			continue
		if cur is None:
			continue
		if ref_re.match(text):
			cur["answer"] = ref_re.match(text).group(1).strip()
			cur["type"] = "short"
			continue
		if rubric_re.match(text):
			cur["rubric"] = rubric_re.match(text).group(1).strip()
			continue
		if ans_re.match(text):
			cur["answer"] = ans_re.match(text).group(1).strip()
			continue
		if exp_re.match(text):
			cur["explanation"] = exp_re.match(text).group(1).strip()
			continue
		if opt_re.match(text):
			cur["options"][opt_re.match(text).group(1)] = opt_re.match(text).group(2).strip()
			continue
		# 行内连写选项：A.xxx B.yyy C.zzz
		if re.search(r"[A-E][\.、]", text) and len(cur["options"]) < 2:
			parts = re.split(r"(?=[A-E][\.、．])", text)
			got = False
			for part in parts:
				mm = opt_re.match(part.strip())
				if mm:
					cur["options"][mm.group(1)] = mm.group(2).strip()
					got = True
			if got:
				continue
		cur["stem"] = (cur["stem"] + " " + text).strip() if cur["stem"] else text
	flush()
	for q in questions:
		if q["type"] == "short":
			q["options_list"] = []
			continue
		ans = (q["answer"] or "").strip().upper()
		opts = q["options"]
		if set(opts.keys()) <= {"A", "B"} and set(v for v in opts.values()) <= {"对", "错"}:
			q["type"] = "judge"
		elif len([c for c in ans if c.isalpha()]) >= 2:
			q["type"] = "multi"
		else:
			q["type"] = "single"
		q["options_list"] = [opts.get(lab, "") for lab in sorted(opts.keys())]
	return questions
def _pdf_raw_to_png(raw, width, height, colorspace, predictor=1):
	"""把 PDF 里 Flate 解压后的原始图片数据（8 位 DeviceRGB/DeviceGray，无预测器或 PNG 预测器）手写成 PNG（标准库）。失败返回 None。"""
	try:
		if colorspace == "DeviceRGB":
			bpp, ctype = 3, 2
		elif colorspace == "DeviceGray":
			bpp, ctype = 1, 0
		else:
			return None
		stride = width * bpp
		if predictor is not None and predictor >= 10:
			# 每行开头 1 字节是 PNG 滤波器类型，需按行反滤波
			rows, pos = [], 0
			prev = bytearray(stride)
			for _ in range(height):
				if pos >= len(raw):
					return None
				ft = raw[pos]
				pos += 1
				row = bytearray(raw[pos:pos + stride])
				pos += stride
				if len(row) < stride:
					return None
				if ft == 1:
					for i in range(bpp, stride):
						row[i] = (row[i] + row[i - bpp]) & 0xFF
				elif ft == 2:
					for i in range(stride):
						row[i] = (row[i] + prev[i]) & 0xFF
				elif ft == 3:
					for i in range(stride):
						left = row[i - bpp] if i >= bpp else 0
						row[i] = (row[i] + ((left + prev[i]) >> 1)) & 0xFF
				elif ft == 4:
					for i in range(stride):
						a = row[i - bpp] if i >= bpp else 0
						b = prev[i]
						c = prev[i - bpp] if i >= bpp else 0
						p = a + b - c
						pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
						pr = a if (pa <= pb and pa <= pc) else (b if pb <= pc else c)
						row[i] = (row[i] + pr) & 0xFF
				elif ft != 0:
					return None
				rows.append(bytes(row))
				prev = row
			raw_rows = rows
		else:
			if len(raw) < stride * height:
				return None
			raw_rows = [raw[i * stride:(i + 1) * stride] for i in range(height)]
		png_data = b"".join(b"\x00" + r for r in raw_rows)
		comp = zlib.compress(png_data)
		def chunk(typ, payload):
			c = typ + payload
			return len(payload).to_bytes(4, "big") + c + (zlib.crc32(c) & 0xFFFFFFFF).to_bytes(4, "big")
		ihdr = width.to_bytes(4, "big") + height.to_bytes(4, "big") + bytes([8, ctype, 0, 0, 0])
		return b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr) + chunk(b"IDAT", comp) + chunk(b"IEND", b"")
	except Exception:
		return None
def parse_pdf(data):
	"""返回 (questions, info, err)。questions 与 docx 同结构；info 含 kind/pages/text_chars/images。
	kind=text 才能导入；scanned/unreadable 返回 err，不造假识别。"""
	if not data or data[:5] != b"%PDF-":
		return [], {"kind": "unreadable", "pages": 0, "text_chars": 0, "images": 0, "readable_ratio": 0}, "不是有效的 PDF 文件"
	objs = _pdf_objects(data)
	# 找页面对象（/Type /Page，不含 /Pages），按对象号排序
	pages = []
	for num in sorted(objs):
		body = objs[num]
		if b"/Type" in body and re.search(rb"/Type\s*/Page[^s]", body):
			pages.append(num)
	all_lines, images, scanned_hits = [], [], 0
	for pno in pages:
		body = objs[pno]
		content_nums = []
		m = re.search(rb"/Contents\s+(\d+)\s+\d+\s+R", body)
		if m:
			content_nums = [int(m.group(1))]
		else:
			m2 = re.search(rb"/Contents\s*\[([^\]]*)\]", body)
			if m2:
				content_nums = [int(x) for x in re.findall(rb"(\d+)\s+\d+\s+R", m2.group(1))]
		stream = b""
		for cn in content_nums:
			if cn in objs:
				stream += _pdf_stream_bytes(objs[cn]) + b"\n"
		font_cmaps = _pdf_font_cmaps(objs, body)
		items = _pdf_text_items(stream, font_cmaps)
		lines = _pdf_lines(items)
		for ln in lines:
			ln["_page"] = pno
		all_lines.extend(lines)
		# 图片：页面 Resources 里的 XObject 指向的 Image 对象（只取 DCTDecode 的 JPEG）
		xobj = {}
		rm = re.search(rb"/XObject\s*<<([^>]*)>>", _pdf_resources_body(objs, body), re.S)
		if rm:
			for nm, ref in re.findall(rb"/(\w+)\s+(\d+)\s+\d+\s+R", rm.group(1)):
				xobj[nm.decode("latin-1", "ignore")] = int(ref)
		for name, ref in xobj.items():
			iobj = objs.get(ref, b"")
			if b"/Subtype" not in iobj or b"/Image" not in iobj:
				continue
			if b"/DCTDecode" in iobj:
				blob = _pdf_stream_bytes(iobj)
				if blob[:2] == b"\xff\xd8":
					images.append({"name": name, "bytes": blob, "mime": "image/jpeg", "filename": name + ".jpg", "page": pno})
			elif b"/FlateDecode" in iobj:
				wm = re.search(rb"/Width\s+(\d+)", iobj)
				hm = re.search(rb"/Height\s+(\d+)", iobj)
				bm = re.search(rb"/BitsPerComponent\s+(\d+)", iobj)
				cs = "DeviceRGB" if b"/DeviceRGB" in iobj else ("DeviceGray" if b"/DeviceGray" in iobj else "")
				pm = re.search(rb"/DecodeParms\s*<<[^>]*?/Predictor\s+(\d+)", iobj, re.S)
				pred = int(pm.group(1)) if pm else 1
				if wm and hm and bm and int(bm.group(1)) == 8 and cs:
					png = _pdf_raw_to_png(_pdf_stream_bytes(iobj), int(wm.group(1)), int(hm.group(1)), cs, pred)
					if png:
						images.append({"name": name, "bytes": png, "mime": "image/png", "filename": name + ".png", "page": pno})
					else:
						scanned_hits += 1
				else:
					scanned_hits += 1
			else:
				scanned_hits += 1
		# 图片在内容流里的位置（cm 矩阵 + Do）
		for m in re.finditer(rb"(-?[\d.]+)\s+0\s+0\s+(-?[\d.]+)\s+(-?[\d.]+)\s+(-?[\d.]+)\s+cm\s*/(\w+)\s+Do", stream):
			for im in images:
				if im["name"] == m.group(5).decode("latin-1", "ignore") and "y" not in im:
					im["y"] = float(m.group(4))
	questions = _pdf_cut_questions(all_lines)
	text_chars = sum(len(ln["text"]) for ln in all_lines)
	total_chars = max(1, text_chars)
	cjk = sum(1 for ln in all_lines for ch in ln["text"] if "\u4e00" <= ch <= "\u9fff")
	alnum = sum(1 for ln in all_lines for ch in ln["text"] if ch.isalnum() and not ("\u4e00" <= ch <= "\u9fff"))
	readable = (cjk + alnum) / total_chars
	info = {"kind": "text", "pages": len(pages), "text_chars": text_chars, "images": len(images), "images_skipped": scanned_hits, "readable_ratio": round(readable, 2)}
	if not pages:
		info["kind"] = "unreadable"
		return [], info, "该 PDF 无法提取有效文字（可能是扫描型、无文字层，或字体未内嵌 ToUnicode），暂不支持自动识别；请改用 Word/Excel 导入，或等 OCR 功能上线后再试。不要硬做假识别。"
	if text_chars < 20 and images:
		info["kind"] = "scanned"
		return [], info, "该 PDF 是扫描型（图片型、无文字层），暂不支持自动识别；扫描识别需本地 OCR，目前为后置功能。请改用 Word/Excel 导入。"
	if text_chars < 20 or readable < 0.5:
		info["kind"] = "unreadable"
		return [], info, "该 PDF 无法提取有效文字（可能是扫描型、无文字层，或字体未内嵌 ToUnicode），暂不支持自动识别；请改用 Word/Excel 导入，或等 OCR 功能上线后再试。不要硬做假识别。"
	if text_chars < 30 * max(1, len(pages)) and images:
		info["kind"] = "scanned"
		return [], info, "该 PDF 是扫描型（图片型、无文字层），暂不支持自动识别；扫描识别需本地 OCR，目前为后置功能。请改用 Word/Excel 导入。"
	# 图片按 y 坐标挂到最近的题干上，换算成 dist 档（<20pt=0，<60=1，<150=2，<300=3，否则 4）
	for im in images:
		if "y" not in im or not questions:
			im["dist"] = None
			continue
		best, best_dy = None, None
		for q in questions:
			dy = abs(im["y"] - q.get("_y", 0))
			if best_dy is None or dy < best_dy:
				best, best_dy = q, dy
		if best_dy is None:
			im["dist"] = None
		elif best_dy < 20:
			im["dist"] = 0
		elif best_dy < 60:
			im["dist"] = 1
		elif best_dy < 150:
			im["dist"] = 2
		elif best_dy < 300:
			im["dist"] = 3
		else:
			im["dist"] = 4
		best["images"].append({"filename": im["filename"], "bytes": im["bytes"], "mime": im["mime"], "dist": im["dist"]})
	for q in questions:
		q.pop("_y", None)
	return questions, info, ""

# ---------------- HTTP 层 ----------------
def parse_multipart(body, boundary):
	out = {}
	parts = body.split(b"--" + boundary)
	for part in parts:
		if not part or part in (b"--\r\n", b"--", b"\r\n"):
			continue
		if b"\r\n\r\n" not in part:
			continue
		head, payload = part.split(b"\r\n\r\n", 1)
		if payload.endswith(b"\r\n"):
			payload = payload[:-2]
		if payload.endswith(b"--"):
			payload = payload[:-2]
		m = re.search(r'name="([^"]+)"(?:;\s*filename="([^"]*)")?', head.decode("utf-8", "ignore"))
		if not m:
			continue
		name, filename = m.group(1), m.group(2)
		if filename:
			out[name] = (filename, payload)
		else:
			out[name] = payload.decode("utf-8", "ignore")
	return out
class Handler(BaseHTTPRequestHandler):
	def log_message(self, fmt, *args):
		pass
	def send_json(self, obj, status=200, extra_headers=None):
		data = json.dumps(obj, ensure_ascii=False).encode()
		self.send_response(status)
		self.send_header("Content-Type", "application/json; charset=utf-8")
		self.send_header("Content-Length", str(len(data)))
		if extra_headers:
			for k, v in extra_headers.items():
				self.send_header(k, v)
		self.end_headers()
		self.wfile.write(data)
	def send_html(self, html, status=200, extra_headers=None):
		data = html.encode() if isinstance(html, str) else html
		self.send_response(status)
		self.send_header("Content-Type", "text/html; charset=utf-8")
		self.send_header("Content-Length", str(len(data)))
		if extra_headers:
			for k, v in extra_headers.items():
				self.send_header(k, v)
		self.end_headers()
		self.wfile.write(data)
	def send_text(self, text, ctype="text/plain; charset=utf-8", status=200):
		data = text.encode()
		self.send_response(status)
		self.send_header("Content-Type", ctype)
		self.send_header("Content-Length", str(len(data)))
		self.end_headers()
		self.wfile.write(data)
	def read_body(self):
		n = int(self.headers.get("Content-Length") or 0)
		return self.rfile.read(n) if n else b""
	def read_json(self):
		try:
			return json.loads(self.read_body().decode() or "{}")
		except Exception:
			return {}
	def read_form(self):
		body = self.read_body().decode("utf-8", "ignore")
		return {k: v[0] for k, v in parse_qs(body).items()}
	def get_user(self):
		cookie = self.headers.get("Cookie") or ""
		m = re.search(r"token=([A-Za-z0-9_\-]+)", cookie)
		if not m:
			return None
		s = SESSIONS.get(m.group(1))
		if not s or time.time() > s["exp"]:
			return None
		return s
	def need_user(self):
		u = self.get_user()
		if not u:
			self.send_json({"ok": False, "error": "未登录"}, 401)
			return None
		return u
	def serve_static(self, path):
		safe = os.path.normpath(os.path.join(STATIC_BASE, "static", path.lstrip("/")))
		if not safe.startswith(os.path.join(STATIC_BASE, "static")) or not os.path.isfile(safe):
			self.send_text("404", status=404)
			return
		ext = os.path.splitext(safe)[1].lower()
		ctype = {".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "application/javascript; charset=utf-8", ".png": "image/png"}.get(ext, "application/octet-stream")
		with open(safe, "rb") as f:
			data = f.read()
		self.send_response(200)
		self.send_header("Content-Type", ctype)
		self.send_header("Content-Length", str(len(data)))
		self.end_headers()
		self.wfile.write(data)
	def do_GET(self):
		try:
			self._handle_get()
		except BrokenPipeError:
			pass
		except Exception as e:
			try:
				self.send_json({"ok": False, "error": f"服务端异常：{e}"}, 500)
			except Exception:
				pass

	def _handle_get(self):
		u = urlparse(self.path)
		path, qs = u.path, {k: v[0] for k, v in parse_qs(u.query).items()}
		if path == "/" or path == "/index.html":
			return self.serve_static("index.html")
		if path.startswith("/static/"):
			return self.serve_static(path[len("/static/"):])
		if path.startswith("/assets/"):
			fname = os.path.basename(unquote(path[len("/assets/"):]))
			fpath = os.path.join(ASSETS_DIR, fname)
			if not os.path.isfile(fpath):
				self.send_text("图片不存在", status=404)
				return
			with open(fpath, "rb") as f:
				data = f.read()
			ext = fname.split(".")[-1].lower()
			ctype = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "gif": "image/gif"}.get(ext, "application/octet-stream")
			self.send_response(200)
			self.send_header("Content-Type", ctype)
			self.send_header("Content-Length", str(len(data)))
			self.end_headers()
			self.wfile.write(data)
			return
		if path == "/showcase.html":
			fpath = os.path.join(STATIC_BASE, "showcase.html")
			if not os.path.isfile(fpath):
				self.send_text("404", status=404)
				return
			with open(fpath, "rb") as f:
				data = f.read()
			self.send_response(200)
			self.send_header("Content-Type", "text/html; charset=utf-8")
			self.send_header("Content-Length", str(len(data)))
			self.end_headers()
			self.wfile.write(data)
			return
		if path == "/lite":
			return self.lite_home()
		if path == "/lite/practice":
			return self.lite_practice(qs)
		if path == "/lite/report":
			return self.lite_report()
		if path == "/lite/plans":
			return self.lite_plans()
		if path == "/api/me":
			user = self.get_user()
			return self.send_json({"ok": True, "user": user} if user else {"ok": False, "user": None})
		if path == "/api/adaptive":
			user = self.need_user()
			if not user:
				return
			conn = get_db()
			prof = adaptive_profile(conn, user["user_id"])
			conn.close()
			return self.send_json({"ok": True, "adaptive": prof})
		if path == "/api/admin/overview":
			user = self.need_user()
			if not user:
				return
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可见"}, 403)
			return self.send_json({"ok": True, "overview": self.admin_overview(user)})
		if path == "/api/admin/teams":
			user = self.need_user()
			if not user:
				return
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可见"}, 403)
			return self.send_json({"ok": True, "teams": self.admin_overview(user)["teams"], "heatmap": self.admin_overview(user)["heatmap"]})
		if path.startswith("/api/admin/user/"):
			user = self.need_user()
			if not user:
				return
			try:
				uid = int(path.split("/")[-1])
			except Exception:
				return self.send_json({"ok": False, "error": "用户不存在"}, 404)
			if user["role"] not in ("admin", "instructor") and uid != user["user_id"]:
				return self.send_json({"ok": False, "error": "只能看自己的明细"}, 403)
			audit(user["username"], "view_user_detail", f"查看用户 {uid} 的个人明细")
			conn = get_db()
			rep = self.report_for(uid, conn)
			conn.close()
			return self.send_json({"ok": True, "report": rep})
		if path == "/api/quality":
			user = self.need_user()
			if not user:
				return
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可见"}, 403)
			conn = get_db()
			rows = []
			for r in conn.execute("SELECT qs.*, q.stem, q.subject FROM quality_scores qs JOIN questions q ON q.id=qs.question_id ORDER BY qs.accuracy ASC").fetchall():
				rows.append({"question_id": r["question_id"], "stem": r["stem"], "subject": r["subject"], "total": r["total"], "correct": r["correct"], "accuracy": r["accuracy"], "flag": r["flag"]})
			conn.close()
			return self.send_json({"ok": True, "quality": rows})
		if path == "/api/essay/questions":
			user = self.need_user()
			if not user:
				return
			qs_list = self.pick_questions(user, "essay", 50)
			return self.send_json({"ok": True, "questions": qs_list})
		if path == "/api/essay/queue":
			user = self.need_user()
			if not user:
				return
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可批阅"}, 403)
			conn = get_db()
			rows = []
			for r in conn.execute("SELECT rs.*, q.stem, q.answer AS reference_answer, q.rubric, u.display_name, u.team FROM review_scores rs JOIN questions q ON q.id=rs.question_id JOIN users u ON u.id=rs.user_id WHERE rs.status='pending' ORDER BY rs.created_at").fetchall():
				rows.append(qdict(r))
			conn.close()
			return self.send_json({"ok": True, "queue": rows})
		if path == "/api/essay/mine":
			user = self.need_user()
			if not user:
				return
			conn = get_db()
			rows = []
			for r in conn.execute("SELECT rs.*, q.stem FROM review_scores rs JOIN questions q ON q.id=rs.question_id WHERE rs.user_id=? ORDER BY rs.created_at DESC LIMIT 50", (user["user_id"],)).fetchall():
				rows.append(qdict(r))
			conn.close()
			return self.send_json({"ok": True, "submissions": rows})
		if path == "/api/plans":
			user = self.need_user()
			if not user:
				return
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可看计划"}, 403)
			conn = get_db()
			out = []
			for pl in conn.execute("SELECT * FROM study_plans ORDER BY id DESC").fetchall():
				uids = [r["user_id"] for r in conn.execute("SELECT user_id FROM tasks WHERE plan_id=?", (pl["id"],)).fetchall()]
				pcts = [plan_progress(conn, pl, uid)["pct"] for uid in uids]
				out.append({"id": pl["id"], "title": pl["title"], "team": pl["team"], "knowledge": pl["knowledge"], "target_count": pl["target_count"], "daily_count": pl["daily_count"], "due_date": pl["due_date"], "scope": pl["scope"], "created_by": pl["created_by"], "created_at": pl["created_at"], "assigned": len(uids), "done_count": sum(1 for p in pcts if p >= 100), "avg_pct": round(sum(pcts) / len(pcts)) if pcts else 0})
			conn.close()
			return self.send_json({"ok": True, "plans": out})
		if path == "/api/plans/me":
			user = self.need_user()
			if not user:
				return
			conn = get_db()
			out = []
			for pl in conn.execute("SELECT sp.* FROM study_plans sp JOIN tasks t ON t.plan_id=sp.id WHERE t.user_id=? ORDER BY sp.due_date", (user["user_id"],)).fetchall():
				p = plan_progress(conn, pl, user["user_id"])
				if p["pct"] >= 100:
					conn.execute("UPDATE tasks SET status='done' WHERE plan_id=? AND user_id=?", (pl["id"], user["user_id"]))
				out.append({"id": pl["id"], "title": pl["title"], "knowledge": pl["knowledge"], "due_date": pl["due_date"], "done": p["done"], "target": p["target"], "pct": p["pct"], "overdue": p["overdue"], "days_left": p["days_left"], "daily_count": p["daily_count"]})
			conn.commit()
			conn.close()
			return self.send_json({"ok": True, "plans": out})
		if path == "/api/templates":
			user = self.need_user()
			if not user:
				return
			conn = get_db()
			rows = [qdict(r) for r in conn.execute("SELECT * FROM paper_templates ORDER BY id DESC").fetchall()]
			conn.close()
			return self.send_json({"ok": True, "templates": rows})
		if path.startswith("/api/templates/"):
			user = self.need_user()
			if not user:
				return
			tid = path.split("/")[-1]
			conn = get_db()
			row = conn.execute("SELECT * FROM paper_templates WHERE id=?", (tid,)).fetchone()
			conn.close()
			if not row:
				return self.send_json({"ok": False, "error": "模板不存在"}, 404)
			return self.send_json({"ok": True, "template": qdict(row)})
		if path == "/api/federation/catalog":
			# 对方主机拉目录用：只认联邦令牌，不认登录态；只返回题库目录，不返回成绩/密码。
			if not hmac.compare_digest(qs.get("token", ""), fed_token()):
				return self.send_json({"ok": False, "error": "联邦令牌不正确"}, 401)
			conn = get_db()
			n = conn.execute("SELECT COUNT(*) n FROM questions WHERE status='published'").fetchone()["n"]
			subs = [r["subject"] for r in conn.execute("SELECT DISTINCT subject FROM questions WHERE status='published' ORDER BY subject").fetchall()]
			conn.close()
			return self.send_json({"ok": True, "catalog": {"name": "常熟边检站刷题宝", "version": VERSION, "question_count": n, "subjects": subs}})
		if path == "/api/federation/token":
			user = self.need_user()
			if not user:
				return
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可见"}, 403)
			return self.send_json({"ok": True, "token": fed_token(), "lan_url": f"http://{lan_ip()}:{PORT}"})
		if path == "/api/federation/hosts":
			user = self.need_user()
			if not user:
				return
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可见"}, 403)
			conn = get_db()
			rows = [qdict(r) for r in conn.execute("SELECT id,name,host,port,status,last_seen,last_error,last_count,created_at FROM peer_hosts ORDER BY id").fetchall()]
			conn.close()
			return self.send_json({"ok": True, "hosts": rows})
		if path == "/api/federation/packages":
			user = self.need_user()
			if not user:
				return
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可见"}, 403)
			conn = get_db()
			rows = [qdict(r) for r in conn.execute("SELECT * FROM federation_packages ORDER BY id DESC LIMIT 100").fetchall()]
			conn.close()
			return self.send_json({"ok": True, "packages": rows})
		if path == "/api/backup/status":
			user = self.need_user()
			if not user:
				return
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可见"}, 403)
			return self.send_json({"ok": True, "backup": backup_status_summary()})
		if path == "/api/backup/list":
			user = self.need_user()
			if not user:
				return
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可见"}, 403)
			return self.send_json({"ok": True, "backups": list_backups()})
		if path.startswith("/api/backup/download/"):
			user = self.need_user()
			if not user:
				return
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可下载备份"}, 403)
			fname = os.path.basename(unquote(path[len("/api/backup/download/"):]))
			if not fname.endswith(".zip") or "/" in fname:
				return self.send_json({"ok": False, "error": "备份文件名不正确"}, 400)
			fpath = os.path.join(BACKUP_DIR, fname)
			if not os.path.isfile(fpath):
				return self.send_json({"ok": False, "error": "备份文件不存在"}, 404)
			with open(fpath, "rb") as f:
				data = f.read()
			self.send_response(200)
			self.send_header("Content-Type", "application/zip")
			self.send_header("Content-Disposition", f'attachment; filename="{fname}"')
			self.send_header("Content-Length", str(len(data)))
			self.end_headers()
			self.wfile.write(data)
			return
		if path == "/api/ai/variants":
			user = self.need_user()
			if not user:
				return
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可见"}, 403)
			conn = get_db()
			rows = []
			for r in conn.execute("SELECT q.*, p.stem AS parent_stem FROM questions q LEFT JOIN questions p ON p.id=q.parent_id WHERE q.source LIKE '变式·%' ORDER BY q.id DESC LIMIT 100").fetchall():
				d = qdict(r)
				d["parent_stem"] = r["parent_stem"]
				rows.append(d)
			conn.close()
			return self.send_json({"ok": True, "variants": rows})
		if path.startswith("/api/ai/tips/"):
			user = self.need_user()
			if not user:
				return
			try:
				qid = int(path.split("/")[-1])
			except Exception:
				return self.send_json({"ok": False, "error": "题目不存在"}, 404)
			conn = get_db()
			res = ai_tip_for(conn, qid)
			conn.close()
			return self.send_json(res, 404 if not res.get("ok") else 200)
		if path == "/lite/admin":
			return self.lite_admin()
		if path.startswith("/api/exams/") and path.endswith("/print"):
			user = self.need_user()
			if not user:
				return
			sid = path.split("/")[3]
			conn = get_db()
			s = conn.execute("SELECT * FROM exam_sessions WHERE id=?", (sid,)).fetchone()
			if not s or (s["user_id"] != user["user_id"] and user["role"] not in ("admin", "instructor")):
				conn.close()
				return self.send_json({"ok": False, "error": "场次不存在或无权查看"}, 404)
			u = conn.execute("SELECT * FROM users WHERE id=?", (s["user_id"],)).fetchone()
			details = []
			data = json.loads(s["question_ids_json"])
			for qid in data["ids"]:
				draft = conn.execute("SELECT user_answer, is_correct FROM attempts WHERE exam_session_id=? AND question_id=? AND mode='exam' ORDER BY id DESC LIMIT 1", (sid, qid)).fetchone()
				q = get_question_full(conn, qid)
				pending = bool(draft and draft["is_correct"] is None)
				details.append({"question_id": qid, "stem": q["stem"] if q else "", "user_answer": draft["user_answer"] if draft else "", "correct_answer": "待人工批阅" if pending else (q["answer"] if q else ""), "is_correct": None if pending else (bool(draft["is_correct"]) if draft else False)})
			conn.close()
			rows = "".join(f"<tr><td>{i+1}</td><td>{d['stem']}</td><td>{d['user_answer'] or '未答'}</td><td>{d['correct_answer']}</td><td>{'对' if d['is_correct'] else ('待批阅' if d['is_correct'] is None else '错')}</td></tr>" for i, d in enumerate(details))
			html = ("<!DOCTYPE html><html><head><meta charset='utf-8'><title>成绩单</title><style>body{font-family:sans-serif;font-size:15px;line-height:1.6}table{border-collapse:collapse;width:100%}td,th{border:1px solid #999;padding:8px;text-align:left}h1{font-size:22px}</style></head><body>"
				f"<h1>阶段考核成绩单</h1><p>姓名：{u['display_name']}（{u['team']}） · 场次：{s['title']} · 得分：{s['score']} / {s['total']} · 交卷：{s['submitted_at'] or '未交卷'}</p>"
				f"<table><tr><th>#</th><th>题干</th><th>你的答案</th><th>正确答案</th><th>对错</th></tr>{rows}</table><p>打印：浏览器菜单 → 打印。本页仅供打印/存档，成绩以系统记录为准。</p></body></html>")
			return self.send_html(html)
		if path == "/api/questions":
			user = self.need_user()
			if not user:
				return
			conn = get_db()
			rows = conn.execute("SELECT * FROM questions WHERE status='published' ORDER BY id").fetchall()
			out = []
			for r in rows:
				d = get_question_full(conn, r["id"])
				if qs.get("subject") and d["subject"] != qs["subject"]:
					continue
				if qs.get("knowledge") and qs["knowledge"] not in d["knowledge"]:
					continue
				if qs.get("type") and d["type"] != qs["type"]:
					continue
				out.append({"id": d["id"], "type": d["type"], "stem": d["stem"], "subject": d["subject"], "difficulty": d["difficulty"], "knowledge": d["knowledge"], "assets": d["assets"], "options": [{"label": o["label"], "content": o["content"]} for o in d["options"]]})
			conn.close()
			return self.send_json({"ok": True, "questions": out, "total": len(out)})
		if path == "/api/practice":
			user = self.need_user()
			if not user:
				return
			mode = qs.get("mode", "free")
			count = int(qs.get("count", "10") or 10)
			qs_list = self.pick_questions(user, mode, count, qs.get("knowledge", ""), qs.get("subject", ""))
			return self.send_json({"ok": True, "mode": mode, "questions": qs_list})
		if path == "/api/reports/stats":
			user = self.need_user()
			if not user:
				return
			conn = get_db()
			type_rows = conn.execute("SELECT type, COUNT(*) n FROM questions WHERE status='published' GROUP BY type ORDER BY n DESC").fetchall()
			diff_rows = conn.execute("SELECT difficulty, COUNT(*) n FROM questions WHERE status='published' GROUP BY difficulty ORDER BY difficulty").fetchall()
			conn.close()
			type_names = {"single": "单选", "multi": "多选", "judge": "判断"}
			return self.send_json({"ok": True, "stats": {"type_counts": [{"type": r["type"], "label": type_names.get(r["type"], r["type"]), "count": r["n"]} for r in type_rows], "difficulty_counts": [{"difficulty": r["difficulty"], "count": r["n"]} for r in diff_rows], "total": sum(r["n"] for r in type_rows)}})
		if path == "/api/reports/me":
			user = self.need_user()
			if not user:
				return
			return self.send_json({"ok": True, "report": self.report_for(user["user_id"])})
		if path == "/api/reports/team":
			user = self.need_user()
			if not user:
				return
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可看队报告"}, 403)
			return self.send_json({"ok": True, "report": self.team_report(user)})
		if path == "/api/reports/me.csv":
			user = self.need_user()
			if not user:
				return
			return self.send_csv_report(self.report_for(user["user_id"]), "report-me.csv")
		if path == "/api/reports/team.csv":
			user = self.need_user()
			if not user:
				return
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可看队报告"}, 403)
			return self.send_csv_report(self.team_report(user), "report-team.csv", team=True)
		if path == "/api/bank/versions":
			user = self.need_user()
			if not user:
				return
			conn = get_db()
			rows = [qdict(r) for r in conn.execute("SELECT * FROM bank_versions ORDER BY id DESC").fetchall()]
			conn.close()
			return self.send_json({"ok": True, "versions": rows})
		if path == "/api/import/jobs":
			user = self.need_user()
			if not user:
				return
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可看导入"}, 403)
			conn = get_db()
			jobs = [qdict(r) for r in conn.execute("SELECT * FROM import_jobs ORDER BY id DESC LIMIT 20").fetchall()]
			queue = [qdict(r) for r in conn.execute("SELECT * FROM review_queue ORDER BY id DESC LIMIT 100").fetchall()]
			conn.close()
			return self.send_json({"ok": True, "jobs": jobs, "review_queue": queue})
		if path.startswith("/api/import/jobs/") and path.endswith("/pairings"):
			user = self.need_user()
			if not user:
				return
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可复核配对"}, 403)
			jid = path.split("/")[4]
			conn = get_db()
			job = conn.execute("SELECT * FROM import_jobs WHERE id=?", (jid,)).fetchone()
			if not job:
				conn.close()
				return self.send_json({"ok": False, "error": "导入任务不存在"}, 404)
			rows = []
			for r in conn.execute("SELECT ip.*, q.stem, a.path AS asset_path FROM image_pairings ip LEFT JOIN questions q ON q.id=ip.question_id LEFT JOIN question_assets a ON a.id=ip.asset_id WHERE ip.job_id=? ORDER BY ip.confidence ASC, ip.id", (jid,)).fetchall():
				d = qdict(r)
				rows.append(d)
			try:
				report = json.loads(job["pairing_report_json"] or "{}")
			except Exception:
				report = {}
			conn.close()
			return self.send_json({"ok": True, "job_id": int(jid), "filename": job["filename"], "pairing": {"auto": job["pairing_auto"], "review": job["pairing_review"], "manual": job["pairing_manual"]}, "report": report, "pairings": rows})
		if path.startswith("/api/import/jobs/"):
			user = self.need_user()
			if not user:
				return
			jid = path.split("/")[-1]
			conn = get_db()
			items = [qdict(r) for r in conn.execute("SELECT * FROM import_items WHERE job_id=? ORDER BY row_no", (jid,)).fetchall()]
			conn.close()
			return self.send_json({"ok": True, "items": items})
		if path.startswith("/api/exams/") and path.endswith("/state"):
			user = self.need_user()
			if not user:
				return
			sid = path.split("/")[3]
			conn = get_db()
			s = conn.execute("SELECT * FROM exam_sessions WHERE id=? AND user_id=?", (sid, user["user_id"])).fetchone()
			conn.close()
			if not s:
				return self.send_json({"ok": False, "error": "场次不存在"}, 404)
			ends = datetime.strptime(s["ends_at"], "%Y-%m-%d %H:%M:%S")
			remain = max(0, int((ends - datetime.now()).total_seconds()))
			return self.send_json({"ok": True, "status": s["status"], "remaining_seconds": remain, "ends_at": s["ends_at"]})
		self.send_text("404 未找到", status=404)
	def send_csv_report(self, rep, filename, team=False):
		buf = io.StringIO()
		w = csv.writer(buf)
		if team:
			w.writerow(["队报告", rep.get("team", ""), "生成时间", now_iso()])
			w.writerow(["参训人数", rep.get("member_count"), "总作答", rep.get("total_attempts"), "平均正确率", rep.get("avg_accuracy")])
			w.writerow(["知识点", "作答数", "正确数", "正确率"])
			for k in rep.get("knowledge", []):
				w.writerow([k["knowledge"], k["total"], k["correct"], k["accuracy"]])
			w.writerow(["高频易错题ID", "错题次数"])
			for e in rep.get("wrong_top", []):
				w.writerow([e["question_id"], e["wrong_count"]])
		else:
			w.writerow(["个人报告", rep.get("username", ""), "生成时间", now_iso()])
			w.writerow(["总作答", rep.get("total"), "正确", rep.get("correct"), "正确率", rep.get("accuracy")])
			w.writerow(["知识点", "作答数", "正确数", "正确率", "Elo"])
			for k in rep.get("by_knowledge", []):
				w.writerow([k["knowledge"], k["total"], k["correct"], k["accuracy"], k["elo"]])
			w.writerow(["薄弱TOP"])
			for k in rep.get("weak_top", []):
				w.writerow([k["knowledge"], k["accuracy"]])
		data = buf.getvalue()
		b = data.encode("utf-8-sig")
		self.send_response(200)
		self.send_header("Content-Type", "text/csv; charset=utf-8")
		self.send_header("Content-Disposition", 'attachment; filename="' + filename + '"')
		self.send_header("Content-Length", str(len(b)))
		self.end_headers()
		self.wfile.write(b)
	def pick_questions(self, user, mode, count, knowledge="", subject=""):
		conn = get_db()
		if mode == "essay":
			rows = [get_question_full(conn, r["id"]) for r in conn.execute("SELECT id FROM questions WHERE status='published' AND type IN ('short','material') ORDER BY id").fetchall()]
			conn.close()
			return [{"id": q["id"], "type": q["type"], "stem": q["stem"], "subject": q["subject"], "difficulty": q["difficulty"], "knowledge": q["knowledge"], "assets": q["assets"], "options": [], "max_score": q.get("max_score", 10), "parent_id": q.get("parent_id")} for q in rows[:count]]
		all_q = [get_question_full(conn, r["id"]) for r in conn.execute("SELECT id FROM questions WHERE status='published' AND type NOT IN ('short','material') ORDER BY id").fetchall()]
		def pub(q):
			return {"id": q["id"], "type": q["type"], "stem": q["stem"], "subject": q["subject"], "difficulty": q["difficulty"], "knowledge": q["knowledge"], "assets": q["assets"], "options": [{"label": o["label"], "content": o["content"]} for o in q["options"]]}
		# 疑似错题只在抽新题的模式里排除（free/顺序/随机/薄弱/考核）；
		# 错题回顾和错题本是用户主动重练自己错过的题，不排除，否则错过的题永远练不回来。
		if mode not in ("review", "wrong"):
			sus = suspect_qids(conn)
			all_q = [q for q in all_q if q["id"] not in sus]
		if subject:
			all_q = [q for q in all_q if q["subject"] == subject]
		if knowledge:
			all_q = [q for q in all_q if knowledge in q["knowledge"]]
		if mode == "wrong":
			rows = conn.execute("SELECT question_id FROM wrong_book WHERE user_id=? AND mastered=0 ORDER BY wrong_count DESC", (user["user_id"],)).fetchall()
			ids = [r["question_id"] for r in rows]
			picked = [q for q in all_q if q["id"] in ids]
		elif mode in ("weak", "adaptive"):
			picked_pub, _prof = adaptive_pick(conn, user, count)
			conn.close()
			return picked_pub
		elif mode == "sequential":
			picked = sorted(all_q, key=lambda q: ((q["knowledge"] or [""])[0], q["difficulty"], q["id"]))
			conn.close()
			return [pub(q) for q in picked[:count]]
		elif mode == "random":
			picked = all_q[:]
			random.shuffle(picked)
			conn.close()
			return [pub(q) for q in picked[:count]]
		elif mode == "review":
			due_ids = [r["question_id"] for r in conn.execute("SELECT question_id FROM review_schedule WHERE user_id=? AND date(next_review)<=date('now') ORDER BY next_review", (user["user_id"],)).fetchall()]
			wrong_ids = [r["question_id"] for r in conn.execute("SELECT question_id FROM wrong_book WHERE user_id=? AND mastered=0 ORDER BY wrong_count DESC", (user["user_id"],)).fetchall()]
			ordered = due_ids + [i for i in wrong_ids if i not in due_ids]
			by_id = {q["id"]: q for q in all_q}
			picked = [by_id[i] for i in ordered if i in by_id]
			rest = [q for q in all_q if q["id"] not in ordered]
			random.shuffle(rest)
			picked += rest
			conn.close()
			return [pub(q) for q in picked[:count]]
		else:
			picked = all_q
		random.shuffle(picked)
		conn.close()
		return [pub(q) for q in picked[:count]]
	def report_for(self, user_id, conn=None):
		close = False
		if conn is None:
			conn = get_db()
			close = True
		user = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
		total = conn.execute("SELECT COUNT(*) n FROM attempts WHERE user_id=? AND mode IN ('practice','exam') AND is_correct IS NOT NULL", (user_id,)).fetchone()["n"]
		correct = conn.execute("SELECT COUNT(*) n FROM attempts WHERE user_id=? AND mode IN ('practice','exam') AND is_correct=1", (user_id,)).fetchone()["n"]
		ess_total = conn.execute("SELECT COUNT(*) n FROM attempts a JOIN questions q ON q.id=a.question_id WHERE a.user_id=? AND q.type IN ('short','material') AND a.mode IN ('practice','exam')", (user_id,)).fetchone()["n"]
		ess_pending = conn.execute("SELECT COUNT(*) n FROM attempts a JOIN questions q ON q.id=a.question_id WHERE a.user_id=? AND q.type IN ('short','material') AND a.mode IN ('practice','exam') AND a.is_correct IS NULL", (user_id,)).fetchone()["n"]
		ess_sc = conn.execute("SELECT COALESCE(SUM(score),0) s, COALESCE(SUM(max_score),0) m FROM review_scores WHERE user_id=? AND status='graded'", (user_id,)).fetchone()
		essay_stat = {"total": ess_total, "graded": ess_total - ess_pending, "pending": ess_pending, "score": ess_sc["s"], "max_score": ess_sc["m"]}
		plans_stat = []
		for pl in conn.execute("SELECT sp.* FROM study_plans sp JOIN tasks t ON t.plan_id=sp.id WHERE t.user_id=? ORDER BY sp.due_date LIMIT 5", (user_id,)).fetchall():
			p = plan_progress(conn, pl, user_id)
			plans_stat.append({"id": pl["id"], "title": pl["title"], "knowledge": pl["knowledge"], "due_date": pl["due_date"], "done": p["done"], "target": p["target"], "pct": p["pct"], "overdue": p["overdue"], "days_left": p["days_left"], "daily_count": p["daily_count"]})
		by_kn = []
		for r in conn.execute("SELECT knowledge,total,correct,elo FROM mastery_states WHERE user_id=? ORDER BY elo ASC", (user_id,)).fetchall():
			acc = round(r["correct"] / r["total"], 3) if r["total"] else 0
			by_kn.append({"knowledge": r["knowledge"], "total": r["total"], "correct": r["correct"], "accuracy": acc, "elo": r["elo"]})
		trend = [{"date": r["d"], "total": r["n"], "correct": r["c"]} for r in conn.execute("SELECT substr(answered_at,1,10) d, COUNT(*) n, SUM(is_correct) c FROM attempts WHERE user_id=? GROUP BY d ORDER BY d DESC LIMIT 14", (user_id,)).fetchall()]
		wrong_n = conn.execute("SELECT COUNT(*) n FROM wrong_book WHERE user_id=? AND mastered=0", (user_id,)).fetchone()["n"]
		due_n = conn.execute("SELECT COUNT(*) n FROM review_schedule WHERE user_id=? AND date(next_review)<=date('now')", (user_id,)).fetchone()["n"]
		streak = streak_days(conn, user_id)
		prof = adaptive_profile(conn, user_id)
		if close:
			conn.close()
		weak = sorted([k for k in by_kn if k["total"] >= 5 and k["accuracy"] < 0.60], key=lambda x: (x["accuracy"], x["elo"]))[:5]
		return {"username": user["username"] if user else "", "display_name": user["display_name"] if user else "", "team": user["team"] if user else "", "total": total, "correct": correct, "accuracy": round(correct / total, 3) if total else 0, "by_knowledge": by_kn, "weak_top": weak, "trend": trend, "wrong_count": wrong_n, "due_count": due_n, "streak_days": streak, "essay": essay_stat, "plans": plans_stat, "adaptive": {"weak_knowledge": prof["weak_knowledge"], "mastered_knowledge": prof["mastered_knowledge"], "ratio": prof["ratio"], "sample_note": prof["sample_note"], "cold_start": prof["cold_start"], "per_knowledge": prof["per_knowledge"]}, "advice": ("薄弱项：" + "、".join(k["knowledge"] for k in weak) + "，建议用薄弱项训练每天练 10 道。") if weak else ("样本不足：已答 %d 题，满 20 题后开始个性化判断；先做 10 道练习再看报告。" % total if total < 20 else "暂无明显薄弱项，继续保持随机测验。")}
	def team_report(self, user):
		conn = get_db()
		team = user["team"]
		if user["role"] == "instructor":
			members = conn.execute("SELECT id FROM users WHERE team=?", (team,)).fetchall()
		else:
			members = conn.execute("SELECT id FROM users").fetchall()
		mids = [r["id"] for r in members]
		if not mids:
			conn.close()
			return {"team": team, "member_count": 0, "total_attempts": 0, "avg_accuracy": 0, "knowledge": [], "wrong_top": []}
		ph = ",".join("?" * len(mids))
		total = conn.execute(f"SELECT COUNT(*) n FROM attempts WHERE user_id IN ({ph})", mids).fetchone()["n"]
		correct = conn.execute(f"SELECT COUNT(*) n FROM attempts WHERE user_id IN ({ph}) AND is_correct=1", mids).fetchone()["n"]
		kn = []
		for r in conn.execute(f"SELECT knowledge, SUM(total) t, SUM(correct) c FROM mastery_states WHERE user_id IN ({ph}) GROUP BY knowledge ORDER BY t DESC", mids).fetchall():
			kn.append({"knowledge": r["knowledge"], "total": r["t"], "correct": r["c"], "accuracy": round(r["c"] / r["t"], 3) if r["t"] else 0})
		wrong = [{"question_id": r["question_id"], "wrong_count": r["n"]} for r in conn.execute(f"SELECT question_id, COUNT(*) n FROM wrong_book WHERE user_id IN ({ph}) AND mastered=0 GROUP BY question_id ORDER BY n DESC LIMIT 10", mids).fetchall()]
		conn.close()
		return {"team": team, "member_count": len(mids), "total_attempts": total, "avg_accuracy": round(correct / total, 3) if total else 0, "knowledge": kn, "wrong_top": wrong}
	def admin_overview(self, user):
		conn = get_db()
		total_users = conn.execute("SELECT COUNT(*) n FROM users").fetchone()["n"]
		today = datetime.now().strftime("%Y-%m-%d")
		active_today = conn.execute("SELECT COUNT(DISTINCT user_id) n FROM attempts WHERE substr(answered_at,1,10)=?", (today,)).fetchone()["n"]
		today_attempts = conn.execute("SELECT COUNT(*) n FROM attempts WHERE substr(answered_at,1,10)=? AND mode IN ('practice','exam')", (today,)).fetchone()["n"]
		tot = conn.execute("SELECT COUNT(*) n FROM attempts WHERE mode IN ('practice','exam')").fetchone()["n"]
		cor = conn.execute("SELECT COUNT(*) n FROM attempts WHERE mode IN ('practice','exam') AND is_correct=1").fetchone()["n"]
		trend = [{"date": r["d"], "total": r["n"], "correct": r["c"]} for r in conn.execute("SELECT substr(answered_at,1,10) d, COUNT(*) n, SUM(is_correct) c FROM attempts WHERE mode IN ('practice','exam') GROUP BY d ORDER BY d DESC LIMIT 14", ).fetchall()]
		trend = list(reversed(trend))
		pending = conn.execute("SELECT COUNT(*) n FROM review_queue WHERE status='pending'").fetchone()["n"]
		weak_top = [{"knowledge": r["knowledge"], "total": r["t"], "correct": r["c"], "accuracy": round(r["c"] / r["t"], 3) if r["t"] else 0} for r in conn.execute("SELECT knowledge, SUM(total) t, SUM(correct) c FROM mastery_states GROUP BY knowledge ORDER BY c*1.0/NULLIF(t,0) ASC LIMIT 5").fetchall()]
		suspects = conn.execute("SELECT COUNT(*) n FROM quality_scores WHERE flag!='normal'").fetchone()["n"]
		teams = []
		for trow in conn.execute("SELECT DISTINCT team FROM users WHERE team IS NOT NULL AND team!=''").fetchall():
			team = trow["team"]
			mids = [r["id"] for r in conn.execute("SELECT id FROM users WHERE team=?", (team,)).fetchall()]
			ph = ",".join("?" * len(mids))
			tt = conn.execute(f"SELECT COUNT(*) n FROM attempts WHERE user_id IN ({ph}) AND mode IN ('practice','exam')", mids).fetchone()["n"]
			cc = conn.execute(f"SELECT COUNT(*) n FROM attempts WHERE user_id IN ({ph}) AND mode IN ('practice','exam') AND is_correct=1", mids).fetchone()["n"]
			part = conn.execute(f"SELECT COUNT(DISTINCT user_id) n FROM attempts WHERE user_id IN ({ph}) AND date(answered_at)>=date('now','-14 days')", mids).fetchone()["n"]
			below = 0
			for m in mids:
				r = conn.execute("SELECT COUNT(*) n, COALESCE(SUM(is_correct),0) c FROM attempts WHERE user_id=? AND mode IN ('practice','exam')", (m,)).fetchone()
				if r["n"] >= 10 and r["n"] and r["c"] / r["n"] < 0.60:
					below += 1
			teams.append({"team": team, "member_count": len(mids), "total_attempts": tt, "avg_accuracy": round(cc / tt, 3) if tt else 0, "participation": round(part / len(mids), 3) if mids else 0, "below_target": below})
		warnings = []
		for u in conn.execute("SELECT id, display_name, team FROM users").fetchall():
			last = conn.execute("SELECT MAX(answered_at) m FROM attempts WHERE user_id=?", (u["id"],)).fetchone()["m"]
			if not last or (datetime.now() - datetime.strptime(last, "%Y-%m-%d %H:%M:%S")).days >= 7:
				warnings.append({"type": "inactive_7d", "user_id": u["id"], "display_name": u["display_name"], "team": u["team"], "detail": "7 天无作答" if last else "从未作答"})
			r7 = conn.execute("SELECT COUNT(*) n, COALESCE(SUM(is_correct),0) c FROM attempts WHERE user_id=? AND mode IN ('practice','exam') AND date(answered_at)>=date('now','-7 days')", (u["id"],)).fetchone()
			r14 = conn.execute("SELECT COUNT(*) n, COALESCE(SUM(is_correct),0) c FROM attempts WHERE user_id=? AND mode IN ('practice','exam') AND date(answered_at)>=date('now','-14 days') AND date(answered_at)<date('now','-7 days')", (u["id"],)).fetchone()
			if r7["n"] >= 5 and r14["n"] >= 5 and r7["c"] / r7["n"] < r14["c"] / r14["n"] - 0.15:
				warnings.append({"type": "accuracy_drop", "user_id": u["id"], "display_name": u["display_name"], "team": u["team"], "detail": f"近 7 天正确率 {round(r7['c']/r7['n'],2)}，低于前 7 天 {round(r14['c']/r14['n'],2)}"})
		for r in conn.execute("SELECT knowledge, SUM(total) t, SUM(correct) c FROM mastery_states GROUP BY knowledge").fetchall():
			if r["t"] >= 10 and r["c"] / r["t"] < 0.60:
				warnings.append({"type": "knowledge_low", "user_id": None, "display_name": "全站", "team": "", "detail": f"知识点「{r['knowledge']}」全站正确率 {round(r['c']/r['t'],2)}（{r['t']} 题），低于 60%"})
		# 知识点 x 部门热力
		heat = {}
		for r in conn.execute("SELECT u.team team, m.knowledge k, SUM(m.total) t, SUM(m.correct) c FROM mastery_states m JOIN users u ON u.id=m.user_id GROUP BY u.team, m.knowledge").fetchall():
			heat.setdefault(r["k"], {})[r["team"]] = round(r["c"] / r["t"], 2) if r["t"] else 0
		plans_active = conn.execute("SELECT COUNT(*) n FROM study_plans").fetchone()["n"]
		plans_overdue = 0
		for pl in conn.execute("SELECT * FROM study_plans").fetchall():
			if not pl["due_date"] or pl["due_date"] >= today:
				continue
			uids = [r["user_id"] for r in conn.execute("SELECT user_id FROM tasks WHERE plan_id=?", (pl["id"],)).fetchall()]
			if uids and any(plan_progress(conn, pl, uid)["pct"] < 100 for uid in uids):
				plans_overdue += 1
		conn.close()
		return {"total_users": total_users, "active_today": active_today, "today_attempts": today_attempts, "avg_accuracy": round(cor / tot, 3) if tot else 0, "total_attempts": tot, "trend14": trend, "pending_review": pending, "weak_top": weak_top, "suspects": suspects, "teams": teams, "warnings": warnings, "heatmap": heat, "plans_active": plans_active, "plans_overdue": plans_overdue}
	def sample_by_template(self, conn, rules, total_count):
		sus = suspect_qids(conn)
		all_q = [get_question_full(conn, r["id"]) for r in conn.execute("SELECT id FROM questions WHERE status='published' AND type NOT IN ('short','material') ORDER BY id").fetchall()]
		all_q = [q for q in all_q if q["id"] not in sus]
		picked, seen = [], set()
		kw = (rules or {}).get("knowledge_weights") or {}
		dd = (rules or {}).get("difficulty_dist") or {}
		if kw:
			for kn, w in kw.items():
				n = max(0, int(round(total_count * int(w) / max(1, sum(int(v) for v in kw.values())))))
				pool = [q for q in all_q if kn in q["knowledge"] and q["id"] not in seen]
				random.shuffle(pool)
				for q in pool[:n]:
					picked.append(q); seen.add(q["id"])
		if dd:
			for dstr, w in dd.items():
				n = max(0, int(round(total_count * int(w) / max(1, sum(int(v) for v in dd.values())))))
				pool = [q for q in all_q if q["difficulty"] == int(dstr) and q["id"] not in seen]
				random.shuffle(pool)
				for q in pool[:n]:
					picked.append(q); seen.add(q["id"])
		rest = [q for q in all_q if q["id"] not in seen]
		random.shuffle(rest)
		picked += rest[:max(0, total_count - len(picked))]
		return picked[:total_count]
	# Lite 版（IE8 / Chrome 49 上限版）：只用 CSS2.1 能解析的写法——大字号、
	# 大按钮、留白、实线卡片分隔；不用圆角、阴影、毛玻璃、flex、动效、深色模式。
	# 降级点见《设计检查表-HIG》G5–G10，已明说，不悄悄降标准。
	LITE_CSS = ("body{font-family:SimSun,\"Microsoft YaHei\",sans-serif;font-size:18px;line-height:1.6;"
		"color:#000;background:#f2f2f7;margin:0} "
		"h1{font-size:28px;margin:0} h2{font-size:26px;margin:0 0 8px} h3{font-size:22px;margin:16px 0 8px} "
		"a{color:#007aff} "
		".bar{background:#007aff;color:#fff;padding:16px} "
		".wrap{width:92%;margin:0 auto;padding:16px 0} "
		".card{background:#fff;border:2px solid #c6c6c8;padding:16px;margin:0 0 16px} "
		".nav{font-size:18px;margin:0 0 16px} .nav a{margin-right:16px} "
		"input{font-size:18px;padding:10px} "
		"input[type=submit],input[type=button]{font-size:18px;padding:12px 24px;background:#007aff;color:#fff;border:2px solid #007aff;cursor:pointer} "
		"table{border-collapse:collapse;width:100%;font-size:16px} td,th{border:1px solid #c6c6c8;padding:10px;text-align:left} "
		".ok{color:#1d7a35;font-weight:bold} .no{color:#b3261e;font-weight:bold} .muted{color:#555;font-size:15px} .litebar-wrap{display:block;background:#ddd;height:16px} .litebar{display:block;background:#007aff;height:16px}")
	def lite_page(self, title, body, user=None):
		who = f"当前：{user['display_name']}（{user['role']} / {user['team']}）" if user else ""
		nav = "<p class=\"nav\"><a href='/lite'>首页</a><a href='/lite/practice?mode=free'>自由练习</a><a href='/lite/practice?mode=wrong'>错题重练</a><a href='/lite/report'>我的报告</a><a href='/'>现代版</a></p>" if user else "<p class=\"nav\"><a href='/'>现代版</a></p>"
		html = ("<!DOCTYPE html><html><head><meta charset=\"utf-8\"><title>" + title + " - 刷题宝 Lite</title>"
			"<style type=\"text/css\">" + self.LITE_CSS + "</style></head><body>"
			"<div class=\"bar\"><h1>刷题宝 Lite</h1><p>常熟边检站 · 局域网离线版</p></div>"
			"<div class=\"wrap\">" + (("<p>" + who + "</p>") if who else "") + nav + "<div class=\"card\">" + body + "</div>"
			"<p class=\"muted\">Lite 版已按老浏览器能力上限尽量接近苹果设计：大字号、大按钮、清晰层级。做不到的：无圆角、无阴影、无动效、无深色模式，详见《设计检查表-HIG》。</p>"
			"</div></body></html>")
		return self.send_html(html)
	def lite_home(self):
		user = self.get_user()
		if not user:
			return self.lite_page("登录", "<h3>登录</h3><p>用站里分配的账号登录。</p><form method=\"post\" action=\"/lite/login\"><p>账号：<br><input name=\"username\" value=\"\"></p><p>密码：<br><input type=\"password\" name=\"password\" value=\"\"></p><p><input type=\"submit\" value=\"登录\"></p></form><p class=\"muted\">演示账号（民警 minjing / 教官 jiaoguan / 管理员 admin）密码见主机上的《产品介绍》，登录页不再明文展示。</p>")
		admin_link = " | <a href=\"/lite/admin\">后台总览</a>" if user["role"] in ("admin", "instructor") else ""
		body = "<h3>首页</h3><p><a href=\"/lite/practice?mode=free\">自由练习</a> | <a href=\"/lite/practice?mode=wrong\">错题重练</a> | <a href=\"/lite/report\">我的报告</a> | <a href=\"/lite/plans\">我的学习计划</a>" + admin_link + "</p><form method=\"post\" action=\"/lite/logout\"><input type=\"submit\" value=\"退出登录\"></form>"
		return self.lite_page("首页", body, user)
	def lite_practice(self, qs):
		user = self.get_user()
		if not user:
			return self.lite_home()
		mode = qs.get("mode", "free")
		lst = self.pick_questions(user, mode, 1)
		if not lst:
			return self.lite_page("练习", "<p>暂无题目（错题本为空时请先做自由练习）。</p><p><a href='/lite'>返回</a></p>", user)
		q = lst[0]
		img = "".join(f"<p><img src='/assets/{a['path']}' width='300'></p>" for a in q["assets"])
		opts_html = "".join(f"<p><input type='radio' name='answer' value='{o['label']}'> {o['label']}. {o['content']}</p>" for o in q["options"])
		body = f"<h3>练习（{mode}）</h3><p style=\"font-size:20px;font-weight:bold\">{q['stem']}</p>{img}<form method=\"post\" action=\"/lite/answer\"><input type=\"hidden\" name=\"question_id\" value=\"{q['id']}\"><input type=\"hidden\" name=\"mode\" value=\"{mode}\">{opts_html}<p><input type=\"submit\" value=\"提交本题\"></p></form><p><a href=\"/lite/practice?mode={mode}\">换一题</a> | <a href=\"/lite\">返回首页</a></p>"
		return self.lite_page("练习", body, user)
	def lite_report(self):
		user = self.get_user()
		if not user:
			return self.lite_home()
		rep = self.report_for(user["user_id"])
		rows = ''.join('<tr><td>' + k['knowledge'] + '</td><td>' + str(k['total']) + '</td><td>' + str(k['correct']) + '</td><td>' + str(k['accuracy']) + '</td><td>' + str(k['elo']) + '</td></tr>' for k in rep['by_knowledge'])
		bars = ''.join('<p>' + k['knowledge'] + '：正确率 ' + str(round((k['accuracy'] or 0) * 100)) + '%（' + str(k['correct']) + '/' + str(k['total']) + '）<br><span class="litebar-wrap"><span class="litebar" style="width:' + str(int((k['accuracy'] or 0) * 100)) + '%">&nbsp;</span></span></p>' for k in rep['by_knowledge'])
		trend_rows = ''.join('<tr><td>' + t['date'] + '</td><td>' + str(t['total']) + '</td><td>' + str(t['correct']) + '</td></tr>' for t in reversed(rep['trend']))
		conn = get_db()
		type_names = {'single': '单选', 'multi': '多选', 'judge': '判断'}
		type_lines = ''.join('<p>' + type_names.get(r['type'], r['type']) + '：' + str(r['n']) + ' 道</p>' for r in conn.execute("SELECT type, COUNT(*) n FROM questions WHERE status='published' GROUP BY type ORDER BY n DESC").fetchall())
		conn.close()
		body = '<h3>我的报告</h3><p>总作答 ' + str(rep['total']) + '，正确 ' + str(rep['correct']) + '，正确率 ' + str(rep['accuracy']) + '，错题本 ' + str(rep['wrong_count']) + ' 道</p><p>' + rep['advice'] + '</p>' + '<h3>知识点掌握（文字条形版）</h3>' + bars + '<h3>题型占比（文字版）</h3>' + type_lines + '<h3>近 14 天趋势</h3><table border="1"><tr><td>日期</td><td>作答</td><td>正确</td></tr>' + trend_rows + '</table>' + '<h3>知识点明细</h3><table border="1"><tr><td>知识点</td><td>作答</td><td>正确</td><td>正确率</td><td>Elo</td></tr>' + rows + '</table>' + '<p class="muted">Lite 版说明：图表用文字条形代替，无动画、无环形图/雷达图（老浏览器不支持 SVG 动画），数字与现代版一致。</p><p><a href="/lite">返回首页</a></p>'
		return self.lite_page("报告", body, user)
	def lite_plans(self):
		user = self.get_user()
		if not user:
			return self.lite_home()
		conn = get_db()
		rows = conn.execute("SELECT sp.* FROM study_plans sp JOIN tasks t ON t.plan_id=sp.id WHERE t.user_id=? ORDER BY sp.due_date", (user["user_id"],)).fetchall()
		items = ""
		for pl in rows:
			p = plan_progress(conn, pl, user["user_id"])
			items += "<p><b>" + (pl["title"] or "") + "</b>（" + (pl["knowledge"] or "全部知识点") + "）：已做 " + str(p["done"]) + " / " + str(p["target"]) + " 道（" + str(p["pct"]) + "%），截止 " + (pl["due_date"] or "未定") + ("，<b>已逾期</b>" if p["overdue"] else "") + "</p>"
		conn.close()
		body = "<h3>我的学习计划</h3>" + (items or "<p>暂无学习计划。</p>") + "<p><a href=\"/lite\">返回首页</a></p>"
		return self.lite_page("学习计划", body, user)
	def lite_admin(self):
		user = self.get_user()
		if not user:
			return self.lite_home()
		if user["role"] not in ("admin", "instructor"):
			return self.lite_page("后台总览", "<p>民警账号只能看自己的报告，请用教官或管理员账号查看后台。</p><p><a href='/lite'>返回首页</a></p>", user)
		ov = self.admin_overview(user)
		bs = backup_status_summary()
		conn = get_db()
		fed_n = conn.execute("SELECT COUNT(*) n FROM peer_hosts").fetchone()["n"]
		conn.close()
		team_bars = ''.join('<p>' + t['team'] + '：平均正确率 ' + str(round((t['avg_accuracy'] or 0) * 100)) + '%（' + str(t['member_count']) + ' 人，参与率 ' + str(round((t['participation'] or 0) * 100)) + '%）<br><span class="litebar-wrap"><span class="litebar" style="width:' + str(int((t['avg_accuracy'] or 0) * 100)) + '%">&nbsp;</span></span></p>' for t in ov['teams'])
		team_rows = "".join(f"<tr><td>{t['team']}</td><td>{t['member_count']}</td><td>{t['total_attempts']}</td><td>{t['avg_accuracy']}</td><td>{t['participation']}</td><td>{t['below_target']}</td></tr>" for t in ov["teams"])
		warn = "".join(f"<li>{w['display_name']}：{w['detail']}</li>" for w in ov["warnings"]) or "<li>暂无预警</li>"
		body = (f"<h3>后台总览（Lite 文字版）</h3><p>总人数 {ov['total_users']}，今日在线 {ov['active_today']} 人，今日作答 {ov['today_attempts']} 道，平均正确率 {ov['avg_accuracy']}，待审核 {ov['pending_review']}，疑似错题 {ov['suspects']} 道</p>"
			f"<h3>部门正确率（文字条形版）</h3>{team_bars}<h3>各部门</h3><table border='1'><tr><td>部门</td><td>人数</td><td>作答</td><td>正确率</td><td>参与率</td><td>未达标</td></tr>{team_rows}</table>"
			f"<h3>预警</h3><ul>{warn}</ul>"
			f"<h3>备份与共享（Lite 文字版）</h3><p>备份共 {bs['count']} 份，最近一次：{bs['last_at'] or '还没有备份'}（{bs['last_filename']}）；每日自动备份：{'开' if bs['auto'] else '关'}，保留最近 {bs['keep']} 份；磁盘剩余 {bs['disk']['free_gb']} GB（已用 {bs['disk']['used_pct']}%）。</p>"
			f"<p>联邦共享：已登记对方主机 {fed_n} 台（只开放题库目录，不开放成绩/密码）。</p><p><a href='/lite'>返回首页</a></p>")
		return self.lite_page("后台总览", body, user)
	def do_POST(self):
		try:
			self._handle_post()
		except BrokenPipeError:
			pass
		except Exception as e:
			try:
				self.send_json({"ok": False, "error": f"服务端异常：{e}"}, 500)
			except Exception:
				pass

	def _handle_post(self):
		u = urlparse(self.path)
		path = u.path
		if path == "/api/login":
			body = self.read_json()
			username = (body.get("username") or "").strip()
			pw = body.get("password") or ""
			conn = get_db()
			row = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
			if not row or not check_pw(pw, row["password_hash"]):
				conn.close()
				audit(username, "login_fail", "账号或密码错")
				return self.send_json({"ok": False, "error": "账号或密码错误"}, 401)
			token = secrets.token_urlsafe(32)
			user = {"user_id": row["id"], "username": row["username"], "display_name": row["display_name"], "role": row["role"], "team": row["team"], "exp": time.time() + 12 * 3600}
			SESSIONS[token] = user
			conn.close()
			audit(username, "login", "登录成功")
			return self.send_json({"ok": True, "user": {k: user[k] for k in ("user_id", "username", "display_name", "role", "team")}}, extra_headers={"Set-Cookie": f"token={token}; Path=/; HttpOnly"})
		if path == "/api/logout":
			user = self.get_user()
			if user:
				for k, v in list(SESSIONS.items()):
					if v is user:
						del SESSIONS[k]
			return self.send_json({"ok": True}, extra_headers={"Set-Cookie": "token=; Path=/; Max-Age=0"})
		if path == "/lite/login":
			form = self.read_form()
			username = (form.get("username") or "").strip()
			pw = form.get("password") or ""
			conn = get_db()
			row = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
			if not row or not check_pw(pw, row["password_hash"]):
				conn.close()
				return self.lite_page("登录失败", "<p>账号或密码错误。</p><p><a href='/lite'>返回登录</a></p>")
			token = secrets.token_urlsafe(32)
			SESSIONS[token] = {"user_id": row["id"], "username": row["username"], "display_name": row["display_name"], "role": row["role"], "team": row["team"], "exp": time.time() + 12 * 3600}
			conn.close()
			self.send_response(302)
			self.send_header("Location", "/lite")
			self.send_header("Set-Cookie", f"token={token}; Path=/; HttpOnly")
			self.end_headers()
			return
		if path == "/lite/logout":
			self.read_body()
			user = self.get_user()
			if user:
				for k, v in list(SESSIONS.items()):
					if v is user:
						del SESSIONS[k]
			self.send_response(302)
			self.send_header("Location", "/lite")
			self.end_headers()
			return
		if path == "/lite/answer":
			user = self.get_user()
			if not user:
				return self.lite_home()
			form = self.read_form()
			qid = int(form.get("question_id") or 0)
			ans = (form.get("answer") or "").strip()
			res = self.submit_answer(user, qid, ans, form.get("mode", "practice"))
			if not res.get("ok"):
				return self.lite_page("提交失败", f"<p>{res.get('error')}</p><p><a href='/lite'>返回</a></p>", user)
			mark = "<span class=\"ok\">答对了</span>" if res["is_correct"] else "<span class=\"no\">答错了</span>"
			body = f"<h3>{mark}</h3><p>你的答案：{ans}，正确答案：{res['correct_answer']}</p><p>解析：{res['explanation']}</p><p>想一想：为什么错的选项错、正确选项为什么对？把理由用自己的话说一遍，再做下一题。</p><p><a href=\"/lite/practice?mode={form.get('mode', 'free')}\">下一题</a> | <a href=\"/lite/report\">看报告</a> | <a href=\"/lite\">首页</a></p>"
			return self.lite_page("答题结果", body, user)
		if path == "/api/federation/package":
			# 对方主机拉包用：只认联邦令牌，不走登录态（对方服务器没有本站的登录 Cookie）。
			return self._fed_package()
		user = self.need_user()
		if not user:
			return
		if path == "/api/attempts":
			body = self.read_json()
			res = self.submit_answer(user, int(body.get("question_id") or 0), body.get("answer", ""), body.get("mode", "practice"))
			return self.send_json(res, 400 if not res.get("ok") else 200)
		if path == "/api/essay/submit":
			body = self.read_json()
			qid = int(body.get("question_id") or 0)
			ans = str(body.get("answer") or "").strip()
			if not ans:
				return self.send_json({"ok": False, "error": "请先写答案再提交"}, 400)
			if len(ans) > 5000:
				return self.send_json({"ok": False, "error": "答案过长（最多 5000 字）"}, 400)
			conn = get_db()
			q = get_question_full(conn, qid)
			if not q or q["type"] not in ("short", "material"):
				conn.close()
				return self.send_json({"ok": False, "error": "题目不存在或不是简答/材料题"}, 404)
			with DB_LOCK:
				cur = conn.execute("INSERT INTO attempts(user_id,question_id,mode,user_answer,is_correct,version_id,answered_at) VALUES(?,?,?,?,NULL,?,?)", (user["user_id"], qid, "practice", ans, q["version_id"], now_iso()))
				aid = cur.lastrowid
				cur2 = conn.execute("INSERT INTO review_scores(question_id,user_id,score,comment,reviewer,attempt_id,status,max_score,created_at) VALUES(?,?,NULL,'','',?,'pending',?,?)", (qid, user["user_id"], aid, q.get("max_score", 10), now_iso()))
				rid = cur2.lastrowid
				conn.commit()
			conn.close()
			audit(user["username"], "essay_submit", f"简答题 {qid} 已提交待批")
			return self.send_json({"ok": True, "review_id": rid, "message": "已提交，待教官人工批阅"})
		if path == "/api/essay/review":
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可批阅"}, 403)
			body = self.read_json()
			rid = int(body.get("review_id") or 0)
			try:
				score = float(body.get("score"))
			except Exception:
				return self.send_json({"ok": False, "error": "分数要是数字"}, 400)
			comment = str(body.get("comment") or "").strip()
			conn = get_db()
			row = conn.execute("SELECT * FROM review_scores WHERE id=?", (rid,)).fetchone()
			if not row:
				conn.close()
				return self.send_json({"ok": False, "error": "批阅记录不存在"}, 404)
			if row["status"] == "graded":
				conn.close()
				return self.send_json({"ok": False, "error": "该题已批阅过，不能重复批改"}, 400)
			if score < 0 or score > (row["max_score"] or 10):
				conn.close()
				return self.send_json({"ok": False, "error": f"分数应在 0 到 {row['max_score']} 之间"}, 400)
			q = get_question_full(conn, row["question_id"])
			passed = score >= 0.6 * (row["max_score"] or 10)
			with DB_LOCK:
				conn.execute("UPDATE review_scores SET score=?, comment=?, reviewer=?, status='graded', reviewed_at=? WHERE id=?", (score, comment, user["username"], now_iso(), rid))
				if row["attempt_id"]:
					conn.execute("UPDATE attempts SET is_correct=? WHERE id=?", (1 if passed else 0, row["attempt_id"]))
				if q:
					update_mastery(conn, row["user_id"], q["knowledge"], passed, q["difficulty"])
					update_review_schedule(conn, row["user_id"], row["question_id"], passed)
					refresh_quality_for(conn, row["question_id"])
					if not passed:
						conn.execute("INSERT INTO wrong_book(user_id,question_id,wrong_count,last_wrong_at) VALUES(?,?,1,?) ON CONFLICT(user_id,question_id) DO UPDATE SET wrong_count=wrong_count+1, last_wrong_at=excluded.last_wrong_at, mastered=0", (row["user_id"], row["question_id"], now_iso()))
				conn.commit()
			conn.close()
			audit(user["username"], "essay_review", f"批阅 {rid} 得分 {score}/{row['max_score']}")
			return self.send_json({"ok": True, "passed": passed})
		if path == "/api/questions/short":
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可建题"}, 403)
			body = self.read_json()
			qtype = body.get("type") or "short"
			if qtype not in ("short", "material"):
				return self.send_json({"ok": False, "error": "题型只能是 short / material"}, 400)
			stem = (body.get("stem") or "").strip()
			if not stem:
				return self.send_json({"ok": False, "error": "题干不能为空"}, 400)
			ref = str(body.get("reference_answer") or "").strip()
			if qtype == "short" and not ref:
				return self.send_json({"ok": False, "error": "简答题要有参考答案"}, 400)
			try:
				ms = float(body.get("max_score") or 10)
			except Exception:
				ms = 10
			if ms <= 0:
				ms = 10
			try:
				diff = int(body.get("difficulty") or 3)
			except Exception:
				diff = 3
			conn = get_db()
			with DB_LOCK:
				cur = conn.execute("INSERT INTO questions(type,stem,answer,explanation,subject,difficulty,source,status,version_id,created_by,created_at,rubric,max_score,parent_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)", (qtype, stem, ref, "", body.get("subject") or "未分类", diff, "手工建题", "published", current_version_id(conn), user["username"], now_iso(), str(body.get("rubric") or ""), ms, body.get("parent_id")))
				qid = cur.lastrowid
				for kn in re.split(r"[、，,；;／/]", str(body.get("knowledge") or "")):
					kn = kn.strip()
					if kn:
						conn.execute("INSERT OR IGNORE INTO knowledge_nodes(name,subject) VALUES(?,?)", (kn, body.get("subject") or "未分类"))
						kid = conn.execute("SELECT id FROM knowledge_nodes WHERE name=?", (kn,)).fetchone()["id"]
						conn.execute("INSERT OR IGNORE INTO question_knowledge(question_id,knowledge_id) VALUES(?,?)", (qid, kid))
				conn.commit()
			conn.close()
			audit(user["username"], "question_create", f"新建{qtype}题 {qid}")
			return self.send_json({"ok": True, "question_id": qid})
		if path == "/api/plans":
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可下发计划"}, 403)
			body = self.read_json()
			title = (body.get("title") or "").strip()
			if not title:
				return self.send_json({"ok": False, "error": "计划要有名称"}, 400)
			try:
				target_count = int(body.get("target_count") or 0)
			except Exception:
				target_count = 0
			if target_count <= 0:
				return self.send_json({"ok": False, "error": "目标题量要是大于 0 的整数"}, 400)
			try:
				daily_count = int(body.get("daily_count") or 0)
			except Exception:
				daily_count = 0
			due_date = (body.get("due_date") or "").strip()
			if due_date:
				try:
					datetime.strptime(due_date, "%Y-%m-%d")
				except Exception:
					return self.send_json({"ok": False, "error": "截止日格式应为 YYYY-MM-DD"}, 400)
			scope = body.get("scope") or "team"
			if scope not in ("team", "personal"):
				return self.send_json({"ok": False, "error": "范围只能是 team（部门）或 personal（个人）"}, 400)
			team = (body.get("team") or "").strip()
			target_uid = body.get("user_id")
			conn = get_db()
			if scope == "personal":
				try:
					target_uid = int(target_uid)
				except Exception:
					conn.close()
					return self.send_json({"ok": False, "error": "个人计划要指定用户 ID"}, 400)
				members = conn.execute("SELECT id, team FROM users WHERE id=?", (target_uid,)).fetchall()
				if not members:
					conn.close()
					return self.send_json({"ok": False, "error": "指定用户不存在"}, 404)
				team = members[0]["team"] or ""
			else:
				if not team:
					team = user["team"]
				members = conn.execute("SELECT id FROM users WHERE team=?", (team,)).fetchall()
				if not members:
					conn.close()
					return self.send_json({"ok": False, "error": "该部门下没有用户"}, 400)
			with DB_LOCK:
				cur = conn.execute("INSERT INTO study_plans(title,team,target_count,due_date,created_by,created_at,knowledge,daily_count,scope,target_user_id) VALUES(?,?,?,?,?,?,?,?,?,?)", (title, team, target_count, due_date, user["username"], now_iso(), (body.get("knowledge") or "").strip(), daily_count, scope, target_uid if scope == "personal" else None))
				pid = cur.lastrowid
				for mrow in members:
					conn.execute("INSERT INTO tasks(plan_id,user_id,title,status,created_at,due_date) VALUES(?,?,?,?,?,?)", (pid, mrow["id"], title, "pending", now_iso(), due_date))
				conn.commit()
			conn.close()
			audit(user["username"], "plan_create", f"学习计划 {pid}《{title}》下发给 {len(members)} 人")
			return self.send_json({"ok": True, "plan_id": pid, "assigned": len(members)})
		if path == "/api/weak":
			body = self.read_json()
			total = int(body.get("total") or 10)
			conn = get_db()
			picked, prof = adaptive_pick(conn, user, total)
			conn.close()
			return self.send_json({"ok": True, "total": total, "ratio": prof["ratio"], "weak_knowledge": prof["weak_knowledge"], "mastered_knowledge": prof["mastered_knowledge"], "sample_note": prof["sample_note"], "cold_start": prof["cold_start"], "per_knowledge": prof["per_knowledge"], "due_count": prof["due_count"], "questions": picked})
		if path == "/api/exams/start":
			body = self.read_json()
			count = int(body.get("count") or 20)
			minutes = int(body.get("minutes") or 30)
			conn = get_db()
			paper_id = body.get("paper_id")
			template_id = body.get("template_id")
			if template_id:
				trow = conn.execute("SELECT * FROM paper_templates WHERE id=?", (template_id,)).fetchone()
				if not trow:
					conn.close()
					return self.send_json({"ok": False, "error": "组卷模板不存在"}, 404)
				try:
					rules = json.loads(trow["rules_json"] or "{}")
				except Exception:
					rules = {}
				picked_q = self.sample_by_template(conn, rules, count)
				ids = [q["id"] for q in picked_q]
				title = trow["title"]
				paper_id = None
				if not ids:
					conn.close()
					return self.send_json({"ok": False, "error": "模板抽题为空，请检查配比"}, 400)
				random.shuffle(ids)
				ids = ids[:count]
				order = {}
				for qid in ids:
					labels = [r["label"] for r in conn.execute("SELECT label FROM question_options WHERE question_id=? ORDER BY label", (qid,)).fetchall()]
					random.shuffle(labels)
					order[str(qid)] = labels
				started = datetime.now()
				ends = started + timedelta(minutes=minutes)
				cur = conn.execute("INSERT INTO exam_sessions(user_id,paper_id,title,question_ids_json,started_at,ends_at,status,total) VALUES(?,?,?,?,?,?,?,?)", (user["user_id"], None, title, json.dumps({"ids": ids, "order": order}, ensure_ascii=False), started.strftime("%Y-%m-%d %H:%M:%S"), ends.strftime("%Y-%m-%d %H:%M:%S"), "ongoing", len(ids)))
				sid = cur.lastrowid
				qs_out = []
				for qid in ids:
					q = get_question_full(conn, qid)
					opts = {o["label"]: o for o in q["options"]}
					qs_out.append({"id": q["id"], "type": q["type"], "stem": q["stem"], "subject": q["subject"], "difficulty": q["difficulty"], "knowledge": q["knowledge"], "assets": q["assets"], "options": [{"label": lab, "content": opts[lab]["content"]} for lab in order[str(qid)]]})
				conn.commit()
				conn.close()
				audit(user["username"], "exam_start", f"场次 {sid} {title}（模板 {template_id}）{len(ids)}题 {minutes}分钟")
				return self.send_json({"ok": True, "session_id": sid, "title": title, "started_at": started.strftime("%Y-%m-%d %H:%M:%S"), "ends_at": ends.strftime("%Y-%m-%d %H:%M:%S"), "total": len(ids), "questions": qs_out})
			if paper_id:
				ids = [r["question_id"] for r in conn.execute("SELECT question_id FROM paper_items WHERE paper_id=? ORDER BY sort_order", (paper_id,)).fetchall()]
				trow = conn.execute("SELECT title FROM papers WHERE id=?", (paper_id,)).fetchone()
				title = trow["title"] if trow else "阶段考核"
			else:
				include_essay = bool(body.get("include_essay"))
				etype = "" if include_essay else " AND type NOT IN ('short','material')"
				ids = [r["id"] for r in conn.execute("SELECT id FROM questions WHERE status='published'" + etype + " ORDER BY id").fetchall()]
				title = body.get("title") or "阶段考核·通用卷"
				if body.get("subject"):
					ids = [r["id"] for r in conn.execute("SELECT id FROM questions WHERE status='published'" + etype + " AND subject=? ORDER BY id", (body["subject"],)).fetchall()]
			random.shuffle(ids)
			ids = ids[:count]
			if not ids:
				conn.close()
				return self.send_json({"ok": False, "error": "题库为空，无法开考"}, 400)
			order = {}
			for qid in ids:
				labels = [r["label"] for r in conn.execute("SELECT label FROM question_options WHERE question_id=? ORDER BY label", (qid,)).fetchall()]
				random.shuffle(labels)
				order[str(qid)] = labels
			started = datetime.now()
			ends = started + timedelta(minutes=minutes)
			cur = conn.execute("INSERT INTO exam_sessions(user_id,paper_id,title,question_ids_json,started_at,ends_at,status,total) VALUES(?,?,?,?,?,?,?,?)", (user["user_id"], paper_id, title, json.dumps({"ids": ids, "order": order}, ensure_ascii=False), started.strftime("%Y-%m-%d %H:%M:%S"), ends.strftime("%Y-%m-%d %H:%M:%S"), "ongoing", len(ids)))
			sid = cur.lastrowid
			qs_out = []
			for qid in ids:
				q = get_question_full(conn, qid)
				opts = {o["label"]: o for o in q["options"]}
				qs_out.append({"id": q["id"], "type": q["type"], "stem": q["stem"], "subject": q["subject"], "difficulty": q["difficulty"], "knowledge": q["knowledge"], "assets": q["assets"], "options": [{"label": lab, "content": opts[lab]["content"]} for lab in order[str(qid)]]})
			conn.commit()
			conn.close()
			audit(user["username"], "exam_start", f"场次 {sid} {title} {len(ids)}题 {minutes}分钟")
			return self.send_json({"ok": True, "session_id": sid, "title": title, "started_at": started.strftime("%Y-%m-%d %H:%M:%S"), "ends_at": ends.strftime("%Y-%m-%d %H:%M:%S"), "total": len(ids), "questions": qs_out})
		if path.startswith("/api/exams/") and path.endswith("/answer"):
			sid = path.split("/")[3]
			body = self.read_json()
			conn = get_db()
			s = conn.execute("SELECT * FROM exam_sessions WHERE id=? AND user_id=?", (sid, user["user_id"])).fetchone()
			if not s:
				conn.close()
				return self.send_json({"ok": False, "error": "场次不存在"}, 404)
			if s["status"] != "ongoing":
				conn.close()
				return self.send_json({"ok": False, "error": "场次已结束"}, 400)
			if datetime.now() > datetime.strptime(s["ends_at"], "%Y-%m-%d %H:%M:%S"):
				conn.close()
				return self.send_json({"ok": False, "error": "已到交卷时间，请提交"}, 400)
			qid = int(body.get("question_id") or 0)
			ans = str(body.get("answer") or "")
			with DB_LOCK:
				conn.execute("DELETE FROM attempts WHERE exam_session_id=? AND question_id=? AND mode='exam_draft'", (sid, qid))
				conn.execute("INSERT INTO attempts(user_id,question_id,mode,exam_session_id,user_answer,is_correct,version_id,answered_at) VALUES(?,?,?,?,?,?,?,?)", (user["user_id"], qid, "exam_draft", sid, ans, 0, current_version_id(conn), now_iso()))
				conn.commit()
			conn.close()
			return self.send_json({"ok": True, "saved": True})
		if path.startswith("/api/exams/") and path.endswith("/submit"):
			sid = path.split("/")[3]
			conn = get_db()
			s = conn.execute("SELECT * FROM exam_sessions WHERE id=? AND user_id=?", (sid, user["user_id"])).fetchone()
			if not s:
				conn.close()
				return self.send_json({"ok": False, "error": "场次不存在"}, 404)
			if s["status"] != "ongoing":
				conn.close()
				return self.send_json({"ok": False, "error": "已交卷"}, 400)
			data = json.loads(s["question_ids_json"])
			ids = data["ids"]
			score = 0
			essay_pending = 0
			details = []
			for qid in ids:
				draft = conn.execute("SELECT user_answer FROM attempts WHERE exam_session_id=? AND question_id=? AND mode='exam_draft' ORDER BY id DESC LIMIT 1", (sid, qid)).fetchone()
				ans = draft["user_answer"] if draft else ""
				q = get_question_full(conn, qid)
				if q["type"] in ("short", "material"):
					# 简答/材料题不自动判分：记一次待批阅作答，进批阅队列，不计入自动分
					cur = conn.execute("INSERT INTO attempts(user_id,question_id,mode,exam_session_id,user_answer,is_correct,version_id,answered_at) VALUES(?,?,?,?,?,NULL,?,?)", (user["user_id"], qid, "exam", sid, ans, q["version_id"], now_iso()))
					aid = cur.lastrowid
					conn.execute("INSERT INTO review_scores(question_id,user_id,score,comment,reviewer,attempt_id,status,max_score,created_at) VALUES(?,?,NULL,'','',?,'pending',?,?)", (qid, user["user_id"], aid, q.get("max_score", 10), now_iso()))
					details.append({"question_id": qid, "user_answer": ans, "correct_answer": "待人工批阅", "is_correct": None})
					essay_pending += 1
					continue
				ok = check_answer(q["type"], q["answer"], ans)
				if ok:
					score += 1
				details.append({"question_id": qid, "user_answer": ans, "correct_answer": q["answer"], "is_correct": ok})
				conn.execute("INSERT INTO attempts(user_id,question_id,mode,exam_session_id,user_answer,is_correct,version_id,answered_at) VALUES(?,?,?,?,?,?,?,?)", (user["user_id"], qid, "exam", sid, ans, 1 if ok else 0, q["version_id"], now_iso()))
				update_mastery(conn, user["user_id"], q["knowledge"], ok, q["difficulty"])
				update_review_schedule(conn, user["user_id"], qid, ok)
				refresh_quality_for(conn, qid)
				if not ok:
					conn.execute("INSERT INTO wrong_book(user_id,question_id,wrong_count,last_wrong_at) VALUES(?,?,1,?) ON CONFLICT(user_id,question_id) DO UPDATE SET wrong_count=wrong_count+1, last_wrong_at=excluded.last_wrong_at, mastered=0", (user["user_id"], qid, now_iso()))
			conn.execute("UPDATE exam_sessions SET submitted_at=?, score=?, status='submitted' WHERE id=?", (now_iso(), score, sid))
			conn.commit()
			conn.close()
			audit(user["username"], "exam_submit", f"场次 {sid} 得分 {score}/{len(ids)}（简答待批 {essay_pending} 道）")
			return self.send_json({"ok": True, "score": score, "total": len(ids), "details": details, "essay_pending": essay_pending})
		if path in ("/api/import/excel", "/api/import/word", "/api/import/pdf"):
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可导入"}, 403)
			ctype = self.headers.get("Content-Type") or ""
			m = re.search(r"boundary=([^\s;]+)", ctype)
			if not m:
				return self.send_json({"ok": False, "error": "请用 multipart/form-data 上传文件"}, 400)
			fields = parse_multipart(self.read_body(), m.group(1).encode())
			tup = fields.get("file")
			if not tup:
				return self.send_json({"ok": False, "error": "未收到文件"}, 400)
			filename, blob = tup
			if len(blob) > 20 * 1024 * 1024:
				return self.send_json({"ok": False, "error": "文件超过 20MB"}, 400)
			is_word = path.endswith("/word")
			is_pdf = path.endswith("/pdf")
			if is_word and filename.lower().endswith(".doc") and not filename.lower().endswith(".docx"):
				return self.send_json({"ok": False, "error": ".doc 为旧格式，请先离线转为 .docx 再导入：用本机 Word / WPS 另存为 .docx，或用 LibreOffice 离线命令 soffice --headless --convert-to docx 文件.doc（不联网）。转换后原图会保留在 docx 里。"}, 400)
			if is_pdf and not filename.lower().endswith(".pdf"):
				return self.send_json({"ok": False, "error": "请上传 .pdf 文件"}, 400)
			res = self.do_import(blob, filename, "pdf" if is_pdf else ("word" if is_word else "excel"), user)
			return self.send_json(res, 400 if not res.get("ok") else 200)
		if path.startswith("/api/import/jobs/") and path.endswith("/approve"):
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可审核"}, 403)
			jid = path.split("/")[4]
			conn = get_db()
			with DB_LOCK:
				conn.execute("UPDATE review_queue SET status='approved', reviewer=?, reviewed_at=? WHERE job_id=? AND status='pending'", (user["username"], now_iso(), jid))
				conn.commit()
			conn.close()
			audit(user["username"], "import_approve", f"导入任务 {jid} 审核通过")
			return self.send_json({"ok": True})
		if path.startswith("/api/review/") and path.endswith("/approve"):
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可审核"}, 403)
			rid = path.split("/")[3]
			conn = get_db()
			with DB_LOCK:
				conn.execute("UPDATE review_queue SET status='approved', reviewer=?, reviewed_at=? WHERE id=?", (user["username"], now_iso(), rid))
				conn.commit()
			conn.close()
			return self.send_json({"ok": True})
		if path.startswith("/api/import/pairings/") and path.endswith("/confirm"):
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可复核"}, 403)
			pid = path.split("/")[4]
			body = self.read_json()
			target = body.get("question_id")
			conn = get_db()
			row = conn.execute("SELECT * FROM image_pairings WHERE id=?", (pid,)).fetchone()
			if not row:
				conn.close()
				return self.send_json({"ok": False, "error": "配对记录不存在"}, 404)
			with DB_LOCK:
				if row["question_id"] is None:
					if not target:
						conn.close()
						return self.send_json({"ok": False, "error": "该图暂无对应题目，请指定目标题号"}, 400)
					tq = conn.execute("SELECT id FROM questions WHERE id=?", (target,)).fetchone()
					if not tq:
						conn.close()
						return self.send_json({"ok": False, "error": "目标题目不存在"}, 404)
					ppath = os.path.join(UPLOAD_DIR, os.path.basename(row["pending_path"] or ""))
					if not row["pending_path"] or not os.path.isfile(ppath):
						conn.close()
						return self.send_json({"ok": False, "error": "待指派图片文件已不存在，请重新导入"}, 400)
					with open(ppath, "rb") as f:
						blob = f.read()
					ext = (row["filename"].split(".")[-1].lower() if "." in row["filename"] else "png")
					mime = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg", "gif": "image/gif"}.get(ext, "image/png")
					aid = save_asset(conn, int(target), blob, row["filename"], mime)
					try:
						os.remove(ppath)
					except Exception:
						pass
					conn.execute("UPDATE image_pairings SET asset_id=?, question_id=?, status='confirmed' WHERE id=?", (aid, int(target), pid))
				elif target and int(target) != row["question_id"]:
					tq = conn.execute("SELECT id FROM questions WHERE id=?", (target,)).fetchone()
					if not tq:
						conn.close()
						return self.send_json({"ok": False, "error": "目标题目不存在"}, 404)
					if row["asset_id"]:
						conn.execute("UPDATE question_assets SET question_id=? WHERE id=?", (int(target), row["asset_id"]))
					conn.execute("UPDATE image_pairings SET question_id=?, status='confirmed' WHERE id=?", (int(target), pid))
				else:
					conn.execute("UPDATE image_pairings SET status='confirmed' WHERE id=?", (pid,))
				conn.commit()
			conn.close()
			audit(user["username"], "pairing_confirm", f"配对 {pid} 已确认")
			return self.send_json({"ok": True})
		if path.startswith("/api/import/pairings/") and path.endswith("/reject"):
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可复核"}, 403)
			pid = path.split("/")[4]
			conn = get_db()
			row = conn.execute("SELECT * FROM image_pairings WHERE id=?", (pid,)).fetchone()
			if not row:
				conn.close()
				return self.send_json({"ok": False, "error": "配对记录不存在"}, 404)
			with DB_LOCK:
				if row["asset_id"]:
					conn.execute("DELETE FROM question_assets WHERE id=?", (row["asset_id"],))
				if row["pending_path"]:
					try:
						os.remove(os.path.join(UPLOAD_DIR, os.path.basename(row["pending_path"])))
					except Exception:
						pass
				conn.execute("UPDATE image_pairings SET status='rejected' WHERE id=?", (pid,))
				conn.commit()
			conn.close()
			audit(user["username"], "pairing_reject", f"配对 {pid} 已驳回（图片移除）")
			return self.send_json({"ok": True})
		if path.startswith("/api/review/") and path.endswith("/reject"):
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可审核"}, 403)
			rid = path.split("/")[3]
			conn = get_db()
			with DB_LOCK:
				r = conn.execute("SELECT question_id FROM review_queue WHERE id=?", (rid,)).fetchone()
				conn.execute("UPDATE review_queue SET status='rejected', reviewer=?, reviewed_at=? WHERE id=?", (user["username"], now_iso(), rid))
				if r and r["question_id"]:
					conn.execute("UPDATE questions SET status='rejected' WHERE id=?", (r["question_id"],))
				conn.commit()
			conn.close()
			return self.send_json({"ok": True})
		if path == "/api/templates":
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可建模板"}, 403)
			body = self.read_json()
			title = (body.get("title") or "").strip()
			if not title:
				return self.send_json({"ok": False, "error": "模板要有标题"}, 400)
			try:
				rules = body.get("rules") or {}
				if isinstance(rules, str):
					rules = json.loads(rules)
			except Exception:
				return self.send_json({"ok": False, "error": "配比规则不是有效 JSON"}, 400)
			conn = get_db()
			cur = conn.execute("INSERT INTO paper_templates(title,subject,total_count,rules_json,created_by,created_at) VALUES(?,?,?,?,?,?)", (title, body.get("subject") or "", int(body.get("total_count") or 10), json.dumps(rules, ensure_ascii=False), user["username"], now_iso()))
			tid = cur.lastrowid
			conn.commit()
			conn.close()
			audit(user["username"], "template_create", f"组卷模板 {tid} {title}")
			return self.send_json({"ok": True, "template_id": tid})
		if path.startswith("/api/questions/") and path.endswith("/status"):
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可操作"}, 403)
			qid = path.split("/")[3]
			body = self.read_json()
			st = body.get("status") or ""
			if st not in ("published", "review", "disabled"):
				return self.send_json({"ok": False, "error": "状态只能是 published / review / disabled"}, 400)
			conn = get_db()
			with DB_LOCK:
				conn.execute("UPDATE questions SET status=? WHERE id=?", (st, qid))
				conn.commit()
			conn.close()
			audit(user["username"], "question_status", f"题目 {qid} 改为 {st}")
			return self.send_json({"ok": True})
		if path == "/api/quality/refresh":
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可操作"}, 403)
			conn = get_db()
			with DB_LOCK:
				for r in conn.execute("SELECT id FROM questions").fetchall():
					refresh_quality_for(conn, r["id"])
				conn.commit()
			conn.close()
			return self.send_json({"ok": True})
		if path == "/api/bank/publish":
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可发布"}, 403)
			body = self.read_json()
			conn = get_db()
			with DB_LOCK:
				approved = [r["question_id"] for r in conn.execute("SELECT DISTINCT question_id FROM review_queue WHERE status='approved' AND question_id IS NOT NULL").fetchall()]
				if not approved:
					approved = [r["id"] for r in conn.execute("SELECT id FROM questions WHERE status='draft'").fetchall()]
				if not approved:
					conn.close()
					return self.send_json({"ok": False, "error": "没有可发布的草稿题（请先导入并审核通过）"}, 400)
				n_ver = conn.execute("SELECT COUNT(*) n FROM bank_versions").fetchone()["n"]
				ver_no = f"v1.0.{n_ver}"
				while conn.execute("SELECT id FROM bank_versions WHERE version_no=?", (ver_no,)).fetchone():
					n_ver += 1
					ver_no = f"v1.0.{n_ver}"
				conn.execute("UPDATE bank_versions SET is_current=0")
				cur = conn.execute("INSERT INTO bank_versions(version_no,note,question_count,is_current,created_by,created_at) VALUES(?,?,?,?,?,?)", (ver_no, body.get("note") or "导入发布", len(approved), 1, user["username"], now_iso()))
				vid = cur.lastrowid
				for qid in approved:
					conn.execute("UPDATE questions SET status='published', version_id=? WHERE id=?", (vid, qid))
					conn.execute("INSERT OR IGNORE INTO bank_version_items(version_id,question_id) VALUES(?,?)", (vid, qid))
				conn.execute("UPDATE review_queue SET status='published' WHERE status='approved' AND question_id IN (%s)" % ",".join("?" * len(approved)), approved)
				conn.commit()
			conn.close()
			audit(user["username"], "bank_publish", f"发布 {ver_no}，{len(approved)} 题")
			return self.send_json({"ok": True, "version": ver_no, "count": len(approved)})
		if path == "/api/bank/rollback":
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可回滚"}, 403)
			body = self.read_json()
			vid = int(body.get("version_id") or 0)
			conn = get_db()
			row = conn.execute("SELECT * FROM bank_versions WHERE id=?", (vid,)).fetchone()
			if not row:
				conn.close()
				return self.send_json({"ok": False, "error": "版本不存在"}, 404)
			with DB_LOCK:
				conn.execute("UPDATE bank_versions SET is_current=0")
				conn.execute("UPDATE bank_versions SET is_current=1 WHERE id=?", (vid,))
				conn.commit()
			conn.close()
			audit(user["username"], "bank_rollback", f"回滚到 {row['version_no']}")
			return self.send_json({"ok": True, "version": row["version_no"]})
		if path.startswith("/api/wrong/") and path.endswith("/mastered"):
			qid = int(path.split("/")[3])
			conn = get_db()
			with DB_LOCK:
				conn.execute("UPDATE wrong_book SET mastered=1 WHERE user_id=? AND question_id=?", (user["user_id"], qid))
				conn.commit()
			conn.close()
			return self.send_json({"ok": True})
		if path == "/api/federation/hosts":
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可登记"}, 403)
			body = self.read_json()
			name = (body.get("name") or "").strip()
			host = (body.get("host") or "").strip()
			token = (body.get("token") or "").strip()
			try:
				port = int(body.get("port") or 8765)
			except Exception:
				return self.send_json({"ok": False, "error": "端口要是数字"}, 400)
			if not name or not host or not token:
				return self.send_json({"ok": False, "error": "名称、对方主机地址、共享令牌都要填"}, 400)
			if "://" in host or "/" in host or " " in host:
				return self.send_json({"ok": False, "error": "对方主机地址只填 IP 或主机名，不要带 http:// 和路径"}, 400)
			if not (1 <= port <= 65535):
				return self.send_json({"ok": False, "error": "端口应在 1 到 65535 之间"}, 400)
			conn = get_db()
			ex = conn.execute("SELECT id FROM peer_hosts WHERE host=? AND port=?", (host, port)).fetchone()
			with DB_LOCK:
				if ex:
					conn.execute("UPDATE peer_hosts SET name=?, token=?, status='enabled' WHERE id=?", (name, token, ex["id"]))
					hid = ex["id"]
				else:
					cur = conn.execute("INSERT INTO peer_hosts(name,host,port,token,status,created_at) VALUES(?,?,?,?,?,?)", (name, host, port, token, "enabled", now_iso()))
					hid = cur.lastrowid
				conn.commit()
			conn.close()
			audit(user["username"], "fed_register", f"登记联邦主机 {name} {host}:{port}")
			return self.send_json({"ok": True, "host_id": hid})
		if path.startswith("/api/federation/hosts/") and path.endswith("/delete"):
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可删除"}, 403)
			try:
				hid = int(path.split("/")[4])
			except Exception:
				return self.send_json({"ok": False, "error": "主机不存在"}, 404)
			conn = get_db()
			with DB_LOCK:
				conn.execute("DELETE FROM peer_hosts WHERE id=?", (hid,))
				conn.commit()
			conn.close()
			audit(user["username"], "fed_delete", f"删除联邦主机 {hid}")
			return self.send_json({"ok": True})
		if path.startswith("/api/federation/hosts/") and path.endswith("/test"):
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可测试"}, 403)
			try:
				hid = int(path.split("/")[4])
			except Exception:
				return self.send_json({"ok": False, "error": "主机不存在"}, 404)
			conn = get_db()
			h = conn.execute("SELECT * FROM peer_hosts WHERE id=?", (hid,)).fetchone()
			if not h:
				conn.close()
				return self.send_json({"ok": False, "error": "主机不存在"}, 404)
			try:
				cat = fed_request(h["host"], h["port"], h["token"], "GET", "/api/federation/catalog")
				n = (cat.get("catalog") or {}).get("question_count", 0)
				with DB_LOCK:
					conn.execute("UPDATE peer_hosts SET last_seen=?, last_error='', last_count=? WHERE id=?", (now_iso(), n, hid))
					conn.commit()
				conn.close()
				return self.send_json({"ok": True, "catalog": cat.get("catalog")})
			except Exception as e:
				with DB_LOCK:
					conn.execute("UPDATE peer_hosts SET last_error=? WHERE id=?", (str(e)[:200], hid))
					conn.commit()
				conn.close()
				return self.send_json({"ok": False, "error": str(e)}, 400)
		if path == "/api/federation/pull":
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可拉取"}, 403)
			body = self.read_json()
			try:
				hid = int(body.get("host_id") or 0)
			except Exception:
				return self.send_json({"ok": False, "error": "请先选择对方主机"}, 400)
			conn = get_db()
			h = conn.execute("SELECT * FROM peer_hosts WHERE id=?", (hid,)).fetchone()
			if not h:
				conn.close()
				return self.send_json({"ok": False, "error": "对方主机不存在"}, 404)
			if h["status"] != "enabled":
				conn.close()
				return self.send_json({"ok": False, "error": "该主机已停用，请先在登记里恢复"}, 400)
			try:
				res = fed_request(h["host"], h["port"], h["token"], "POST", "/api/federation/package", {"question_ids": body.get("question_ids") or [], "subject": body.get("subject") or "", "limit": body.get("limit") or 50})
			except Exception as e:
				conn.close()
				return self.send_json({"ok": False, "error": str(e)}, 400)
			pkg = res.get("package") or {}
			sha = res.get("sha256", "")
			expect = hashlib.sha256(json.dumps(pkg, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
			if sha != expect:
				conn.close()
				return self.send_json({"ok": False, "error": "共享包哈希校验失败，已拒绝导入（可能传输中被改动）"}, 400)
			incoming = pkg.get("questions") or []
			if not incoming:
				conn.close()
				return self.send_json({"ok": False, "error": "对方题库里没有可拉取的题目"}, 400)
			existing = {}
			for r in conn.execute("SELECT id, stem, answer FROM questions").fetchall():
				opts = [o["content"] for o in conn.execute("SELECT content FROM question_options WHERE question_id=? ORDER BY label", (r["id"],)).fetchall()]
				existing[content_hash(r["stem"], r["answer"], opts)] = r["id"]
			peer_label = f"联邦:{h['name']}"
			cur = conn.execute("INSERT INTO import_jobs(filename,file_type,total_rows,ok_rows,bad_rows,status,created_by,created_at) VALUES(?,?,?,?,?,?,?,?)", (f"联邦包@{h['name']}（{len(incoming)} 题）", "federation", len(incoming), 0, 0, "parsed", user["username"], now_iso()))
			job_id = cur.lastrowid
			imported = 0
			skipped = 0
			with DB_LOCK:
				for i, q in enumerate(incoming):
					opts = q.get("options") or []
					hh = content_hash(q.get("stem", ""), q.get("answer", ""), opts)
					if hh in existing:
						skipped += 1
						continue
					d = {"row_no": i + 1, "stem": q.get("stem", ""), "type": q.get("type", "single"), "answer": q.get("answer", ""), "explanation": q.get("explanation", ""), "subject": q.get("subject", "未分类"), "knowledge": q.get("knowledge") or ["未分类"], "difficulty": q.get("difficulty", 3), "rubric": q.get("rubric", ""), "max_score": q.get("max_score", 10), "options_list": opts}
					cleaned, verr = validate_row(d)
					if verr:
						conn.execute("INSERT INTO import_items(job_id,row_no,raw_json,error,status) VALUES(?,?,?,?,?)", (job_id, i + 1, json.dumps(d, ensure_ascii=False), verr, "bad"))
						continue
					conn.execute("INSERT INTO questions(type,stem,answer,explanation,subject,difficulty,source,status,version_id,created_by,created_at,rubric,max_score,parent_id) VALUES(?,?,?,?,?,?,?,?,NULL,?,?,?,?,NULL)", (cleaned["type"], cleaned["stem"], cleaned["answer"], cleaned["explanation"], cleaned["subject"], cleaned["difficulty"], peer_label, "draft", user["username"], now_iso(), cleaned.get("rubric", ""), cleaned.get("max_score", 10)))
					qid = conn.execute("SELECT last_insert_rowid() id").fetchone()["id"]
					for j, opt in enumerate(cleaned["options"]):
						conn.execute("INSERT INTO question_options(question_id,label,content) VALUES(?,?,?)", (qid, chr(65 + j), opt))
					for kn in cleaned["knowledge"]:
						conn.execute("INSERT OR IGNORE INTO knowledge_nodes(name,subject) VALUES(?,?)", (kn, cleaned["subject"]))
						kid = conn.execute("SELECT id FROM knowledge_nodes WHERE name=?", (kn,)).fetchone()["id"]
						conn.execute("INSERT OR IGNORE INTO question_knowledge(question_id,knowledge_id) VALUES(?,?)", (qid, kid))
					for a in q.get("assets") or []:
						try:
							blob = base64.b64decode(a.get("data_b64", ""))
							if blob:
								save_asset(conn, qid, blob, a.get("filename", "image.png"), a.get("mime", "image/png"), a.get("option_label"))
						except Exception:
							continue
					conn.execute("INSERT INTO import_items(job_id,row_no,raw_json,error,status) VALUES(?,?,?,?,?)", (job_id, i + 1, json.dumps(cleaned, ensure_ascii=False), "", "ok"))
					conn.execute("INSERT INTO review_queue(job_id,question_id,row_no,reason,status) VALUES(?,?,?,?,?)", (job_id, qid, i + 1, "联邦拉取，待审核", "pending"))
					existing[hh] = qid
					imported += 1
				conn.execute("UPDATE import_jobs SET ok_rows=?, bad_rows=? WHERE id=?", (imported, len(incoming) - imported - skipped, job_id))
				conn.execute("INSERT INTO federation_packages(host_id,direction,filename,sha256,question_count,status,created_by,created_at) VALUES(?,?,?,?,?,?,?,?)", (hid, "in", f"联邦包@{h['name']}", sha, imported, "ok", user["username"], now_iso()))
				conn.commit()
			conn.close()
			audit(user["username"], "fed_pull", f"从 {h['name']} 拉取联邦包：新题 {imported}，去重跳过 {skipped}，进草稿待审核（任务 {job_id}）")
			return self.send_json({"ok": True, "job_id": job_id, "imported": imported, "skipped_dup": skipped, "total": len(incoming), "sha256": sha, "message": f"已拉取 {imported} 道新题进草稿（去重 {skipped} 道），请在“题库导入”里审核后发布"})
		if path == "/api/backup/create":
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可备份"}, 403)
			body = self.read_json()
			note = (body.get("note") or "手动备份").strip() or "手动备份"
			try:
				res = make_backup(note, user["username"])
			except Exception as e:
				return self.send_json({"ok": False, "error": f"备份失败：{e}"}, 500)
			prune_backups()
			audit(user["username"], "backup_create", f"备份 {res['filename']}（{res['size_bytes']} 字节）")
			return self.send_json(res)
		if path == "/api/backup/restore":
			if user["role"] not in ("admin",):
				return self.send_json({"ok": False, "error": "仅管理员可恢复备份"}, 403)
			body = self.read_json()
			res = restore_backup_file(body.get("filename") or "", user["username"])
			return self.send_json(res, 400 if not res.get("ok") else 200)
		if path == "/api/ai/variants":
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可生成变式"}, 403)
			body = self.read_json()
			try:
				qid = int(body.get("question_id") or 0)
				count = min(max(int(body.get("count") or 2), 1), 3)
			except Exception:
				return self.send_json({"ok": False, "error": "题目 ID 或数量不正确"}, 400)
			conn = get_db()
			q = get_question_full(conn, qid)
			if not q:
				conn.close()
				return self.send_json({"ok": False, "error": "母题不存在"}, 404)
			if q["type"] in ("short", "material"):
				conn.close()
				return self.send_json({"ok": False, "error": "简答/材料题暂不支持变式（只有选择/判断题可变式）"}, 400)
			if q["status"] != "published":
				conn.close()
				return self.send_json({"ok": False, "error": "只有已发布的题目才能生成变式"}, 400)
			vars_ = make_variants(q, count)
			if not vars_:
				conn.close()
				return self.send_json({"ok": False, "error": "这道题没有可替换的槽位（选项少于 3 个且题干无可换表述/数字），无法生成变式"}, 400)
			ids = []
			with DB_LOCK:
				for v in vars_:
					conn.execute("INSERT INTO questions(type,stem,answer,explanation,subject,difficulty,source,status,version_id,created_by,created_at,rubric,max_score,parent_id) VALUES(?,?,?,?,?,?,?,?,NULL,?,?,?,?,?)", (q["type"], v["stem"], v["answer"], v["explanation"], q["subject"], q["difficulty"], f"变式·母题#{qid}（{v['kind']}）", "draft", user["username"], now_iso(), q.get("rubric", ""), q.get("max_score", 10), qid))
					vid = conn.execute("SELECT last_insert_rowid() id").fetchone()["id"]
					for j, opt in enumerate(v["options"]):
						conn.execute("INSERT INTO question_options(question_id,label,content) VALUES(?,?,?)", (vid, chr(65 + j), opt))
					for kn in q.get("knowledge", []):
						conn.execute("INSERT OR IGNORE INTO knowledge_nodes(name,subject) VALUES(?,?)", (kn, q["subject"]))
						kid = conn.execute("SELECT id FROM knowledge_nodes WHERE name=?", (kn,)).fetchone()["id"]
						conn.execute("INSERT OR IGNORE INTO question_knowledge(question_id,knowledge_id) VALUES(?,?)", (vid, kid))
					ids.append(vid)
				conn.execute("INSERT INTO ai_jobs(kind,input_json,status,result_json,created_at) VALUES(?,?,?,?,?)", ("variant", json.dumps({"question_id": qid, "count": count}, ensure_ascii=False), "done", json.dumps({"variant_ids": ids, "kinds": [v["kind"] for v in vars_], "notes": [v["note"] for v in vars_]}, ensure_ascii=False), now_iso()))
				conn.commit()
			conn.close()
			audit(user["username"], "ai_variant", f"母题 {qid} 生成变式 {len(ids)} 道（{','.join(v['kind'] for v in vars_)}），待人工审核")
			return self.send_json({"ok": True, "variant_ids": ids, "kinds": [v["kind"] for v in vars_], "notes": [v["note"] for v in vars_], "message": "变式已生成进草稿，须人工审核通过后才能发布"})
		if path.startswith("/api/ai/variants/") and path.endswith("/approve"):
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可审核"}, 403)
			try:
				vid = int(path.split("/")[4])
			except Exception:
				return self.send_json({"ok": False, "error": "变式不存在"}, 404)
			conn = get_db()
			row = conn.execute("SELECT * FROM questions WHERE id=? AND source LIKE '变式·%'", (vid,)).fetchone()
			if not row:
				conn.close()
				return self.send_json({"ok": False, "error": "变式不存在"}, 404)
			if row["status"] == "published":
				conn.close()
				return self.send_json({"ok": False, "error": "该变式已发布过，不能重复审核"}, 400)
			vid_cur = current_version_id(conn)
			with DB_LOCK:
				conn.execute("UPDATE questions SET status='published', version_id=? WHERE id=?", (vid_cur, vid))
				conn.execute("INSERT OR IGNORE INTO bank_version_items(version_id,question_id) VALUES(?,?)", (vid_cur, vid))
				conn.commit()
			conn.close()
			audit(user["username"], "ai_variant_approve", f"变式 {vid} 审核通过并发布")
			return self.send_json({"ok": True})
		if path.startswith("/api/ai/variants/") and path.endswith("/reject"):
			if user["role"] not in ("admin", "instructor"):
				return self.send_json({"ok": False, "error": "仅管理员/教官可审核"}, 403)
			try:
				vid = int(path.split("/")[4])
			except Exception:
				return self.send_json({"ok": False, "error": "变式不存在"}, 404)
			conn = get_db()
			row = conn.execute("SELECT * FROM questions WHERE id=? AND source LIKE '变式·%'", (vid,)).fetchone()
			if not row:
				conn.close()
				return self.send_json({"ok": False, "error": "变式不存在"}, 404)
			with DB_LOCK:
				conn.execute("UPDATE questions SET status='disabled' WHERE id=?", (vid,))
				conn.commit()
			conn.close()
			audit(user["username"], "ai_variant_reject", f"变式 {vid} 审核驳回")
			return self.send_json({"ok": True})
		self.send_json({"ok": False, "error": "未知接口"}, 404)
	def _fed_package(self):
		# 对方主机拉包用：只认联邦令牌；只发已发布题 + 选项 + 图片，不发成绩/密码/用户信息。
		tok = parse_qs(urlparse(self.path).query).get("token", [""])[0]
		if not hmac.compare_digest(tok, fed_token()):
			return self.send_json({"ok": False, "error": "联邦令牌不正确"}, 401)
		body = self.read_json()
		conn = get_db()
		qids = body.get("question_ids") or []
		rows = []
		if qids:
			for x in qids[:500]:
				try:
					q = get_question_full(conn, int(x))
				except Exception:
					q = None
				if q and q["status"] == "published":
					rows.append(q)
		else:
			subj = (body.get("subject") or "").strip()
			try:
				limit = min(max(int(body.get("limit") or 50), 1), 500)
			except Exception:
				limit = 50
			if subj:
				ids = conn.execute("SELECT id FROM questions WHERE status='published' AND subject=? ORDER BY id LIMIT ?", (subj, limit)).fetchall()
			else:
				ids = conn.execute("SELECT id FROM questions WHERE status='published' ORDER BY id LIMIT ?", (limit,)).fetchall()
			rows = [get_question_full(conn, r["id"]) for r in ids]
		pkg_qs = []
		for q in rows:
			assets = []
			for a in q.get("assets", []):
				fp = a.get("path") or ""
				if not os.path.isfile(fp):
					fp = os.path.join(ASSETS_DIR, os.path.basename(fp))
				if os.path.isfile(fp):
					try:
						with open(fp, "rb") as f:
							assets.append({"filename": a.get("filename", os.path.basename(fp)), "mime": a.get("mime", "image/png"), "option_label": a.get("option_label"), "data_b64": base64.b64encode(f.read()).decode()})
					except Exception:
						continue
			pkg_qs.append({"type": q["type"], "stem": q["stem"], "answer": q["answer"], "explanation": q.get("explanation", ""), "subject": q.get("subject", ""), "difficulty": q.get("difficulty", 3), "knowledge": q.get("knowledge", []), "rubric": q.get("rubric", ""), "max_score": q.get("max_score", 10), "options": [o["content"] for o in q["options"]], "assets": assets})
		pkg = {"from": "常熟边检站刷题宝", "version": VERSION, "exported_at": now_iso(), "questions": pkg_qs}
		sha = hashlib.sha256(json.dumps(pkg, ensure_ascii=False, sort_keys=True).encode()).hexdigest()
		conn.close()
		return self.send_json({"ok": True, "package": pkg, "sha256": sha})
	def submit_answer(self, user, qid, ans, mode="practice"):
		if not qid:
			return {"ok": False, "error": "缺少题目"}
		conn = get_db()
		q = get_question_full(conn, qid)
		if not q:
			conn.close()
			return {"ok": False, "error": "题目不存在"}
		if q["type"] in ("short", "material"):
			conn.close()
			return {"ok": False, "error": "简答/材料题请用文字提交，待教官人工批阅，不自动判分"}
		ok = check_answer(q["type"], q["answer"], ans)
		with DB_LOCK:
			conn.execute("INSERT INTO attempts(user_id,question_id,mode,user_answer,is_correct,version_id,answered_at) VALUES(?,?,?,?,?,?,?)", (user["user_id"], qid, mode if mode in ("practice", "exam") else "practice", ans, 1 if ok else 0, q["version_id"], now_iso()))
			update_mastery(conn, user["user_id"], q["knowledge"], ok, q["difficulty"])
			update_review_schedule(conn, user["user_id"], qid, ok)
			refresh_quality_for(conn, qid)
			if not ok:
				conn.execute("INSERT INTO wrong_book(user_id,question_id,wrong_count,last_wrong_at) VALUES(?,?,1,?) ON CONFLICT(user_id,question_id) DO UPDATE SET wrong_count=wrong_count+1, last_wrong_at=excluded.last_wrong_at, mastered=0", (user["user_id"], qid, now_iso()))
			else:
				conn.execute("UPDATE wrong_book SET mastered=1 WHERE user_id=? AND question_id=? AND wrong_count=0", (user["user_id"], qid))
			conn.commit()
		conn.close()
		return {"ok": True, "is_correct": ok, "correct_answer": q["answer"], "explanation": q["explanation"]}
	def do_import(self, blob, filename, file_type, user):
		conn = get_db()
		cur = conn.execute("INSERT INTO import_jobs(filename,file_type,total_rows,ok_rows,bad_rows,status,created_by,created_at) VALUES(?,?,?,?,?,?,?,?)", (filename, file_type, 0, 0, 0, "parsed", user["username"], now_iso()))
		job_id = cur.lastrowid
		parsed = []
		parsed_orphans = []
		err = ""
		if file_type == "excel":
			rows, images_by_row, err = parse_xlsx(blob)
			for d in rows:
				parsed.append((d.get("row_no"), d, list(images_by_row.get(d.get("row_no"), []))))
			for arow, imgs in list(images_by_row.items()):
				if any(p[0] == arow for p in parsed):
					continue
				nxt = [p for p in parsed if p[0] > arow]
				if nxt:
					nxt[0][2].extend(imgs)
				elif parsed:
					# 锚点行在所有题行之后：挂到最后一题，距离大→置信度低，进人工队列，不静默丢图
					parsed[-1][2].extend(imgs)
		elif file_type == "pdf":
			questions, pinfo, err = parse_pdf(blob)
			if err:
				conn.execute("UPDATE import_jobs SET status='failed' WHERE id=?", (job_id,))
				conn.commit()
				conn.close()
				return {"ok": False, "error": err, "job_id": job_id, "pdf_info": pinfo}
			for i, q in enumerate(questions):
				d = {"row_no": i + 1, "stem": q["stem"], "type": q["type"], "answer": q["answer"], "explanation": q["explanation"], "subject": q["subject"], "knowledge": q["knowledge"], "difficulty": q["difficulty"], "rubric": q.get("rubric", ""), "max_score": q.get("max_score", 10), "options_list": q.get("options_list", [])}
				parsed.append((i + 1, d, q.get("images", [])))
		else:
			questions, err, orphans = parse_docx(blob)
			for i, q in enumerate(questions):
				d = {"row_no": i + 1, "stem": q["stem"], "type": q["type"], "answer": q["answer"], "explanation": q["explanation"], "subject": q["subject"], "knowledge": q["knowledge"], "difficulty": q["difficulty"], "rubric": q.get("rubric", ""), "max_score": q.get("max_score", 10), "options_list": q.get("options_list", [])}
				parsed.append((i + 1, d, q.get("images", [])))
			for im in orphans:
				parsed_orphans.append(im)
		if err:
			conn.execute("UPDATE import_jobs SET status='failed' WHERE id=?", (job_id,))
			conn.commit()
			conn.close()
			return {"ok": False, "error": err, "job_id": job_id}
		ok_n = 0
		bad_n = 0
		bad_list = []
		row_qids = {}
		pending_parents = []
		pair_counts = {"auto": 0, "review": 0, "manual": 0}
		pair_items = []
		with DB_LOCK:
			for row_no, d, imgs in parsed:
				cleaned, verr = validate_row(d)
				if verr:
					bad_n += 1
					bad_list.append({"row_no": row_no, "error": verr})
					conn.execute("INSERT INTO import_items(job_id,row_no,raw_json,error,status) VALUES(?,?,?,?,?)", (job_id, row_no, json.dumps(d, ensure_ascii=False), verr, "bad"))
					conn.execute("INSERT INTO review_queue(job_id,question_id,row_no,reason,status) VALUES(?,?,?,?,?)", (job_id, None, row_no, verr, "needs_fix"))
					continue
				ok_n += 1
				conn.execute("INSERT INTO questions(type,stem,answer,explanation,subject,difficulty,source,status,version_id,created_by,created_at,rubric,max_score,parent_id) VALUES(?,?,?,?,?,?,?,?,NULL,?,?,?,?,NULL)", (cleaned["type"], cleaned["stem"], cleaned["answer"], cleaned["explanation"], cleaned["subject"], cleaned["difficulty"], f"导入:{filename}", "draft", user["username"], now_iso(), cleaned.get("rubric", ""), cleaned.get("max_score", 10)))
				qid = conn.execute("SELECT last_insert_rowid() id").fetchone()["id"]
				row_qids[row_no] = qid
				if cleaned.get("parent_row"):
					try:
						pending_parents.append((qid, int(cleaned["parent_row"])))
					except Exception:
						pass
				for i, opt in enumerate(cleaned["options"]):
					conn.execute("INSERT INTO question_options(question_id,label,content) VALUES(?,?,?)", (qid, chr(65 + i), opt))
				for kn in cleaned["knowledge"]:
					conn.execute("INSERT OR IGNORE INTO knowledge_nodes(name,subject) VALUES(?,?)", (kn, cleaned["subject"]))
					kid = conn.execute("SELECT id FROM knowledge_nodes WHERE name=?", (kn,)).fetchone()["id"]
					conn.execute("INSERT OR IGNORE INTO question_knowledge(question_id,knowledge_id) VALUES(?,?)", (qid, kid))
				for img in imgs:
					aid = save_asset(conn, qid, img["bytes"], img["filename"], img["mime"])
					if "dist" in img:
						dist = img.get("dist")
					else:
						dist = abs(int(img.get("anchor_row", row_no)) - int(row_no))
					conf = pairing_confidence(dist)
					st = pairing_status(conf)
					pair_counts[st] += 1
					anchor_txt = f"锚点行{img.get('anchor_row')}" if img.get("anchor_row") else f"锚点段落距题干{dist}段"
					conn.execute("INSERT INTO image_pairings(job_id,asset_id,question_id,filename,confidence,status,reason,created_at) VALUES(?,?,?,?,?,?,?,?)", (job_id, aid, qid, img["filename"], conf, st, f"{anchor_txt}，置信度 {conf:.2f}（{'自动通过' if st == 'auto' else ('需复核' if st == 'review' else '需人工指定')}）", now_iso()))
					pair_items.append({"filename": img["filename"], "question_id": qid, "confidence": conf, "status": st})
				conn.execute("INSERT INTO import_items(job_id,row_no,raw_json,error,status) VALUES(?,?,?,?,?)", (job_id, row_no, json.dumps(cleaned, ensure_ascii=False), "", "ok"))
				conn.execute("INSERT INTO review_queue(job_id,question_id,row_no,reason,status) VALUES(?,?,?,?,?)", (job_id, qid, row_no, "待审核", "pending"))
			for qid, prow in pending_parents:
				if prow in row_qids:
					conn.execute("UPDATE questions SET parent_id=? WHERE id=?", (row_qids[prow], qid))
			for im in parsed_orphans:
				try:
					h = hashlib.sha256(im["bytes"]).hexdigest()[:16]
					ext = (im["filename"].split(".")[-1].lower() if "." in im["filename"] else "png")
					if ext not in ("png", "jpg", "jpeg", "gif", "bmp"):
						ext = "png"
					pname = f"pending_{job_id}_{h}.{ext}"
					with open(os.path.join(UPLOAD_DIR, pname), "wb") as f:
						f.write(im["bytes"])
					pair_counts["manual"] += 1
					conn.execute("INSERT INTO image_pairings(job_id,asset_id,question_id,filename,confidence,status,reason,pending_path,created_at) VALUES(?,?,?,?,?,?,?,?,?)", (job_id, None, None, im["filename"], 0.40, "manual", "图片所在段落无对应题号，需人工指定题目", pname, now_iso()))
					pair_items.append({"filename": im["filename"], "question_id": None, "confidence": 0.40, "status": "manual"})
				except Exception:
					pass
			conn.execute("UPDATE import_jobs SET total_rows=?, ok_rows=?, bad_rows=?, status='parsed', pairing_auto=?, pairing_review=?, pairing_manual=?, pairing_report_json=? WHERE id=?", (len(parsed), ok_n, bad_n, pair_counts["auto"], pair_counts["review"], pair_counts["manual"], json.dumps({"auto": pair_counts["auto"], "review": pair_counts["review"], "manual": pair_counts["manual"], "items": pair_items[:200]}, ensure_ascii=False), job_id))
			conn.commit()
		conn.close()
		audit(user["username"], "import", f"{filename} 解析 {len(parsed)} 行，通过 {ok_n}，待修 {bad_n}；配对自动 {pair_counts['auto']} / 复核 {pair_counts['review']} / 人工 {pair_counts['manual']}")
		return {"ok": True, "job_id": job_id, "total": len(parsed), "ok": ok_n, "bad": bad_n, "bad_list": bad_list, "pairing": pair_counts}
# ---------------- v0.6：备份 / 联邦 / 本地 AI 变式（纯标准库） ----------------
def get_setting(key, default=""):
	try:
		conn = get_db()
		row = conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
		conn.close()
		return row["value"] if row else default
	except Exception:
		return default

def set_setting(key, value):
	conn = get_db()
	with DB_LOCK:
		conn.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value", (key, value))
		conn.commit()
	conn.close()

def fed_token():
	tok = get_setting("fed_token")
	if not tok:
		tok = secrets.token_urlsafe(24)
		set_setting("fed_token", tok)
	return tok

def content_hash(stem, answer, options):
	raw = json.dumps([stem.strip(), str(answer).strip(), [str(o).strip() for o in options]], ensure_ascii=False)
	return hashlib.sha256(raw.encode()).hexdigest()

def disk_status():
	try:
		du = shutil.disk_usage(BASE)
		return {"total_gb": round(du.total / 1024 ** 3, 1), "free_gb": round(du.free / 1024 ** 3, 1), "used_pct": round(100 * (du.total - du.free) / du.total, 1) if du.total else 0}
	except Exception:
		return {"total_gb": 0, "free_gb": 0, "used_pct": 0}

def list_backups():
	conn = get_db()
	rows = [qdict(r) for r in conn.execute("SELECT * FROM backups_meta ORDER BY id DESC").fetchall()]
	conn.close()
	return rows

def make_backup(note, user):
	"""一键备份：数据库 + 题库附件 + 待指派图片，打成带时间戳的 zip。返回 dict。"""
	os.makedirs(BACKUP_DIR, exist_ok=True)
	conn = get_db()
	try:
		conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
	except Exception:
		pass
	conn.close()
	ts = datetime.now().strftime("%Y%m%d-%H%M%S")
	fname = f"backup-{ts}.zip"
	fpath = os.path.join(BACKUP_DIR, fname)
	_n = 2
	while os.path.exists(fpath):
		fname = f"backup-{ts}-{_n}.zip"
		fpath = os.path.join(BACKUP_DIR, fname)
		_n += 1
	with zipfile.ZipFile(fpath, "w", zipfile.ZIP_DEFLATED) as z:
		if os.path.isfile(DB_PATH):
			z.write(DB_PATH, "shuati.db")
		for folder, prefix in ((ASSETS_DIR, "assets"), (UPLOAD_DIR, "uploads")):
			if os.path.isdir(folder):
				for fn in sorted(os.listdir(folder)):
					fp = os.path.join(folder, fn)
					if os.path.isfile(fp):
						z.write(fp, f"{prefix}/{fn}")
	size = os.path.getsize(fpath)
	conn = get_db()
	with DB_LOCK:
		conn.execute("INSERT INTO backups_meta(filename,note,created_at,size_bytes,status) VALUES(?,?,?,?,?)", (fname, note, now_iso(), size, "ok"))
		conn.commit()
	conn.close()
	return {"ok": True, "filename": fname, "size_bytes": size, "note": note}

def prune_backups(keep=AUTO_BACKUP_KEEP):
	"""只保留最近 keep 份备份，旧的连文件带记录一起删。返回删掉的份数。"""
	rows = list_backups()
	removed = 0
	for r in rows[keep:]:
		try:
			fp = os.path.join(BACKUP_DIR, r["filename"])
			if os.path.isfile(fp):
				os.remove(fp)
			conn = get_db()
			with DB_LOCK:
				conn.execute("DELETE FROM backups_meta WHERE id=?", (r["id"],))
				conn.commit()
			conn.close()
			removed += 1
		except Exception:
			continue
	return removed

def restore_backup_file(fname, user):
	"""恢复备份：先自动再备一份当前库防丢，再用 sqlite 备份 API 把备份库写回当前库，附件按包内文件替换。"""
	safe = os.path.basename(fname or "")
	if not safe.endswith(".zip") or "/" in fname or "\\" in fname:
		return {"ok": False, "error": "备份文件名不正确"}
	fpath = os.path.join(BACKUP_DIR, safe)
	if not os.path.isfile(fpath):
		return {"ok": False, "error": "备份文件不存在"}
	# 先解包源备份，再做恢复前自动备份：自动备份绝不能覆盖正要恢复的源文件。
	tmpd = os.path.join(BACKUP_DIR, "_restore_tmp")
	shutil.rmtree(tmpd, ignore_errors=True)
	os.makedirs(tmpd, exist_ok=True)
	try:
		with zipfile.ZipFile(fpath) as z:
			names = z.namelist()
			if "shuati.db" not in names:
				return {"ok": False, "error": "备份包里没有数据库文件，无法恢复"}
			z.extractall(tmpd)
	except Exception as e:
		return {"ok": False, "error": f"备份包损坏，无法解包：{e}"}
	auto = make_backup("恢复前自动备份（恢复 " + safe + " 之前）", user)
	try:
		src_db = os.path.join(tmpd, "shuati.db")
		src_conn = sqlite3.connect(src_db)
		dst_conn = get_db()
		try:
			src_conn.backup(dst_conn)
		finally:
			src_conn.close()
			dst_conn.close()
		# 备份 API 直接写了主库文件，旧 -wal 里的内容会“复活”（已删的数据又出现）——
		# 先检查点合并，再删 -wal/-shm，恢复才真正生效。
		try:
			_c = sqlite3.connect(DB_PATH)
			_c.execute("PRAGMA wal_checkpoint(TRUNCATE)")
			_c.close()
		except Exception:
			pass
		for _suf in ("-wal", "-shm"):
			try:
				os.remove(DB_PATH + _suf)
			except Exception:
				pass
		for folder, prefix in ((ASSETS_DIR, "assets"), (UPLOAD_DIR, "uploads")):
			src_folder = os.path.join(tmpd, prefix)
			if os.path.isdir(src_folder):
				shutil.rmtree(folder, ignore_errors=True)
				shutil.copytree(src_folder, folder)
		shutil.rmtree(tmpd, ignore_errors=True)
	except Exception as e:
		shutil.rmtree(tmpd, ignore_errors=True)
		return {"ok": False, "error": f"恢复失败：{e}（已先自动备份当前库：{auto.get('filename', '')}）"}
	# 恢复用源库内容覆盖了当前库，自动备份的那条记录也被 wipe 掉了——重新记回来（文件本身还在）。
	# 顺带把磁盘上所有备份文件重新扫一遍：恢复会把源库时间点的记录表整个换回来，之后建的备份
	# （文件还在磁盘上）记录会丢，扫回来才能让列表和磁盘对得上。
	try:
		conn = get_db()
		have = {r["filename"] for r in conn.execute("SELECT filename FROM backups_meta").fetchall()}
		with DB_LOCK:
			for fn in sorted(os.listdir(BACKUP_DIR)):
				if fn.endswith(".zip") and fn not in have:
					fp = os.path.join(BACKUP_DIR, fn)
					note = "恢复前自动备份" if fn == auto.get("filename") else "恢复后重新发现的备份文件"
					created = datetime.fromtimestamp(os.path.getmtime(fp)).strftime("%Y-%m-%d %H:%M:%S")
					conn.execute("INSERT INTO backups_meta(filename,note,created_at,size_bytes,status) VALUES(?,?,?,?,?)", (fn, note, created, os.path.getsize(fp), "ok"))
					have.add(fn)
			conn.commit()
		conn.close()
	except Exception:
		pass
	audit(user, "backup_restore", f"从 {safe} 恢复（恢复前已自动备份 {auto.get('filename', '')}）")
	return {"ok": True, "restored": safe, "auto_backup": auto.get("filename", "")}

def auto_backup_loop():
	"""每日自动备份守护线程：每小时看一次，超过 24 小时没有备份就备一份，保留最近 7 份。"""
	while True:
		try:
			time.sleep(3600)
			rows = list_backups()
			last = rows[0]["created_at"] if rows else ""
			need = True
			if last:
				try:
					need = (datetime.now() - datetime.strptime(last, "%Y-%m-%d %H:%M:%S")).total_seconds() > 24 * 3600
				except Exception:
					need = True
			if need:
				make_backup("每日自动备份", "system")
				prune_backups()
		except Exception:
			continue

def fed_request(host, port, token, method, api_path, body=None, timeout=FED_TIMEOUT):
	"""调对方主机的联邦接口。只在局域网内用 http，不经过互联网。"""
	url = f"http://{host}:{port}{api_path}"
	sep = "&" if "?" in url else "?"
	url = url + sep + "token=" + token
	data = json.dumps(body, ensure_ascii=False).encode() if body is not None else None
	req = urllib.request.Request(url, data=data, method=method, headers={"Content-Type": "application/json"})
	try:
		with urllib.request.urlopen(req, timeout=timeout) as resp:
			return json.loads(resp.read().decode())
	except urllib.error.HTTPError as e:
		try:
			msg = json.loads(e.read().decode()).get("error", f"对方返回 HTTP {e.code}")
		except Exception:
			msg = f"对方返回 HTTP {e.code}"
		raise ValueError(msg)
	except Exception as e:
		raise ValueError(f"连不上对方主机（{host}:{port}）：{e}")

# ---- 本地 AI 变式引擎：纯规则，不联网、不接模型、不装大模型 ----
VARIANT_SYNONYMS = [("应当", "应该"), ("必须", "应"), ("旅客", "出入境旅客"), ("可以", "能够"), ("不得", "不准")]
NUM_REPLACE = {1: 2, 2: 3, 3: 5, 5: 10, 7: 14, 10: 15, 15: 20, 20: 30, 30: 45, 45: 30, 60: 90, 24: 48}

def _remap_answer(qtype, old_options, new_options, old_answer):
	"""选项重排后重算答案字母。old_options/new_options 都是内容列表。"""
	pos = {c: i for i, c in enumerate(old_options)}
	if qtype == "single":
		idx = pos.get(old_answer.strip(), 0)
		return chr(65 + new_options.index(old_options[idx])) if old_options[idx] in new_options else old_answer
	if qtype == "multi":
		letters = []
		for ch in str(old_answer):
			if ch.strip() in pos:
				letters.append(chr(65 + new_options.index(old_options[pos[ch.strip()]])))
		return "".join(sorted(letters))
	return old_answer

def make_variants(q, count):
	"""按母题生成变式（只改可替换槽位，不改考点）。返回 [{kind, stem, options, answer, explanation, note}]。
	kind：shuffle=选项顺序变式；wording=题干表述变式；numeric=题干数字变式。"""
	out = []
	contents = [o["content"] for o in q["options"]]
	correct_contents = []
	if q["type"] == "single":
		correct_contents = [contents[ord(str(q["answer"]).strip()[0]) - 65]] if str(q["answer"]).strip() else []
	elif q["type"] == "multi":
		correct_contents = [contents[ord(ch) - 65] for ch in str(q["answer"]) if ch.strip() and 65 <= ord(ch) < 65 + len(contents)]
	if q["type"] in ("single", "multi") and len(contents) >= 3:
		new_opts = contents[:]
		for _ in range(20):
			random.shuffle(new_opts)
			if new_opts != contents:
				break
		if new_opts != contents:
			out.append({"kind": "shuffle", "stem": q["stem"], "options": new_opts,
				"answer": _remap_answer(q["type"], contents, new_opts, q["answer"]),
				"explanation": q["explanation"] + "（变式说明：仅选项顺序打乱，考点与答案内容不变。）",
				"note": "选项顺序变式：只打乱选项顺序，答案内容不变。"})
	for old_w, new_w in VARIANT_SYNONYMS:
		if old_w in q["stem"]:
			out.append({"kind": "wording", "stem": q["stem"].replace(old_w, new_w, 1), "options": contents[:],
				"answer": q["answer"],
				"explanation": q["explanation"] + "（变式说明：仅题干同义词替换，考点与答案不变。）",
				"note": f"题干表述变式：仅把“{old_w}”换成“{new_w}”，答案不变。"})
			break
	m = re.search(r"(\d+)", q["stem"])
	if m:
		num = int(m.group(1))
		rep_num = NUM_REPLACE.get(num)
		if rep_num is not None and str(num) not in "".join(correct_contents) and str(num) not in (q["explanation"] or ""):
			out.append({"kind": "numeric", "stem": q["stem"].replace(str(num), str(rep_num), 1), "options": contents[:],
				"answer": q["answer"],
				"explanation": q["explanation"] + "（变式说明：题干数字已替换，须人工复核数字合理性后再发布。）",
				"note": f"题干数字变式：题干数字 {num} 换成 {rep_num}，须人工复核数字合理性。"})
	return out[:count]

def ai_tip_for(conn, qid):
	"""易错点提示：用全站作答统计算，不编数据。返回 {total, correct, accuracy, top_wrong, tip}。"""
	q = conn.execute("SELECT stem FROM questions WHERE id=?", (qid,)).fetchone()
	if not q:
		return {"ok": False, "error": "题目不存在"}
	rows = conn.execute("SELECT user_answer, is_correct FROM attempts WHERE question_id=? AND is_correct IS NOT NULL", (qid,)).fetchall()
	total = len(rows)
	correct = sum(1 for r in rows if r["is_correct"])
	acc = round(correct / total * 100) if total else None
	wrong_counts = {}
	for r in rows:
		if not r["is_correct"] and r["user_answer"]:
			wrong_counts[r["user_answer"]] = wrong_counts.get(r["user_answer"], 0) + 1
	top_wrong = max(wrong_counts.items(), key=lambda kv: kv[1]) if wrong_counts else None
	if total == 0:
		tip = "暂无作答数据，尚无易错统计：先让大家练一练，再回来查看最常见的错误选项。"
	elif acc is not None and acc < 60:
		tip = f"属于易错题（全站正确率 {acc}%）：讲评时重点讲清为什么错选项错、正确选项为什么对；建议把本题放进薄弱项训练。"
	elif acc is not None and acc > 90:
		tip = f"掌握较好（全站正确率 {acc}%）：可做快速复习，不必反复练。"
	else:
		tip = f"中等难度（全站正确率 {acc}%）：注意区分易混选项，讲评时对照解析逐项辨析。"
	if top_wrong:
		tip += f"最常见的错误答案是“{top_wrong[0]}”（{top_wrong[1]} 人次）。"
	return {"ok": True, "question_id": qid, "total": total, "correct": correct, "accuracy": acc,
		"top_wrong": {"answer": top_wrong[0], "count": top_wrong[1]} if top_wrong else None, "tip": tip}

def backup_status_summary():
	rows = list_backups()
	last = rows[0] if rows else None
	d = disk_status()
	return {"count": len(rows), "last_filename": last["filename"] if last else "", "last_at": last["created_at"] if last else "",
		"last_size": last.get("size_bytes", 0) if last else 0, "auto": os.environ.get("SHUATI_AUTOBACKUP", "1") != "0",
		"keep": AUTO_BACKUP_KEEP, "disk": d}

def lan_ip():
	try:
		import socket
		s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		s.connect(("8.8.8.8", 80))
		ip = s.getsockname()[0]
		s.close()
		return ip
	except Exception:
		return "127.0.0.1"
def main():
	# 控制台编码可能不是 UTF-8（如英文 Windows 的 cp1252、wine 的 cp1252）：
	# 中文横幅直接 print 会抛 UnicodeEncodeError 导致整个程序崩溃。
	# 设为 errors="replace" 后打不出的字变问号，但程序绝不因此崩。
	for _stream in (sys.stdout, sys.stderr):
		try:
			_stream.reconfigure(encoding="utf-8", errors="replace")
		except Exception:
			pass
	init_db()
	if os.environ.get("SHUATI_AUTOBACKUP", "1") != "0":
		threading.Thread(target=auto_backup_loop, daemon=True).start()
	srv = ThreadingHTTPServer((HOST, PORT), Handler)
	print(f"常熟边检站刷题宝 MVP {VERSION} 已启动")
	print(f"本机访问：http://127.0.0.1:{PORT}/")
	print(f"局域网访问：http://{lan_ip()}:{PORT}/  （其他电脑用这个地址）")
	print(f"Lite 版（老浏览器）：http://{lan_ip()}:{PORT}/lite")
	print("演示账号：admin / jiaoguan / minjing / minjing2，密码都是 123456")
	print(f"数据库在 {DB_PATH}；备份在 {BACKUP_DIR}（每日自动备份，保留最近 {AUTO_BACKUP_KEEP} 份）。")
	print("按 Ctrl+C 停止。")
	if getattr(sys, "frozen", False) or os.environ.get("SHUATI_OPEN_BROWSER", "0") == "1":
		try:
			import webbrowser
			threading.Timer(1.0, lambda: webbrowser.open(f"http://127.0.0.1:{PORT}/")).start()
			print("已自动打开浏览器（exe 模式）。")
		except Exception:
			pass
	try:
		srv.serve_forever()
	except KeyboardInterrupt:
		print("已停止。")
if __name__ == "__main__":
	main()
