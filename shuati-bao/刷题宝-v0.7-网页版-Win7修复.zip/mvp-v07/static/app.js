// 刷题宝 v0.2 前端：纯原生 JS，无框架、无 CDN
// HIG 要点：无原生 alert()/confirm()，改用 Toast 与应用内弹窗；
// 动效 200–350ms 弹簧曲线、可打断；减弱动效时瞬间切换；考核页默认减动效。
let me = null;
let examSession = null;
let examTimerId = null;
let examSyncId = null;
let toastTimer = null;

function api(path, opts) {
  return fetch(path, Object.assign({headers: {'Content-Type': 'application/json'}}, opts || {}))
    .then(function(r){ return r.json().catch(function(){ return {ok:false, error:'返回不是 JSON'}; }).then(function(j){ return {status:r.status, body:j}; }); })
    .then(function(x){ if (x.status === 401) { toast('请先登录'); } return x.body; });
}
function esc(s) { return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;'); }

// ---- Toast：轻量反馈，2.4 秒后自动消失，可被新 Toast 打断 ----
function toast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(function(){ t.classList.remove('show'); }, 2400);
}

// ---- 应用内弹窗：讲清后果，按钮讲清动作；Esc / 点遮罩可取消 ----
function showModal(opts) {
  const root = document.getElementById('modalRoot');
  root.innerHTML = '<div class="modal-backdrop" id="modalBackdrop"><div class="modal" role="alertdialog" aria-labelledby="modalTitle">'
    + '<h3 id="modalTitle">' + esc(opts.title) + '</h3><p>' + esc(opts.body) + '</p>'
    + '<div class="actions"><button type="button" class="btn-secondary" id="modalCancel">' + esc(opts.cancelText || '取消') + '</button>'
    + '<button type="button" class="' + (opts.danger ? 'btn-danger' : '') + '" id="modalOk">' + esc(opts.okText || '确定') + '</button></div></div></div>';
  const close = function(){ root.innerHTML = ''; document.removeEventListener('keydown', onKey); };
  const onKey = function(e){ if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', onKey);
  document.getElementById('modalBackdrop').addEventListener('click', function(e){ if (e.target.id === 'modalBackdrop') close(); });
  document.getElementById('modalCancel').addEventListener('click', close);
  document.getElementById('modalOk').addEventListener('click', function(){ close(); opts.onOk && opts.onOk(); });
  document.getElementById('modalOk').focus();
}

function fillUser(u) {
  document.getElementById('username').value = u;
  document.getElementById('password').value = '';
  document.getElementById('password').focus();
}
async function login() {
  const u = document.getElementById('username').value.trim();
  const p = document.getElementById('password').value;
  if (!u || !p) { document.getElementById('loginMsg').textContent = '请先输入账号和密码。'; return; }
  const j = await api('/api/login', {method: 'POST', body: JSON.stringify({username: u, password: p})});
  if (!j.ok) { document.getElementById('loginMsg').textContent = '登录失败：' + (j.error || '账号或密码错误'); return; }
  me = j.user; afterLogin();
  toast('登录成功，' + me.display_name);
}
function afterLogin() {
  document.getElementById('loginCard').classList.add('hidden');
  document.getElementById('appCard').classList.remove('hidden');
  document.getElementById('who').textContent = me.display_name + ' · ' + me.team;
  const adminBtn = document.getElementById('tab-admin');
  if (adminBtn) adminBtn.style.display = (me.role === 'admin' || me.role === 'instructor') ? '' : 'none';
  loadPractice();
  loadTemplates();
}
async function logout() {
  await api('/api/logout', {method: 'POST', body: '{}'});
  location.reload();
}
function showTab(name) {
  const names = ['practice','weak','exam','report','team','import','admin'];
  names.forEach(function(n) {
    const panel = document.getElementById('tab' + n.charAt(0).toUpperCase() + n.slice(1));
    const isCurrent = n === name;
    panel.classList.toggle('hidden', !isCurrent);
    // 可打断的切换：重启动画类，快速连点立即跟手
    if (isCurrent) { panel.classList.remove('panel'); void panel.offsetWidth; panel.classList.add('panel'); }
    const b = document.getElementById('tab-' + n);
    if (b) { b.classList.toggle('active', isCurrent); b.setAttribute('aria-selected', isCurrent ? 'true' : 'false'); }
  });
  document.body.classList.toggle('exam-mode', name === 'exam');
  if (name === 'report') loadReport();
  if (name === 'team') loadTeam();
  if (name === 'import') loadJobs();
  if (name === 'weak') loadAdaptive();
  if (name === 'admin') loadAdmin();
}
function emptyState(icon, title, hint) {
  return '<div class="empty"><div class="big">' + icon + '</div><h3>' + title + '</h3><p class="muted">' + hint + '</p></div>';
}
function renderQuestions(list, containerId, kind) {
  const box = document.getElementById(containerId);
  if (!list.length) {
    box.innerHTML = emptyState('📝', '暂无题目', kind === 'exam' ? '请先开始考核。' : '先做几道自由练习，错题本有了内容后这里才会有题目。');
    return;
  }
  box.innerHTML = list.map(function(q, i) {
    const imgs = (q.assets || []).map(function(a) { return '<p><img src="/assets/' + esc(a.path) + '" alt="题目配图"></p>'; }).join('');
    const opts = q.options.map(function(o) {
      const input = q.type === 'multi'
        ? '<input type="checkbox" name="q' + q.id + '" value="' + o.label + '" onchange="markSelected(' + q.id + ')">'
        : '<input type="radio" name="q' + q.id + '" value="' + o.label + '" onchange="markSelected(' + q.id + ')">';
      return '<label class="opt">' + input + '<span><b>' + o.label + '.</b> ' + esc(o.content) + '</span></label>';
    }).join('');
    const btn = kind === 'exam'
      ? '<button type="button" onclick="saveExamAnswer(' + q.id + ')">保存草稿</button>'
      : '<button type="button" onclick="submitOne(' + q.id + ', \'' + kind + '\')">提交本题</button>';
    const typeName = q.type === 'multi' ? '多选' : (q.type === 'judge' ? '判断' : '单选');
    return '<article class="q" id="qbox-' + q.id + '"><p class="q-meta">第 ' + (i + 1) + ' 题 · ' + typeName + ' · ' + esc(q.subject) + ' · 难度 ' + q.difficulty + ' / 5</p>'
      + '<p class="q-stem">' + esc(q.stem) + '</p>' + imgs
      + '<p class="muted">知识点：' + esc((q.knowledge || []).join('、') || '未标注') + '</p>'
      + '<div role="group" aria-label="第 ' + (i + 1) + ' 题选项">' + opts + '</div>'
      + '<p style="margin-top:16px">' + btn + ' <span id="res-' + q.id + '"></span></p></article>';
  }).join('');
}
function markSelected(qid) {
  const box = document.getElementById('qbox-' + qid);
  if (!box) return;
  box.querySelectorAll('.opt').forEach(function(l) {
    const inp = l.querySelector('input');
    l.classList.toggle('selected', !!(inp && inp.checked));
  });
}
function getAnswer(qid) {
  const els = document.querySelectorAll('input[name="q' + qid + '"]:checked');
  return Array.from(els).map(function(e) { return e.value; }).join('');
}
function paintOptions(qid, correctAnswer) {
  const box = document.getElementById('qbox-' + qid);
  if (!box) return;
  const picked = getAnswer(qid);
  box.querySelectorAll('.opt').forEach(function(l) {
    const inp = l.querySelector('input');
    if (!inp) return;
    if (correctAnswer.indexOf(inp.value) >= 0) l.classList.add('correct');
    else if (picked.indexOf(inp.value) >= 0) l.classList.add('wrong-picked');
  });
}
async function submitOne(qid, kind) {
  const ans = getAnswer(qid);
  if (!ans) { toast('请先选一个答案'); return; }
  const j = await api('/api/attempts', {method: 'POST', body: JSON.stringify({question_id: qid, answer: ans, mode: 'practice'})});
  const el = document.getElementById('res-' + qid);
  if (!j.ok) { toast('提交失败：' + (j.error || '请重试')); return; }
  paintOptions(qid, j.correct_answer || '');
  const elab = '<br><span class="muted">精细加工：想一想，为什么错的选项错、正确选项为什么对？把理由用自己的话说一遍，再做下一题。</span>';
  el.innerHTML = j.is_correct
    ? '<span class="feedback ok" style="display:block"><span class="answer">答对了 ✓</span><br>解析：' + esc(j.explanation || '暂无解析') + elab + '</span>'
    : '<span class="feedback no" style="display:block"><span class="answer">答错了，正确答案是 ' + esc(j.correct_answer) + '</span><br>解析：' + esc(j.explanation || '暂无解析') + elab + '</span>';
  try { localStorage.setItem('draft-practice-' + qid, ans); } catch (e) {}
}
// ---- SVG 小图：纯 CSS/SVG 画图，零 CDN、离线可用 ----
function radarSVG(per) {
  if (!per || !per.length) return '<p class="muted">还没有掌握度数据，先做 10 道练习。</p>';
  const items = per.slice(0, 6);
  const cx = 110, cy = 110, R = 80;
  const pts = items.map(function(k, i) {
    const a = -Math.PI / 2 + i * 2 * Math.PI / items.length;
    const r = R * Math.max(0, Math.min(1, k.accuracy || 0));
    return (cx + r * Math.cos(a)).toFixed(1) + ',' + (cy + r * Math.sin(a)).toFixed(1);
  }).join(' ');
  const grid = [0.25, 0.5, 0.75, 1].map(function(f) {
    return '<polygon points="' + items.map(function(k, i) { const a = -Math.PI / 2 + i * 2 * Math.PI / items.length; return (cx + R * f * Math.cos(a)).toFixed(1) + ',' + (cy + R * f * Math.sin(a)).toFixed(1); }).join(' ') + '" fill="none" stroke="#c6c6c8"/>';
  }).join('');
  const labels = items.map(function(k, i) {
    const a = -Math.PI / 2 + i * 2 * Math.PI / items.length;
    return '<text x="' + (cx + (R + 16) * Math.cos(a)).toFixed(0) + '" y="' + (cy + (R + 16) * Math.sin(a)).toFixed(0) + '" font-size="11" text-anchor="middle">' + esc(k.knowledge) + ' ' + Math.round((k.accuracy || 0) * 100) + '%</text>';
  }).join('');
  return '<svg width="220" height="220" viewBox="0 0 220 220" role="img" aria-label="知识点掌握雷达图">' + grid + '<polygon points="' + pts + '" fill="rgba(0,122,255,.25)" stroke="#007aff" stroke-width="2"/>' + labels + '</svg>';
}
function lineSVG(trend) {
  if (!trend || !trend.length) return '<p class="muted">暂无趋势数据。</p>';
  const W = 560, H = 120, pad = 24;
  const max = Math.max.apply(null, trend.map(function(d){ return d.total; }).concat([1]));
  const pts = trend.map(function(d, i) {
    const x = pad + i * (W - 2 * pad) / Math.max(1, trend.length - 1);
    const y = H - pad - (d.total / max) * (H - 2 * pad);
    return x.toFixed(1) + ',' + y.toFixed(1);
  }).join(' ');
  const dots = trend.map(function(d, i) {
    const x = pad + i * (W - 2 * pad) / Math.max(1, trend.length - 1);
    const y = H - pad - (d.total / max) * (H - 2 * pad);
    return '<circle cx="' + x.toFixed(1) + '" cy="' + y.toFixed(1) + '" r="3" fill="#007aff"/>';
  }).join('');
  return '<svg width="100%" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="近14天作答趋势"><polyline points="' + pts + '" fill="none" stroke="#007aff" stroke-width="2"/>' + dots + '<text x="8" y="16" font-size="11" fill="#666">近14天每天作答数（最高 ' + max + ' 道）</text></svg>';
}
function barsSVG(teams) {
  if (!teams || !teams.length) return '<p class="muted">暂无部门数据。</p>';
  const rows = teams.map(function(tm) {
    const pct = Math.round((tm.avg_accuracy || 0) * 100);
    return '<p style="margin:8px 0"><b>' + esc(tm.team) + '</b>（' + tm.member_count + ' 人，参与率 ' + Math.round((tm.participation || 0) * 100) + '%，未达标 ' + tm.below_target + ' 人）<br><span class="bar"><i style="width:' + pct + '%"></i></span> 平均正确率 ' + pct + '%</p>';
  }).join('');
  return rows;
}
async function loadLearnMode(mode) {
  const hints = {
    sequential: '顺序练习：按知识点顺序、难度从易到难，先把基础立起来。',
    random: '随机测验：跨知识点混排，逼着判断“这题该用什么方法”。低分不计入考核，只算掌握度。',
    review: '错题回顾：按 1/3/7/14 天到期时间排，先练快忘的，再练已稳的。'
  };
  document.getElementById('learnHint').textContent = hints[mode] || '';
  const q = new URLSearchParams({mode: mode, count: document.getElementById('practiceCount').value || 10});
  const j = await api('/api/practice?' + q.toString());
  if (!j.ok) { document.getElementById('practiceList').innerHTML = emptyState('⚠️', '加载失败', esc(j.error || '请检查网络后重试')); return; }
  renderQuestions(j.questions, 'practiceList', 'practice');
}
async function loadAdaptive() {
  const j = await api('/api/adaptive');
  if (!j.ok) return;
  const a = j.adaptive;
  document.getElementById('adaptiveBox').innerHTML = '<p><b>你的自适应画像</b>：' + esc(a.sample_note) + '</p>'
    + '<p class="muted">当前比例 薄弱 ' + a.ratio.weak_pct + '% / 复习 ' + a.ratio.review_pct + '% / 新题 ' + a.ratio.new_pct + '%；到期未复习 ' + a.due_count + ' 道；连续学习 ' + a.streak_days + ' 天。'
    + (a.weak_knowledge.length ? '薄弱：' + esc(a.weak_knowledge.join('、')) + '。' : '')
    + (a.mastered_knowledge.length ? '已掌握：' + esc(a.mastered_knowledge.join('、')) + '（占比已降到 10% 以下）。' : '') + '</p>'
    + (a.per_knowledge.map(function(k){ return '<p class="muted">' + esc(k.knowledge) + '：作答 ' + k.total + '，正确率 ' + Math.round((k.accuracy||0)*100) + '%，目标难度 ' + k.target_difficulty + ' / 5' + (k.status === 'insufficient' ? '（样本不足，暂不下薄弱结论）' : '') + '</p>'; }).join(''));
  const radar = document.getElementById('weakRadar');
  if (radar) radar.innerHTML = '<h4>知识点掌握雷达</h4>' + radarSVG(a.per_knowledge);
}
async function loadPractice() {
  const mode = document.getElementById('practiceMode').value;
  const kn = document.getElementById('practiceKn').value.trim();
  const subj = document.getElementById('practiceSubject').value.trim();
  const count = document.getElementById('practiceCount').value || 10;
  const q = new URLSearchParams({mode: mode, count: count, knowledge: kn, subject: subj});
  const j = await api('/api/practice?' + q.toString());
  if (!j.ok) { document.getElementById('practiceList').innerHTML = emptyState('⚠️', '加载失败', esc(j.error || '请检查网络后重试')); return; }
  renderQuestions(j.questions, 'practiceList', 'practice');
}
async function loadWeak() {
  const total = document.getElementById('weakCount').value || 10;
  const wp = document.getElementById('weakPct').value || 50;
  const rp = document.getElementById('reviewPct').value || 30;
  const j = await api('/api/weak', {method: 'POST', body: JSON.stringify({total: Number(total), weak_pct: Number(wp), review_pct: Number(rp)})});
  if (!j.ok) { document.getElementById('weakInfo').textContent = '生成失败：' + (j.error || '请重试'); return; }
  document.getElementById('weakInfo').textContent = (j.sample_note || '') + ' 薄弱知识点：' + (j.weak_knowledge.join('、') || '暂无') + '；比例 薄弱' + j.ratio.weak_pct + '% / 复习' + j.ratio.review_pct + '% / 新题' + j.ratio.new_pct + '%；到期未复习 ' + (j.due_count || 0) + ' 道。';
  renderQuestions(j.questions, 'weakList', 'practice');
  loadAdaptive();
}
// ---- 考核计时：本地每秒平滑走字，以服务端 ends_at 为准；每 10 秒校准一次 ----
function fmtLeft(s) {
  s = Math.max(0, s);
  return '剩余 ' + Math.floor(s / 60) + '分' + String(s % 60).padStart(2, '0') + '秒';
}
function tickTimer() {
  if (!examSession || !examSession.ends_at) return;
  const left = Math.floor((new Date(examSession.ends_at).getTime() - Date.now()) / 1000);
  const el = document.getElementById('examTimer');
  el.textContent = fmtLeft(left);
  el.classList.toggle('warn', left > 0 && left <= 300);
  if (left <= 0) { clearInterval(examTimerId); clearInterval(examSyncId); toast('时间到，正在自动交卷'); submitExam(); }
}
function startTimer() {
  if (!examSession) return;
  clearInterval(examTimerId); clearInterval(examSyncId);
  tickTimer();
  examTimerId = setInterval(tickTimer, 1000);
  examSyncId = setInterval(async function() {
    const j = await api('/api/exams/' + examSession.session_id + '/state');
    if (j.ok && typeof j.remaining_seconds === 'number') {
      examSession.ends_at = new Date(Date.now() + j.remaining_seconds * 1000).toISOString();
      tickTimer();
    }
  }, 10000);
}
async function startExam() {
  const count = Number(document.getElementById('examCount').value || 10);
  const minutes = Number(document.getElementById('examMinutes').value || 30);
  const tpl = document.getElementById('examTemplate');
  const template_id = tpl && tpl.value ? Number(tpl.value) : null;
  const body = {count: count, minutes: minutes};
  if (template_id) body.template_id = template_id;
  const incEssay = document.getElementById('examIncludeEssay');
  if (incEssay && incEssay.checked) body.include_essay = true;
  const j = await api('/api/exams/start', {method: 'POST', body: JSON.stringify(body)});
  if (!j.ok) { toast('开考失败：' + (j.error || '请重试')); return; }
  examSession = j;
  try { localStorage.setItem('exam-session', JSON.stringify({id: j.session_id, ends_at: j.ends_at})); } catch (e) {}
  document.getElementById('examResult').innerHTML = '';
  renderQuestions(j.questions, 'examList', 'exam');
  startTimer();
  toast('考核已开始，祝顺利');
}
async function saveExamAnswer(qid) {
  if (!examSession) { toast('请先开始考核'); return; }
  const ans = getAnswer(qid);
  if (!ans) { toast('请先选一个答案'); return; }
  const j = await api('/api/exams/' + examSession.session_id + '/answer', {method: 'POST', body: JSON.stringify({question_id: qid, answer: ans})});
  const el = document.getElementById('res-' + qid);
  if (el) el.textContent = j.ok ? '草稿已保存' : '保存失败：' + (j.error || '请重试');
  if (j.ok) { toast('草稿已保存'); try { localStorage.setItem('draft-exam-' + examSession.session_id + '-' + qid, ans); } catch (e) {} }
}
function resumeExam() {
  const raw = localStorage.getItem('exam-session');
  if (!raw) { toast('本地没有未交卷的考核记录'); return; }
  const s = JSON.parse(raw);
  examSession = {session_id: s.id, ends_at: s.ends_at};
  document.getElementById('examResult').innerHTML = '<p class="muted">已恢复场次 ' + esc(String(s.id)) + '。草稿存在服务端，刷新后只要场次未到期，重新进入同一场次交卷即可计分；点“开始考核”会开新卷。</p>';
  startTimer();
}
function confirmSubmitExam() {
  if (!examSession) { toast('没有进行中的考核'); return; }
  showModal({title: '交卷', body: '交卷后不能再改答案，未答的题按错算。确定现在交卷吗？', okText: '交卷', danger: true, onOk: submitExam});
}
async function submitExam() {
  if (!examSession) { toast('没有进行中的考核'); return; }
  const j = await api('/api/exams/' + examSession.session_id + '/submit', {method: 'POST', body: '{}'});
  clearInterval(examTimerId); clearInterval(examSyncId);
  document.getElementById('examTimer').textContent = '';
  if (!j.ok) { toast('交卷失败：' + (j.error || '请重试')); return; }
  document.getElementById('examResult').innerHTML = '<div class="card" style="margin-top:16px"><h3>交卷完成</h3><p>得分：' + j.score + ' / ' + j.total + '</p><p class="muted">错题已进错题本，去“薄弱项”练一练。</p></div>';
  document.getElementById('examPrint').innerHTML = '<a class="btn btn-secondary" href="/api/exams/' + examSession.session_id + '/print" target="_blank" rel="noopener">打印成绩单</a>';
  examSession = null;
  toast('已交卷，得分 ' + j.score + ' / ' + j.total);
  try { localStorage.removeItem('exam-session'); } catch (e) {}
}
async function loadReport() {
  const j = await api('/api/reports/me');
  if (!j.ok) { document.getElementById('reportBox').innerHTML = emptyState('⚠️', '加载失败', esc(j.error || '请重试')); return; }
  const r = j.report;
  if (!r.total) {
    document.getElementById('reportBox').innerHTML = emptyState('📊', '还没有作答记录', '先做 10 道练习，这里就会出现你的正确率、薄弱项和趋势。');
    return;
  }
  const rows = r.by_knowledge.map(function(k) {
    const pct = Math.round((k.accuracy || 0) * 100);
    return '<tr><td>' + esc(k.knowledge) + '</td><td>' + k.total + '</td><td>' + k.correct + '</td><td>' + pct + '%</td><td>' + k.elo + '</td></tr>'
      + '<tr><td colspan="5" style="padding-top:0"><span class="bar"><i style="width:' + pct + '%"></i></span></td></tr>';
  }).join('');
  const trend = r.trend.map(function(t) { return '<tr><td>' + esc(t.date) + '</td><td>' + t.total + '</td><td>' + t.correct + '</td></tr>'; }).join('');
  document.getElementById('reportBox').innerHTML = '<p>总作答 ' + r.total + '，正确 ' + r.correct + '，正确率 ' + Math.round((r.accuracy || 0) * 100) + '%，错题本 ' + r.wrong_count + ' 道，连续学习 ' + (r.streak_days || 0) + ' 天，到期未复习 ' + (r.due_count || 0) + ' 道</p><p>' + esc(r.advice) + '</p>';
  const rr = document.getElementById('reportRadar');
  if (rr && r.adaptive) rr.innerHTML = '<h4>知识点掌握雷达</h4>' + radarSVG(r.adaptive.per_knowledge);
  document.getElementById('reportBox').innerHTML += '<h4>知识点掌握（Elo 越高掌握越好，薄弱 TOP 在前）</h4><table><tr><th>知识点</th><th>作答</th><th>正确</th><th>正确率</th><th>Elo</th></tr>' + rows + '</table><h4>近 14 天趋势</h4><table><tr><th>日期</th><th>作答</th><th>正确</th></tr>' + trend + '</table>';
}
async function loadTeam() {
  const j = await api('/api/reports/team');
  if (!j.ok) { document.getElementById('teamBox').innerHTML = emptyState('🔒', '看不到队报告', '民警账号只看自己的报告；队报告请用教官或管理员账号查看。'); return; }
  const r = j.report;
  const rows = r.knowledge.map(function(k) { return '<tr><td>' + esc(k.knowledge) + '</td><td>' + k.total + '</td><td>' + k.correct + '</td><td>' + Math.round((k.accuracy || 0) * 100) + '%</td></tr>'; }).join('');
  const wrong = r.wrong_top.map(function(w) { return '<tr><td>题 ' + w.question_id + '</td><td>' + w.wrong_count + '</td></tr>'; }).join('');
  document.getElementById('teamBox').innerHTML = '<p>队：' + esc(r.team) + '，人数 ' + r.member_count + '，总作答 ' + r.total_attempts + '，平均正确率 ' + Math.round((r.avg_accuracy || 0) * 100) + '%</p><table><tr><th>知识点</th><th>作答</th><th>正确</th><th>正确率</th></tr>' + rows + '</table><h4>高频易错题</h4><table><tr><th>题目</th><th>错题人数</th></tr>' + wrong + '</table>';
}
async function uploadFile(path, inputId, msgId) {
  const f = document.getElementById(inputId).files[0];
  if (!f) { toast('请先选一个文件'); return; }
  const fd = new FormData();
  fd.append('file', f);
  document.getElementById(msgId).textContent = '上传解析中…';
  const r = await fetch(path, {method: 'POST', body: fd});
  const j = await r.json().catch(function(){ return {ok:false, error:'返回不是 JSON'}; });
  if (!j.ok) { document.getElementById(msgId).textContent = '导入失败：' + (j.error || '请检查文件格式后重传'); return; }
  let msg = '导入完成：任务 ' + j.job_id + '，共 ' + j.total + ' 行，通过 ' + j.ok + '，待修 ' + j.bad + '。';
  if (j.bad_list && j.bad_list.length) msg += ' 待修：' + j.bad_list.map(function(b) { return '第' + b.row_no + '行 ' + b.error; }).join('；');
  if (j.pairing) msg += ' 图文配对：自动过 ' + (j.pairing.auto || 0) + ' 张，复核 ' + (j.pairing.review || 0) + ' 张，人工 ' + (j.pairing.manual || 0) + ' 张。';
  document.getElementById(msgId).textContent = msg + ' 请点“刷新导入任务”查看审核队列，再点“审核通过最新任务”+“发布新版本”。';
  toast('导入完成，通过 ' + j.ok + ' 行，待修 ' + j.bad + ' 行');
  loadJobs();
  if (j.job_id) loadPairings(j.job_id);
}
let lastJobId = null;
async function loadJobs() {
  const j = await api('/api/import/jobs');
  if (!j.ok) { document.getElementById('jobsBox').innerHTML = '<p>' + esc(j.error || '加载失败') + '</p>'; return; }
  if (j.jobs.length) lastJobId = j.jobs[0].id;
  const jobs = j.jobs.map(function(x) { return '<tr><td>' + x.id + '</td><td>' + esc(x.filename) + '</td><td>' + esc(x.file_type) + '</td><td>' + x.total_rows + '</td><td>' + x.ok_rows + '</td><td>' + x.bad_rows + '</td><td>' + esc(x.status) + '</td></tr>'; }).join('');
  const queue = j.review_queue.map(function(x) { return '<tr><td>' + x.id + '</td><td>' + x.job_id + '</td><td>' + (x.question_id || '-') + '</td><td>第' + x.row_no + '行</td><td>' + esc(x.reason) + '</td><td>' + esc(x.status) + '</td></tr>'; }).join('');
  document.getElementById('jobsBox').innerHTML = '<h4>导入任务</h4><table><tr><th>ID</th><th>文件</th><th>类型</th><th>总行</th><th>通过</th><th>待修</th><th>状态</th></tr>' + (jobs || '<tr><td colspan="7">暂无导入任务</td></tr>') + '</table><h4>审核队列</h4><table><tr><th>ID</th><th>任务</th><th>题目</th><th>行</th><th>原因</th><th>状态</th></tr>' + (queue || '<tr><td colspan="6">队列为空</td></tr>') + '</table>';
  const v = await api('/api/bank/versions');
  if (v.ok) document.getElementById('versionsBox').innerHTML = v.versions.map(function(x) { return '<p>' + esc(x.version_no) + '（' + x.question_count + ' 题，当前：' + (x.is_current ? '是' : '否') + '） <button type="button" class="btn-secondary" onclick="confirmRollback(' + x.id + ', \'' + esc(x.version_no) + '\')">回滚到此版</button></p>'; }).join('');
  if (lastJobId) loadPairings(lastJobId);
}
async function approveJob() {
  if (!lastJobId) { toast('请先刷新导入任务'); return; }
  const j = await api('/api/import/jobs/' + lastJobId + '/approve', {method: 'POST', body: '{}'});
  if (j.ok) { toast('审核通过'); } else { toast('失败：' + (j.error || '请重试')); }
  loadJobs();
}
async function publishBank() {
  const j = await api('/api/bank/publish', {method: 'POST', body: JSON.stringify({note: '网页端发布'})});
  if (j.ok) { toast('已发布 ' + j.version + '，' + j.count + ' 题'); } else { toast('发布失败：' + (j.error || '请重试')); }
  loadJobs();
}
function confirmRollback(id, version) {
  showModal({title: '回滚到 ' + version, body: '回滚后当前题库会切回该版本，新版题目不再出给学员；已有的作答和成绩不受影响。确定回滚吗？', okText: '回滚到此版', danger: true, onOk: async function() {
    const j = await api('/api/bank/rollback', {method: 'POST', body: JSON.stringify({version_id: id})});
    if (j.ok) { toast('已回滚到 ' + j.version); } else { toast('失败：' + (j.error || '请重试')); }
    loadJobs();
  }});
}
async function loadAdmin() {
  const j = await api('/api/admin/overview');
  if (!j.ok) { document.getElementById('adminOverview').innerHTML = '<p>' + esc(j.error || '加载失败') + '</p>'; return; }
  const o = j.overview;
  document.getElementById('adminOverview').innerHTML = '<div class="stat-grid">'
    + '<div class="stat"><div class="num">' + o.total_users + '</div><p class="muted">总人数</p></div>'
    + '<div class="stat"><div class="num">' + o.active_today + '</div><p class="muted">今日在线</p></div>'
    + '<div class="stat"><div class="num">' + o.today_attempts + '</div><p class="muted">今日作答</p></div>'
    + '<div class="stat"><div class="num">' + Math.round((o.avg_accuracy || 0) * 100) + '%</div><p class="muted">平均正确率</p></div>'
    + '<div class="stat"><div class="num">' + o.pending_review + '</div><p class="muted">待审核导入</p></div>'
    + '<div class="stat"><div class="num" style="color:var(--red)">' + o.suspects + '</div><p class="muted">疑似错题</p></div></div>'
    + '<p class="muted">薄弱 TOP：' + (o.weak_top.map(function(k){ return esc(k.knowledge) + ' ' + Math.round((k.accuracy||0)*100) + '%'; }).join('、') || '暂无') + '</p>';
  document.getElementById('adminTrend').innerHTML = lineSVG(o.trend14);
  document.getElementById('adminTeams').innerHTML = barsSVG(o.teams);
  const heat = o.heatmap || {};
  const teams = o.teams.map(function(x){ return x.team; });
  const kns = Object.keys(heat);
  let heatHtml = '<table><tr><th>知识点</th>' + teams.map(function(tm){ return '<th>' + esc(tm) + '</th>'; }).join('') + '</tr>';
  kns.forEach(function(kn) {
    heatHtml += '<tr><td>' + esc(kn) + '</td>' + teams.map(function(tm) {
      const v = heat[kn][tm];
      if (v === undefined) return '<td>—</td>';
      const pct = Math.round(v * 100);
      const bg = v < 0.6 ? 'rgba(255,59,48,.25)' : (v < 0.8 ? 'rgba(255,149,0,.2)' : 'rgba(52,199,89,.15)');
      return '<td style="background:' + bg + '">' + pct + '%</td>';
    }).join('') + '</tr>';
  });
  document.getElementById('adminHeat').innerHTML = heatHtml + '</table>';
  document.getElementById('adminWarnings').innerHTML = o.warnings.length
    ? '<ul>' + o.warnings.map(function(w){ return '<li><b style="color:var(--red)">预警</b> ' + esc(w.display_name) + (w.team ? '（' + esc(w.team) + '）' : '') + '：' + esc(w.detail) + '</li>'; }).join('') + '</ul>'
    : '<p class="muted">暂无预警。</p>';
  loadQuality();
  loadTemplates();
  loadFed();
  loadBackup();
  loadVariants();
}
async function loadAdminUser() {
  const id = document.getElementById('adminUserId').value;
  const j = await api('/api/admin/user/' + id);
  if (!j.ok) { document.getElementById('adminPerson').innerHTML = '<p>' + esc(j.error || '加载失败') + '</p>'; return; }
  const r = j.report;
  document.getElementById('adminPerson').innerHTML = '<p><b>' + esc(r.display_name) + '</b>（' + esc(r.team) + '）：总作答 ' + r.total + '，正确率 ' + Math.round((r.accuracy||0)*100) + '%，连续学习 ' + (r.streak_days||0) + ' 天，到期未复习 ' + (r.due_count||0) + ' 道。查看已记审计。</p>'
    + (r.adaptive ? radarSVG(r.adaptive.per_knowledge) : '');
}
async function loadQuality() {
  const j = await api('/api/quality');
  if (!j.ok) { document.getElementById('qualityBox').innerHTML = '<p>' + esc(j.error || '加载失败') + '</p>'; return; }
  const sus = j.quality.filter(function(q){ return q.flag !== 'normal'; });
  const rows = j.quality.map(function(q) {
    return '<tr><td>' + q.question_id + '</td><td>' + esc(q.stem.slice(0, 30)) + '…</td><td>' + q.total + '</td><td>' + Math.round((q.accuracy||0)*100) + '%</td><td>' + esc(q.flag) + '</td><td><button type="button" class="btn-secondary" onclick="setQuestionStatus(' + q.question_id + ',\'disabled\')">停用</button> <button type="button" class="btn-secondary" onclick="setQuestionStatus(' + q.question_id + ',\'published\')">恢复</button></td></tr>';
  }).join('');
  document.getElementById('qualityBox').innerHTML = '<p class="muted">疑似 ' + sus.length + ' 道（正确率低于 20% 或高于 95%，且作答≥5 题）。疑似题已不进薄弱训练和新抽题。</p><table><tr><th>题号</th><th>题干</th><th>作答</th><th>正确率</th><th>标记</th><th>操作</th></tr>' + (rows || '<tr><td colspan="6">暂无质量数据，先做几道题。</td></tr>') + '</table>';
}
async function setQuestionStatus(qid, status) {
  const j = await api('/api/questions/' + qid + '/status', {method: 'POST', body: JSON.stringify({status: status})});
  toast(j.ok ? '已更新' : '失败：' + (j.error || '请重试'));
  loadQuality();
}
async function refreshQuality() {
  const j = await api('/api/quality/refresh', {method: 'POST', body: '{}'});
  toast(j.ok ? '质量已重新核算' : '失败：' + (j.error || '请重试'));
  loadQuality();
}
async function loadTemplates() {
  const j = await api('/api/templates');
  const sel = document.getElementById('examTemplate');
  if (sel && j.ok) {
    sel.innerHTML = '<option value="">不使用模板（按题库顺序随机抽）</option>' + j.templates.map(function(x){ return '<option value="' + x.id + '">' + esc(x.title) + '（' + x.total_count + ' 题）</option>'; }).join('');
  }
  const box = document.getElementById('tplBox');
  if (box) box.innerHTML = j.ok ? j.templates.map(function(x){ return '<p>' + esc(x.title) + '（' + x.total_count + ' 题，规则 ' + esc(x.rules_json || '{}') + '）</p>'; }).join('') || '<p class="muted">暂无模板。</p>' : '';
}
async function createTemplate() {
  let rules = {};
  try { rules = JSON.parse(document.getElementById('tplRules').value || '{}'); } catch (e) { toast('配比规则不是有效 JSON'); return; }
  const j = await api('/api/templates', {method: 'POST', body: JSON.stringify({title: document.getElementById('tplTitle').value, total_count: Number(document.getElementById('tplTotal').value || 10), rules: rules})});
  toast(j.ok ? '模板已新建' : '失败：' + (j.error || '请重试'));
  loadTemplates();
}
window.addEventListener('load', async function() {
  const j = await api('/api/me');
  if (j.ok && j.user) { me = j.user; afterLogin(); }
});

/* =====================================================================
   v0.4 图表引擎 + 动效（追加覆盖 v0.3 同名函数）
   五种图全部内联 SVG + 原生 JS 手写，零 CDN、离线可用。
   动效：弹簧轻动 cubic-bezier(.34,1.56,.64,1)，200–350ms，可打断；
   数字滚动 600ms 内完成，可打断；prefers-reduced-motion 时瞬间显示。
   ===================================================================== */
const V04_COLORS = { blue: '#007aff', green: '#34c759', red: '#ff3b30', orange: '#ff9500', purple: '#af52de', teal: '#5ac8fa', gray: '#8e8e93' };
const reducedMotion = () => window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
function easeOutBack(t) { const c = 1.70158; return 1 + (c + 1) * Math.pow(t - 1, 3) + c * Math.pow(t - 1, 2); }
function easeOutCubic(t) { return 1 - Math.pow(1 - t, 3); }
function clamp01(v) { return Math.max(0, Math.min(1, v)); }

/* ---- 数字滚动：0 → 目标值，600ms，可打断（重复调用会取消上一轮） ---- */
function animateCount(el, target, opts) {
  opts = opts || {};
  const decimals = opts.decimals || 0, suffix = opts.suffix || '', prefix = opts.prefix || '';
  if (reducedMotion() || !isFinite(target)) { el.textContent = prefix + Number(target).toFixed(decimals) + suffix; return; }
  if (el._countRaf) cancelAnimationFrame(el._countRaf);
  const start = performance.now(), dur = 600;
  const step = (now) => {
    const p = clamp01((now - start) / dur);
    const eased = easeOutCubic(p);
    el.textContent = prefix + (target * eased).toFixed(decimals) + suffix;
    if (p < 1) el._countRaf = requestAnimationFrame(step);
  };
  el._countRaf = requestAnimationFrame(step);
}
function runCountUps(root) {
  root.querySelectorAll('[data-count]').forEach(function (el) {
    animateCount(el, parseFloat(el.getAttribute('data-count')), { decimals: parseInt(el.getAttribute('data-decimals') || '0', 10), suffix: el.getAttribute('data-suffix') || '' });
  });
}
/* ---- 卡片依次入场：每张延迟 60ms，可打断（新渲染会重置） ---- */
function revealStagger(root) {
  const cards = root.querySelectorAll('.reveal');
  cards.forEach(function (el, i) {
    el.classList.remove('in');
    if (reducedMotion()) { el.classList.add('in'); return; }
    setTimeout(function () { el.classList.add('in'); }, i * 60);
  });
}
function statCard(value, label, opts) {
  opts = opts || {};
  return '<div class="stat-card reveal"><div class="num" data-count="' + value + '" data-decimals="' + (opts.decimals || 0) + '" data-suffix="' + (opts.suffix || '') + '">' + value + (opts.suffix || '') + '</div><div class="lbl">' + esc(label) + '</div></div>';
}
function chartCard(title, sub, innerHtml) {
  return '<div class="chart-card reveal"><h4>' + esc(title) + '</h4><p class="sub">' + esc(sub) + '</p>' + innerHtml + '</div>';
}
function chartEmpty(text) { return '<div class="empty"><div class="big">📊</div><p class="muted">' + esc(text) + '</p></div>'; }

/* ---- 雷达图：知识点掌握度（动画：多边形从中心弹簧展开） ---- */
function radarChartSVG(items, uid) {
  if (!items || !items.length) return chartEmpty('还没有掌握度数据，先做 10 道练习。');
  const data = items.slice(0, 6);
  const cx = 130, cy = 130, R = 92;
  const angle = (i) => -Math.PI / 2 + i * 2 * Math.PI / data.length;
  const pt = (i, r) => (cx + r * Math.cos(angle(i))).toFixed(1) + ',' + (cy + r * Math.sin(angle(i))).toFixed(1);
  const grid = [0.25, 0.5, 0.75, 1].map(function (f) {
    return '<polygon points="' + data.map(function (k, i) { return pt(i, R * f); }).join(' ') + '" fill="none" stroke="#c6c6c8" stroke-width="1"/>';
  }).join('');
  const axes = data.map(function (k, i) { return '<line x1="' + cx + '" y1="' + cy + '" x2="' + pt(i, R).split(',')[0] + '" y2="' + pt(i, R).split(',')[1] + '" stroke="#e5e5ea"/>'; }).join('');
  const labels = data.map(function (k, i) {
    return '<text x="' + (cx + (R + 18) * Math.cos(angle(i))).toFixed(0) + '" y="' + (cy + (R + 18) * Math.sin(angle(i))).toFixed(0) + '" font-size="11" text-anchor="middle" fill="#666">' + esc(k.knowledge) + ' ' + Math.round((k.accuracy || 0) * 100) + '%</text>';
  }).join('');
  const centerPts = data.map(function (k, i) { return pt(i, 0); }).join(' ');
  const finalPts = data.map(function (k, i) { return pt(i, R * clamp01(k.accuracy || 0)); }).join(' ');
  const dots = data.map(function (k, i) {
    const p = pt(i, R * clamp01(k.accuracy || 0)).split(',');
    return '<circle class="radar-dot" data-i="' + i + '" cx="' + p[0] + '" cy="' + p[1] + '" r="4" fill="#007aff"><title>' + esc(k.knowledge) + '：正确率 ' + Math.round((k.accuracy || 0) * 100) + '%，作答 ' + (k.total || 0) + ' 道</title></circle>';
  }).join('');
  return '<svg viewBox="0 0 260 260" width="100%" style="max-width:280px;margin:0 auto" role="img" aria-label="知识点掌握雷达图">'
    + grid + axes
    + '<polygon class="radar-poly" data-final="' + finalPts + '" points="' + centerPts + '" fill="rgba(0,122,255,.25)" stroke="#007aff" stroke-width="2"/>'
    + dots + labels + '</svg>'
    + '<p class="legend"><i style="background:#007aff"></i>掌握度（正确率）<span>· 悬停圆点看详情</span></p>';
}
function animateRadar(root) {
  const poly = root.querySelector('.radar-poly');
  if (!poly) return;
  const finalPts = poly.getAttribute('data-final').split(' ').map(function (s) { return s.split(',').map(Number); });
  const cx = 130, cy = 130;
  if (reducedMotion()) { poly.setAttribute('points', poly.getAttribute('data-final')); root.querySelectorAll('.radar-dot').forEach(function (d) { d.setAttribute('opacity', '1'); }); return; }
  if (root._radarRaf) cancelAnimationFrame(root._radarRaf);
  const start = performance.now(), dur = 350;
  const step = (now) => {
    const p = clamp01((now - start) / dur), e = easeOutBack(p);
    poly.setAttribute('points', finalPts.map(function (pt) { return (cx + (pt[0] - cx) * e).toFixed(1) + ',' + (cy + (pt[1] - cy) * e).toFixed(1); }).join(' '));
    root.querySelectorAll('.radar-dot').forEach(function (d) { d.setAttribute('opacity', String(e)); });
    if (p < 1) root._radarRaf = requestAnimationFrame(step);
  };
  root._radarRaf = requestAnimationFrame(step);
}

/* ---- 趋势图：近14天作答量（柱）+ 正确率（折线描绘） ---- */
function trendChartSVG(trend) {
  if (!trend || !trend.length) return chartEmpty('暂无趋势数据，先做几道练习。');
  const data = trend.slice().reverse(); // 服务端是倒序，图表用时间正序
  const W = 560, H = 180, padL = 32, padR = 12, padT = 16, padB = 28;
  const maxTotal = Math.max.apply(null, data.map(function (d) { return d.total; }).concat([1]));
  const x = (i) => padL + i * (W - padL - padR) / Math.max(1, data.length - 1);
  const yVol = (v) => H - padB - (v / maxTotal) * (H - padT - padB);
  const yAcc = (d) => H - padB - (d.total ? (d.correct / d.total) : 0) * (H - padT - padB);
  const bars = data.map(function (d, i) {
    return '<rect class="trend-bar" data-h="' + (H - padB - yVol(d.total)).toFixed(1) + '" x="' + (x(i) - 8).toFixed(1) + '" y="' + yVol(d.total).toFixed(1) + '" width="16" height="' + (H - padB - yVol(d.total)).toFixed(1) + '" rx="3" fill="rgba(0,122,255,.18)"><title>' + esc(d.date) + '：作答 ' + d.total + ' 道，答对 ' + d.correct + ' 道</title></rect>';
  }).join('');
  const pts = data.map(function (d, i) { return x(i).toFixed(1) + ',' + yAcc(d).toFixed(1); }).join(' ');
  const dots = data.map(function (d, i) {
    const acc = d.total ? Math.round(d.correct / d.total * 100) : 0;
    return '<circle class="trend-dot" cx="' + x(i).toFixed(1) + '" cy="' + yAcc(d).toFixed(1) + '" r="4" fill="#34c759" stroke="#fff" stroke-width="1.5"><title>' + esc(d.date) + '：正确率 ' + acc + '%（' + d.correct + '/' + d.total + '）</title></circle>';
  }).join('');
  const labels = data.map(function (d, i) { return '<text x="' + x(i).toFixed(1) + '" y="' + (H - 8) + '" font-size="10" text-anchor="middle" fill="#8e8e93">' + esc(d.date.slice(5)) + '</text>'; }).join('');
  return '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" role="img" aria-label="近14天趋势图">'
    + '<line x1="' + padL + '" y1="' + (H - padB) + '" x2="' + (W - padR) + '" y2="' + (H - padB) + '" stroke="#c6c6c8"/>'
    + bars
    + '<polyline class="trend-line" points="' + pts + '" fill="none" stroke="#34c759" stroke-width="2.5" stroke-linejoin="round" stroke-linecap="round"/>'
    + dots + labels + '</svg>'
    + '<p class="legend"><i style="background:rgba(0,122,255,.35)"></i>作答量（柱）<i style="background:#34c759"></i>正确率（折线）</p>';
}
function animateTrend(root) {
  const line = root.querySelector('.trend-line');
  if (!line) return;
  if (reducedMotion()) { root.querySelectorAll('.trend-bar').forEach(function (b) { b.setAttribute('opacity', '1'); }); return; }
  if (root._trendRaf) cancelAnimationFrame(root._trendRaf);
  const start = performance.now(), dur = 350;
  let len = 0;
  try { len = line.getTotalLength(); } catch (e) { len = 0; }
  const step = (now) => {
    const p = clamp01((now - start) / dur), e = easeOutCubic(p);
    if (len) { line.style.strokeDasharray = String(len); line.style.strokeDashoffset = String(len * (1 - e)); }
    root.querySelectorAll('.trend-bar').forEach(function (b) {
      const h = parseFloat(b.getAttribute('data-h') || '0');
      const y0 = 152; // H - padB
      b.setAttribute('height', String(Math.max(0, h * e)));
      b.setAttribute('y', String(y0 - h * e));
    });
    root.querySelectorAll('.trend-dot').forEach(function (d) { d.setAttribute('opacity', String(e)); });
    if (p < 1) root._trendRaf = requestAnimationFrame(step);
  };
  root._trendRaf = requestAnimationFrame(step);
}

/* ---- 柱状图：各知识点作答与正确（双柱生长） ---- */
function barsChartSVG(byKn) {
  if (!byKn || !byKn.length) return chartEmpty('暂无知识点数据。');
  const data = byKn.slice(0, 8);
  const W = 560, H = 200, padL = 32, padB = 44, padT = 20;
  const maxV = Math.max.apply(null, data.map(function (k) { return k.total; }).concat([1]));
  const bw = (W - padL - 16) / data.length;
  const cols = data.map(function (k, i) {
    const x0 = padL + i * bw + 6;
    const hT = (k.total / maxV) * (H - padT - padB), hC = (k.correct / maxV) * (H - padT - padB);
    const y0 = H - padB;
    return '<g><rect class="col-bar" data-h="' + hT.toFixed(1) + '" x="' + x0.toFixed(1) + '" y="' + (y0 - hT).toFixed(1) + '" width="14" height="' + hT.toFixed(1) + '" rx="3" fill="rgba(0,122,255,.3)"><title>' + esc(k.knowledge) + '：作答 ' + k.total + ' 道</title></rect>'
      + '<rect class="col-bar" data-h="' + hC.toFixed(1) + '" x="' + (x0 + 16).toFixed(1) + '" y="' + (y0 - hC).toFixed(1) + '" width="14" height="' + hC.toFixed(1) + '" rx="3" fill="#34c759"><title>' + esc(k.knowledge) + '：答对 ' + k.correct + ' 道，正确率 ' + Math.round((k.accuracy || 0) * 100) + '%</title></rect>'
      + '<text x="' + (x0 + 15).toFixed(1) + '" y="' + (H - padB + 14) + '" font-size="10" text-anchor="middle" fill="#666">' + esc(k.knowledge.slice(0, 5)) + '</text>'
      + '<text x="' + (x0 + 15).toFixed(1) + '" y="' + (y0 - Math.max(hT, hC) - 6).toFixed(1) + '" font-size="11" font-weight="700" text-anchor="middle" fill="#000">' + Math.round((k.accuracy || 0) * 100) + '%</text></g>';
  }).join('');
  return '<svg viewBox="0 0 ' + W + ' ' + H + '" width="100%" role="img" aria-label="各知识点作答与正确柱状图">'
    + '<line x1="' + padL + '" y1="' + (H - padB) + '" x2="' + (W - 8) + '" y2="' + (H - padB) + '" stroke="#c6c6c8"/>' + cols + '</svg>'
    + '<p class="legend"><i style="background:rgba(0,122,255,.35)"></i>作答数<i style="background:#34c759"></i>答对数<span>· 柱顶为正确率</span></p>';
}
function animateBars(root) {
  if (reducedMotion()) return;
  if (root._barsRaf) cancelAnimationFrame(root._barsRaf);
  const start = performance.now(), dur = 350;
  const y0 = 156; // H - padB
  const step = (now) => {
    const p = clamp01((now - start) / dur), e = easeOutBack(p);
    root.querySelectorAll('.col-bar').forEach(function (b) {
      const h = parseFloat(b.getAttribute('data-h') || '0');
      b.setAttribute('height', String(Math.max(0, h * e)));
      b.setAttribute('y', String(y0 - h * e));
    });
    if (p < 1) root._barsRaf = requestAnimationFrame(step);
  };
  root._barsRaf = requestAnimationFrame(step);
}

/* ---- 热力图：部门 × 知识点（HTML 网格，悬停提示） ---- */
function heatmapHTML(heatmap, teams, singleRow) {
  const kns = Object.keys(heatmap || {});
  if (!kns.length) return chartEmpty('暂无热力数据。');
  const teamNames = teams && teams.length ? teams.map(function (t) { return typeof t === 'string' ? t : t.team; }) : Object.keys(heatmap[kns[0]] || {});
  const cellClass = (v) => v === undefined || v === null ? 'heat-none' : (v < 0.6 ? 'heat-low' : (v < 0.8 ? 'heat-mid' : 'heat-high'));
  const cols = singleRow ? kns.length : teamNames.length;
  let html = '<div class="heat-grid" style="grid-template-columns:repeat(' + (cols + 1) + ',1fr)"><div></div>';
  if (singleRow) {
    kns.forEach(function (kn) { html += '<div style="font-size:12px;color:#666;text-align:center">' + esc(kn.slice(0, 6)) + '</div>'; });
    html += '</div><div class="heat-grid" style="grid-template-columns:repeat(' + (cols + 1) + ',1fr)"><div style="font-size:12px;color:#666">掌握度</div>';
    kns.forEach(function (kn) {
      const v = heatmap[kn] && heatmap[kn][Object.keys(heatmap[kn])[0]];
      html += '<div class="heat-cell reveal ' + cellClass(v) + '" title="' + esc(kn) + '：正确率 ' + (v === undefined ? '—' : Math.round(v * 100) + '%') + '"><span class="v">' + (v === undefined ? '—' : Math.round(v * 100) + '%') + '</span></div>';
    });
    html += '</div>';
  } else {
    teamNames.forEach(function (tm) { html += '<div style="font-size:12px;color:#666;text-align:center">' + esc(tm) + '</div>'; });
    html += '</div><div class="heat-grid" style="grid-template-columns:repeat(' + (cols + 1) + ',1fr)">';
    kns.forEach(function (kn) {
      html += '<div style="font-size:12px;color:#666;display:flex;align-items:center">' + esc(kn.slice(0, 6)) + '</div>';
      teamNames.forEach(function (tm) {
        const v = heatmap[kn] && heatmap[kn][tm];
        html += '<div class="heat-cell reveal ' + cellClass(v) + '" title="' + esc(kn) + ' · ' + esc(tm) + '：正确率 ' + (v === undefined ? '—' : Math.round(v * 100) + '%') + '"><span class="v">' + (v === undefined ? '—' : Math.round(v * 100) + '%') + '</span></div>';
      });
    });
    html += '</div>';
  }
  return html + '<p class="legend"><i style="background:rgba(255,59,48,.35)"></i>低于 60%<i style="background:rgba(255,149,0,.35)"></i>60–80%<i style="background:rgba(52,199,89,.3)"></i>80% 以上</p>';
}

/* ---- 环形图：题型 / 难度占比（扇区生长，可切换） ---- */
function donutChartSVG(counts, opts) {
  opts = opts || {};
  if (!counts || !counts.length) return chartEmpty('暂无占比数据。');
  const total = counts.reduce(function (s, c) { return s + c.count; }, 0) || 1;
  const palette = ['#007aff', '#34c759', '#ff9500', '#af52de', '#5ac8fa', '#ff3b30'];
  const R = 70, C = 2 * Math.PI * R;
  let acc = 0;
  const segs = counts.map(function (c, i) {
    const frac = c.count / total;
    const dash = (frac * C).toFixed(1);
    const gap = (C - frac * C).toFixed(1);
    const off = (-acc * C).toFixed(1);
    acc += frac;
    return '<circle class="donut-seg" data-frac="' + frac.toFixed(4) + '" cx="90" cy="90" r="' + R + '" fill="none" stroke="' + palette[i % palette.length] + '" stroke-width="26" stroke-dasharray="' + dash + ' ' + gap + '" stroke-dashoffset="' + off + '" transform="rotate(-90 90 90)"><title>' + esc(c.label) + '：' + c.count + ' 道，占 ' + Math.round(frac * 100) + '%</title></circle>';
  }).join('');
  const legend = counts.map(function (c, i) {
    return '<span><i style="background:' + palette[i % palette.length] + '"></i>' + esc(c.label) + ' ' + c.count + ' 道（' + Math.round(c.count / total * 100) + '%）</span>';
  }).join('');
  return '<div class="donut-wrap"><svg viewBox="0 0 180 180" width="180" height="180" role="img" aria-label="占比环形图">' + segs
    + '<text x="90" y="86" font-size="26" font-weight="700" text-anchor="middle">' + total + '</text>'
    + '<text x="90" y="106" font-size="12" text-anchor="middle" fill="#8e8e93">题量（道）</text></svg>'
    + '<div class="legend" style="flex-direction:column;align-items:flex-start;gap:8px">' + legend + '</div></div>';
}
function animateDonut(root) {
  if (reducedMotion()) return;
  if (root._donutRaf) cancelAnimationFrame(root._donutRaf);
  const start = performance.now(), dur = 350;
  const segs = Array.prototype.slice.call(root.querySelectorAll('.donut-seg'));
  const C = 2 * Math.PI * 70;
  const step = (now) => {
    const p = clamp01((now - start) / dur), e = easeOutCubic(p);
    let acc = 0;
    segs.forEach(function (s) {
      const frac = parseFloat(s.getAttribute('data-frac')) * e;
      s.setAttribute('stroke-dasharray', (frac * C).toFixed(1) + ' ' + (C - frac * C).toFixed(1));
      s.setAttribute('stroke-dashoffset', String(-acc * C));
      acc += parseFloat(s.getAttribute('data-frac'));
    });
    if (p < 1) root._donutRaf = requestAnimationFrame(step);
  };
  root._donutRaf = requestAnimationFrame(step);
}

/* ---- 覆盖原 radarSVG：带弹簧展开动画 ---- */
function radarSVG(per) {
  if (!per || !per.length) return '<p class="muted">还没有掌握度数据，先做 10 道练习。</p>';
  return radarChartSVG(per.map(function (k) { return { knowledge: k.knowledge, accuracy: k.accuracy, total: k.total }; }));
}
function animateChartsIn(root) {
  root.querySelectorAll('.radar-poly').forEach(function () { animateRadar(root); });
  if (root.querySelector('.trend-line')) animateTrend(root);
  if (root.querySelector('.col-bar')) animateBars(root);
  if (root.querySelector('.donut-seg')) animateDonut(root);
}

/* ---- 覆盖 loadReport：可视化仪表盘（先做报告） ---- */
async function loadReport() {
  const box = document.getElementById('reportBox');
  const statsEl = document.getElementById('reportStats');
  const chartsEl = document.getElementById('reportCharts');
  const j = await api('/api/reports/me');
  if (!j.ok) { box.innerHTML = emptyState('⚠️', '加载失败', esc(j.error || '请重试')); return; }
  const r = j.report;
  const s = await api('/api/reports/stats');
  const stats = s.ok ? s.stats : { type_counts: [], difficulty_counts: [], total: 0 };
  if (!r.total) {
    statsEl.innerHTML = ''; chartsEl.innerHTML = '';
    box.innerHTML = emptyState('📊', '还没有作答记录', '先做 10 道练习，这里就会出现你的正确率、薄弱项和趋势。');
    return;
  }
  statsEl.innerHTML =
    statCard(r.total, '总作答（道）') +
    statCard(Math.round((r.accuracy || 0) * 100), '总正确率', { suffix: '%' }) +
    statCard(r.correct, '答对（道）') +
    statCard(r.wrong_count, '错题本（道）') +
    statCard(r.streak_days || 0, '连续学习（天）') +
    statCard(r.due_count || 0, '到期未复习（道）');
  const essay = r.essay || {total: 0, graded: 0, pending: 0, score: 0, max_score: 0};
  const plans = r.plans || [];
  statsEl.innerHTML += '<div class="stat-card reveal"><div class="num">' + essay.score + ' / ' + essay.max_score + '</div><div class="lbl">简答得分（分）</div></div>'
    + '<div class="stat-card reveal"><div class="num">' + plans.filter(function (p) { return p.pct >= 100; }).length + ' / ' + plans.length + '</div><div class="lbl">学习计划已完成</div></div>';
  const heatSingle = {};
  r.by_knowledge.forEach(function (k) { heatSingle[k.knowledge] = { '本人': k.accuracy || 0 }; });
  chartsEl.innerHTML =
    chartCard('知识点掌握雷达', '哪个知识点最弱，一眼看清', radarChartSVG(r.by_knowledge)) +
    chartCard('近 14 天趋势', '作答量（柱）与正确率（折线）', trendChartSVG(r.trend)) +
    chartCard('各知识点作答与正确', '深蓝是作答数，绿色是答对数，柱顶是正确率', barsChartSVG(r.by_knowledge)) +
    chartCard('知识点掌握热力', '低于 60% 标红，优先补', heatmapHTML(heatSingle, ['本人'], true)) +
    chartCard('题库占比环形', '当前题库的题型与难度分布', '<div style="margin-bottom:8px"><button type="button" class="btn-secondary" onclick="switchDonut(this,\'type\')">按题型</button> <button type="button" class="btn-secondary" onclick="switchDonut(this,\'diff\')">按难度</button></div><div id="reportDonut">' + donutChartSVG(stats.type_counts.map(function (c) { return { label: c.label, count: c.count }; })) + '</div>');
  box.innerHTML = '<p>' + esc(r.advice) + '</p>'
    + '<h4>知识点明细</h4><table><tr><th>知识点</th><th>作答</th><th>正确</th><th>正确率</th><th>Elo</th></tr>'
    + r.by_knowledge.map(function (k) { return '<tr><td>' + esc(k.knowledge) + '</td><td>' + k.total + '</td><td>' + k.correct + '</td><td>' + Math.round((k.accuracy || 0) * 100) + '%</td><td>' + k.elo + '</td></tr>'; }).join('') + '</table>'
    + '<h4>近 14 天明细</h4><table><tr><th>日期</th><th>作答</th><th>正确</th></tr>'
    + r.trend.map(function (t) { return '<tr><td>' + esc(t.date) + '</td><td>' + t.total + '</td><td>' + t.correct + '</td></tr>'; }).join('') + '</table>';
  box.innerHTML += '<h4>简答 / 材料题</h4><p>共提交 ' + essay.total + ' 道，已批 ' + essay.graded + ' 道，待批 ' + essay.pending + ' 道；得分 ' + essay.score + ' / ' + essay.max_score + ' 分（与选择题分开计分）。</p>'
    + '<h4>我的学习计划</h4>' + (plans.length ? plans.map(function (p) {
      return '<p><b>' + esc(p.title) + '</b>（' + esc(p.knowledge || '全部知识点') + '）：已做 ' + p.done + ' / ' + p.target + ' 道（' + p.pct + '%），截止 ' + esc(p.due_date || '未定') + (p.overdue ? '，<b style="color:var(--red)">已逾期</b>' : (p.days_left !== null && p.days_left !== undefined ? '，还剩 ' + p.days_left + ' 天' : '')) + '</p>';
    }).join('') : '<p class="muted">暂无学习计划。</p>');
  window._reportStats = stats;
  revealStagger(statsEl); revealStagger(chartsEl); runCountUps(statsEl);
  animateChartsIn(chartsEl);
}
function switchDonut(btn, mode) {
  const stats = window._reportStats || window._teamStats;
  if (!stats) return;
  const box = btn.closest('.chart-card').querySelector('#reportDonut, #teamDonut, #adminDonut');
  if (!box) return;
  const counts = mode === 'diff'
    ? stats.difficulty_counts.map(function (c) { return { label: '难度 ' + c.difficulty, count: c.count }; })
    : stats.type_counts.map(function (c) { return { label: c.label, count: c.count }; });
  box.innerHTML = donutChartSVG(counts);
  animateDonut(box);
}

/* ---- 覆盖 loadTeam：队报告仪表盘 ---- */
async function loadTeam() {
  const box = document.getElementById('teamBox');
  const statsEl = document.getElementById('teamStats');
  const chartsEl = document.getElementById('teamCharts');
  const j = await api('/api/reports/team');
  if (!j.ok) { box.innerHTML = emptyState('🔒', '看不到队报告', '民警账号只看自己的报告；队报告请用教官或管理员账号查看。'); return; }
  const r = j.report;
  const s = await api('/api/reports/stats');
  const stats = s.ok ? s.stats : { type_counts: [], difficulty_counts: [], total: 0 };
  window._teamStats = stats;
  statsEl.innerHTML =
    statCard(r.member_count, '队内人数（人）') +
    statCard(r.total_attempts, '总作答（道）') +
    statCard(Math.round((r.avg_accuracy || 0) * 100), '平均正确率', { suffix: '%' }) +
    statCard(r.wrong_top.length, '高频易错题（道）');
  let heatHtml = '';
  try {
    const ov = await api('/api/admin/overview');
    if (ov.ok && ov.overview && ov.overview.heatmap) {
      const heat = {};
      Object.keys(ov.overview.heatmap).forEach(function (kn) { if (ov.overview.heatmap[kn][r.team] !== undefined) heat[kn] = { [r.team]: ov.overview.heatmap[kn][r.team] }; });
      heatHtml = chartCard('本队知识点热力', '低于 60% 标红', heatmapHTML(heat, [r.team], true));
    }
  } catch (e) { heatHtml = ''; }
  chartsEl.innerHTML =
    chartCard('各知识点作答与正确', '本队各知识点表现', barsChartSVG(r.knowledge)) +
    chartCard('题库占比环形', '当前题库的题型与难度分布', '<div style="margin-bottom:8px"><button type="button" class="btn-secondary" onclick="switchDonut(this,\'type\')">按题型</button> <button type="button" class="btn-secondary" onclick="switchDonut(this,\'diff\')">按难度</button></div><div id="teamDonut">' + donutChartSVG(stats.type_counts.map(function (c) { return { label: c.label, count: c.count }; })) + '</div>') +
    (heatHtml || chartCard('高频易错题', '错得最多的题', r.wrong_top.length ? '<table><tr><th>题目</th><th>错题人数</th></tr>' + r.wrong_top.map(function (w) { return '<tr><td>题 ' + w.question_id + '</td><td>' + w.wrong_count + '</td></tr>'; }).join('') + '</table>' : '<p class="muted">暂无易错题。</p>'));
  box.innerHTML = '<p>队：' + esc(r.team) + '，人数 ' + r.member_count + '，总作答 ' + r.total_attempts + '，平均正确率 ' + Math.round((r.avg_accuracy || 0) * 100) + '%</p>'
    + '<h4>知识点明细</h4><table><tr><th>知识点</th><th>作答</th><th>正确</th><th>正确率</th></tr>' + r.knowledge.map(function (k) { return '<tr><td>' + esc(k.knowledge) + '</td><td>' + k.total + '</td><td>' + k.correct + '</td><td>' + Math.round((k.accuracy || 0) * 100) + '%</td></tr>'; }).join('') + '</table>'
    + '<h4>高频易错题</h4><table><tr><th>题目</th><th>错题人数</th></tr>' + r.wrong_top.map(function (w) { return '<tr><td>题 ' + w.question_id + '</td><td>' + w.wrong_count + '</td></tr>'; }).join('') + '</table>';
  revealStagger(statsEl); revealStagger(chartsEl); runCountUps(statsEl);
  animateChartsIn(chartsEl);
}

/* ---- 覆盖 loadAdmin：后台仪表盘（数字滚动 + 五种图） ---- */
async function loadAdmin() {
  const j = await api('/api/admin/overview');
  if (!j.ok) { document.getElementById('adminOverview').innerHTML = '<p>' + esc(j.error || '加载失败') + '</p>'; return; }
  const o = j.overview;
  const s = await api('/api/reports/stats');
  const stats = s.ok ? s.stats : { type_counts: [], difficulty_counts: [], total: 0 };
  window._reportStats = stats;
  document.getElementById('adminOverview').innerHTML =
    statCard(o.total_users, '总人数（人）') +
    statCard(o.active_today, '今日在线（人）') +
    statCard(o.today_attempts, '今日作答（道）') +
    statCard(Math.round((o.avg_accuracy || 0) * 100), '平均正确率', { suffix: '%' }) +
    statCard(o.pending_review, '待审核导入（个）') +
    statCard(o.suspects, '疑似错题（道）') +
    '<div class="stat-card reveal"><div class="num">' + (o.plans_active || 0) + '</div><div class="lbl">进行中学习计划</div></div>' +
    '<div class="stat-card reveal"><div class="num">' + (o.plans_overdue || 0) + '</div><div class="lbl">逾期学习计划</div></div>';
  document.getElementById('adminCharts').innerHTML =
    chartCard('近 14 天趋势', '全站作答量与正确率', trendChartSVG(o.trend14)) +
    chartCard('部门横向对比', '各部门平均正确率，只比平均和分布', barsChartSVG(o.teams.map(function (t) { return { knowledge: t.team, total: Math.max(1, t.total_attempts), correct: Math.round(t.total_attempts * (t.avg_accuracy || 0)), accuracy: t.avg_accuracy || 0 }; }))) +
    chartCard('知识点 × 部门掌握度热力', '低于 60% 标红', heatmapHTML(o.heatmap || {}, o.teams.map(function (t) { return t.team; }))) +
    chartCard('题库占比环形', '当前题库的题型与难度分布', '<div style="margin-bottom:8px"><button type="button" class="btn-secondary" onclick="switchDonut(this,\'type\')">按题型</button> <button type="button" class="btn-secondary" onclick="switchDonut(this,\'diff\')">按难度</button></div><div id="adminDonut">' + donutChartSVG(stats.type_counts.map(function (c) { return { label: c.label, count: c.count }; })) + '</div>') +
    chartCard('薄弱 TOP', '全站最弱的知识点', o.weak_top.length ? '<table><tr><th>知识点</th><th>作答</th><th>正确率</th></tr>' + o.weak_top.map(function (k) { return '<tr><td>' + esc(k.knowledge) + '</td><td>' + k.total + '</td><td>' + Math.round((k.accuracy || 0) * 100) + '%</td></tr>'; }).join('') + '</table>' : '<p class="muted">暂无薄弱项。</p>');
  document.getElementById('adminWarnings').innerHTML = o.warnings.length
    ? '<ul>' + o.warnings.map(function (w) { return '<li><b style="color:var(--red)">预警</b> ' + esc(w.display_name) + (w.team ? '（' + esc(w.team) + '）' : '') + '：' + esc(w.detail) + '</li>'; }).join('') + '</ul>'
    : '<p class="muted">暂无预警。</p>';
  if (o.plans_overdue) { document.getElementById('adminWarnings').innerHTML += '<p><b style="color:var(--red)">预警</b> 学习计划逾期：' + o.plans_overdue + ' 个计划到期仍未完成，去后台“学习计划下发”看明细。</p>'; }
  const ov = document.getElementById('adminOverview'), ch = document.getElementById('adminCharts');
  revealStagger(ov); revealStagger(ch); runCountUps(ov);
  animateChartsIn(ch);
  loadQuality();
  loadTemplates();
}

/* ---- 覆盖 loadAdminUser：个人明细也带数字滚动与雷达动画 ---- */
async function loadAdminUser() {
  const id = document.getElementById('adminUserId').value;
  const j = await api('/api/admin/user/' + id);
  if (!j.ok) { document.getElementById('adminPerson').innerHTML = '<p>' + esc(j.error || '加载失败') + '</p>'; return; }
  const r = j.report;
  document.getElementById('adminPerson').innerHTML = '<div class="dash-grid">'
    + statCard(r.total, '总作答（道）')
    + statCard(Math.round((r.accuracy || 0) * 100), '正确率', { suffix: '%' })
    + statCard(r.streak_days || 0, '连续学习（天）')
    + statCard(r.due_count || 0, '到期未复习（道）') + '</div>'
    + '<p><b>' + esc(r.display_name) + '</b>（' + esc(r.team) + '）。查看已记审计。</p>'
    + (r.adaptive ? '<div id="adminPersonRadar">' + radarChartSVG(r.adaptive.per_knowledge) + '</div>' : '');
  const box = document.getElementById('adminPerson');
  revealStagger(box); runCountUps(box); animateRadar(box);
}

/* =====================================================================
   v0.4 答题动效与画面细节（覆盖）
   ===================================================================== */
function renderQuestions(list, containerId, kind) {
  const box = document.getElementById(containerId);
  if (!list.length) {
    box.innerHTML = emptyState('📝', '暂无题目', kind === 'exam' ? '请先开始考核。' : '先做几道自由练习，错题本有了内容后这里才会有题目。');
    return;
  }
  box.innerHTML = list.map(function (q, i) {
    const imgs = (q.assets || []).map(function (a) { return '<figure class="q-img"><img src="/assets/' + esc(a.path) + '" alt="题目配图"></figure>'; }).join('');
    const opts = q.options.map(function (o) {
      const input = q.type === 'multi'
        ? '<input type="checkbox" name="q' + q.id + '" value="' + o.label + '" onchange="markSelected(' + q.id + ')">'
        : '<input type="radio" name="q' + q.id + '" value="' + o.label + '" onchange="markSelected(' + q.id + ')">';
      return '<label class="opt">' + input + '<span><b>' + o.label + '.</b> ' + esc(o.content) + '</span></label>';
    }).join('');
    const btn = kind === 'exam'
      ? '<button type="button" onclick="saveExamAnswer(' + q.id + ')">保存草稿</button>'
      : '<button type="button" onclick="submitOne(' + q.id + ', \'' + kind + '\')">提交本题</button>';
    const typeName = q.type === 'multi' ? '多选' : (q.type === 'judge' ? '判断' : '单选');
    return '<article class="q" id="qbox-' + q.id + '" style="animation-delay:' + Math.min(i, 5) * 60 + 'ms"><p class="q-meta">第 ' + (i + 1) + ' 题 · ' + typeName + ' · ' + esc(q.subject) + ' · 难度 ' + q.difficulty + ' / 5</p>'
      + '<p class="q-stem">' + esc(q.stem) + '</p>' + imgs
      + '<p class="muted">知识点：' + esc((q.knowledge || []).join('、') || '未标注') + '</p>'
      + '<div role="group" aria-label="第 ' + (i + 1) + ' 题选项">' + opts + '</div>'
      + '<p style="margin-top:16px">' + btn + ' <span id="res-' + q.id + '"></span></p></article>';
  }).join('');
  if (reducedMotion()) { box.querySelectorAll('.q').forEach(function (el) { el.style.animation = 'none'; el.style.opacity = '1'; }); }
}
function markSelected(qid) {
  const box = document.getElementById('qbox-' + qid);
  if (!box) return;
  box.querySelectorAll('.opt').forEach(function (l) {
    const inp = l.querySelector('input');
    const was = l.classList.contains('selected');
    l.classList.toggle('selected', !!(inp && inp.checked));
    if (!was && inp && inp.checked && !reducedMotion()) {
      l.classList.remove('pop'); void l.offsetWidth; l.classList.add('pop');
    }
  });
}
async function submitOne(qid, kind) {
  const ans = getAnswer(qid);
  if (!ans) { toast('请先选一个答案'); return; }
  const btn = document.querySelector('#qbox-' + qid + ' button');
  if (btn) btn.disabled = true;
  const j = await api('/api/attempts', {method: 'POST', body: JSON.stringify({question_id: qid, answer: ans, mode: 'practice'})});
  if (btn) btn.disabled = false;
  const el = document.getElementById('res-' + qid);
  if (!j.ok) { toast('提交失败：' + (j.error || '请重试')); return; }
  paintOptions(qid, j.correct_answer || '');
  const elab = '<br><span class="muted">精细加工：想一想，为什么错的选项错、正确选项为什么对？把理由用自己的话说一遍，再做下一题。</span>';
  el.innerHTML = j.is_correct
    ? '<span class="feedback ok pop" style="display:block"><span class="answer">答对了 ✓</span><br>解析：' + esc(j.explanation || '暂无解析') + elab + '</span>'
    : '<span class="feedback no pop" style="display:block"><span class="answer">答错了，正确答案是 ' + esc(j.correct_answer) + '</span><br>解析：' + esc(j.explanation || '暂无解析') + elab + '</span>';
  try { localStorage.setItem('draft-practice-' + qid, ans); } catch (e) {}
}
async function saveExamAnswer(qid) {
  if (!examSession) { toast('请先开始考核'); return; }
  const ta = document.getElementById('essay-' + qid);
  const ans = ta ? ta.value.trim() : getAnswer(qid);
  if (!ans) { toast('请先写答案或选一个答案'); return; }
  const j = await api('/api/exams/' + examSession.session_id + '/answer', {method: 'POST', body: JSON.stringify({question_id: qid, answer: ans})});
  const el = document.getElementById('res-' + qid);
  if (el) {
    el.innerHTML = j.ok ? '<span class="saved-pop">✓ 草稿已保存</span>' : '保存失败：' + (j.error || '请重试');
    if (j.ok && !reducedMotion()) { const s = el.querySelector('.saved-pop'); if (s) { s.classList.remove('saved-pop'); void s.offsetWidth; s.classList.add('saved-pop'); } }
  }
  if (j.ok) { toast('草稿已保存'); try { localStorage.setItem('draft-exam-' + examSession.session_id + '-' + qid, ans); } catch (e) {} }
}
async function submitExam() {
  if (!examSession) { toast('没有进行中的考核'); return; }
  const j = await api('/api/exams/' + examSession.session_id + '/submit', {method: 'POST', body: '{}'});
  clearInterval(examTimerId); clearInterval(examSyncId);
  document.getElementById('examTimer').textContent = '';
  if (!j.ok) { toast('交卷失败：' + (j.error || '请重试')); return; }
  document.getElementById('examResult').innerHTML = '<div class="card score-pop" style="margin-top:16px"><h3>交卷完成</h3><p>得分：<b class="num" data-count="' + j.score + '" data-decimals="0">' + j.score + '</b> / ' + j.total + '</p>' + (j.essay_pending ? '<p class="muted">其中简答 ' + j.essay_pending + ' 道待教官人工批阅，不计入自动分。</p>' : '') + '<p class="muted">错题已进错题本，去“薄弱项”练一练。</p></div>';
  document.getElementById('examPrint').innerHTML = '<a class="btn btn-secondary" href="/api/exams/' + examSession.session_id + '/print" target="_blank" rel="noopener">打印成绩单</a>';
  runCountUps(document.getElementById('examResult'));
  const sid = examSession.session_id;
  examSession = null;
  toast('已交卷，得分 ' + j.score + ' / ' + j.total);
  try { localStorage.removeItem('exam-session'); } catch (e) {}
  void sid;
}

/* =====================================================================
   v0.5 P1（追加覆盖）
   1）图文错位复核：配对清单、置信度徽章、换题、确认/驳回
   2）PDF 文字型导入：复用 uploadFile（/api/import/pdf）
   3）简答/材料题：文字作答 + 人工批阅（不自动判分）
   4）学习计划：下发 + 我的进度 + 后台列表与逾期预警
   ===================================================================== */
function showTab(name) {
  const names = ['practice', 'essay', 'weak', 'exam', 'report', 'team', 'import', 'admin'];
  names.forEach(function (n) {
    const panel = document.getElementById('tab' + n.charAt(0).toUpperCase() + n.slice(1));
    if (!panel) return;
    const isCurrent = n === name;
    panel.classList.toggle('hidden', !isCurrent);
    if (isCurrent) { panel.classList.remove('panel'); void panel.offsetWidth; panel.classList.add('panel'); }
    const b = document.getElementById('tab-' + n);
    if (b) { b.classList.toggle('active', isCurrent); b.setAttribute('aria-selected', isCurrent ? 'true' : 'false'); }
  });
  document.body.classList.toggle('exam-mode', name === 'exam');
  if (name === 'report') loadReport();
  if (name === 'team') loadTeam();
  if (name === 'import') loadJobs();
  if (name === 'weak') loadAdaptive();
  if (name === 'admin') { loadAdmin(); loadEssayQueue(); loadPlansAdmin(); }
  if (name === 'essay') { loadEssayQuestions(); loadEssayMine(); }
}

/* ---- renderQuestions 覆盖：简答/材料题渲染 textarea ---- */
function renderQuestions(list, containerId, kind) {
  const box = document.getElementById(containerId);
  if (!list.length) {
    box.innerHTML = emptyState('📝', '暂无题目', kind === 'exam' ? '请先开始考核。' : (kind === 'essay' ? '暂无简答 / 材料题，教官可在后台新建。' : '先做几道自由练习，错题本有了内容后这里才会有题目。'));
    return;
  }
  box.innerHTML = list.map(function (q, i) {
    const imgs = (q.assets || []).map(function (a) { return '<figure class="q-img"><img src="/assets/' + esc(a.path) + '" alt="题目配图"></figure>'; }).join('');
    const typeName = q.type === 'multi' ? '多选' : (q.type === 'judge' ? '判断' : (q.type === 'short' ? '简答' : (q.type === 'material' ? '材料' : '单选')));
    const head = '<article class="q" id="qbox-' + q.id + '" style="animation-delay:' + Math.min(i, 5) * 60 + 'ms"><p class="q-meta">第 ' + (i + 1) + ' 题 · ' + typeName + ' · ' + esc(q.subject) + ' · 难度 ' + q.difficulty + ' / 5</p>'
      + '<p class="q-stem">' + esc(q.stem) + '</p>' + imgs
      + '<p class="muted">知识点：' + esc((q.knowledge || []).join('、') || '未标注') + '</p>';
    if (q.type === 'short' || q.type === 'material') {
      const ebtn = kind === 'exam'
        ? '<button type="button" onclick="saveExamAnswer(' + q.id + ')">保存草稿</button>'
        : '<button type="button" onclick="submitEssay(' + q.id + ')">提交文字答案</button>';
      return head + '<p><label for="essay-' + q.id + '">你的答案（文字）</label><textarea id="essay-' + q.id + '" rows="4" placeholder="写清楚要点，教官按评分要点人工批阅"></textarea></p>'
        + '<p style="margin-top:16px">' + ebtn + ' <span id="res-' + q.id + '"></span></p></article>';
    }
    const opts = q.options.map(function (o) {
      const input = q.type === 'multi'
        ? '<input type="checkbox" name="q' + q.id + '" value="' + o.label + '" onchange="markSelected(' + q.id + ')">'
        : '<input type="radio" name="q' + q.id + '" value="' + o.label + '" onchange="markSelected(' + q.id + ')">';
      return '<label class="opt">' + input + '<span><b>' + o.label + '.</b> ' + esc(o.content) + '</span></label>';
    }).join('');
    const btn = kind === 'exam'
      ? '<button type="button" onclick="saveExamAnswer(' + q.id + ')">保存草稿</button>'
      : '<button type="button" onclick="submitOne(' + q.id + ', \'' + kind + '\')">提交本题</button>';
    return head + '<div role="group" aria-label="第 ' + (i + 1) + ' 题选项">' + opts + '</div>'
      + '<p style="margin-top:16px">' + btn + ' <span id="res-' + q.id + '"></span></p></article>';
  }).join('');
  if (reducedMotion()) { box.querySelectorAll('.q').forEach(function (el) { el.style.animation = 'none'; el.style.opacity = '1'; }); }
}

/* ---- 简答：作答 / 我的提交 ---- */
async function loadEssayQuestions() {
  const j = await api('/api/essay/questions');
  const box = document.getElementById('essayList');
  if (!box) return;
  if (!j.ok) { box.innerHTML = emptyState('⚠️', '加载失败', esc(j.error || '请重试')); return; }
  renderQuestions(j.questions, 'essayList', 'essay');
}
async function submitEssay(qid) {
  const ta = document.getElementById('essay-' + qid);
  const ans = ta ? ta.value.trim() : '';
  if (!ans) { toast('请先写答案再提交'); return; }
  const j = await api('/api/essay/submit', {method: 'POST', body: JSON.stringify({question_id: qid, answer: ans})});
  const el = document.getElementById('res-' + qid);
  if (!j.ok) { toast('提交失败：' + (j.error || '请重试')); return; }
  if (el) el.innerHTML = '<span class="feedback ok" style="display:block">已提交，待教官人工批阅。得分与评语会出现在“我的提交”里。</span>';
  if (ta) ta.value = '';
  toast('已提交，待教官批阅');
  loadEssayMine();
}
async function loadEssayMine() {
  const box = document.getElementById('essayMine');
  if (!box) return;
  const j = await api('/api/essay/mine');
  if (!j.ok) { box.innerHTML = '<p>' + esc(j.error || '加载失败') + '</p>'; return; }
  if (!j.submissions.length) { box.innerHTML = '<p class="muted">还没有提交过简答 / 材料题。</p>'; return; }
  box.innerHTML = '<table><tr><th>题目</th><th>状态</th><th>得分</th><th>评语</th></tr>' + j.submissions.map(function (s) {
    const state = s.status === 'graded' ? '已批阅' : '待批阅';
    const score = s.status === 'graded' ? s.score + ' / ' + s.max_score : '—';
    return '<tr><td>' + esc((s.stem || '').slice(0, 40)) + '</td><td>' + state + '</td><td>' + score + '</td><td>' + esc(s.comment || '') + '</td></tr>';
  }).join('') + '</table>';
}

/* ---- 简答批阅队列（教官/管理员） ---- */
async function loadEssayQueue() {
  const box = document.getElementById('essayQueue');
  if (!box) return;
  const j = await api('/api/essay/queue');
  if (!j.ok) { box.innerHTML = '<p>' + esc(j.error || '加载失败') + '</p>'; return; }
  if (!j.queue.length) { box.innerHTML = '<p class="muted">待批队列为空。</p>'; return; }
  box.innerHTML = j.queue.map(function (s) {
    return '<article class="q"><p class="q-meta">' + esc(s.display_name || '') + '（' + esc(s.team || '') + '）· 满分 ' + s.max_score + ' 分</p>'
      + '<p class="q-stem">' + esc(s.stem || '') + '</p>'
      + '<p><b>参考答案：</b>' + esc(s.reference_answer || '未填') + '</p>'
      + '<p><b>评分要点：</b>' + esc(s.rubric || '未填') + '</p>'
      + '<div class="field-row"><div><label for="score-' + s.id + '">分数（0–' + s.max_score + '）</label><input id="score-' + s.id + '" type="number" min="0" max="' + s.max_score + '" step="0.5"></div>'
      + '<div><label for="comment-' + s.id + '">评语</label><input id="comment-' + s.id + '" placeholder="写清楚得分点和不足"></div></div>'
      + '<p style="margin-top:16px"><button type="button" onclick="gradeEssay(' + s.id + ')">提交批阅</button> <span id="grade-' + s.id + '"></span></p></article>';
  }).join('');
}
async function gradeEssay(rid) {
  const scoreEl = document.getElementById('score-' + rid);
  const commentEl = document.getElementById('comment-' + rid);
  const score = scoreEl ? parseFloat(scoreEl.value) : NaN;
  if (isNaN(score)) { toast('请先填分数'); return; }
  const j = await api('/api/essay/review', {method: 'POST', body: JSON.stringify({review_id: rid, score: score, comment: commentEl ? commentEl.value : ''})});
  const el = document.getElementById('grade-' + rid);
  if (!j.ok) { toast('批阅失败：' + (j.error || '请重试')); return; }
  if (el) el.textContent = j.passed ? '已批阅：通过' : '已批阅：未通过（已进错题本）';
  toast('批阅完成');
  loadEssayQueue();
}

/* ---- 学习计划：下发 / 后台列表 ---- */
async function createPlan() {
  const scope = document.getElementById('planScope').value;
  const body = {
    title: document.getElementById('planTitle').value.trim(),
    knowledge: document.getElementById('planKnowledge').value.trim(),
    target_count: Number(document.getElementById('planTarget').value || 0),
    daily_count: Number(document.getElementById('planDaily').value || 0),
    due_date: document.getElementById('planDue').value,
    scope: scope,
    team: document.getElementById('planTeam').value.trim(),
    user_id: document.getElementById('planUserId').value ? Number(document.getElementById('planUserId').value) : null
  };
  if (!body.title) { toast('计划要有名称'); return; }
  const j = await api('/api/plans', {method: 'POST', body: JSON.stringify(body)});
  if (!j.ok) { toast('下发失败：' + (j.error || '请重试')); return; }
  toast('已下发给 ' + j.assigned + ' 人');
  loadPlansAdmin();
}
async function loadPlansAdmin() {
  const box = document.getElementById('plansBox');
  if (!box) return;
  const j = await api('/api/plans');
  if (!j.ok) { box.innerHTML = '<p>' + esc(j.error || '加载失败') + '</p>'; return; }
  if (!j.plans.length) { box.innerHTML = '<p class="muted">暂无学习计划。</p>'; return; }
  box.innerHTML = '<table><tr><th>计划</th><th>知识点</th><th>目标</th><th>下发</th><th>完成</th><th>平均进度</th><th>截止</th></tr>' + j.plans.map(function (p) {
    return '<tr><td>' + esc(p.title) + '</td><td>' + esc(p.knowledge || '全部') + '</td><td>' + p.target_count + ' 道</td><td>' + p.assigned + ' 人</td><td>' + p.done_count + ' 人</td><td>' + p.avg_pct + '%</td><td>' + esc(p.due_date || '未定') + '</td></tr>';
  }).join('') + '</table>';
}

/* ---- 图文配对复核 ---- */
async function loadPairings(jobId) {
  const box = document.getElementById('pairingBox');
  if (!box) return;
  if (!jobId) { box.innerHTML = '<p class="muted">暂无导入任务。</p>'; return; }
  const j = await api('/api/import/jobs/' + jobId + '/pairings');
  if (!j.ok) { box.innerHTML = '<p>' + esc(j.error || '加载失败') + '</p>'; return; }
  const rep = j.pairing || {};
  let html = '<p>配对报告（任务 ' + j.job_id + ' · ' + esc(j.filename || '') + '）：自动过 ' + (rep.auto || 0) + ' 张，复核 ' + (rep.review || 0) + ' 张，人工 ' + (rep.manual || 0) + ' 张。</p>';
  if (!j.pairings.length) { html += '<p class="muted">本次导入没有图片配对。</p>'; box.innerHTML = html; return; }
  html += '<table><tr><th>图片</th><th>题干</th><th>置信度</th><th>状态</th><th>操作</th></tr>' + j.pairings.map(function (p) {
    const conf = Math.round((p.confidence || 0) * 100) + '%';
    const badge = p.status === 'auto' ? '自动过' : (p.status === 'review' ? '待复核' : (p.status === 'manual' ? '人工' : (p.status === 'confirmed' ? '已确认' : p.status)));
    const img = p.asset_path ? '<img src="/assets/' + esc(p.asset_path) + '" alt="配图" style="max-width:120px">' : esc(p.filename || '（待指派）');
    return '<tr><td>' + img + '</td><td>' + esc((p.stem || '（未指派题目）').slice(0, 40)) + '</td><td>' + conf + '</td><td>' + badge + '</td><td>'
      + '<input type="number" id="pq-' + p.id + '" placeholder="换到题号" style="max-width:110px"> '
      + '<button type="button" class="btn-secondary" onclick="confirmPairing(' + p.id + ')">确认</button> '
      + '<button type="button" class="btn-danger" onclick="rejectPairing(' + p.id + ')">驳回</button></td></tr>';
  }).join('') + '</table>';
  box.innerHTML = html;
}
async function confirmPairing(pid) {
  const el = document.getElementById('pq-' + pid);
  const body = {};
  if (el && el.value) body.question_id = Number(el.value);
  const j = await api('/api/import/pairings/' + pid + '/confirm', {method: 'POST', body: JSON.stringify(body)});
  if (!j.ok) { toast('确认失败：' + (j.error || '请重试')); return; }
  toast('已确认配对');
  if (lastJobId) loadPairings(lastJobId);
}
async function rejectPairing(pid) {
  showModal({title: '驳回配对', body: '驳回后这张图片会从题库里删掉，不再挂到任何题目。确定驳回吗？', okText: '驳回', danger: true, onOk: async function () {
    const j = await api('/api/import/pairings/' + pid + '/reject', {method: 'POST', body: '{}'});
    if (!j.ok) { toast('驳回失败：' + (j.error || '请重试')); return; }
    toast('已驳回');
    if (lastJobId) loadPairings(lastJobId);
  }});
}

// ---- v0.6：联邦共享 / 备份 / 本地 AI 变式（纯原生 JS，无 CDN） ----
async function loadFed() {
  const box = document.getElementById('fedBox');
  if (!box) return;
  const h = await api('/api/federation/hosts');
  if (!h.ok) { box.innerHTML = '<p class="muted">加载失败：' + esc(h.error || '') + '</p>'; return; }
  const p = await api('/api/federation/packages');
  let html = '';
  if (!h.hosts.length) html += '<p class="muted">还没登记对方主机。先在上面填对方站名、IP 和共享令牌。</p>';
  h.hosts.forEach(function(x){
    html += '<div class="card" style="margin:8px 0"><h4>' + esc(x.name) + '（' + esc(x.host) + ':' + x.port + '）</h4>'
      + '<p class="muted">状态：' + esc(x.status) + '；上次连通：' + esc(x.last_seen || '未测试') + '；对方题数：' + (x.last_count || 0)
      + (x.last_error ? '；最近一次失败：' + esc(x.last_error) : '') + '</p>'
      + '<p><button type="button" class="btn-secondary" onclick="testFed(' + x.id + ')">测试连通</button> '
      + '<button type="button" class="btn-secondary" onclick="pullFed(' + x.id + ')">拉取题库</button> '
      + '<button type="button" class="btn-danger" onclick="delFed(' + x.id + ')">删除登记</button></p></div>';
  });
  if (p.ok && p.packages.length) {
    html += '<h4>最近的共享包记录</h4>';
    p.packages.slice(0, 5).forEach(function(pk){
      html += '<p class="muted">#' + pk.id + ' ' + (pk.direction === 'in' ? '拉入' : '发出') + ' · ' + esc(pk.filename) + ' · ' + pk.question_count + ' 道 · ' + esc(pk.created_at) + ' · ' + esc(pk.status) + '</p>';
    });
  }
  box.innerHTML = html;
}
async function showFedToken() {
  const j = await api('/api/federation/token');
  if (!j.ok) { toast('查看失败：' + (j.error || '')); return; }
  showModal({title: '本站共享令牌', body: '把这个令牌和本站地址发给对方管理员，对方登记时填进去才能拉取本站题库。令牌：' + j.token + '；本站地址：' + j.lan_url, okText: '知道了'});
}
async function registerFed() {
  const body = {name: document.getElementById('fedName').value.trim(), host: document.getElementById('fedHost').value.trim(), port: Number(document.getElementById('fedPort').value) || 8765, token: document.getElementById('fedTokenInput').value.trim()};
  const j = await api('/api/federation/hosts', {method: 'POST', body: JSON.stringify(body)});
  if (!j.ok) { toast('登记失败：' + (j.error || '')); return; }
  toast('已登记对方主机');
  loadFed();
}
async function testFed(id) {
  const j = await api('/api/federation/hosts/' + id + '/test', {method: 'POST', body: JSON.stringify({})});
  if (!j.ok) { toast('连通失败：' + (j.error || '')); loadFed(); return; }
  toast('连通正常，对方题库 ' + (j.catalog.question_count || 0) + ' 道');
  loadFed();
}
function pullFed(id) {
  showModal({title: '拉取对方题库', body: '从对方主机拉取已发布题：先按内容哈希去重，拉回的题进草稿，须在“题库导入”里审核后发布，不直接覆盖本站题库。确定拉取吗？', okText: '拉取', onOk: async function(){
    const j = await api('/api/federation/pull', {method: 'POST', body: JSON.stringify({host_id: id})});
    if (!j.ok) { toast('拉取失败：' + (j.error || '')); return; }
    toast(j.message || '拉取完成');
    loadFed();
  }});
}
function delFed(id) {
  showModal({title: '删除登记', body: '删除这台对方主机的登记，之后不能再从它拉题（已拉回的题不受影响）。确定删除吗？', okText: '删除', danger: true, onOk: async function(){
    const j = await api('/api/federation/hosts/' + id + '/delete', {method: 'POST', body: JSON.stringify({})});
    if (!j.ok) { toast('删除失败：' + (j.error || '')); return; }
    toast('已删除登记');
    loadFed();
  }});
}
async function loadBackup() {
  const box = document.getElementById('backupBox');
  if (!box) return;
  const s = await api('/api/backup/status');
  const l = await api('/api/backup/list');
  if (!s.ok || !l.ok) { box.innerHTML = '<p class="muted">加载失败：' + esc((s.error || l.error || '')) + '</p>'; return; }
  const b = s.backup;
  let html = '<p class="muted">磁盘剩余 ' + b.disk.free_gb + ' GB（已用 ' + b.disk.used_pct + '%）；每日自动备份：' + (b.auto ? '开' : '关') + '，保留最近 ' + b.keep + ' 份；共 ' + b.count + ' 份。'
    + (b.last_at ? '最近一次：' + esc(b.last_at) + '（' + esc(b.last_filename) + '）。' : '还没有备份。') + '</p>';
  if (!l.backups.length) html += '<p class="muted">还没有备份，点“立即备份”备一份。</p>';
  l.backups.forEach(function(x){
    html += '<p>· ' + esc(x.filename) + '（' + Math.round((x.size_bytes || 0) / 1024) + ' KB，' + esc(x.created_at) + '，' + esc(x.note || '') + '） '
      + '<a href="/api/backup/download/' + encodeURIComponent(x.filename) + '" target="_blank" rel="noopener">下载</a> '
      + '<button type="button" class="btn-secondary" onclick="restoreBackup(\'' + esc(x.filename) + '\')">恢复</button></p>';
  });
  box.innerHTML = html;
}
async function createBackup() {
  const j = await api('/api/backup/create', {method: 'POST', body: JSON.stringify({note: '手动备份'})});
  if (!j.ok) { toast('备份失败：' + (j.error || '')); return; }
  toast('备份完成：' + j.filename);
  loadBackup();
}
function restoreBackup(fname) {
  showModal({title: '恢复备份', body: '恢复会用备份内容覆盖当前数据库和题库附件。恢复前会自动再备一份当前库防丢。恢复后请刷新页面。确定从 ' + fname + ' 恢复吗？', okText: '恢复', danger: true, onOk: async function(){
    const j = await api('/api/backup/restore', {method: 'POST', body: JSON.stringify({filename: fname})});
    if (!j.ok) { toast('恢复失败：' + (j.error || '')); return; }
    toast('已恢复，恢复前自动备份为 ' + (j.auto_backup || ''));
    loadBackup();
  }});
}
async function loadVariants() {
  const box = document.getElementById('aiBox');
  if (!box) return;
  const j = await api('/api/ai/variants');
  if (!j.ok) { box.innerHTML = '<p class="muted">加载失败：' + esc(j.error || '') + '</p>'; return; }
  if (!j.variants.length) { box.innerHTML = '<p class="muted">还没有变式。填母题 ID 生成：变式先进草稿，审核通过才能发布。</p>'; return; }
  let html = '';
  j.variants.forEach(function(v){
    html += '<div class="card" style="margin:8px 0"><h4>变式 #' + v.id + '（' + esc(v.source || '') + '）· ' + esc(v.status) + '</h4>'
      + '<p>' + esc(v.stem) + '</p><p class="muted">母题：' + esc(v.parent_stem || '') + '</p>'
      + '<p><button type="button" class="btn-secondary" onclick="approveVariant(' + v.id + ')">审核通过并发布</button> '
      + '<button type="button" class="btn-danger" onclick="rejectVariant(' + v.id + ')">驳回</button></p></div>';
  });
  box.innerHTML = html;
}
async function genVariants() {
  const qid = Number(document.getElementById('aiQid').value) || 0;
  const count = Number(document.getElementById('aiCount').value) || 2;
  const j = await api('/api/ai/variants', {method: 'POST', body: JSON.stringify({question_id: qid, count: count})});
  if (!j.ok) { toast('生成失败：' + (j.error || '')); return; }
  toast('已生成 ' + j.variant_ids.length + ' 道变式进草稿，请审核');
  loadVariants();
}
async function approveVariant(id) {
  const j = await api('/api/ai/variants/' + id + '/approve', {method: 'POST', body: JSON.stringify({})});
  if (!j.ok) { toast('审核失败：' + (j.error || '')); return; }
  toast('变式已发布');
  loadVariants();
}
async function rejectVariant(id) {
  const j = await api('/api/ai/variants/' + id + '/reject', {method: 'POST', body: JSON.stringify({})});
  if (!j.ok) { toast('驳回失败：' + (j.error || '')); return; }
  toast('变式已驳回');
  loadVariants();
}
async function loadTip() {
  const box = document.getElementById('tipBox');
  const qid = Number(document.getElementById('tipQid').value) || 0;
  const j = await api('/api/ai/tips/' + qid);
  if (!j.ok) { box.innerHTML = '<p class="muted">查看失败：' + esc(j.error || '') + '</p>'; return; }
  box.innerHTML = '<p>本题全站作答 ' + j.total + ' 次，正确 ' + j.correct + ' 次' + (j.accuracy === null ? '（暂无作答数据）' : '，正确率 ' + j.accuracy + '%') + '。'
    + (j.top_wrong ? '最常见的错误答案是“' + esc(j.top_wrong.answer) + '”（' + j.top_wrong.count + ' 人次）。' : '') + '</p><p>' + esc(j.tip) + '</p>';
}
