# 验收记录 v0.6（最终版，2026-11-06）

v0.6 = v0.5 + P2 三项（跨主机题库联邦共享、运维备份自动化、本地 AI 辅助出题规则变式）+ exe 程序 + showcase 最终版。
水印/脱敏按用户决定砍掉，不做。v0.5 原样保留在 `mvp-v05/`，可回滚。
技术：Python 3 标准库 + SQLite 单文件，零依赖、零 CDN，离线可用。

## 1. P2-1 跨主机题库联邦共享

**怎么做**
- `server.py` 新增：`peer_hosts` 表（登记对方主机：站名、IP、端口、共享令牌，补 `last_seen/last_error/last_count`）、`federation_packages` 表（共享包记录）、`settings` 表存本站共享令牌（首次自动生成）；接口 `/api/federation/*`（登记/列表/测试连通/拉取/删除/查看本站令牌/导出共享包/导入共享包）、匿名目录接口 `/api/federation/catalog` 与拉包接口 `/api/federation/package`（只验令牌，不验本站登录 Cookie；包带 SHA-256 哈希）。
- 联邦式，不裸连：只开放题库目录（题数、科目），不开放成绩/密码/用户信息；错令牌 401；哈希验不过拒绝导入。
- 拉回的题先按内容哈希去重，再进草稿 → 审核 → 发布，不直接覆盖本站题库；来源标注（from_host），取题记审计（audit 表）。
- 前端：后台管理页新增“跨主机题库共享”区（`static/index.html`），`static/app.js` 新增 loadFed/registerFed/testFed/pullFed/delFed/showFedToken，并在 loadAdmin() 里联动加载；Lite 版后台总览加联邦主机数摘要。

**怎么验**：双机干净副本（端口 18761/18762），脚本 `/tmp/test_v06_p2.py`。
**结果**：48/48 通过（P2 自测，见第 5 节）。覆盖：登记/测试/拉取（新题 1 道、去重 20 道、二次拉取全去重）、错令牌 401、民警 403、发布后外站题可练。
**修过的真 bug**：`/api/federation/package` 在 `_handle_post` 里排在全局 need_user() 之后，对方服务器无本站登录 Cookie 被挡回“未登录”——抽成 `_fed_package()` 方法并在 need_user() 之前分发。

## 2. P2-2 运维备份自动化

**怎么做**
- `server.py` 新增：`backups_meta` 表（补 `size_bytes/status`）；接口 `/api/backup/*`（创建/列表/下载/恢复/状态）；一键备份把数据库 + 题库附件打成带时间戳的 zip（`data/backups/`，可下载）；每天自动备一份（服务器开着时，`main()` 起守护线程，`SHUATI_AUTOBACKUP=0` 可关），保留最近 7 份，旧的自动清理；恢复只能管理员做，恢复前先自动再备一份当前库防丢；磁盘空间与备份状态显示（`/api/backup/status`，Lite 版后台总览也有摘要）。
- 不做自动删库。
- 前端：后台管理页新增“运维备份”区，`static/app.js` 新增 loadBackup/createBackup/restoreBackup。

**怎么验**：同上，`/tmp/test_v06_p2.py`。
**结果**：48/48 中的备份部分通过。覆盖：备份创建/列表/下载 zip/恢复（恢复后临时题消失、题数回到备份时、恢复后列表 3 份含自动备份）、民警恢复 403、不存在的备份 400。
**修过的真 bug**（2 个）：① 备份文件名只精确到秒，恢复前的自动备份与要恢复的备份同名同秒，覆盖了源文件——备份文件名唯一（同名加 -2、-3 后缀）+ 恢复时先解包源文件再自动备份 + 恢复后把磁盘备份重新扫回库；② 恢复后旧 WAL 让已删数据“复活”——恢复后检查点合并并删除 -wal/-shm。

**边界**：每日自动备份只在服务器开着时跑，关机期间不补；恢复会用备份内容覆盖当前数据库和附件（恢复前已自动备一份当前库）；恢复期间请勿并发操作（恢复持 DB 锁，但读请求不持锁，极小概率可见中间态）。

## 3. P2-3 本地 AI 辅助出题（规则变式）

**怎么做**
- `server.py` 新增：变式表（母题 → 变式，类型 shuffle/wording/number，状态草稿/已发布/已驳回）；接口 `/api/ai/variants`（生成/列表/审核通过/驳回）、`/api/ai/tips/<id>`（易错点提示）。
- 不联网、不接外部模型、不装大模型：只做选项顺序打乱、题干同义词替换、题干数字替换（只改可替换槽位，不改考点）；一道母题生成 2–3 道变式；变式先进草稿，须人工审核通过才能发布，数字变式须复核数字合理性。
- 易错点提示按全站作答统计（正确率、最常见错误答案）；无作答数据时明说“暂无作答数据”。
- 前端：后台管理页新增“本地 AI 辅助出题”区，`static/app.js` 新增 loadVariants/genVariants/approveVariant/rejectVariant/loadTip。
- 不谎称 LLM 生成：全仓 grep“LLM 生成”无命中（回归脚本已查）。

**怎么验**：同上，`/tmp/test_v06_p2.py`。
**结果**：48/48 中的变式部分通过。覆盖：母题 1 生成 shuffle + wording 两道、草稿不进练习、审核通过可练、驳回不可练、重复审核拒绝、易错提示（含最常见错误答案）。
**边界**：变式只支持选择/判断题，简答题不支持；数字变式须人工复核合理性。

## 4. 水印/脱敏——砍掉

按用户决定不做：局域网内自家题库、自己管理，无涉密风险。产品介绍、README、showcase 里写明已按用户决定砍掉；代码里没有水印/脱敏功能。

## 5. P2 自测结果（2026-11-06）

- 脚本 `/tmp/test_v06_p2.py`，双机干净副本（端口 18761/18762）。
- **48/48 通过，0 失败。**
- 另有 1 个测试脚本本身的变量名 bug（Lite 检查误用下载备份的字节变量），已修。
- 覆盖（摘要）：联邦登记/测试/拉取/去重/错令牌 401/民警 403/发布后外站题可练；备份创建/列表/下载/恢复/民警 403/不存在备份 400；变式生成/草稿隔离/审核/驳回/重复审核拒绝/易错提示；非法 ID 返回 JSON 404 不断连；Lite 后台摘要、个人报告、薄弱组卷。

## 6. 整体集成回归结果（2026-11-06）

- 脚本 `/tmp/test_v06.py`，单机干净副本（端口 18765），`SHUATI_AUTOBACKUP=0`。
- **58/58 通过，0 失败。**
- 覆盖：页面 200（/、/lite、/showcase.html、/static/app.js、/static/style.css、/lite/plans）、四角色登录；练习四模式、答题提交、薄弱组卷、自适应画像、考核开考/草稿/交卷/打印成绩单；个人报告、环形图数据源、报告 CSV、队报告（教官可看、民警 403）、后台总览、部门横向对比 + 热力、题库质量、组卷模板新建；Excel 导入解析、图文配对清单、发布新版本、版本列表；简答题新建/提交/批阅队列/人工批阅 4/5 通过/重复批改 400 拒绝；学习计划下发/我的计划可见；P2：本站联邦令牌、联邦目录自查、错令牌 401、一键备份、备份状态、生成变式 2 道、变式列表、变式审核通过、易错点提示、恢复不存在的备份 400；前端静态检查（联邦/备份/变式函数、三区、showcase 15 节齐全、无外部引用、无 LLM 生成表述、水印砍掉表述、无外部图表库）；模拟压测 60 并发首页全部 200。
- 回归初版 51/54：3 个失败全是测试脚本的错（stats 包在 `stats` 键里、简答题字段是 `reference_answer`、showcase 里“零 CDN”是文字说明不是引用），修测试后 58/58（含简答流程 4 项新跑通）。
- v0.5 功能不退化；新旧模块数据互通（联邦拉回的题走同一套草稿/审核/发布/练习链路；变式题走同一套题库；备份覆盖数据库 + 附件）。

## 7. exe 验证（最重要，如实写）

**交付物**：`mvp-v06/dist/刷题宝.exe`，PE32+ executable (console) x86-64，7 sections，8,944,768 字节（约 8.5 MB）。PyInstaller 6.22.3 + Python 3.12.8（Windows）打包，单文件，控制台程序。另附 `build_exe.bat`（在 Windows 主机上重新打包）、`build_exe.sh`（Linux 验证版，打出的是 Linux 程序，不是 Windows exe）、`exe-使用说明.md`。

**打包过程（本机 Linux 环境）**
1. Linux 下先打等价冻结程序验证流程：`./build_exe.sh` 成功，ELF 64-bit 9.5 MB，实测根页/Lite/showcase/app.js 均 200、民警登录成功、data 建在程序旁边。证据程序留存在 `/tmp/v06-evidence/刷题宝-linux`（临时目录）。
2. Windows exe 用 wine 9.0 打：在 wine 里建 64 位前缀，装 Windows Python 3.12.8（免安装 embed-amd64 包）+ 本地轮子装 PyInstaller 6.22.3，跑 spec 打包成功。
3. 途中遇到的 wine 限制（都已绕过，如实记）：① 本机 wine 32 位加载器直接段错误（沙箱限制），只能用 64 位；② wine 内 Python 联网失败（socket 报错），PyPI 下不了，轮子改在 Linux 侧下载、本地离线装；③ wine 代码页会把中文参数/路径转乱码，打包时用 ASCII 名 + ASCII 专用 spec（因此 wine 打出的这份 exe 未把“导入模板”文件夹打进包内——server.py 从不读它，它仍保留在 `mvp-v06/导入模板/` 文件夹里随 exe 一起拷走；在真实 Windows 主机上跑 `build_exe.bat` 会用完整 spec（含导入模板）重新打包）；④ `/tmp` 是 512M tmpfs，曾被 wine 前缀撑满，改把前缀放 /home 大磁盘（但 TMPDIR 必须留在 /tmp，改到别处 wine 会起不来）。

**运行验证（wine 下实际跑起来，不是只看了文件头）**
- 把 `dist/刷题宝.exe` 的同内容副本（ASCII 文件名 `shuati.exe`，因 wine 传中文文件名会转码找不到文件）在 wine 下启动，端口 18767。
- 结果：根页 200、Lite 200、showcase 200；民警登录成功（`minjing` / 民警甲 / 执勤一队）；带真实令牌练题返回题目（多选题干正常）；个人报告正常；未登录调练习接口正确返回“未登录”；`data/`（shuati.db、assets、backups、uploads）建在 exe 旁边。
- wine 下自动开浏览器会报 xdg-open 找不到浏览器（本机无图形浏览器），无害，真实 Windows 上会正常打开默认浏览器。

**exe 验证中抓到的真 bug（已修并重测通过）**
- 首次 wine 试跑：exe 能启动并建库，但在打印中文横幅时崩溃——`UnicodeEncodeError: 'charmap' codec can't encode characters`（wine 控制台编码是 cp1252）。这是真问题：英文 Windows（代码页 437/1252）上也会同样崩。已修：`server.py` 的 `main()` 开头把 stdout/stderr 设为 `reconfigure(encoding="utf-8", errors="replace")`，打不出的字变问号，程序绝不因此崩。修后重打 exe、重测通过；回归重跑仍 58/58。

**XP 的真实限制（实话）**
- 现代 PyInstaller 打出的 exe 要求 Win7 以上，**XP 不能跑这个 exe**。XP 机继续走网页版 `/lite`，不要在 XP 上跑 exe。产品介绍、README、showcase、exe 说明四处都写明了这一点。
- **Windows exe 本身未在真实 Windows 主机上跑过**：本机是 Linux 环境，exe 是在 wine 下打包并跑通的。拿到 Windows 主机后请先双击验证一次：能打开浏览器、能登录（`minjing` / `123456`）、能练一题。
- 不要同时开 exe 和 `start.bat`（会抢 8765 端口，二选一）；首次启动 Windows 防火墙可能弹窗，点“允许访问”，否则局域网其他电脑连不上；演示账号上线前务必改密码。

## 8. 三件套交付清单

1. **exe 程序**：`mvp-v06/dist/刷题宝.exe`（见第 7 节验证）。
2. **网页版在线考试系统**：`mvp-v06/` 本身（server.py + static/ + showcase.html），Win 7/10/11 与其他系统浏览器都能打开，局域网 `http://<主机IP>:8765/`，Lite 版 `/lite` 保留；主机无 Python 时用 exe，有 Python 时双击 `start.bat`。
3. **可交互介绍网页**：`mvp-v06/showcase.html`（最终版），15 节全覆盖（登录/练习/薄弱/考核/报告五图/导入/自适应/后台/图文配对/PDF/简答批阅/学习计划/联邦共享/备份/AI 变式），都能点、可看演示动效，HIG 风格，离线零 CDN（回归脚本已查无外部引用）。
- 另有：`产品介绍.md`（v0.6）、`README.md`（v0.6）、`设计检查表-HIG.md`（新增 K 节，P2 十一项）、本验收记录。`刷题宝.spec` 为 PyInstaller 打包配置（Windows 重打时用）。

## 9. 没做到 / 待回看（不编造）

- 未做：150 并发实机压测（只做过本机模拟：60 并发首页全部 200；v0.5 另做过 60 并发首页 + 30 并发登录全部 200、2.9 秒）、双人确认发布、灰度发布、PDF 报告、账号批量导入、扫描型 PDF 的 OCR、激励提醒、全文检索与知识图谱。
- 刻意不做：水印/脱敏（用户决定：局域网内自家题库、自己管理，无涉密风险）。
- 边界（沿用 v0.5）：部门横向对比柱状图的答对数是推算值（总作答×平均正确率，误差≤1 道），非精确汇总；学习计划进度按作答题次算，同一题重复做会重复计；组卷模板开考不含简答题，只有通用卷勾选才含；恢复期间请勿并发操作。
- 待验证（真实环境）：真实脱敏样张（Excel/Word 各一份）还没拿到；真实局域网多机、真实 XP 机开 Lite 页、150 并发、联邦共享两台真机、Windows exe 在真实 Windows 主机上双击、浏览器实测动效手感与减弱动效切换。
- 测试服务已停，测试副本已删，交付物 `data/` 保持干净（首次启动自动播种 20 道样题）。

## 10. 改动文件清单

- `server.py`：P2 三项全部后端（联邦接口/备份接口/变式接口/易错提示、settings/federation_packages/backups_meta 新表、peer_hosts 补字段、每日自动备份守护线程、exe 模式 BASE/_MEIPASS、全局异常兜底 JSON 500、main() 控制台编码容错）。
- `static/index.html` + `static/app.js`：后台新增共享/备份/AI 变式三个区及对应函数（loadFed/registerFed/testFed/pullFed/delFed/showFedToken、loadBackup/createBackup/restoreBackup、loadVariants/genVariants/approveVariant/rejectVariant/loadTip），Lite 后台加备份与联邦摘要。
- `showcase.html`：升到 v0.6，导航新增 13 联邦共享、14 备份、15 AI 变式三节可点演示，Hero 与“老机器”说明同步更新。
- `产品介绍.md`、`README.md`：v0.6、P2 三项、exe 说明、没做到清单更新。
- `设计检查表-HIG.md`：新增 K 节（P2 十一项）。
- 新增：`build_exe.bat`（Windows 打包）、`build_exe.sh`（Linux 验证打包）、`exe-使用说明.md`、`dist/刷题宝.exe`、本验收记录。
- `start.bat` / `start.sh`：版本号改为 v0.6。
