# 刷题宝 v0.4 — 验收记录（2026-11-06）

v0.4 视觉升级：报告仪表盘（五种图 + 数字滚动 + 弹簧轻动）+ 答题动效与画面细节。
v0.3 原样保留在 `mvp-v03/`，可回滚；本版在 `mvp-v04/`，版本号已改为 v0.4。

## 一、改了什么

| 文件 | 改动 |
|---|---|
| `server.py` | 版本改为 v0.4；新增只读接口 `GET /api/reports/stats`（返回题型计数 `type_counts` 与难度计数 `difficulty_counts`，供环形图用）；Lite 报告 `/lite/report` 加知识点文字条形与题型占比文字版，Lite 后台 `/lite/admin` 加部门正确率文字条形；其余后端逻辑未动 |
| `static/index.html` | 报告/队报告/后台加仪表盘容器 `#reportStats/#reportCharts/#teamStats/#teamCharts/#adminCharts`；其余结构未动 |
| `static/app.js` | 追加 v0.4 图表引擎与动效（约 480 行，覆盖旧同名函数）：`radarChartSVG`（雷达）、`trendChartSVG`（趋势）、`barsChartSVG`（柱状）、`heatmapHTML`（热力）、`donutChartSVG`（环形）+ `animateCount`（数字滚动 600ms）、`revealStagger`（卡片依次入场 60ms）、`animateRadar/animateTrend/animateBars/animateDonut`（图表生长/描绘 350ms）；重写 `loadReport/loadTeam/loadAdmin/loadAdminUser` 为仪表盘渲染；重写 `renderQuestions/markSelected/submitOne/saveExamAnswer/submitExam` 加答题动效 |
| `static/style.css` | 追加 v0.4 样式：`.stat-card`、`.chart-card`、`.reveal`、`.heat-cell`、`.donut-wrap`、`.legend`、`.q-img`（圆角 12px + 阴影）、`.opt.pop`、`.feedback.pop`、`.saved-pop`、`.score-pop`、减弱动效覆盖 |
| `showcase.html` | 标题与徽章改为 v0.4；报告页换成可点演示仪表盘（五种图齐全：雷达/趋势/柱状/热力/环形，数字滚动、卡片依次入场、「再播一遍动效」与「减弱动效」开关）；练习页加 v0.4 动效说明；老机器段加 Lite 文字条形说明 |
| `产品介绍.md` | 新增「v0.4 视觉升级新增（相对 v0.3）」一节（仪表盘、动效、答题细节、Lite 降级点）；看报告流程的描述同步更新 |
| `设计检查表-HIG.md` | 新增 I 节（I1–I7）：五种图、数字滚动、弹簧轻动、悬停提示与空状态、减弱动效、答题动效、Lite 新增降级点 |
| `验收记录-v0.4.md` | 本文件 |

## 二、自测方法与结果

干净副本：把 `mvp-v04` 完整复制到 `/tmp/shuati-v04-test2`，清空 `data/`，端口 18765 启动；
测试脚本 `/tmp/test_v04.py`（临时脚本，未进交付物）。民警 `minjing` 提交 10 道练习（8 对 2 错）造数据，
再分别用教官 `jiaoguan`、管理员 `admin` 验队报告与后台。

**结果：62 通过 / 0 失败。** 分组如下：

- 页面可达（5 项）：根页 / Lite / showcase / app.js / style.css 均 200。
- 登录与作答（3 项）：三角色登录成功；10 道练习提交成功；种子题 ≥10 道。
- 报告数据源（11 项）：个人报告 total ≥10、正确率在 0~1 之间、`by_knowledge`（雷达源）、`trend`（趋势源）非空；
  `GET /api/reports/stats` 正常，`type_counts` 与 `difficulty_counts`（环形源）非空；队报告、后台总览、
  `heatmap`（热力源）、`trend14`、`teams`、后台个人明细均正常。
- Lite 文字版（2 项）：`/lite/report` 含文字条形 `litebar` 与「文字条形版」说明；`/lite/admin` 含「后台总览（Lite 文字版）」与部门条形。
- v0.4 静态检查（22 项）：`app.js` 含五种图函数、`animateCount`、`revealStagger`、`switchDonut`、`prefers-reduced-motion`、
  弹簧 `cubic-bezier(.34,1.56,.64,1)`，无外部图表库（无 ECharts/Chart.js、无 http(s) 外链——“cdn”只出现在「零 CDN」注释里）；
  `style.css` 含 `.stat-card/.chart-card/.reveal/.heat-cell/.donut-wrap/.q-img/.opt.pop/.score-pop` 与减弱动效覆盖；
  `index.html` 含 5 个仪表盘容器；showcase 含报告演示五种图与减弱动效切换。
- v0.3 回归抽查（10 项）：顺序练习取题、薄弱项取题（POST `/api/weak`）、自适应画像、考核开始/保存草稿/交卷、
  题库质量、组卷模板、报告 CSV 导出、题库版本——全部正常，未退化。

测试服务已停（18765 端口已关闭），测试副本已删；交付物 `mvp-v04/data/` 为空目录，首次启动自动播种 20 道样题。

## 三、五种图各怎么验（手动）

1. **雷达图**：民警登录 → 我的报告 →「知识点掌握雷达」，多边形从中心弹簧展开；悬停圆点看「知识点：正确率 x%，作答 n 道」。
2. **趋势图**：同一页「近 14 天趋势」，柱子长高、绿线描绘；悬停看每天作答/正确。
3. **柱状图**：同一页「各知识点作答与正确」，深蓝柱是作答数、绿柱是答对数，柱顶是正确率。
4. **热力图**：同一页「知识点掌握热力」（单人单行）；管理员 → 后台管理 →「知识点 × 部门掌握度热力」，低于 60% 标红；悬停看具体数值。
5. **环形图**：三处报告都有「题库占比环形」，点「按题型 / 按难度」切换，扇区生长；悬停看「题型：n 道，占 x%」。
6. **数字滚动**：刷新任意报告页，顶部数字卡从 0 滚到目标值（600ms 内）。
7. **减弱动效**：系统开「减弱动态效果」后刷新，数字、图表、卡片全部瞬间显示；showcase 报告页也有「减弱动效」开关可点着试。
8. **空状态**：新账号（无作答）打开报告，不造假数据，显示「还没有作答记录，先做 10 道练习」。

## 四、答题动效改了什么

- 选项选中：220ms 弹簧轻动（`.opt.pop`）+ 蓝色高亮；多选/单选都有效。
- 提交反馈：对错反馈带 220ms 轻动（`.feedback.pop`），正确答案行高亮（`paintOptions` 已有，保留）；提交中按钮禁用防重复点。
- 题目卡片：依次入场，每张延迟 60ms，可打断（重新渲染会重置）。
- 考核草稿：保存后「✓ 草稿已保存」带轻动（`.saved-pop`）+ Toast。
- 交卷：得分卡带轻动（`.score-pop`），得分数字滚动；考核页默认减动效不变。
- 题目图片：包一层 `figure.q-img`，圆角 12px + 阴影，留白加大（`margin-bottom:16px`）。
- 倒计时：沿用 v0.3 的实现（本地每秒更新、服务端 `ends_at` 为准、每 10 秒校准），v0.4 未改倒计时代码。

## 五、没做到 / 待回看（实话）

- **浏览器实测动效手感**：未在真实浏览器里点过。动画时长、弹簧手感、减弱动效切换只验了代码存在与接口数据，
  没做真人手感验收；showcase 的演示动效同样只验了代码与结构。
- **后台「部门横向对比」柱状图的「答对数」是推算值**：用 `总作答 × 平均正确率` 四舍五入算出，误差 ≤1 道；
  部门总作答与平均正确率本身是真实值。以后如需精确值，应从作答明细按部门汇总。
- **个人/队热力是单行条**：个人热力只有「本人」一行、队热力只有「本队」一行；真正的「部门 × 知识点」矩阵只在后台总览有。
- **考核页倒计时未改**：v0.4 未改倒计时代码，仍是 v0.3 的每秒更新实现。
- **未验证（沿用 v0.3 待办）**：真实脱敏样张（Excel/Word 各一份）、真实局域网多机、真实 XP 机、150 并发压测、XP 原生 EXE；
  真实样张用户尚未提供。
- **自测中的两个插曲（已解决，非产品问题）**：第一次跑测试时 Lite 路由测错了（报告在 `/lite/report`、后台在 `/lite/admin`，不是 `/lite`），
  `/api/weak` 是 POST 不是 GET；“无外部图表库”检查曾误报——`echarts` 是 `animateChartsIn` 函数名里的子串，
  `cdn` 只出现在「零 CDN」注释里，已改用词边界匹配复核通过。
