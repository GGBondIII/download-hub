# 常熟站智考通 v2.1 — 验收记录（诊断修复版）

> 程序名：常熟站智考通，版本 v2.1。v2.0 是智考通框架 + 刷题宝功能合成版；v2.1 是 v2.0 的诊断修复版，
> 其余功能不变。mvp-v07 与 mvp-zhikaotong-v1 原样保留，未动；v2.0 的 zip 与文件也在同一目录下并存。
> 验收日期：2026-11-06。

## 一、为什么出 v2.1

v2.0 的 exe 在用户真实 Windows 机上双击后没有任何反应（没窗口、没报错）。我方核查包是完整的
（python34/pythonw.exe、python34.dll、msvcr100.dll、_tkinter.pyd、tcl86t.dll、tk86t.dll、init.tcl、
Lib/ 各模块都在，全是 32 位，依赖链完整），所以是程序启动时静默崩溃——pythonw.exe 没有控制台窗口，
报错信息用户看不到。v2.1 的目标就是让报错看得见：先拿到报错，再谈修复。**用户机器上静默崩溃的
真正根因目前仍未知**，要靠 v2.1 的 debug.bat / error.log 拿到报错后才能定位；本版不谎称已修好根因。

## 二、v2.1 改了什么（相对 v2.0）

| # | 改动 | 位置 |
| --- | --- | --- |
| 1 | 新增 `python34/python.exe`（控制台版 Python 3.4.4，PE32，27,136 字节，从官方 python-3.4.4.msi 用 msiextract 解出，与 pythonw.exe 同源） | `exe/python34/python.exe` |
| 2 | 新增 `debug.bat`（GBK + CRLF，无 chcp 65001）：控制台里跑 `python34\python.exe app\main.py`，跑完 `pause` 停住，报错直接显示 | `exe/debug.bat` |
| 3 | `main.py` 启动失败兜底：全部可能失败的 import（tkinter、config、theme、api_client）移进 `_main()`，由 `main()` 的 try/except 包住；一旦失败，写 `exe/error.log`（含 Python 版本、sys.path、完整 traceback），同时用 `ctypes.windll.user32.MessageBoxW` 弹框显示（不用 tkinter.messagebox，因为 tkinter 本身可能就是坏掉的那一环）；写完后重新抛出，让控制台（debug.bat）里也能看到 traceback | `exe/app/main.py` |
| 4 | 两个启动器的“找不到 pythonw.exe”提示改成直说“请先把整个压缩包解压到一个文件夹，再进文件夹双击运行；不要直接在压缩包里双击，也不要只把 exe 单独拖出来。”重新交叉编译 | `_build/launcher/launcher.c`、`rebrand-tool/rebrand-launcher.c`、`exe/changshu-zhikaotong.exe`、`exe/rebrand-tool.exe` |
| 5 | 版本号统一升到 v2.1：branding.json（exe/ 与 rebrand-tool/ 各一份）、server.py 的 VERSION（web/ 与 exe/app/server/ 两份）、theme.py 的 VERSION/TITLE、app.js/lite.js 的 VERSION 与界面显示、/api/version、db.py 的 app_version 默认值、federation.py 的 VERSION、seed.py 的初始题库版本（v2.1.0）、import_jobs 的新版本号（v2.1.x）、product-intro.md、showcase.html（三份同步）、README、start.bat/start.sh | 全树 |
| 6 | exe/ 的 README.txt 加一行 debug.bat 说明；product-intro.md 与 showcase.html 加 v2.1 改动说明；showcase 的“exe 双击没反应？”FAQ 更新为 debug.bat + error.log 的用法 | 文档 |

其余功能（12 模块、刷题宝 15 项并入功能、改名工具、端口 8766、账号）与 v2.0 完全一致，未动。

## 三、验证结果

### 1. python.exe（控制台版）
- 来源：官方 python-3.4.4.msi（python.org），msiextract 解出，与已有 pythonw.exe 同源。
- `file` 确认：`PE32 executable (console) Intel 80386, for MS Windows`，27,136 字节。
- pythonw.exe（27,648 字节，PE32 GUI）、python34.dll、msvcr100.dll 未动。

### 2. debug.bat
- GBK 编码 + CRLF（8 行全是 CRLF，无单独 LF），无 chcp 65001；`file` 认作 DOS batch file。
- 内容：`cd /d %~dp0` 后跑 `python34\python.exe app\main.py`，跑完 `pause`。控制台里能看到完整报错。

### 3. main.py 兜底（两条路径都实测过）
- **运行时失败**：无显示器环境（no DISPLAY）下跑 `python3 app/main.py`（ZKT_NO_EMBED=1），`tk.Tk()` 抛 `TclError: no display name`，兜底写出 `exe/error.log`（994 字节，含 Python 版本、sys.path、完整 traceback），stderr 里也打出重新抛出的 traceback，退出码 1。
- **导入时失败**（模拟 tkinter 坏掉）：用一个故意抛 ImportError 的 tkinter 模块遮住真 tkinter 再跑，兜底同样写出 `error.log`（783 字节，含 ImportError traceback），退出码 1。——这正是 v2.0 兜底缺失的缺口：原来 import 在模块顶层，tkinter 一坏整个模块导不进来，兜底根本跑不到。
- 两次测试的 error.log 已删掉，不随包发出（用户机器上失败时会重新生成）。
- ctypes MessageBoxW 在 Linux 下不存在 `ctypes.windll`，兜底里这一步被内层 try/except 吃掉，不影响写日志；在 Windows 上会正常弹框。

### 4. 启动器（两个都重编过）
- `i686-w64-mingw32-gcc -O2 -mwindows -municode` 交叉编译，`file` 确认均为 `PE32 executable (GUI) Intel 80386`。
- 二进制里用 UTF-16LE 查过：新提示文案“请先把整个压缩包解压”在，旧文案“python34 文件夹可能被误删”已不在。
- 主启动器与改名工具启动器均已替换进 `exe/`（改名工具启动器同时替换进 `rebrand-tool/` 的副本）。

### 5. 版本号 v2.1（全树核对）
- `branding.json` 两份均为 v2.1；`server.py` 两份 VERSION 均为 v2.1；`theme.py` VERSION/TITLE 为 v2.1。
- 网页版干净副本冒烟（Python 3.12，端口 18768）：`/api/version` 返回 `current_version: v2.1`；根页、/lite 均 200；Lite 页标题与页脚显示 v2.1；民警登录成功。
- `web/` 与 `exe/app/server/` 除 `__pycache__` 与 web 独有的 README.md/data/start.bat/start.sh 外逐文件一致。
- 其余 v2.0 字样只剩有意的历史表述（“v2.0 并入刷题宝功能”“v2.0 新增”等），用户能看到的版本号已全部是 v2.1。

### 6. 语法与兼容性
- 全部 70 个 .py（web/ + exe/app/ + rebrand.py 两份，排除 `__pycache__` 与 python34/Lib）做 `ast.parse` 全过；
  3.5+ 语法扫描（f-string、async/await、walrus）无真命中（两处命中是 check_py34.py 与 rebrand.py 文档字符串里
  写明的“无 :=”字样，以及 check_py34.py 里用来检测 walrus 的正则本身）。
- `web/static/app.js` 与 `lite.js` 做 `node --check` 全过。
- 注意：本机已无 Python 3.8（/opt/python38 不存在），语法检查用系统 Python 3.12 的 ast.parse + 正则扫描，
  未用 `ast.parse(feature_version=(3,4))`；新改的 main.py 只用了 3.4 已有的语法（try/except、global、ctypes）。

### 7. 打包
- `changshu-zhikaotong-v2.1-exe.zip`：exe/ 内容平铺打包，全部英文文件名，`unzip -t` 全过。
- `changshu-zhikaotong-v2.1-full.zip`：顶层文件夹 `changshu-zhikaotong-v2.1/` + README.txt + exe/ + web/ +
  product-intro.md + showcase.html + acceptance-v2.1.md，全部英文文件名，`unzip -t` 全过。
- `changshu-zhikaotong-v2.1-web.zip`：web/ 内容平铺打包，全部英文文件名，`unzip -t` 全过。
  注：任务原先说 web/ 没改、不用重打 web zip，但版本号统一升到 v2.1 本来就要改 web/ 里的
  server.py、app.js、lite.js 等文件，所以 web/ 实际变了，web zip 按 v2.1 重打了一份；
  v2.0 的 web zip 不再单独提供，完整包里含的就是最新的 web/（v2.1）。

## 四、让用户做的事（诊断步骤）

1. 从 GitHub 公开库下载 `changshu-zhikaotong-v2.1-full.zip`，完整解压（不要直接在压缩包里双击）。
2. 进解出来的 `changshu-zhikaotong-v2.1/exe/` 文件夹，双击 `debug.bat`。
3. 黑色控制台窗口里会显示启动过程与报错；程序退出后窗口停住，把整个窗口截图发回来。
4. 同时把 `exe/error.log`（启动失败时自动生成）的全文发回来。
5. 拿到这两样东西，才能定位用户机器上静默崩溃的真正原因。

## 五、已知限制（没有验证过，不要当作已验证）

- **用户机器上静默崩溃的真正根因仍未知**：v2.1 只加了看报错的工具，没修根因；根因要等用户跑 debug.bat / 发 error.log 后再定位。
- 32 位 exe 与改名工具启动器未在真实 XP/Win7/Win10 机上双击验证过（只交叉编译 + `file` 确认 PE32；
  GUI 未在真实 Windows 点按过，客户端只在 Linux 下做过无界面逻辑测试）。
- python.exe 与 debug.bat 未在真实 Windows 控制台里跑过（只核对了文件格式与内容）。
- 真实局域网多机与 150 并发压测未做；浏览器实测未做；Pillow 在真实 XP 上的加载未验证。
- v2.0 的三个旧问题修复（部门对比精确汇总、计划进度去重计数、模板开考含简答题）沿用 v2.0 的验收结论，
  v2.1 未重测（v2.1 没改这些逻辑，只改了启动与版本标识）。
