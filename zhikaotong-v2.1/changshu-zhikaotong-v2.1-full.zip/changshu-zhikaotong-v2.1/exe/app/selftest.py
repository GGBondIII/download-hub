# -*- coding: utf-8 -*-
"""常熟站智考通 v2.1 -- 界面逻辑自测(仅供 Xvfb 下自测驱动)。

由 main.py 在 ZKT_SELFTEST=1 时加载:按顺序驱动真实 UI
(登录三角色、学员首页四模块入口、练习答题判分、模拟考建卷、
考官建考试、管理员用户列表),每步打印 SELFTEST <名> PASS/FAIL,
最后打印 SELFTEST DONE n/m 并退出。
Python 3.4 兼容语法。
"""
import sys

RESULTS = []


def _log(name, ok, detail=""):
    RESULTS.append((name, ok))
    print("SELFTEST {0} {1} {2}".format(name, "PASS" if ok else "FAIL",
                                        detail))
    sys.stdout.flush()


def _login(app, username):
    app.ui["login_user"].set(username)
    app.ui["login_pass"].set("123456")
    app.ui["login_button"].invoke()


def run(app):
    root = app.root
    steps = []

    def step_login_student():
        try:
            _login(app, "minjing")
        except Exception as e:
            _log("login_student", False, str(e))
            return nxt()
        root.after(800, check_login_student)

    def check_login_student():
        ok = app.page == "home_student" and (app.user or {}).get("role") == "student"
        _log("login_student", ok, "page={0}".format(app.page))
        nxt()

    def step_home_modules():
        ok = True
        try:
            for mode in ("顺序", "随机", "错题", "题型"):
                cmd = app.ui.get("home_modules", {}).get(mode)
                if not cmd:
                    ok = False
                    break
                cmd()
                root.update()
                if app.page != "practice":
                    ok = False
                    break
                app.goto("home")
                root.update()
        except Exception as e:
            _log("home_modules", False, str(e))
            nxt()
            return
        _log("home_modules", ok, "4 modes opened practice page")
        nxt()

    def step_practice():
        try:
            app.goto("practice", mode="顺序")
            root.update()
            app.ui["practice_count_var"].set("5")
            app.ui["practice_start"]()
            root.update()
        except Exception as e:
            _log("practice_start", False, str(e))
            nxt()
            return
        root.after(800, check_practice)

    def check_practice():
        sess = app.ui.get("practice_session")
        if not sess or not sess.questions:
            _log("practice_start", False, "no questions")
            nxt()
            return
        _log("practice_start", True,
             "questions={0}".format(len(sess.questions)))
        try:
            panel = sess.panel
            if hasattr(panel, "rows") and panel.rows:
                panel._toggle(panel.rows[0])
            panel.submit()
            root.update()
            res = panel.result or {}
            ok = res.get("correct_answer") is not None
            _log("practice_grade", ok,
                 "correct={0} answer={1}".format(res.get("correct"),
                                                 res.get("correct_answer")))
        except Exception as e:
            _log("practice_grade", False, str(e))
        nxt()

    def step_mock():
        try:
            app.goto("mock")
            root.update()
            app.ui["mock_count_vars"]["单选"].set("2")
            app.ui["mock_dur_var"].set("30")
            app.ui["mock_start"]()
            root.update()
        except Exception as e:
            _log("mock_create", False, str(e))
            nxt()
            return
        root.after(800, check_mock)

    def check_mock():
        runner = app.ui.get("mock_runner")
        if not runner or len(runner.detail) != 2:
            _log("mock_create", False,
                 "runner={0}".format(bool(runner)))
            nxt()
            return
        _log("mock_create", True, "questions=2")
        try:
            panel = runner.panel
            if hasattr(panel, "rows") and panel.rows:
                panel._toggle(panel.rows[0])
            panel.submit()
            root.update()
            runner._submit()
            root.update()
            res = app.ui.get("mock_result") or {}
            _log("mock_submit", res.get("score") is not None,
                 "score={0}".format(res.get("score")))
        except Exception as e:
            _log("mock_submit", False, str(e))
        nxt()

    def step_login_examiner():
        try:
            app.logout()
            root.update()
            _login(app, "jiaoguan")
        except Exception as e:
            _log("login_examiner", False, str(e))
            nxt()
            return
        root.after(800, check_login_examiner)

    def check_login_examiner():
        ok = (app.user or {}).get("role") == "examiner"
        _log("login_examiner", ok, "page={0}".format(app.page))
        try:
            app.goto("exam_manage")
            root.update()
            exams = app.ui.get("admin_exams") or []
            _log("examiner_exam_list", len(exams) >= 1,
                 "count={0}".format(len(exams)))
        except Exception as e:
            _log("examiner_exam_list", False, str(e))
        nxt()

    def step_create_exam():
        try:
            import views_examiner
            views_examiner._exam_dialog(app, app.content, None)
            root.update()
            app.ui["exam_dialog_vars"]["name"].set("自测考试-UI")
            app.ui["exam_dialog_counts"]["单选"].set("2")
            app.ui["exam_dialog_save"]()
            root.update()
        except Exception as e:
            _log("examiner_create_exam", False, str(e))
            nxt()
            return
        root.after(800, check_create_exam)

    def check_create_exam():
        exams = app.ui.get("admin_exams") or []
        ok = any(e.get("name") == "自测考试-UI" for e in exams)
        _log("examiner_create_exam", ok, "count={0}".format(len(exams)))
        nxt()

    def step_login_admin():
        try:
            app.logout()
            root.update()
            _login(app, "admin")
        except Exception as e:
            _log("login_admin", False, str(e))
            nxt()
            return
        root.after(800, check_login_admin)

    def check_login_admin():
        ok = (app.user or {}).get("role") == "admin"
        _log("login_admin", ok, "page={0}".format(app.page))
        try:
            app.goto("user_manage")
            root.update()
            users = app.ui.get("admin_users") or []
            _log("admin_user_list", len(users) >= 4,
                 "count={0}".format(len(users)))
        except Exception as e:
            _log("admin_user_list", False, str(e))
        try:
            app.goto("admin_stats")
            root.update()
            stats = app.ui.get("admin_stats") or {}
            _log("admin_stats", "student_count" in stats,
                 "students={0}".format(stats.get("student_count")))
        except Exception as e:
            _log("admin_stats", False, str(e))
        nxt()

    def step_login_student_v2():
        try:
            app.logout()
            root.update()
            _login(app, "minjing")
        except Exception as e:
            _log("login_student_v2", False, str(e))
            nxt()
            return
        root.after(800, check_login_student_v2)

    def check_login_student_v2():
        ok = (app.user or {}).get("role") == "student"
        _log("login_student_v2", ok, "page={0}".format(app.page))
        nxt()

    def step_v2_units():
        # 不依赖服务器的纯逻辑:题目归一化 + 四种 Canvas 图表能建出来
        try:
            import views_student as vs
            q = vs.normalize_v2_question(
                {"id": 1, "type": "single", "stem": "题干",
                 "options": [{"label": "A", "content": "甲"},
                             {"label": "B", "content": "乙"}],
                 "knowledge": ["法规"], "subject": "基础法规"})
            ok = q["type"] == "单选" and q["options"] == {"A": "甲",
                                                          "B": "乙"} and \
                q["category"] == "法规"
            _log("v2_normalize", ok, "type={0}".format(q["type"]))
        except Exception as e:
            _log("v2_normalize", False, str(e))
        try:
            from tkinter import Frame
            import widgets
            tmp = Frame(root)
            widgets.radar_chart(tmp, [("甲", 0.8), ("乙", 0.5),
                                      ("丙", 0.9)], "雷达")
            widgets.donut_chart(tmp, [("对", 8, "#16A34A"),
                                      ("错", 2, "#DC2626")], "环形")
            widgets.trend_chart(tmp, [("11-01", 5), ("11-02", 8)], "趋势")
            widgets.heatmap_chart(tmp, {"法规": {"一队": 0.8, "二队": 0.5}},
                                  "热力")
            tmp.destroy()
            _log("v2_charts", True, "radar/donut/trend/heatmap built")
        except Exception as e:
            _log("v2_charts", False, str(e))
        nxt()

    def step_v2_student():
        # 学员 v2 视图:服务端 v2 未就绪时应显示错误条、不抛异常
        try:
            app.goto("adaptive")
            root.update()
            ok1 = app.page == "adaptive"
            app.goto("modes")
            root.update()
            ok2 = app.page == "modes" and \
                len(app.ui.get("v2_mode_entries") or []) == 5
            app.goto("weak")
            root.update()
            ok3 = app.page == "weak"
            app.goto("my_dashboard")
            root.update()
            ok4 = app.page == "my_dashboard"
            app.goto("my_plans")
            root.update()
            ok5 = app.page == "my_plans"
            app.goto("my_essay")
            root.update()
            ok6 = app.page == "my_essay"
            _log("v2_student_views", all([ok1, ok2, ok3, ok4, ok5, ok6]),
                 "adaptive/modes/weak/dashboard/plans/essay pages={0}".format(
                     [ok1, ok2, ok3, ok4, ok5, ok6]))
        except Exception as e:
            _log("v2_student_views", False, str(e))
        nxt()

    def step_v2_api_calls():
        # v2 客户端调用:v2 服务端已落地,学员可调的 adaptive/modes/weak
        # 应成功返回;其余(考官/管理员接口)学员调应得 ApiError(403),
        # 而不是崩溃/超时。
        from api_client import ApiError
        ok_calls = [("adaptive", lambda: app.api.v2_adaptive()),
                    ("modes", lambda: app.api.v2_practice_modes()),
                    ("weak", lambda: app.api.v2_weak())]
        denied = [("quality", lambda: app.api.v2_quality()),
                  ("templates", lambda: app.api.v2_templates()),
                  ("essay_queue", lambda: app.api.v2_essay_queue()),
                  ("plans", lambda: app.api.v2_plans()),
                  ("import_jobs", lambda: app.api.v2_import_jobs()),
                  ("bank_versions", lambda: app.api.v2_bank_versions()),
                  ("dashboard_overview",
                   lambda: app.api.v2_dashboard_overview()),
                  ("fed_hosts", lambda: app.api.v2_fed_hosts()),
                  ("backup_status", lambda: app.api.v2_backup_status()),
                  ("ai_variants", lambda: app.api.v2_ai_variants())]
        bad = []
        for name, fn in ok_calls:
            try:
                fn()
            except ApiError as e:
                bad.append(name + ":should-succeed status={0}".format(e.status))
            except Exception as e:
                bad.append(name + ":exc={0}".format(e))
        for name, fn in denied:
            try:
                fn()
                bad.append(name + ":unexpected-ok")
            except ApiError as e:
                if e.status not in (404, 403):
                    bad.append(name + ":status={0}".format(e.status))
            except Exception as e:
                bad.append(name + ":exc={0}".format(e))
        _log("v2_api_calls", not bad,
             "3 ok + 10 denied as expected" if not bad else str(bad))
        nxt()

    def step_login_examiner_v2():
        try:
            app.logout()
            root.update()
            _login(app, "jiaoguan")
        except Exception as e:
            _log("login_examiner_v2", False, str(e))
            nxt()
            return
        root.after(800, check_login_examiner_v2)

    def check_login_examiner_v2():
        ok = (app.user or {}).get("role") == "examiner"
        _log("login_examiner_v2", ok, "page={0}".format(app.page))
        try:
            pages = [("templates", "templates"),
                     ("import_jobs", "import_jobs"),
                     ("quality", "quality"),
                     ("essay_queue", "essay_queue"),
                     ("ai_variants", "ai_variants")]
            results = []
            for page, expect in pages:
                app.goto(page)
                root.update()
                results.append(app.page == expect)
            _log("v2_examiner_views", all(results),
                 "pages={0}".format(results))
        except Exception as e:
            _log("v2_examiner_views", False, str(e))
        nxt()

    def step_login_admin_v2():
        try:
            app.logout()
            root.update()
            _login(app, "admin")
        except Exception as e:
            _log("login_admin_v2", False, str(e))
            nxt()
            return
        root.after(800, check_login_admin_v2)

    def check_login_admin_v2():
        ok = (app.user or {}).get("role") == "admin"
        _log("login_admin_v2", ok, "page={0}".format(app.page))
        try:
            pages = [("admin_dashboard", "admin_dashboard"),
                     ("plans_admin", "plans_admin"),
                     ("federation", "federation"),
                     ("backup", "backup")]
            results = []
            for page, expect in pages:
                app.goto(page)
                root.update()
                results.append(app.page == expect)
            _log("v2_admin_views", all(results),
                 "pages={0}".format(results))
        except Exception as e:
            _log("v2_admin_views", False, str(e))
        nxt()

    def step_finish():
        passed = sum(1 for _, ok in RESULTS if ok)
        print("SELFTEST DONE {0}/{1}".format(passed, len(RESULTS)))
        sys.stdout.flush()
        root.after(300, root.destroy)

    steps = [step_login_student, step_home_modules, step_practice,
             step_mock, step_login_examiner, step_create_exam,
             step_login_admin, step_v2_units, step_login_student_v2,
             step_v2_student, step_v2_api_calls, step_login_examiner_v2,
             step_login_admin_v2, step_finish]
    state = {"i": 0}

    def nxt():
        state["i"] += 1
        if state["i"] < len(steps):
            root.after(300, steps[state["i"]])

    root.after(300, steps[0])
