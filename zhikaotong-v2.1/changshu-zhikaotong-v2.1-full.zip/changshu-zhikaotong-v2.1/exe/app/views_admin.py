# -*- coding: utf-8 -*-
"""常熟站智考通 v2.1 -- 管理员端:用户管理、上报处理、统计分析、版本发布。

Python 3.4 兼容语法,仅标准库。
"""
import base64
import os

from tkinter import Frame, Label, StringVar, Toplevel
from tkinter.ttk import Button, Combobox, Entry, Treeview

try:
    from tkinter import filedialog
except ImportError:
    filedialog = None

from theme import (NAVY, GOLD_LIGHT, BG, CARD, TEXT, TEXT_MUTED, BORDER,
                   GREEN, RED, font)
from widgets import (clear, banner, stat_card, bar_chart, confirm_dialog)
from api_client import ApiError

ROLES = {"admin": "管理员", "examiner": "考官", "student": "学员"}
ROLE_NAMES = ["管理员", "考官", "学员"]


def build_admin_home(app, parent):
    clear(parent)
    app.page = "admin_home"
    app.set_space_handler(None)
    Label(parent, text="管理员端", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    row = Frame(parent, bg=BG)
    row.pack(fill="x", padx=16, pady=8)
    for text, page in (("用户管理", "user_manage"), ("上报处理", "report_manage"),
                       ("统计分析", "admin_stats"),
                       ("客户端更新发布", "version_manage"),
                       ("系统设置", "settings")):
        Button(row, text=text, style="Navy.TButton",
               command=lambda p=page: app.goto(p)).pack(side="left", padx=6)
    row2 = Frame(parent, bg=BG)
    row2.pack(fill="x", padx=16, pady=8)
    for text, page in (("统计仪表盘", "admin_dashboard"),
                       ("学习计划", "plans_admin"), ("联邦共享", "federation"),
                       ("备份管理", "backup")):
        Button(row2, text=text, style="Gold.TButton",
               command=lambda p=page: app.goto(p)).pack(side="left", padx=6)
    return parent


# ---------------- 用户管理 ----------------

def build_user_manage(app, parent, page=1, q="", dept=""):
    clear(parent)
    app.page = "user_manage"
    Label(parent, text="用户管理", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    bar = Frame(parent, bg=BG)
    bar.pack(fill="x", padx=16, pady=4)
    q_var = StringVar(value=q)
    Entry(bar, textvariable=q_var, width=20,
          font=font(bar, 12)).pack(side="left", padx=4)
    dept_var = StringVar(value=dept or "全部部门")
    try:
        depts = (app.api.get("/api/admin/users",
                             params={"page_size": 1}) or {}
                 ).get("departments") or []
    except ApiError:
        depts = []
    Combobox(bar, textvariable=dept_var,
             values=["全部部门"] + list(depts), width=14, state="readonly"
             ).pack(side="left", padx=4)
    Button(bar, text="搜索", style="Ghost.TButton",
           command=lambda: build_user_manage(app, parent, 1, q_var.get(),
                                             dept_var.get())
           ).pack(side="left", padx=4)
    Button(bar, text="批量导入", style="Ghost.TButton",
           command=lambda: _import_users(app, parent)).pack(side="left", padx=4)
    Button(bar, text="新增用户", style="Navy.TButton",
           command=lambda: _user_dialog(app, parent, None)
           ).pack(side="right", padx=4)
    params = {"page": page, "page_size": 20}
    if q:
        params["q"] = q
    if dept and dept != "全部部门":
        params["department"] = dept
    try:
        data = app.api.get("/api/admin/users", params=params)
    except ApiError as e:
        banner(parent, e.message, "error")
        return parent
    items = (data or {}).get("items") or []
    total = (data or {}).get("total", 0)
    app.ui["admin_users"] = items
    Label(parent, text="共 {0} 名用户".format(total), bg=BG, fg=TEXT,
          font=font(parent, 12)).pack(anchor="w", padx=16, pady=4)
    cols = ("选择", "用户名", "姓名", "部门", "角色", "状态")
    tree = Treeview(parent, columns=cols, show="headings", height=14)
    widths = {"选择": 50, "用户名": 120, "姓名": 120, "部门": 140,
              "角色": 80, "状态": 80}
    for c in cols:
        tree.heading(c, text=c)
        tree.column(c, width=widths[c])
    tree.pack(fill="both", expand=True, padx=16)
    checked = set()
    idmap = {}
    for it in items:
        iid = tree.insert("", "end", values=("", it.get("username", ""),
                           it.get("name", ""), it.get("department", ""),
                           ROLES.get(it.get("role", ""), it.get("role", "")),
                           it.get("status", "")))
        idmap[iid] = it

    def on_click(event):
        region = tree.identify("region", event.x, event.y)
        if region != "cell":
            return
        col = tree.identify_column(event.x)
        if col != "#1":
            return
        iid = tree.identify_row(event.y)
        if not iid:
            return
        it = idmap[iid]
        if it.get("id") in checked:
            checked.discard(it.get("id"))
            tree.set(iid, "选择", "")
        else:
            checked.add(it.get("id"))
            tree.set(iid, "选择", "✓")
        sel_lab.configure(text="已选 {0} 人".format(len(checked)))

    tree.bind("<Button-1>", on_click)
    row = Frame(parent, bg=BG)
    row.pack(fill="x", padx=16, pady=6)
    sel_lab = Label(row, text="已选 0 人", bg=BG, fg=TEXT_MUTED,
                    font=font(row, 12))
    sel_lab.pack(side="left", padx=4)
    Button(row, text="全选(当前可见)", style="Ghost.TButton",
           command=lambda: _select_all(tree, idmap, checked, sel_lab)
           ).pack(side="left", padx=4)
    app.ui["user_checked"] = checked
    app.ui["user_tree"] = tree

    def batch(action, label):
        if not checked:
            banner(parent, "请先勾选用户", "warn")
            return
        if action == "delete":
            confirm_dialog(parent, "删除用户",
                           "删除 {0} 名用户,其考试记录将一并删除,且不可恢复。".format(
                               len(checked)),
                           lambda: _do_batch(app, parent, action, checked))
        else:
            _do_batch(app, parent, action, checked)

    Button(row, text="停用所选", style="Ghost.TButton",
           command=lambda: batch("disable", "停用")).pack(side="left", padx=4)
    Button(row, text="启用所选", style="Ghost.TButton",
           command=lambda: batch("enable", "启用")).pack(side="left", padx=4)
    Button(row, text="删除所选", style="Ghost.TButton",
           command=lambda: batch("delete", "删除")).pack(side="left", padx=4)
    Button(row, text="重置密码", style="Ghost.TButton",
           command=lambda: _reset_pw(app, parent, checked)).pack(side="left", padx=4)

    def edit_sel():
        s = tree.selection()
        if not s:
            banner(parent, "请先选择一名用户(点击行高亮)", "warn")
            return
        _user_dialog(app, parent, idmap.get(s[0]))

    Button(row, text="编辑所选(单个)", style="Ghost.TButton",
           command=edit_sel).pack(side="left", padx=4)
    nav = Frame(parent, bg=BG)
    nav.pack(fill="x", padx=16, pady=4)
    Button(nav, text="上一页", style="Ghost.TButton",
           command=lambda: build_user_manage(app, parent, max(1, page - 1),
                                             q, dept) if page > 1 else None
           ).pack(side="left", padx=4)
    Button(nav, text="下一页", style="Ghost.TButton",
           command=lambda: build_user_manage(app, parent, page + 1, q, dept)
           ).pack(side="left", padx=4)
    Label(nav, text="第 {0} 页".format(page), bg=BG, fg=TEXT_MUTED,
          font=font(nav, 12)).pack(side="left", padx=8)
    return parent


def _select_all(tree, idmap, checked, sel_lab):
    for iid, it in idmap.items():
        checked.add(it.get("id"))
        tree.set(iid, "选择", "✓")
    sel_lab.configure(text="已选 {0} 人".format(len(checked)))


def _do_batch(app, parent, action, checked):
    try:
        app.api.post("/api/admin/users/batch",
                     {"action": action, "ids": list(checked)})
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    build_user_manage(app, parent)


def _reset_pw(app, parent, checked):
    if not checked:
        banner(parent, "请先勾选用户", "warn")
        return
    for uid in list(checked):
        try:
            app.api.post("/api/admin/users/{0}/reset-password".format(uid),
                         {"password": "123456"})
        except ApiError as e:
            banner(parent, e.message, "error")
            return
    banner(parent, "已重置所选用户密码为 123456", "ok")


def _import_users(app, parent):
    if filedialog is None:
        banner(parent, "当前环境不支持文件对话框", "error")
        return
    path = filedialog.askopenfilename(filetypes=[("Excel", "*.xlsx")])
    if not path:
        return
    with open(path, "rb") as f:
        raw = f.read()
    try:
        data = app.api.post("/api/admin/users/import",
                            {"filename": os.path.basename(path),
                             "content_b64": base64.b64encode(raw).decode("ascii")})
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    banner(parent, data.get("message", "导入完成"), "ok")
    app.ui["user_import_result"] = data
    build_user_manage(app, parent)


def _user_dialog(app, parent, user):
    top = Toplevel(parent)
    top.title("编辑用户" if user else "新增用户")
    top.geometry("480x420+260+140")
    top.configure(bg=CARD)
    top.transient(parent)
    top.grab_set()
    vars_ = {}
    fields = [("用户名" + ("(不可修改)" if user else ""), "username",
               (user or {}).get("username", "")),
              ("姓名 *", "name", (user or {}).get("name", "")),
              ("部门", "department", (user or {}).get("department", "")),
              ("密码" + ("(留空表示不改动)" if user else "(初始密码,至少 6 位)"),
               "password", "")]
    for label, key, val in fields:
        Label(top, text=label, bg=CARD, fg=TEXT,
              font=font(top, 12)).pack(anchor="w", padx=16, pady=(6, 0))
        var = StringVar(value=val)
        show = "*" if key == "password" else ""
        state = "disabled" if (user and key == "username") else "normal"
        Entry(top, textvariable=var, show=show, width=34,
              font=font(top, 12), state=state).pack(anchor="w", padx=16)
        vars_[key] = var
    role_var = StringVar(value=ROLES.get((user or {}).get("role", "student"),
                                         "学员"))
    Label(top, text="角色", bg=CARD, fg=TEXT,
          font=font(top, 12)).pack(anchor="w", padx=16, pady=(6, 0))
    Combobox(top, textvariable=role_var, values=ROLE_NAMES, width=12,
             state="readonly").pack(anchor="w", padx=16)
    msg = Label(top, text="", bg=CARD, fg="#DC2626", font=font(top, 12))
    msg.pack(anchor="w", padx=16, pady=4)
    app.ui["user_dialog_vars"] = vars_
    app.ui["user_dialog_role"] = role_var

    def save():
        name = vars_["name"].get().strip()
        if not name:
            msg.configure(text="姓名不能为空")
            return
        pw = vars_["password"].get()
        if pw and len(pw) < 6:
            msg.configure(text="密码至少 6 位")
            return
        role = dict((v, k) for k, v in ROLES.items()).get(role_var.get(),
                                                         "student")
        try:
            if user:
                payload = {"name": name,
                           "department": vars_["department"].get().strip(),
                           "role": role}
                if pw:
                    payload["password"] = pw
                app.api.put("/api/admin/users/{0}".format(user.get("id")),
                            payload)
            else:
                if not vars_["username"].get().strip():
                    msg.configure(text="请填写用户名")
                    return
                if not pw:
                    msg.configure(text="新建用户请填写初始密码")
                    return
                app.api.post("/api/admin/users",
                             {"username": vars_["username"].get().strip(),
                              "name": name,
                              "department": vars_["department"].get().strip(),
                              "role": role, "password": pw})
        except ApiError as e:
            msg.configure(text=e.message)
            return
        top.destroy()
        banner(parent, "用户信息已更新", "ok")
        build_user_manage(app, parent)

    Button(top, text="保存", style="Navy.TButton",
           command=save).pack(pady=12)
    app.ui["user_dialog_save"] = save
    return top


# ---------------- 上报处理 ----------------

def build_report_manage(app, parent):
    clear(parent)
    app.page = "report_manage"
    Label(parent, text="上报处理", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    try:
        items = app.api.get("/api/admin/reports")
    except ApiError as e:
        banner(parent, e.message, "error")
        return parent
    app.ui["admin_reports"] = items
    pending = [r for r in items if r.get("status") == "待处理"]
    handled = [r for r in items if r.get("status") != "待处理"]
    if not pending:
        Label(parent, text="暂无待处理的上报", bg=BG, fg=GREEN,
              font=font(parent, 14)).pack(pady=20)
    for r in pending:
        _report_card(app, parent, r, pending=True)
    if handled:
        Label(parent, text="已处理记录", bg=BG, fg=NAVY,
              font=font(parent, 15, bold=True)).pack(anchor="w", padx=16,
                                                      pady=(12, 4))
        for r in handled:
            _report_card(app, parent, r, pending=False)
    return parent


def _report_card(app, parent, r, pending):
    q = r.get("question") or {}
    rep = r.get("reporter") or {}
    card = Frame(parent, bg=CARD, highlightbackground=BORDER,
                 highlightthickness=1)
    card.pack(fill="x", padx=16, pady=6)
    Label(card, text="{0} {1}  状态:{2}".format(q.get("no", ""),
          r.get("type", ""), r.get("status", "")), bg=CARD, fg=NAVY,
          font=font(card, 13, bold=True), anchor="w"
          ).pack(fill="x", padx=12, pady=(8, 2))
    Label(card, text="题干:{0}".format(q.get("stem", "")), bg=CARD, fg=TEXT,
          font=font(card, 12), wraplength=860, justify="left", anchor="w"
          ).pack(fill="x", padx=12)
    if q.get("options"):
        for letter in sorted(q.get("options").keys()):
            Label(card, text="{0}. {1}".format(letter, q["options"][letter]),
                  bg=CARD, fg=TEXT_MUTED, font=font(card, 12), anchor="w",
                  wraplength=860, justify="left").pack(fill="x", padx=24)
    Label(card, text="正确答案:{0}".format(q.get("answer", "")), bg=CARD,
          fg=GREEN, font=font(card, 12, bold=True), anchor="w"
          ).pack(fill="x", padx=12, pady=2)
    if q.get("analysis"):
        Label(card, text="解析:{0}".format(q.get("analysis")), bg=CARD,
              fg=TEXT, font=font(card, 12), wraplength=860, justify="left",
              anchor="w").pack(fill="x", padx=12)
    if q.get("image"):
        Label(card, text="题图:{0}".format(q.get("image")), bg=CARD,
              fg=TEXT_MUTED, font=font(card, 12), anchor="w"
              ).pack(fill="x", padx=12)
    Label(card, text="上报内容:{0}  补充说明:{1}".format(r.get("type", ""),
          r.get("detail", "")), bg=CARD, fg=TEXT, font=font(card, 12),
          wraplength=860, justify="left", anchor="w").pack(fill="x", padx=12,
                                                            pady=2)
    Label(card, text="上报用户:{0}({1})  上报时间:{2}".format(
        rep.get("name", ""), rep.get("department", ""),
        r.get("created_at", "")), bg=CARD, fg=TEXT_MUTED,
        font=font(card, 12), anchor="w").pack(fill="x", padx=12, pady=2)
    if pending:
        reply_var = StringVar()
        Label(card, text="处理回复", bg=CARD, fg=TEXT,
              font=font(card, 12)).pack(anchor="w", padx=12, pady=(6, 0))
        Entry(card, textvariable=reply_var, width=60,
              font=font(card, 12)).pack(anchor="w", padx=12, pady=2)
        row = Frame(card, bg=CARD)
        row.pack(fill="x", padx=12, pady=(4, 10))

        def handle(action):
            try:
                app.api.post("/api/admin/reports/{0}/handle".format(r.get("id")),
                             {"action": action, "reply": reply_var.get()})
            except ApiError as e:
                banner(parent, e.message, "error")
                return
            build_report_manage(app, parent)

        Button(row, text="标记已解决", style="Navy.TButton",
               command=lambda: handle("已解决")).pack(side="left", padx=4)
        Button(row, text="驳回(无需处理)", style="Ghost.TButton",
               command=lambda: handle("已驳回")).pack(side="left", padx=4)
        Button(row, text="停用该题", style="Gold.TButton",
               command=lambda: handle("停用该题")).pack(side="left", padx=4)
    else:
        Label(card, text="处理于:{0}  处理回复:{1}".format(
            r.get("handled_at", ""), r.get("reply", "")), bg=CARD, fg=NAVY,
            font=font(card, 12), anchor="w", wraplength=860, justify="left"
            ).pack(fill="x", padx=12, pady=(2, 8))


# ---------------- 统计分析 ----------------

def build_admin_stats(app, parent):
    clear(parent)
    app.page = "admin_stats"
    Label(parent, text="统计分析", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    try:
        data = app.api.get("/api/admin/stats")
    except ApiError as e:
        banner(parent, e.message, "error")
        return parent
    app.ui["admin_stats"] = data
    row = Frame(parent, bg=BG)
    row.pack(fill="x", padx=16, pady=6)
    for title, val in (("学员总数", str(data.get("student_count", 0))),
                       ("练习总题次", str(data.get("practice_total", 0))),
                       ("全站正确率", "{0}%".format(data.get("accuracy", 0))),
                       ("待处理上报", str(data.get("pending_reports", 0))),
                       ("题库总数", str(data.get("question_count", 0)))):
        stat_card(row, title, val).pack(side="left", fill="x", expand=True,
                                         padx=6)
    dept = [(d.get("department", ""), d.get("count", 0))
            for d in (data.get("students_by_department") or [])]
    bar_chart(parent, dept, "学员部门分布").pack(fill="x", padx=16, pady=8)
    by_type = [(d.get("type", ""), d.get("count", 0))
               for d in (data.get("questions_by_type") or [])]
    bar_chart(parent, by_type, "题库构成").pack(fill="x", padx=16, pady=8)
    exams = [(d.get("name", "")[:8], d.get("submitted", 0))
             for d in (data.get("recent_exams") or [])]
    bar_chart(parent, exams, "考试成绩(最近 5 场:已考人数)").pack(fill="x",
                                                              padx=16, pady=8)
    for d in (data.get("recent_exams") or []):
        Label(parent, text="{0}:已考 {1} 人,均分 {2}".format(
            d.get("name", ""), d.get("submitted", 0), d.get("average", "")),
            bg=BG, fg=TEXT, font=font(parent, 12), anchor="w"
            ).pack(fill="x", padx=16)
    return parent


# ---------------- 客户端更新发布 ----------------

def build_version_manage(app, parent):
    clear(parent)
    app.page = "version_manage"
    Label(parent, text="客户端更新发布", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    form = Frame(parent, bg=CARD, highlightbackground=BORDER,
                 highlightthickness=1)
    form.pack(fill="x", padx=16, pady=6)
    Label(form, text="发布新版本:同一平台一次只保留一个生效版本",
          bg=CARD, fg=NAVY, font=font(form, 13, bold=True)
          ).pack(anchor="w", padx=14, pady=(8, 2))
    plat_var = StringVar(value="win7-32")
    ver_var = StringVar(value="v2.1")
    note_var = StringVar()
    file_var = StringVar()
    for label, var in (("目标平台", plat_var), ("版本号", ver_var),
                       ("更新说明", note_var), ("客户端程序/安装包(可选,仅记文件名)",
                        file_var)):
        Label(form, text=label, bg=CARD, fg=TEXT,
              font=font(form, 12)).pack(anchor="w", padx=14, pady=(4, 0))
        Combobox(form, textvariable=var,
                 values=["win7-32", "win10-64", "xp-32"], width=20,
                 state="readonly") if label == "目标平台" else Entry(
                     form, textvariable=var, width=50, font=font(form, 12)
                 ).pack(anchor="w", padx=14)
    msg = Label(form, text="", bg=CARD, fg="#16A34A", font=font(form, 12))
    msg.pack(anchor="w", padx=14, pady=4)

    def publish():
        try:
            app.api.post("/api/admin/versions",
                         {"platform": plat_var.get(),
                          "version": ver_var.get().strip(),
                          "note": note_var.get(), "filename": file_var.get()})
        except ApiError as e:
            msg.configure(text=e.message, fg="#DC2626")
            return
        msg.configure(text="发布成功,各终端启动时自动检查并升级", fg="#16A34A")
        app.root.after(800, lambda: build_version_manage(app, parent))

    Button(form, text="发布新版本", style="Navy.TButton",
           command=publish).pack(anchor="w", padx=14, pady=10)
    app.ui["version_publish"] = publish
    app.ui["version_vars"] = {"platform": plat_var, "version": ver_var,
                              "note": note_var, "filename": file_var}
    try:
        versions = app.api.get("/api/admin/versions")
    except ApiError as e:
        banner(parent, e.message, "error")
        return parent
    app.ui["admin_versions"] = versions
    if not versions:
        Label(parent, text="尚未发布任何版本", bg=BG, fg=TEXT_MUTED,
              font=font(parent, 12)).pack(anchor="w", padx=16, pady=8)
    for v in versions:
        card = Frame(parent, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1)
        card.pack(fill="x", padx=16, pady=6)
        Label(card, text="{0}  {1}  {2}".format(v.get("version", ""),
              v.get("platform", ""), v.get("status", "")), bg=CARD, fg=NAVY,
              font=font(card, 13, bold=True), anchor="w"
              ).pack(fill="x", padx=12, pady=(8, 2))
        Label(card, text="说明:{0}  包含文件:{1}".format(v.get("note", ""),
              v.get("filename", "")), bg=CARD, fg=TEXT, font=font(card, 12),
              anchor="w", wraplength=860, justify="left"
              ).pack(fill="x", padx=12)
        row = Frame(card, bg=CARD)
        row.pack(fill="x", padx=12, pady=(4, 10))
        vid = v.get("id")
        if v.get("status") != "生效中":
            Button(row, text="设为生效版本", style="Navy.TButton",
                   command=lambda vid=vid: _version_action(app, parent, vid,
                                                           "activate")
                   ).pack(side="left", padx=4)
        else:
            Button(row, text="下架", style="Gold.TButton",
                   command=lambda vid=vid: _version_action(app, parent, vid,
                                                           "deactivate")
                   ).pack(side="left", padx=4)
        Button(row, text="删除记录", style="Ghost.TButton",
               command=lambda vid=vid: _delete_version(app, parent, vid)
               ).pack(side="left", padx=4)
    # 邀请码设置
    Label(parent, text="邀请码设置", bg=BG, fg=NAVY,
          font=font(parent, 15, bold=True)).pack(anchor="w", padx=16,
                                                  pady=(12, 4))
    invite_form = Frame(parent, bg=CARD, highlightbackground=BORDER,
                        highlightthickness=1)
    invite_form.pack(fill="x", padx=16, pady=(0, 20))
    try:
        cur = (app.api.get("/api/settings/invite-code") or {}
               ).get("invite_code", "")
    except ApiError:
        cur = ""
    Label(invite_form, text="当前邀请码:{0}".format(cur), bg=CARD, fg=TEXT,
          font=font(invite_form, 12)).pack(anchor="w", padx=14, pady=(8, 2))
    new_var = StringVar()
    Entry(invite_form, textvariable=new_var, width=24,
          font=font(invite_form, 12)).pack(anchor="w", padx=14)
    imsg = Label(invite_form, text="", bg=CARD, fg="#16A34A",
                 font=font(invite_form, 12))
    imsg.pack(anchor="w", padx=14, pady=4)

    def change_invite():
        try:
            app.api.post("/api/settings/invite-code",
                         {"invite_code": new_var.get().strip()})
        except ApiError as e:
            imsg.configure(text=e.message, fg="#DC2626")
            return
        imsg.configure(text="邀请码已更换", fg="#16A34A")

    Button(invite_form, text="更换邀请码", style="Navy.TButton",
           command=change_invite).pack(anchor="w", padx=14, pady=(0, 12))
    return parent


def _version_action(app, parent, vid, action):
    try:
        app.api.post("/api/admin/versions/{0}/{1}".format(vid, action), {})
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    build_version_manage(app, parent)


def _delete_version(app, parent, vid):
    def do_it():
        try:
            app.api.delete("/api/admin/versions/{0}".format(vid))
        except ApiError as e:
            banner(parent, e.message, "error")
            return
        build_version_manage(app, parent)
    confirm_dialog(parent, "删除版本", "确定删除这条版本记录吗?"
                   "(生效中的版本需先下架才能删除)", do_it, yes_text="删除")


# ---------------- v2:统计仪表盘 / 学习计划 / 联邦共享 / 备份管理 ----------------
# 字段假设(按 v07 admin_overview/report_for 形状,见汇总):
# overview 含 total_users/active_today/today_attempts/avg_accuracy/
# total_attempts/trend14/pending_review/weak_top/suspects/teams/
# warnings/heatmap/plans_active/plans_overdue;
# teams 行含 team/member_count/total_attempts/avg_accuracy/
# participation/below_target;backup status 含 count/last_filename/
# last_at/last_size/auto/keep/disk;备份列表行含 filename/note/
# created_at/size_bytes/status。

def build_admin_dashboard(app, parent):
    """统计分析仪表盘(v2):总览 / 个人 / 部门横向对比 / 预警 + 图表。"""
    clear(parent)
    app.page = "admin_dashboard"
    app.set_space_handler(None)
    Label(parent, text="统计分析仪表盘", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    overview = None
    try:
        overview = app.api.v2_dashboard_overview()
    except ApiError as e:
        banner(parent, e.message, "error")
        app.ui["v2_admin_dashboard"] = {}
        return parent
    if isinstance(overview, dict):
        overview = overview.get("overview") or overview
    overview = overview or {}
    app.ui["v2_admin_dashboard"] = overview
    acc = overview.get("avg_accuracy", 0)
    if acc and acc <= 1:
        acc = int(round(acc * 100))
    row = Frame(parent, bg=BG)
    row.pack(fill="x", padx=16, pady=6)
    for title, val in (("用户总数", str(overview.get("total_users", 0))),
                       ("今日活跃", str(overview.get("active_today", 0))),
                       ("今日作答", str(overview.get("today_attempts", 0))),
                       ("累计作答", str(overview.get("total_attempts", 0))),
                       ("全站正确率", "{0}%".format(acc)),
                       ("待审核导入", str(overview.get("pending_review", 0))),
                       ("疑似错题", str(overview.get("suspects", 0))),
                       ("逾期计划", str(overview.get("plans_overdue", 0)))):
        stat_card(row, title, val).pack(side="left", fill="x", expand=True,
                                         padx=6)
    warnings = overview.get("warnings") or []
    if warnings:
        Label(parent, text="预警({0})".format(len(warnings)), bg=BG, fg=NAVY,
              font=font(parent, 15, bold=True)).pack(anchor="w", padx=16,
                                                      pady=(8, 4))
        for w in warnings[:10]:
            Label(parent, text="{0}({1}):{2}".format(
                w.get("display_name", ""), w.get("team", ""),
                w.get("detail", "")), bg="#FEE2E2", fg="#991B1B",
                font=font(parent, 12), anchor="w", wraplength=860,
                justify="left").pack(fill="x", padx=16, pady=2)
    from widgets import trend_chart, heatmap_chart
    trend = overview.get("trend14") or []
    if trend:
        trend_chart(parent, [(d.get("date", "")[5:],
                              d.get("total", 0)) for d in trend],
                    "近 14 天全站作答趋势").pack(fill="x", padx=16, pady=8)
    teams = None
    try:
        teams = app.api.v2_dashboard_teams()
    except ApiError:
        teams = None
    if isinstance(teams, dict):
        teams = teams.get("teams") or []
    if teams is None:
        teams = overview.get("teams") or []
    app.ui["v2_admin_teams"] = teams or []
    if teams:
        items = []
        for t in teams:
            a = t.get("avg_accuracy", 0)
            if a and a <= 1:
                a = int(round(a * 100))
            items.append((t.get("team", ""), a))
        bar_chart(parent, items, "部门横向对比(正确率 %)").pack(
            fill="x", padx=16, pady=8)
        for t in teams:
            a = t.get("avg_accuracy", 0)
            if a and a <= 1:
                a = int(round(a * 100))
            Label(parent, text="{0}: {1} 人,作答 {2} 次,正确率 {3}%,"
                  "近 14 天参与 {4}%,低于 60% {5} 人".format(
                      t.get("team", ""), t.get("member_count", 0),
                      t.get("total_attempts", 0), a,
                      int(round((t.get("participation", 0) or 0) * 100)),
                      t.get("below_target", 0)), bg=BG, fg=TEXT,
                  font=font(parent, 12), anchor="w").pack(fill="x", padx=16)
    heat = overview.get("heatmap") or {}
    if heat:
        heatmap_chart(parent, heat, "知识点 x 部门正确率热力").pack(
            fill="x", padx=16, pady=8)
    weak_top = overview.get("weak_top") or []
    if weak_top:
        from widgets import radar_chart
        radar_chart(parent, [(d.get("knowledge", ""),
                              d.get("accuracy", 0)) for d in weak_top],
                    "全站最薄弱知识点(雷达)").pack(fill="x", padx=16, pady=8)
    row2 = Frame(parent, bg=BG)
    row2.pack(fill="x", padx=16, pady=10)
    Button(row2, text="学习计划", style="Navy.TButton",
           command=lambda: app.goto("plans_admin")).pack(side="left", padx=6)
    Button(row2, text="联邦共享", style="Navy.TButton",
           command=lambda: app.goto("federation")).pack(side="left", padx=6)
    Button(row2, text="备份管理", style="Navy.TButton",
           command=lambda: app.goto("backup")).pack(side="left", padx=6)
    return parent


def build_plans_admin(app, parent):
    """学习计划下发与进度(管理员/考官)。"""
    clear(parent)
    app.page = "plans_admin"
    app.set_space_handler(None)
    Label(parent, text="学习计划", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    bar = Frame(parent, bg=BG)
    bar.pack(fill="x", padx=16, pady=4)
    Button(bar, text="下发新计划", style="Navy.TButton",
           command=lambda: _plan_dialog(app, parent)).pack(side="left", padx=4)
    try:
        plans = app.api.v2_plans()
    except ApiError as e:
        banner(parent, e.message, "error")
        app.ui["v2_plans"] = []
        return parent
    if isinstance(plans, dict):
        plans = plans.get("plans") or []
    app.ui["v2_plans"] = plans or []
    if not plans:
        Label(parent, text="暂无学习计划,点击下发新计划", bg=BG, fg=TEXT_MUTED,
              font=font(parent, 14)).pack(pady=30)
        return parent
    for p in plans:
        card = Frame(parent, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1)
        card.pack(fill="x", padx=16, pady=6)
        Label(card, text="{0}  平均进度 {1}%  完成 {2}/{3} 人".format(
            p.get("title", ""), p.get("avg_pct", 0), p.get("done_count", 0),
            p.get("assigned", 0)), bg=CARD, fg=NAVY,
            font=font(card, 13, bold=True), anchor="w").pack(
                fill="x", padx=12, pady=(8, 2))
        Label(card, text="范围:{0}  部门:{1}  知识点:{2}  目标:{3} 题  "
              "每日:{4} 题  截止:{5}".format(p.get("scope", ""),
              p.get("team", ""), p.get("knowledge", "") or "全部",
              p.get("target_count", 0), p.get("daily_count", 0),
              p.get("due_date", "") or "无"), bg=CARD, fg=TEXT_MUTED,
              font=font(card, 12), anchor="w", wraplength=860,
              justify="left").pack(fill="x", padx=12, pady=(0, 8))
    return parent


def _plan_dialog(app, parent):
    top = Toplevel(parent)
    top.title("下发学习计划")
    top.geometry("520x560+240+80")
    top.configure(bg=CARD)
    top.transient(parent)
    top.grab_set()
    title_var = StringVar(value="")
    scope_var = StringVar(value="team")
    team_var = StringVar(value="")
    uid_var = StringVar(value="")
    target_var = StringVar(value="50")
    daily_var = StringVar(value="10")
    due_var = StringVar(value="")
    kn_var = StringVar(value="")
    for label, var in (("计划名称 *", title_var), ("部门(部门计划)", team_var),
                       ("个人用户 ID(个人计划)", uid_var),
                       ("目标题量 *", target_var), ("每日目标题量", daily_var),
                       ("截止日(YYYY-MM-DD,选填)", due_var),
                       ("知识点(选填,空为全部)", kn_var)):
        Label(top, text=label, bg=CARD, fg=TEXT,
              font=font(top, 12)).pack(anchor="w", padx=16, pady=(6, 0))
        Entry(top, textvariable=var, width=40,
              font=font(top, 12)).pack(anchor="w", padx=16)
    Label(top, text="范围", bg=CARD, fg=TEXT,
          font=font(top, 12)).pack(anchor="w", padx=16, pady=(6, 0))
    Combobox(top, textvariable=scope_var, values=["team", "personal"],
             width=12, state="readonly").pack(anchor="w", padx=16)
    Label(top, text="team=部门全员,personal=指定一名用户",
          bg=CARD, fg=TEXT_MUTED, font=font(top, 11)).pack(anchor="w", padx=16)
    msg = Label(top, text="", bg=CARD, fg="#DC2626", font=font(top, 12))
    msg.pack(anchor="w", padx=16, pady=4)
    app.ui["plan_dialog_vars"] = {"title": title_var, "scope": scope_var,
                                  "team": team_var, "user_id": uid_var,
                                  "target": target_var, "daily": daily_var,
                                  "due": due_var, "knowledge": kn_var}

    def save():
        title = title_var.get().strip()
        if not title:
            msg.configure(text="计划名称不能为空")
            return
        try:
            target = int(target_var.get() or 0)
            daily = int(daily_var.get() or 0)
        except Exception:
            msg.configure(text="题量须为数字")
            return
        uid = None
        if scope_var.get() == "personal":
            try:
                uid = int(uid_var.get())
            except Exception:
                msg.configure(text="个人计划须填写用户 ID")
                return
        try:
            data = app.api.v2_plan_create(title, scope_var.get(),
                                          team=team_var.get().strip(),
                                          user_id=uid, target_count=target,
                                          daily_count=daily,
                                          due_date=due_var.get().strip(),
                                          knowledge=kn_var.get().strip())
        except ApiError as e:
            msg.configure(text=e.message)
            return
        top.destroy()
        banner(parent, "已下发计划:{0}".format(
            (data or {}).get("plan_id", "") if isinstance(data, dict) else ""),
            "ok")
        build_plans_admin(app, parent)

    Button(top, text="下发", style="Navy.TButton",
           command=save).pack(pady=12)
    app.ui["plan_dialog_save"] = save
    return top


def build_federation(app, parent):
    """联邦共享:主机登记 / 测试 / 拉取 + 本机令牌。"""
    clear(parent)
    app.page = "federation"
    app.set_space_handler(None)
    Label(parent, text="联邦共享", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    try:
        token = app.api.v2_fed_token()
    except ApiError:
        token = None
    if isinstance(token, dict):
        tok = token.get("token", "")
        lan = token.get("lan_url", "")
    elif isinstance(token, str):
        tok, lan = token, ""
    else:
        tok, lan = "", ""
    app.ui["v2_fed_token"] = tok
    Label(parent, text="本机共享令牌:{0}  局域网地址:{1}".format(
        tok or "未获取", lan or ""), bg=GOLD_LIGHT, fg=NAVY,
        font=font(parent, 12), anchor="w", wraplength=860,
        justify="left").pack(fill="x", padx=16, pady=4)
    bar = Frame(parent, bg=BG)
    bar.pack(fill="x", padx=16, pady=4)
    Button(bar, text="登记新主机", style="Navy.TButton",
           command=lambda: _fed_host_dialog(app, parent)).pack(side="left",
                                                               padx=4)
    try:
        hosts = app.api.v2_fed_hosts()
    except ApiError as e:
        banner(parent, e.message, "error")
        app.ui["v2_fed_hosts"] = []
        return parent
    if isinstance(hosts, dict):
        hosts = hosts.get("hosts") or []
    app.ui["v2_fed_hosts"] = hosts or []
    if not hosts:
        Label(parent, text="暂无登记主机", bg=BG, fg=TEXT_MUTED,
              font=font(parent, 14)).pack(pady=20)
        return parent
    for h in hosts:
        card = Frame(parent, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1)
        card.pack(fill="x", padx=16, pady=6)
        Label(card, text="{0}  {1}:{2}  状态:{3}".format(
            h.get("name", ""), h.get("host", ""), h.get("port", ""),
            h.get("status", "")), bg=CARD, fg=NAVY,
            font=font(card, 13, bold=True), anchor="w").pack(
                fill="x", padx=12, pady=(8, 2))
        Label(card, text="上次同步:{0}  上次题数:{1}  错误:{2}".format(
            h.get("last_seen", "") or "无", h.get("last_count", ""),
            h.get("last_error", "") or "无"), bg=CARD, fg=TEXT_MUTED,
            font=font(card, 12), anchor="w").pack(fill="x", padx=12)
        row = Frame(card, bg=CARD)
        row.pack(fill="x", padx=12, pady=(4, 10))
        hid = h.get("id")
        Button(row, text="连通测试", style="Ghost.TButton",
               command=lambda hid=hid: _fed_test(app, parent, hid)
               ).pack(side="left", padx=3)
        Button(row, text="查看目录", style="Ghost.TButton",
               command=lambda hid=hid: _fed_catalog(app, parent, hid)
               ).pack(side="left", padx=3)
        Button(row, text="拉取题库", style="Navy.TButton",
               command=lambda hid=hid: _fed_pull(app, parent, hid)
               ).pack(side="left", padx=3)
        Button(row, text="删除", style="Ghost.TButton",
               command=lambda hid=hid: _fed_delete(app, parent, hid)
               ).pack(side="left", padx=3)
    return parent


def _fed_host_dialog(app, parent):
    top = Toplevel(parent)
    top.title("登记联邦主机")
    top.geometry("480x420+260+140")
    top.configure(bg=CARD)
    top.transient(parent)
    top.grab_set()
    name_var = StringVar(value="")
    host_var = StringVar(value="")
    port_var = StringVar(value="8766")
    token_var = StringVar(value="")
    for label, var in (("主机名称 *", name_var),
                       ("对方主机地址(IP 或主机名,不带 http://)", host_var),
                       ("端口", port_var),
                       ("对方共享令牌 *", token_var)):
        Label(top, text=label, bg=CARD, fg=TEXT,
              font=font(top, 12)).pack(anchor="w", padx=16, pady=(6, 0))
        Entry(top, textvariable=var, width=40,
              font=font(top, 12)).pack(anchor="w", padx=16)
    msg = Label(top, text="", bg=CARD, fg="#DC2626", font=font(top, 12))
    msg.pack(anchor="w", padx=16, pady=4)
    app.ui["fed_dialog_vars"] = {"name": name_var, "host": host_var,
                                 "port": port_var, "token": token_var}

    def save():
        if not name_var.get().strip() or not host_var.get().strip() or \
                not token_var.get().strip():
            msg.configure(text="名称、主机地址、令牌都要填")
            return
        try:
            port = int(port_var.get() or 8766)
        except Exception:
            msg.configure(text="端口须为数字")
            return
        try:
            app.api.v2_fed_host_create(name_var.get().strip(),
                                       host_var.get().strip(), port,
                                       token_var.get().strip())
        except ApiError as e:
            msg.configure(text=e.message)
            return
        top.destroy()
        build_federation(app, parent)

    Button(top, text="登记", style="Navy.TButton",
           command=save).pack(pady=12)
    app.ui["fed_dialog_save"] = save
    return top


def _fed_test(app, parent, hid):
    try:
        data = app.api.v2_fed_host_test(hid)
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    cat = (data or {}).get("catalog") if isinstance(data, dict) else None
    msg = "连通测试通过"
    if isinstance(cat, dict):
        msg += ":对方题库 {0} 道".format(cat.get("question_count", ""))
    banner(parent, msg, "ok")
    build_federation(app, parent)


def _fed_catalog(app, parent, hid):
    try:
        cat = app.api.v2_fed_catalog(host_id=hid)
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    app.ui["v2_fed_catalog"] = cat
    if isinstance(cat, dict):
        banner(parent, "对方题库:{0} 题,科目:{1}".format(
            cat.get("question_count", ""),
            "、".join(cat.get("subjects") or [])), "ok")
    else:
        banner(parent, "已获取对方题库目录", "ok")


def _fed_pull(app, parent, hid):
    try:
        data = app.api.v2_fed_pull(hid, limit=50)
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    app.ui["v2_fed_pull"] = data
    banner(parent, (data or {}).get("message", "拉取完成") if
           isinstance(data, dict) else "拉取完成", "ok")
    build_federation(app, parent)


def _fed_delete(app, parent, hid):
    def do_it():
        try:
            app.api.v2_fed_host_delete(hid)
        except ApiError as e:
            banner(parent, e.message, "error")
            return
        build_federation(app, parent)
    confirm_dialog(parent, "删除主机", "确定删除该联邦主机登记吗?",
                   do_it, yes_text="删除")


def build_backup(app, parent):
    """备份管理:一键备份 / 恢复 / 列表 / 下载。"""
    clear(parent)
    app.page = "backup"
    app.set_space_handler(None)
    Label(parent, text="备份管理", bg=BG, fg=NAVY,
          font=font(parent, 18, bold=True)).pack(anchor="w", padx=16, pady=12)
    try:
        status = app.api.v2_backup_status()
    except ApiError as e:
        banner(parent, e.message, "error")
        app.ui["v2_backup_status"] = {}
        return parent
    if isinstance(status, dict):
        status = status.get("backup") or status
    status = status or {}
    app.ui["v2_backup_status"] = status
    row = Frame(parent, bg=BG)
    row.pack(fill="x", padx=16, pady=6)
    for title, val in (("备份份数", str(status.get("count", 0))),
                       ("最近备份", str(status.get("last_filename", "") or "无")),
                       ("最近时间", str(status.get("last_at", "") or "无")),
                       ("自动备份", "开启" if status.get("auto") else "关闭"),
                       ("保留份数", str(status.get("keep", 7)))):
        stat_card(row, title, val).pack(side="left", fill="x", expand=True,
                                         padx=6)
    bar = Frame(parent, bg=BG)
    bar.pack(fill="x", padx=16, pady=8)
    Button(bar, text="一键备份", style="Navy.TButton",
           command=lambda: _backup_create(app, parent)).pack(side="left",
                                                             padx=4)
    try:
        items = app.api.v2_backup_list()
    except ApiError as e:
        banner(parent, e.message, "error")
        app.ui["v2_backups"] = []
        return parent
    if isinstance(items, dict):
        items = items.get("backups") or []
    app.ui["v2_backups"] = items or []
    if not items:
        Label(parent, text="暂无备份,点击一键备份", bg=BG, fg=TEXT_MUTED,
              font=font(parent, 14)).pack(pady=20)
        return parent
    for b in items:
        card = Frame(parent, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1)
        card.pack(fill="x", padx=16, pady=6)
        Label(card, text="{0}  {1}  {2} 字节".format(
            b.get("filename", ""), b.get("created_at", ""),
            b.get("size_bytes", "")), bg=CARD, fg=NAVY,
            font=font(card, 12, bold=True), anchor="w").pack(
                fill="x", padx=12, pady=(8, 2))
        if b.get("note"):
            Label(card, text="备注:{0}".format(b.get("note")), bg=CARD,
                  fg=TEXT_MUTED, font=font(card, 12), anchor="w").pack(
                      fill="x", padx=12)
        row = Frame(card, bg=CARD)
        row.pack(fill="x", padx=12, pady=(4, 10))
        fname = b.get("filename", "")
        Button(row, text="恢复该备份", style="Gold.TButton",
               command=lambda fn=fname: _backup_restore(app, parent, fn)
               ).pack(side="left", padx=3)
        Button(row, text="下载", style="Ghost.TButton",
               command=lambda fn=fname: _backup_download(app, parent, fn)
               ).pack(side="left", padx=3)
    return parent


def _backup_create(app, parent):
    try:
        data = app.api.v2_backup_create("客户端手动备份")
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    banner(parent, "备份完成:{0}".format(
        (data or {}).get("filename", "") if isinstance(data, dict) else ""),
        "ok")
    build_backup(app, parent)


def _backup_restore(app, parent, fname):
    def do_it():
        try:
            app.api.v2_backup_restore(fname)
        except ApiError as e:
            banner(parent, e.message, "error")
            return
        banner(parent, "已恢复备份 {0}(恢复前已自动再备一份)".format(fname),
               "ok")
        build_backup(app, parent)
    confirm_dialog(parent, "恢复备份",
                   "恢复前会自动再备一份当前库,确定恢复 {0} 吗?".format(fname),
                   do_it, yes_text="恢复")


def _backup_download(app, parent, fname):
    try:
        raw = app.api.v2_backup_download(fname)
    except ApiError as e:
        banner(parent, e.message, "error")
        return
    if filedialog is None:
        banner(parent, "当前环境不支持文件对话框", "error")
        return
    path = filedialog.asksaveasfilename(defaultextension=".zip",
                                        initialfile=fname)
    if not path:
        return
    try:
        with open(path, "wb") as f:
            f.write(raw)
    except Exception as e:
        banner(parent, "保存失败:{0}".format(e), "error")
        return
    banner(parent, "备份已保存到 {0}".format(path), "ok")
