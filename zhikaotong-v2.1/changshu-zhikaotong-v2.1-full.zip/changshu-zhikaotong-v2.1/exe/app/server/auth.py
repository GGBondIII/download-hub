# -*- coding: utf-8 -*-
"""常熟站智考通 v2.1 — 认证:登录/注册/改密码/token 校验/角色。

sha256 加盐哈希(盐 16 字节随机 hex,存 "salt$hex")。
token:32 字节随机 hex,内存会话表,供 exe 内嵌服务器与网页版共用。
角色: admin(管理员) / examiner(考官) / student(学员)。
Python 3.4 兼容语法。
"""
import hashlib
import hmac
import os
import time

import db

SESSIONS = {}
SESSION_TTL = 24 * 3600

ROLES = ('admin', 'examiner', 'student')
ROLE_NAMES = {'admin': '管理员', 'examiner': '考官', 'student': '学员'}


def now_iso():
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())


def hash_pw(pw, salt=None):
    if salt is None:
        # bytes 的 hex 方法是 3.5+ 才有,3.4 下用循环拼 hex
        salt = ''.join('%02x' % b for b in bytearray(os.urandom(8)))
    h = hashlib.sha256((salt + pw).encode('utf-8')).hexdigest()
    return "{0}${1}".format(salt, h)


def check_pw(pw, stored):
    try:
        salt, h = stored.split("$", 1)
    except (ValueError, AttributeError):
        return False
    calc = hashlib.sha256((salt + pw).encode('utf-8')).hexdigest()
    return hmac.compare_digest(calc, h)


def public_user(row):
    """去掉密码哈希的用户公开字段。"""
    d = db.row_to_dict(row)
    if d is None:
        return None
    d.pop('password_hash', None)
    d['role_name'] = ROLE_NAMES.get(d.get('role'), d.get('role'))
    return d


def get_user_by_id(user_id):
    conn = db.get_conn()
    with db.DB_LOCK:
        row = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    return row


def get_user_by_username(username):
    conn = db.get_conn()
    with db.DB_LOCK:
        row = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
    return row


def new_token(user_id):
    token = ''.join('%02x' % b for b in bytearray(os.urandom(24)))
    SESSIONS[token] = {'user_id': user_id, 'created': time.time()}
    return token


def verify_token(token):
    """返回用户行(row)或 None。过期会话自动清理。"""
    if not token:
        return None
    sess = SESSIONS.get(token)
    if not sess:
        return None
    if time.time() - sess['created'] > SESSION_TTL:
        SESSIONS.pop(token, None)
        return None
    return get_user_by_id(sess['user_id'])


def revoke_token(token):
    SESSIONS.pop(token, None)


def login(username, password):
    """成功返回 (True, token, user_dict);失败返回 (False, 错误信息, None)。"""
    username = (username or '').strip()
    password = password or ''
    if not username or not password:
        return False, "请填写用户名和密码", None
    row = get_user_by_username(username)
    if row is None:
        return False, "用户名或密码错误", None
    if row['status'] != '正常':
        return False, "该账号已被停用,请联系管理员", None
    if not check_pw(password, row['password_hash']):
        return False, "用户名或密码错误", None
    token = new_token(row['id'])
    return True, token, public_user(row)


def register(name, department, username, password, invite_code):
    """学员注册。成功返回 (True, user_dict);失败返回 (False, 错误信息)。"""
    name = (name or '').strip()
    department = (department or '').strip()
    username = (username or '').strip()
    password = password or ''
    invite_code = (invite_code or '').strip()
    if not name:
        return False, "请填写姓名", None
    if not department:
        return False, "请填写部门", None
    if not username:
        return False, "请填写用户名", None
    if len(password) < 6:
        return False, "密码至少 6 位", None
    real_code = db.get_setting('invite_code', 'CS2026')
    if invite_code != real_code:
        return False, "邀请码不正确,请向管理员索取", None
    if get_user_by_username(username) is not None:
        return False, "该用户名已被注册", None
    conn = db.get_conn()
    with db.DB_LOCK:
        cur = conn.execute(
            "INSERT INTO users(username, password_hash, name, department, role, status, created_at)"
            " VALUES(?, ?, ?, ?, 'student', '正常', ?)",
            (username, hash_pw(password), name, department, now_iso()))
        conn.commit()
        row = conn.execute("SELECT * FROM users WHERE id=?", (cur.lastrowid,)).fetchone()
    return True, "注册成功,请登录", public_user(row)


def change_password(user_id, old_pw, new_pw, confirm_pw):
    if len(new_pw or '') < 6:
        return False, "新密码至少 6 位"
    if new_pw != confirm_pw:
        return False, "两次输入的新密码不一致"
    row = get_user_by_id(user_id)
    if row is None:
        return False, "用户不存在"
    if not check_pw(old_pw or '', row['password_hash']):
        return False, "当前密码不正确"
    conn = db.get_conn()
    with db.DB_LOCK:
        conn.execute("UPDATE users SET password_hash=? WHERE id=?",
                     (hash_pw(new_pw), user_id))
        conn.commit()
    return True, "密码修改成功,下次登录请使用新密码"


def require_role(user, roles):
    """user 为 public_user dict 或 row;roles 为角色名元组。"""
    if user is None:
        return False
    role = user.get('role') if isinstance(user, dict) else user['role']
    return role in roles
