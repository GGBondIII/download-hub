# -*- coding: utf-8 -*-
"""常熟站智考通 v2.1 — 管理员:用户管理(批量导入/新增/编辑/停用/删除/重置密码)、
统计分析、版本发布记录、邀请码管理。
Python 3.4 兼容语法。
"""
import db
import auth


def list_users(keyword='', department='', role='', page=1, page_size=20):
    conn = db.get_conn()
    conds = []
    params = []
    if keyword:
        conds.append("(username LIKE ? OR name LIKE ?)")
        kw = '%' + keyword + '%'
        params += [kw, kw]
    if department:
        conds.append("department=?")
        params.append(department)
    if role:
        conds.append("role=?")
        params.append(role)
    where = ('WHERE ' + ' AND '.join(conds)) if conds else ''
    with db.DB_LOCK:
        total = conn.execute("SELECT COUNT(*) FROM users " + where, params).fetchone()[0]
        rows = conn.execute(
            "SELECT * FROM users " + where + " ORDER BY id LIMIT ? OFFSET ?",
            params + [page_size, (page - 1) * page_size]).fetchall()
        depts = conn.execute(
            "SELECT DISTINCT department FROM users WHERE department<>'' ORDER BY department").fetchall()
    return total, [auth.public_user(r) for r in rows], [r[0] for r in depts]


def list_students():
    """考试名单用:返回在用学员(id/username/name/department)。

    供考官建考试时取名单(GET /api/users/students,角色 admin,examiner)。
    停用账号不返回;只给建考试必需的四个字段,不含密码哈希等敏感字段。
    """
    conn = db.get_conn()
    with db.DB_LOCK:
        rows = conn.execute(
            "SELECT id, username, name, department FROM users "
            "WHERE role='student' AND status='正常' "
            "ORDER BY department, id").fetchall()
    return [{'id': r[0], 'username': r[1], 'name': r[2],
             'department': r[3]} for r in rows]


def create_user(data):
    username = (data.get('username') or '').strip()
    name = (data.get('name') or '').strip()
    password = data.get('password') or ''
    role = data.get('role') or 'student'
    if not username:
        return None, "请填写用户名"
    if not name:
        return None, "姓名不能为空"
    if len(password) < 6:
        return None, "密码至少 6 位"
    if role not in auth.ROLES:
        return None, "角色不合法"
    if auth.get_user_by_username(username) is not None:
        return None, "该用户名已存在"
    conn = db.get_conn()
    with db.DB_LOCK:
        cur = conn.execute(
            "INSERT INTO users(username, password_hash, name, department, role, status, created_at)"
            " VALUES(?, ?, ?, ?, ?, '正常', datetime('now', 'localtime'))",
            (username, auth.hash_pw(password), name, (data.get('department') or '').strip(), role))
        conn.commit()
        row = conn.execute("SELECT * FROM users WHERE id=?", (cur.lastrowid,)).fetchone()
    return auth.public_user(row), ""


def update_user(user_id, data):
    row = auth.get_user_by_id(user_id)
    if row is None:
        return None, "用户不存在"
    name = (data.get('name') or '').strip()
    if 'name' in data and not name:
        return None, "姓名不能为空"
    password = data.get('password') or ''
    if password and len(password) < 6:
        return None, "密码至少 6 位"
    role = data.get('role') or row['role']
    if role not in auth.ROLES:
        return None, "角色不合法"
    conn = db.get_conn()
    with db.DB_LOCK:
        conn.execute(
            "UPDATE users SET name=?, department=?, role=? WHERE id=?",
            (name if 'name' in data else row['name'],
             (data.get('department') or '').strip() if 'department' in data else row['department'],
             role, user_id))
        if password:
            conn.execute("UPDATE users SET password_hash=? WHERE id=?",
                         (auth.hash_pw(password), user_id))
        conn.commit()
        row = conn.execute("SELECT * FROM users WHERE id=?", (user_id,)).fetchone()
    return auth.public_user(row), ""


def set_user_status(user_id, status):
    if status not in ('正常', '停用'):
        return False, "状态只能是 正常/停用"
    conn = db.get_conn()
    with db.DB_LOCK:
        cur = conn.execute("UPDATE users SET status=? WHERE id=?", (status, user_id))
        conn.commit()
    if cur.rowcount == 0:
        return False, "用户不存在"
    return True, ""


def reset_password(user_id, new_password):
    if len(new_password or '') < 6:
        return False, "密码至少 6 位"
    conn = db.get_conn()
    with db.DB_LOCK:
        cur = conn.execute("UPDATE users SET password_hash=? WHERE id=?",
                           (auth.hash_pw(new_password), user_id))
        conn.commit()
    if cur.rowcount == 0:
        return False, "用户不存在"
    return True, ""


def delete_users(ids, operator_id):
    """删除用户,其考试记录一并删除,不可恢复。不能删自己。"""
    conn = db.get_conn()
    deleted = 0
    with db.DB_LOCK:
        for uid in ids:
            if uid == operator_id:
                continue
            conn.execute("DELETE FROM exam_attempts WHERE user_id=?", (uid,))
            conn.execute("DELETE FROM exam_members WHERE user_id=?", (uid,))
            conn.execute("DELETE FROM mock_attempts WHERE user_id=?", (uid,))
            conn.execute("DELETE FROM practice_records WHERE user_id=?", (uid,))
            conn.execute("DELETE FROM wrong_book WHERE user_id=?", (uid,))
            conn.execute("DELETE FROM reports WHERE user_id=?", (uid,))
            cur = conn.execute("DELETE FROM users WHERE id=?", (uid,))
            deleted += cur.rowcount
        conn.commit()
    return deleted


def get_stats():
    conn = db.get_conn()
    with db.DB_LOCK:
        students = conn.execute("SELECT COUNT(*) FROM users WHERE role='student'").fetchone()[0]
        users_total = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        practice_total = conn.execute("SELECT COUNT(*) FROM practice_records").fetchone()[0]
        practice_ok = conn.execute("SELECT COUNT(*) FROM practice_records WHERE correct=1").fetchone()[0]
        pending_reports = conn.execute("SELECT COUNT(*) FROM reports WHERE status='待处理'").fetchone()[0]
        q_total = conn.execute("SELECT COUNT(*) FROM questions").fetchone()[0]
        q_by_type = conn.execute(
            "SELECT type, COUNT(*) FROM questions GROUP BY type").fetchall()
        q_by_cat = conn.execute(
            "SELECT category, COUNT(*) FROM questions GROUP BY category").fetchall()
        dept = conn.execute(
            "SELECT department, COUNT(*) FROM users WHERE role='student' GROUP BY department").fetchall()
        exams = conn.execute(
            "SELECT e.id, e.name, COUNT(a.id) AS n, AVG(a.score) AS avg_score"
            " FROM exams e LEFT JOIN exam_attempts a"
            " ON a.exam_id=e.id AND a.status IN ('已交卷', '迟交')"
            " GROUP BY e.id ORDER BY e.id DESC LIMIT 5").fetchall()
    return {
        'student_count': students,
        'user_count': users_total,
        'practice_total': practice_total,
        'accuracy': round(100.0 * practice_ok / practice_total, 1) if practice_total else 0,
        'pending_reports': pending_reports,
        'question_count': q_total,
        'questions_by_type': [{'type': t, 'count': n} for t, n in q_by_type],
        'questions_by_category': [{'category': c, 'count': n} for c, n in q_by_cat],
        'students_by_department': [{'department': d, 'count': n} for d, n in dept],
        'recent_exams': [{'exam_id': e[0], 'name': e[1], 'submitted': e[2],
                          'average': round(e[3], 1) if e[3] is not None else 0}
                         for e in exams],
    }


# ---------------- 版本发布 ----------------

def list_versions():
    conn = db.get_conn()
    with db.DB_LOCK:
        rows = conn.execute("SELECT * FROM versions ORDER BY id DESC").fetchall()
    return [db.row_to_dict(r) for r in rows]


def latest_version(platform):
    conn = db.get_conn()
    with db.DB_LOCK:
        row = conn.execute(
            "SELECT * FROM versions WHERE platform=? AND status='生效中' ORDER BY id DESC LIMIT 1",
            (platform,)).fetchone()
    return db.row_to_dict(row)


def create_version(data):
    platform = (data.get('platform') or '').strip()
    version = (data.get('version') or '').strip()
    if not platform or not version:
        return None, "目标平台和版本号不能为空"
    conn = db.get_conn()
    with db.DB_LOCK:
        # 同一平台一次只保留一个生效版本:新版本生效,旧的自动下架
        conn.execute("UPDATE versions SET status='已下架' WHERE platform=? AND status='生效中'",
                     (platform,))
        cur = conn.execute(
            "INSERT INTO versions(platform, version, note, filename, status, created_at)"
            " VALUES(?, ?, ?, ?, '生效中', datetime('now', 'localtime'))",
            (platform, version, data.get('note') or '', data.get('filename') or ''))
        conn.commit()
        row = conn.execute("SELECT * FROM versions WHERE id=?", (cur.lastrowid,)).fetchone()
    return db.row_to_dict(row), ""


def set_version_status(version_id, status):
    if status not in ('生效中', '已下架'):
        return False, "状态只能是 生效中/已下架"
    conn = db.get_conn()
    with db.DB_LOCK:
        row = conn.execute("SELECT * FROM versions WHERE id=?", (version_id,)).fetchone()
        if row is None:
            return False, "版本不存在"
        if status == '生效中':
            conn.execute("UPDATE versions SET status='已下架' WHERE platform=? AND status='生效中'",
                         (row['platform'],))
        conn.execute("UPDATE versions SET status=? WHERE id=?", (status, version_id))
        conn.commit()
    return True, ""


def delete_version(version_id):
    conn = db.get_conn()
    with db.DB_LOCK:
        row = conn.execute("SELECT * FROM versions WHERE id=?", (version_id,)).fetchone()
        if row is None:
            return False, "版本不存在"
        if row['status'] == '生效中':
            return False, "生效中的版本需先下架才能删除"
        conn.execute("DELETE FROM versions WHERE id=?", (version_id,))
        conn.commit()
    return True, ""
