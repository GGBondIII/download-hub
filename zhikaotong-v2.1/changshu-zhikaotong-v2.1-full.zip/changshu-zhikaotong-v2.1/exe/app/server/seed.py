# -*- coding: utf-8 -*-
"""常熟站智考通 v2.1 — 播种:20 道常熟边检通用样题 + 演示用户 + 2 场考试。

单选 8 / 多选 4 / 判断 4 / 填空 2 / 简答 2。
内容为边检通用业务知识(出入境证件查验、边防检查职责、口岸限定区域管理、
勤务规范等),不含原站地名。
演示用户密码均为 123456,上线前必改。
Python 3.4 兼容语法。
"""
import json

import auth
import db

DEMO_USERS = [
    # username, name, department, role
    ("admin", "管理员", "站机关", "admin"),
    ("jiaoguan", "教官", "执勤一队", "examiner"),
    ("minjing", "民警甲", "执勤一队", "student"),
    ("minjing2", "民警乙", "执勤二队", "student"),
]

# (no, type, category, stem, options, answer, analysis, difficulty)
SEED_QUESTIONS = [
    ("ZK001", "单选", "证件查验",
     "执勤中发现旅客所持证件疑似伪造,第一步最恰当的做法是?",
     {"A": "直接放行,避免耽误时间", "B": "先稳住旅客,按程序核查并报告带班领导",
      "C": "当场没收证件并让旅客离开", "D": "自行判断真伪后放行"},
     "B", "疑似伪造证件应按程序核查、报告,不可凭个人判断放行或没收了事。证件查验要先核对版式、照片与个人信息,再借助设备辅助核查。", 2),
    ("ZK002", "单选", "证件查验",
     "边防检查执勤人员在查验时,应当做到以下哪一点?",
     {"A": "只查证件,不核对持证人", "B": "证件、人、行程信息相互核对",
      "C": "只看证件有效期", "D": "旅客自述即可,不必核查"},
     "B", "人证对照是基本要求,证件、持证人、行程信息要相互核对,三者一致才能放行。", 1),
    ("ZK003", "单选", "口岸勤务",
     "旅客出境时,边检执勤的常规顺序一般是?",
     {"A": "先放行再查验", "B": "查验、核对无误后放行",
      "C": "只登记不查验", "D": "由旅客自行决定顺序"},
     "B", "先查验核对,无误后再放行,这是常规执勤顺序。查验包括证件查验、人证对照和必要的询问。", 1),
    ("ZK004", "单选", "口岸勤务",
     "发现口岸现场出现旅客大量滞留时,执勤人员首先应?",
     {"A": "继续按原节奏查验,不作处理", "B": "立即报告,配合增开通道、疏导秩序",
      "C": "让旅客自行离开现场", "D": "关闭所有通道"},
     "B", "大客流滞留要立即报告、配合疏导增援,不能放任不管。执勤人员应当服从指挥,协同配合疏导。", 4),
    ("ZK005", "单选", "基础法规",
     "出入境管理的基本原则之一是?",
     {"A": "只管理出境,不管入境", "B": "维护国家主权、安全和社会秩序,保障合法权益",
      "C": "只针对外国人", "D": "不设任何查验程序"},
     "B", "出入境管理兼顾国家安全与合法权益保护,出入境都要管理。维护国家主权、安全和社会秩序是首要原则。", 2),
    ("ZK006", "单选", "证件查验",
     "查验中发现旅客为未成年人单独出行,执勤人员应当?",
     {"A": "直接放行", "B": "按程序核查监护、行程等情况,必要时报告",
      "C": "不予理会", "D": "让其自行联系他人后离开"},
     "B", "未成年人单独出行要按程序核查监护、行程等情况,必要时报告处理,不得擅自放行。", 3),
    ("ZK007", "单选", "口岸勤务",
     "执勤交接班时,应当交接清楚的内容不包括?",
     {"A": "在查旅客、待办事项", "B": "设备、证件、物品情况",
      "C": "个人私事", "D": "值班记录与注意事项"},
     "C", "交接班要交清工作事项,包括在查旅客、待办事项、设备物品和值班记录,个人私事不在交接范围内。", 1),
    ("ZK008", "单选", "证件查验",
     "旅客携带的证件过期,执勤人员应当?",
     {"A": "直接放行", "B": "按规定告知并作相应处理,不放行过期证件",
      "C": "自行帮旅客延期", "D": "不予理会"},
     "B", "证件过期不能作为有效证件放行,要按规定告知并作相应处理。证件有效期是查验的基本要素。", 2),
    ("ZK009", "多选", "口岸勤务",
     "下列哪些属于口岸查控中需要重点留意的情形?(多选)",
     {"A": "证件信息与持证人明显不符", "B": "旅客行程、事由含糊不清",
      "C": "证件有涂改、破损痕迹", "D": "旅客主动配合、证件齐全"},
     "ABC", "A、B、C 都是需要重点留意的异常情形;D 为正常情形。口岸查控要留意证件、行程与持证人之间的不一致。", 3),
    ("ZK010", "多选", "证件查验",
     "证件真伪鉴别常用的方法包括?(多选)",
     {"A": "观察版式、印刷与防伪特征", "B": "核对照片与持证人",
      "C": "借助查验设备辅助核查", "D": "仅凭手感判断"},
     "ABC", "版式观察、人证核对、设备辅助是常用方法;仅凭手感不可靠。真伪鉴别要多种方法相互印证。", 2),
    ("ZK011", "多选", "执勤规范",
     "执勤记录应当做到哪些?(多选)",
     {"A": "记录真实、完整", "B": "及时归档保存",
      "C": "可随意涂改、无需核对", "D": "按规定留存备查"},
     "ABD", "执勤记录要真实完整、及时归档、按规定留存,不可随意涂改。记录是执勤工作的重要凭证。", 2),
    ("ZK012", "多选", "口岸勤务",
     "应急处突中,执勤人员应当做到?(多选)",
     {"A": "服从指挥、协同配合", "B": "保持冷静、按预案处置",
      "C": "擅自离岗、自行其是", "D": "及时报告现场情况"},
     "ABD", "服从指挥、按预案处置、及时报告是基本要求;擅自离岗不可。应急处突首先要报告并配合救助、维持秩序。", 4),
    ("ZK013", "判断", "执勤规范",
     "执勤中遇到旅客对查验有疑问,执勤人员应当耐心解释、按规定处理。",
     {"A": "对", "B": "错"},
     "对", "文明执勤、耐心解释是执勤规范的要求。执勤用语要文明规范、清晰简洁。", 1),
    ("ZK014", "判断", "执勤规范",
     "边检执勤人员可以在执勤中随意向无关人员透露旅客信息。",
     {"A": "对", "B": "错"},
     "错", "旅客信息要保密,不得随意向无关人员透露。执勤人员应当遵守保密规定,保护旅客个人信息。", 1),
    ("ZK015", "判断", "口岸勤务",
     "口岸执勤中,执勤人员发现可疑人员或物品,应当按规定报告并配合处置,不得擅自放行。",
     {"A": "对", "B": "错"},
     "对", "可疑情形要报告、配合处置,不能擅自放行。发现可疑人员或物品,第一步是按程序报告。", 2),
    ("ZK016", "判断", "执勤规范",
     "阶段考核的成绩应当与日常练习成绩分开归档,练习错题不直接计入考核。",
     {"A": "对", "B": "错"},
     "对", "本系统练习与考核分开,练习是练手,考核单独归档。练习错题自动收入错题本复习,不计入考核成绩。", 1),
    ("ZK017", "填空", "证件查验",
     "边防检查执勤中,查验证件的核心要求是做到____、____、行程信息相互核对。",
     {}, "证件、持证人", "人证对照是基本要求:证件、持证人、行程信息要相互核对,三者一致才能放行。", 3),
    ("ZK018", "填空", "口岸勤务",
     "口岸限定区域实行____管理,未经许可的人员不得进入。",
     {}, "封闭", "口岸限定区域实行封闭管理,执勤人员应当对限定区域实施巡查、管控,未经许可的人员不得进入。", 2),
    ("ZK019", "简答", "口岸勤务",
     "简述执勤中发现旅客大量滞留时的处置流程。",
     {}, "立即报告带班领导,配合增开查验通道,引导分流、疏导秩序,留意异常人员,做好现场记录。",
     "处置流程:一是立即报告,二是配合增开通道,三是引导分流疏导秩序,四是留意异常、做好记录。", 5),
    ("ZK020", "简答", "证件查验",
     "简述人证对照的基本内容。",
     {}, "核对证件版式、照片与持证人是否一致,核对姓名、证件号码、有效期等个人信息,核对行程事由是否合理,发现不符按程序核查报告。",
     "人证对照包括:证件与持证人相貌核对、个人信息核对、行程事由核对,发现不符要按程序核查并报告。", 3),
]


def seed_all():
    """首次启动调用:用户不存在才播种,已播种过不再重复。"""
    conn = db.get_conn()
    with db.DB_LOCK:
        n_users = conn.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        if n_users == 0:
            for username, name, dept, role in DEMO_USERS:
                conn.execute(
                    "INSERT INTO users(username, password_hash, name, department, role, status, created_at)"
                    " VALUES(?, ?, ?, ?, ?, '正常', ?)",
                    (username, auth.hash_pw("123456"), name, dept, role, auth.now_iso()))
        n_q = conn.execute("SELECT COUNT(*) FROM questions").fetchone()[0]
        if n_q == 0:
            for no, qtype, cat, stem, opts, ans, ana, diff in SEED_QUESTIONS:
                conn.execute(
                    "INSERT INTO questions(no, type, category, stem, options, answer, analysis, image, status, created_at, difficulty, source)"
                    " VALUES(?, ?, ?, ?, ?, ?, ?, '', '启用', ?, ?, '系统样题')",
                    (no, qtype, cat, stem, json.dumps(opts, ensure_ascii=False),
                     ans, ana, auth.now_iso(), diff))
        # 初始题库版本 v2.1.0:样题全部挂进当前版本
        n_ver = conn.execute("SELECT COUNT(*) FROM bank_versions").fetchone()[0]
        if n_ver == 0:
            cur = conn.execute(
                "INSERT INTO bank_versions(version_no, note, question_count,"
                " is_current, created_by, created_at)"
                " VALUES('v2.1.0', '初始样题版本(20 道)', 20, 1, 'admin', ?)",
                (auth.now_iso(),))
            vid = cur.lastrowid
            for r in conn.execute("SELECT id FROM questions").fetchall():
                conn.execute(
                    "INSERT OR IGNORE INTO bank_version_items(version_id, question_id)"
                    " VALUES(?, ?)", (vid, r[0]))
                conn.execute(
                    "UPDATE questions SET version_id=? WHERE id=?", (vid, r[0]))
        conn.commit()
        n_exams = conn.execute("SELECT COUNT(*) FROM exams").fetchone()[0]
        if n_exams == 0:
            admin = conn.execute("SELECT id FROM users WHERE username='admin'").fetchone()
            admin_id = admin[0] if admin else 0
            # 已发布正式考试:固定试卷 10 道题(ZK001-ZK010),名单含 minjing/minjing2
            qids = [r[0] for r in conn.execute(
                "SELECT id FROM questions WHERE no IN"
                " ('ZK001','ZK002','ZK003','ZK004','ZK005','ZK006','ZK007','ZK008','ZK009','ZK010')"
                " ORDER BY no").fetchall()]
            qcounts = {"单选": 8, "多选": 2, "判断": 0, "填空": 0, "简答": 0}
            qscores = {"单选": 5, "多选": 10, "判断": 5, "填空": 5, "简答": 10}
            cur = conn.execute(
                "INSERT INTO exams(name, subject, duration_min, shuffle, mode, qcounts, qscores,"
                " start_at, end_at, status, fixed_paper, created_by, created_at)"
                " VALUES(?, ?, 60, 0, 'fixed', ?, ?, '', '', '已发布', ?, ?, ?)",
                ("常熟站 2026 年第一季度业务考核", "基础法规",
                 json.dumps(qcounts, ensure_ascii=False),
                 json.dumps(qscores, ensure_ascii=False),
                 json.dumps(qids), admin_id, auth.now_iso()))
            exam_id = cur.lastrowid
            for uname in ("minjing", "minjing2"):
                u = conn.execute("SELECT id FROM users WHERE username=?", (uname,)).fetchone()
                if u:
                    conn.execute("INSERT OR IGNORE INTO exam_members(exam_id, user_id) VALUES(?, ?)",
                                 (exam_id, u[0]))
            # 草稿考试
            conn.execute(
                "INSERT INTO exams(name, subject, duration_min, shuffle, mode, qcounts, qscores,"
                " start_at, end_at, status, fixed_paper, created_by, created_at)"
                " VALUES(?, ?, 45, 1, 'random', ?, ?, '', '', '草稿', '', ?, ?)",
                ("执勤规范专项测试(草稿)", "执勤规范",
                 json.dumps({"单选": 5, "多选": 2, "判断": 3, "填空": 0, "简答": 0}, ensure_ascii=False),
                 json.dumps(qscores, ensure_ascii=False),
                 admin_id, auth.now_iso()))
        conn.commit()
