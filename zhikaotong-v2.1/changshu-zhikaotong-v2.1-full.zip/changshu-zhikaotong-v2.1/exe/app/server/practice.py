# -*- coding: utf-8 -*-
"""常熟站智考通 v2.1 — 日常练习:顺序/随机/错题/题型四种模式。

逐题判分,答错自动入错题本并返回智能分析;做对一题自动移出错题本。
断点续刷:客户端记住上次刷到的题号下标,下次从该下标继续(服务端无状态,
题单由 build_list 的确定性规则生成,随机模式用 seed 固定顺序)。
Python 3.4 兼容语法。
"""
import json
import random

import auth
import db
import questions as qmod
import smart_analysis
from adaptive import record_attempt

MODES = ('顺序', '随机', '错题', '题型')


def build_list(user_id, mode, category='', qtype='', count=0, seed=0):
    """返回题目 id 列表(不含答案)。随机模式用 seed 固定打乱顺序,便于断点续刷。"""
    conn = db.get_conn()
    with db.DB_LOCK:
        if mode == '错题':
            rows = conn.execute(
                "SELECT question_id FROM wrong_book WHERE user_id=? ORDER BY added_at",
                (user_id,)).fetchall()
            ids = [r[0] for r in rows]
            rows = conn.execute(
                "SELECT id FROM questions WHERE id IN (SELECT question_id FROM wrong_book WHERE user_id=?)"
                " AND status='启用'", (user_id,)).fetchall()
            enabled = set([r[0] for r in rows])
            ids = [i for i in ids if i in enabled]
            return ids
        sql = "SELECT id FROM questions WHERE status='启用'"
        params = []
        if category:
            sql += " AND category=?"
            params.append(category)
        if qtype:
            sql += " AND type=?"
            params.append(qtype)
        sql += " ORDER BY no, id"
        rows = conn.execute(sql, params).fetchall()
        ids = [r[0] for r in rows]
    if mode == '随机' or (mode == '题型' and seed):
        rng = random.Random(seed or 12345)
        rng.shuffle(ids)
    if count and count > 0:
        ids = ids[:count]
    return ids


def get_questions_for_list(ids):
    out = []
    for qid in ids:
        row = qmod.get_question(qid)
        if row is not None:
            out.append(qmod.question_to_dict(row, include_answer=False))
    return out


def answer_question(user_id, question_id, mode, user_answer, self_correct=None):
    """判分并记录。返回结果 dict(含 correct/正确答案/解析/智能分析/是否在错题本)。"""
    row = qmod.get_question(question_id)
    if row is None:
        return None, "题目不存在"
    q = qmod.question_to_dict(row)
    correct, auto = qmod.grade_answer(q['type'], user_answer, q['answer'],
                                      self_correct=self_correct)
    if correct is None:
        # 简答未自评:先记录作答,不判分
        correct_flag = 0
    else:
        correct_flag = 1 if correct else 0
    conn = db.get_conn()
    with db.DB_LOCK:
        conn.execute(
            "INSERT INTO practice_records(user_id, question_id, mode, user_answer, correct, answered_at)"
            " VALUES(?, ?, ?, ?, ?, datetime('now', 'localtime'))",
            (user_id, question_id, mode, user_answer or '', correct_flag))
        conn.commit()
    # v2:顺带写 attempts 表 + FSRS 调度 + 掌握度 + 质量分 + 错题本(错题计数)
    # 简答未自评时进人工批阅队列(不自动判分)
    if q['type'] == '简答' and correct is None:
        import essay as essay_mod
        essay_mod.submit_essay(user_id, question_id, user_answer or '')
    elif correct is not None:
        record_attempt(user_id, question_id, mode, user_answer or '', correct)
    with db.DB_LOCK:
        if correct is True:
            in_wrong = False
        elif correct is False:
            in_wrong = True
        else:
            r = conn.execute("SELECT 1 FROM wrong_book WHERE user_id=? AND question_id=?",
                             (user_id, question_id)).fetchone()
            in_wrong = r is not None
    result = {
        'question_id': question_id,
        'correct': correct,
        'auto_graded': auto,
        'correct_answer': q['answer'],
        'analysis': q.get('analysis') or '',
        'in_wrong_book': in_wrong,
        'mode': mode,
    }
    if correct is False:
        ana = smart_analysis.analyze(q['type'], q['stem'], user_answer or '',
                                     q['answer'], q.get('analysis') or '',
                                     q.get('options') or {})
        result['smart_analysis'] = ana
        result['smart_analysis_text'] = smart_analysis.format_text(ana)
    return result, ""


def get_stats(user_id):
    conn = db.get_conn()
    with db.DB_LOCK:
        total = conn.execute("SELECT COUNT(*) FROM practice_records WHERE user_id=?",
                             (user_id,)).fetchone()[0]
        ok = conn.execute("SELECT COUNT(*) FROM practice_records WHERE user_id=? AND correct=1",
                          (user_id,)).fetchone()[0]
        wrong_n = conn.execute("SELECT COUNT(*) FROM wrong_book WHERE user_id=?",
                               (user_id,)).fetchone()[0]
        by_type = conn.execute(
            "SELECT q.type, COUNT(*), SUM(pr.correct) FROM practice_records pr"
            " JOIN questions q ON q.id=pr.question_id"
            " WHERE pr.user_id=? GROUP BY q.type", (user_id,)).fetchall()
        trend = conn.execute(
            "SELECT substr(answered_at, 1, 10) AS d, COUNT(*), SUM(correct)"
            " FROM practice_records WHERE user_id=? GROUP BY d ORDER BY d DESC LIMIT 14",
            (user_id,)).fetchall()
    per_type = []
    for t, n, c in by_type:
        per_type.append({'type': t, 'total': n, 'correct': c or 0,
                         'accuracy': round(100.0 * (c or 0) / n, 1) if n else 0})
    trend_list = [{'date': d, 'total': n, 'correct': c or 0}
                   for d, n, c in reversed(trend)]
    return {
        'total': total, 'correct': ok,
        'accuracy': round(100.0 * ok / total, 1) if total else 0,
        'wrong_count': wrong_n,
        'by_type': per_type,
        'trend': trend_list,
    }


def wrong_book_list(user_id):
    conn = db.get_conn()
    with db.DB_LOCK:
        rows = conn.execute(
            "SELECT q.* FROM wrong_book w JOIN questions q ON q.id=w.question_id"
            " WHERE w.user_id=? ORDER BY w.added_at", (user_id,)).fetchall()
    out = []
    for r in rows:
        q = qmod.question_to_dict(r)
        ana = smart_analysis.analyze(q['type'], q['stem'], '', q['answer'],
                                     q.get('analysis') or '', q.get('options') or {})
        q['smart_analysis'] = ana
        q['smart_analysis_text'] = smart_analysis.format_text(ana)
        out.append(q)
    return out


def wrong_book_remove(user_id, question_id):
    conn = db.get_conn()
    with db.DB_LOCK:
        cur = conn.execute("DELETE FROM wrong_book WHERE user_id=? AND question_id=?",
                           (user_id, question_id))
        conn.commit()
    return cur.rowcount > 0
