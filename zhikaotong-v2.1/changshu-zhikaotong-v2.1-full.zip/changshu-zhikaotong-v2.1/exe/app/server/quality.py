# -*- coding: utf-8 -*-
"""常熟站智考通 v2.1 — 题库质量闭环:按 attempts 重算质量分、疑似错题、停用/恢复。

照抄刷题宝 v0.7 server.py 239–252 行的逻辑。
质量分统计 attempts(mode practice/exam);≥5 题且正确率<20% 标 suspect_low,
>95% 标 suspect_high。Python 3.4 兼容语法。
"""
import db
import questions as qmod


def refresh_quality_for(conn, qid):
    r = conn.execute(
        "SELECT COUNT(*) n, COALESCE(SUM(is_correct), 0) c FROM attempts"
        " WHERE question_id=? AND mode IN ('practice', 'exam')",
        (qid,)).fetchone()
    total, correct = r[0], r[1]
    acc = round(correct / total, 3) if total else 0
    flag = 'normal'
    if total >= 5 and acc < 0.20:
        flag = 'suspect_low'
    elif total >= 5 and acc > 0.95:
        flag = 'suspect_high'
    import auth
    conn.execute(
        "INSERT OR REPLACE INTO quality_scores(question_id, total, correct, accuracy,"
        " flag, updated_at) VALUES(?, ?, ?, ?, ?, ?)",
        (qid, total, correct, acc, flag, auth.now_iso()))
    return {'question_id': qid, 'total': total, 'correct': correct,
            'accuracy': acc, 'flag': flag}


def suspect_qids(conn):
    return set([r[0] for r in conn.execute(
        "SELECT question_id FROM quality_scores WHERE flag!='normal'").fetchall()])


def refresh_all():
    conn = db.get_conn()
    with db.DB_LOCK:
        ids = [r[0] for r in conn.execute("SELECT id FROM questions").fetchall()]
        out = [refresh_quality_for(conn, qid) for qid in ids]
        conn.commit()
    return out


def quality_list():
    conn = db.get_conn()
    with db.DB_LOCK:
        rows = conn.execute(
            "SELECT qs.*, q.stem, q.category FROM quality_scores qs"
            " JOIN questions q ON q.id=qs.question_id"
            " ORDER BY qs.accuracy ASC").fetchall()
    out = []
    for r in rows:
        d = db.row_to_dict(r)
        out.append(d)
    return out


def set_question_status(qid, status):
    """题目停用/恢复(与质量闭环联动):状态只能是 启用/停用。"""
    if status not in ('启用', '停用'):
        return False, "状态只能是 启用/停用"
    conn = db.get_conn()
    with db.DB_LOCK:
        cur = conn.execute("UPDATE questions SET status=? WHERE id=?", (status, qid))
        conn.commit()
    if cur.rowcount == 0:
        return False, "题目不存在"
    return True, ""
