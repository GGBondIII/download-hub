# 常熟站智考通 v2.1（网页版）

## 启动步骤

1. 确认已安装 Python 3.4 或以上版本（`python --version`）。
2. Windows：双击 `start.bat`；Linux/macOS：`sh start.sh`。
3. 首次启动自动在 `data/` 目录下建立数据库（演示数据：4 个用户、20 道题、2 场考试）。
4. 用浏览器打开 http://127.0.0.1:8766/ 。

没有 Python 时请先安装 Python 3.4+，或直接使用 exe 版（双击 `changshu-zhikaotong.exe`，自带运行时）。

## 端口

默认端口 **8766**，可用环境变量 `ZHIKAOTONG_PORT` 修改。

## 演示账号（密码均为 123456，上线前务必修改）

| 账号 | 角色 |
| --- | --- |
| admin | 管理员 |
| jiaoguan | 考官 |
| minjing | 民警 |
| minjing2 | 民警 |

## Lite 版（老浏览器 / XP）

访问 http://127.0.0.1:8766/lite ，界面更简洁，适合 IE8 等老浏览器。

## 局域网使用

局域网其他机器把地址栏的 `127.0.0.1` 换成主机 IP，例如 http://192.168.1.100:8766/ 。

## 数据

题库、用户、考试记录保存在 `data/` 目录（SQLite）。备份时整个 `data/` 目录一起复制。
