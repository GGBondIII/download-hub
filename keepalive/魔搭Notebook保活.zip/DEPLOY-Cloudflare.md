# Cloudflare 部署步骤 — Notebook 保活 Worker v0.2（2026-11-06）

## 前置
- Cloudflare 账号已注册（免费版，不绑卡）。如果还没注册，先在 dash.cloudflare.com 用锚点 Gmail 注册，邮箱验证通过后再往下做。
- 本地装 Node.js 18+ 和 Wrangler：`npm install -g wrangler`，然后 `wrangler login`。

## 部署（3 步）
1. 进 `~/workspace/魔搭Notebook保活/`，跑 `wrangler deploy`。成功后会给一个地址，形如 `https://notebook-keepalive.<你的子域名>.workers.dev`。
2. 在 Cloudflare 控制台 → Workers → notebook-keepalive → Settings → Variables，配三个环境变量：
   - `NOTIFY_EMAIL` = 19986734357@163.com
   - `RESEND_API_KEY` = Resend 免费版 API Key（去 resend.com 免费注册一个，不绑卡）
   - `FROM_EMAIL` = 发件地址（Resend 里验证过的域名，没验证就先用 `onboarding@resend.dev`，只能发给注册邮箱）
3. 验证：打开 `https://<你的地址>/health`，应返回 `{"ok":true,...}`；打开 `/start`，应看到手动启动页。

## 它到底能干什么（诚实版）
- 每 4 小时发一封提醒邮件，附 Notebook 启动链接。
- `/start` 是手动启动页，不是自动启动。
- 不能自动启动 Notebook：免费魔搭实例没有 PAI 编号，没有公开启动接口。
- 真正的点启动由用户电脑上的 WorkBuddy 定时任务 + `notebook_auto_start.py` 在做，这个 Worker 是备份提醒。

## 没配好 Resend 会怎样
- 不发邮件，只记日志，状态页和 `/start` 照常能用。
- 不会报错、不会假装发了。
