#!/bin/bash
# Notebook 里保活 + 9 小时 15 分提醒（放 /mnt/workspace/keepalive/ 里跑）
# 用法（在 Notebook 的 Terminal 里）：
#   cd /mnt/workspace && bash keepalive/keepalive.sh &
# 逻辑：
# - 启动时记启动时间到 /mnt/workspace/keepalive/state.json
# - 每 5 分钟写一次心跳，防 1 小时闲置关机（轻活动，不是刷鼠标）
# - 到 9 小时 15 分，调一次 Worker 的 /notify，让 Worker 发邮件
# - 文件和服务一律放 /mnt/workspace 里，之外的重开就清
set -e
BASE=/mnt/workspace/keepalive
mkdir -p "$BASE"
STATE="$BASE/state.json"
WORKER_URL="${WORKER_URL:-https://<你的worker>.workers.dev}"
START=$(date +%s)
echo "{\"started_at\": $START}" > "$STATE"
echo "started at $(date -d @$START)"
while true; do
  NOW=$(date +%s)
  ELAPSED=$((NOW - START))
  # 心跳：写时间戳 + 轻量 CPU 活动
  echo "{\"started_at\": $START, \"last_heartbeat\": $NOW, \"elapsed_sec\": $ELAPSED}" > "$STATE"
  # 9 小时 15 分 = 33300 秒，只提醒一次
  if [ "$ELAPSED" -ge 33300 ] && [ ! -f "$BASE/notified" ]; then
    echo "9h15m reached, notify worker"
    curl -s "$WORKER_URL/notify" || true
    touch "$BASE/notified"
  fi
  # 9 小时 45 分后主动收尾：同步文件，不再硬撑到被平台踢掉
  if [ "$ELAPSED" -ge 35100 ]; then
    echo "9h45m reached, sync and exit"
    sync || true
    break
  fi
  sleep 300
done
